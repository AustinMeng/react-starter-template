package com.scb.api.ccs.test.step;

import static org.awaitility.Awaitility.await;

import com.scb.channels.foundation.commons.camel.anole.AnoleEndpoint;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

@SuppressWarnings("unused")
public class OracleAQSteps {

    @Autowired
    private StepUtils stepUtils;

    @Autowired
    private CamelContext camelContext;

    @Autowired
    private ProducerTemplate producer;

    private final Map<String, AnoleEndpoint> endpoints = new HashMap<>();

    private final Map<String, String> records = new HashMap<>();

    private static final String PREFIX = "anole:ora:queue:";

    @Given("oracleAQ queue {word} is emptied")
    public void clearQueue(String queue) {
        AnoleEndpoint anoleEndpoint = this.getEndpoint(queue);
        anoleEndpoint.purgeQueue();
        this.resumeJms(queue);
    }

    @Then("oracleAQ queue {word} receives {int} message(s) in {int} second(s)")
    public void verifyQueue(String queue, int num, int seconds) {
        AnoleEndpoint anoleEndpoint = this.getEndpoint(queue);

        await().atMost(seconds, TimeUnit.SECONDS)
                .until(() -> anoleEndpoint.getIncrementalMessages().size() == num);
        anoleEndpoint.takeSnapshot();
    }

    @Then("oracleAQ queue {word} receives a message in {int} second(s) with details")
    public void verifyMessageDetails(String queue, int seconds, DataTable dataTable) {
        AnoleEndpoint anoleEndpoint = this.getEndpoint(queue);

        await().atMost(seconds, TimeUnit.SECONDS)
                .until(() -> anoleEndpoint.getIncrementalMessages().size() == 1);

        List<Exchange> messages = anoleEndpoint.takeSnapshot();
        List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);

        String message = (String) messages.get(messages.size() - 1).getIn()
                .getBody();

        stepUtils.verifyJsonDetails(message, details);
    }

    @Then("oracleAQ queue {word} receives a {word} message in {int} second(s) with details")
    public void verifyMessageDetails(String queue, String type, int seconds, DataTable dataTable) {
        AnoleEndpoint anoleEndpoint = this.getEndpoint(queue);

        await().atMost(seconds, TimeUnit.SECONDS)
                .until(() -> anoleEndpoint.getIncrementalMessages().size() == 1);

        List<Exchange> messages = anoleEndpoint.takeSnapshot();
        List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);

        String message = (String) messages.get(messages.size() - 1).getIn()
                .getBody();
        if ("xml".equalsIgnoreCase(type)) {
            stepUtils.verifyXmlDetails(message, details);
        } else if ("json".equalsIgnoreCase(type)) {
            stepUtils.verifyJsonDetails(message, details);
        } else {
            throw new RuntimeException("Message noun not supported!");
        }
    }

    @Then("oracleAQ queue {word} receives no message in {int} second(s)")
    public void verifyNoMessageToQueue(String queue, int seconds) {
        AnoleEndpoint anoleEndpoint = this.getEndpoint(queue);

        await().during(seconds, TimeUnit.SECONDS).until(() -> anoleEndpoint.getIncrementalMessages().size() == 0);
        anoleEndpoint.takeSnapshot();
    }

    @Given("oracleAQ queue {word} is down")
    public void suspendJms(String queue) {
        this.getEndpoint(queue).suspend();
    }

    @Given("oracleAQ queue {word} is up")
    public void resumeJms(String queue) {
        this.getEndpoint(queue).resume();
    }

    @When("a message {word} is received from oracleAQ queue {word}")
    public void publishOracleAQMessage(String file, String queue) {
        String json = stepUtils.loadContent(file);
        producer.sendBody(PREFIX + queue, json);
    }

    @When("a message {word} is received from oracleAQ queue {word} with details")
    public void publishOracleAQMessage(String file, String queue, DataTable dataTable) {
        List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);
        String json = stepUtils.loadContent(file);
        json = StringUtils.replaceIgnoreCase(json, "${rsnCd}", details.get(0).get("rsnCd"));
        producer.sendBody(PREFIX + queue, json);
    }

    private AnoleEndpoint getEndpoint(String queue) {
        return endpoints
                .computeIfAbsent(queue, q -> camelContext.getEndpoint(PREFIX + q, AnoleEndpoint.class));
    }
}

package com.scb.api.ccs.test.config;

import com.scb.api.ccs.test.step.StepUtils;
import com.scb.api.ccs.test.stub.CadmStub;
import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.channels.foundation.commons.cadm.impl.CadmClientImpl;
import java.net.UnknownHostException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

@SuppressWarnings("unused")
public class TestConfig {

    @Bean
    public StepUtils stepUtils() {
        return new StepUtils();
    }

    @Bean(name = "oracleJdbcTemplate")
    public JdbcTemplate oracleJdbcTemplate(@Qualifier("oracleDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "ccsAgentJdbcTemplate")
    public JdbcTemplate ccsAgentJdbcTemplate(@Qualifier("ccsAgentDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public CadmClient cadmClient() throws UnknownHostException {
        int port = CadmStub.of().start();
        String cadmBaseUrl = "https://localhost:" + port;
        return new CadmClientImpl(cadmBaseUrl);
    }
}

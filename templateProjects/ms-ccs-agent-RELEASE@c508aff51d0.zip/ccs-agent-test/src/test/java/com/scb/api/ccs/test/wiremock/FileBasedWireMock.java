package com.scb.api.ccs.test.wiremock;

import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.extension.responsetemplating.ResponseTemplateTransformer;
import com.github.tomakehurst.wiremock.http.HttpHeader;
import com.github.tomakehurst.wiremock.http.HttpHeaders;
import com.github.tomakehurst.wiremock.matching.AnythingPattern;
import com.github.tomakehurst.wiremock.matching.ContainsPattern;
import com.github.tomakehurst.wiremock.matching.ContentPattern;
import com.github.tomakehurst.wiremock.matching.EqualToJsonPattern;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.net.URI;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

@Slf4j
public class FileBasedWireMock implements TestRule {

    private WireMockServer wireMockServer;

    public enum Section {REQUEST, RESPONSE}

    @Override
    public Statement apply(Statement base, Description description) {
        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                base.evaluate();
            }
        };
    }

    private static List<String> verbs = Lists.newArrayList("GET", "POST", "PATCH", "PUT", "DELETE");

    public FileBasedWireMock(InputStream dataResource, Integer forcedPort, Map<String, String> properties) {
        try {
            initWireMock(dataResource, forcedPort, properties);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static FileBasedWireMock init(InputStream dataResource, Integer forcedPort, Map<String, String> properties) {
        return new FileBasedWireMock(dataResource, forcedPort, properties);
    }

    public int getHttpsPort() {
        return wireMockServer.httpsPort();
    }

    public int getHttpPort() {
        return wireMockServer.port();
    }

    private void initWireMock(InputStream dataResource, Integer forcedPort, Map<String, String> properties) throws IOException {

        WireMockConfiguration config = WireMockConfiguration.options().
                extensions(new ResponseTemplateTransformer(true, "sign", new SignHandlebarFunction()));

        if (forcedPort != null) {
            config.httpsPort(forcedPort);
        } else {
            config.dynamicHttpsPort();
        }

        wireMockServer = new WireMockServer(
                config.
                        dynamicPort().
                        dynamicHttpsPort().
//                needClientAuth(true).
        keystorePassword("password").
                        keystorePath(getKeyStorePath())); //No-args constructor will start on port 8080, no HTTPS
        startWireMockWithData(getStubData(dataResource, properties));

        wireMockServer.start();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> wireMockServer.shutdown()));
    }

    private String getKeyStorePath() throws IOException {
        File tmpFile = File.createTempFile("embedded", "jks");
        try (InputStream in = FileBasedWireMock.class.getClassLoader().getResourceAsStream("keystore/embedded.jks")) {
            try (OutputStream out = new FileOutputStream(tmpFile)) {
                IOUtils.copy(in, out);
            }
        }
        log.info("Loading keystore from resource file " + tmpFile.getAbsolutePath());
        return tmpFile.getAbsolutePath();
    }

    private void startWireMockWithData(Collection<StubData> content) {
        content.forEach(
                (sd) -> {
                    log.info("Stubbing method: " + sd.getMethod() + " with url " + sd.getPath() + ".. ");

                    String configuredRequestPattern = sd.getRequest();
                    ContentPattern contentPattern;
                    if(configuredRequestPattern.equals("*")) {
                        contentPattern = new AnythingPattern();
                    } else if(configuredRequestPattern.startsWith("Contains")) {
                        contentPattern = new ContainsPattern(configuredRequestPattern.split(":")[1]);
                    } else {
                        contentPattern = new EqualToJsonPattern(configuredRequestPattern, true, true);
                    }
                    if (sd.getMethod().equals("GET")) {
                        String path = getPath(sd.getPath());
                        Map<String, String> queryParam = getQueryParam(sd.getPath());
                        MappingBuilder mappingBuilder = WireMock.get(WireMock.urlPathEqualTo(path));
                        putQueryParam(mappingBuilder, queryParam);
                        wireMockServer.stubFor(mappingBuilder
                                .willReturn(WireMock.aResponse()
                                        .withHeaders(sd.getHttpHeaders())
                                        .withBody(sd.getResponse())));
                    }
                    if (sd.getMethod().equals("POST")) {
                        wireMockServer.stubFor(WireMock.post(WireMock.urlPathEqualTo(sd.getPath()))
                                .withRequestBody(contentPattern)
                                .willReturn(WireMock.aResponse()
                                        .withHeaders(sd.getHttpHeaders())
                                        .withBody(sd.getResponse())));
                    }
                    if (sd.getMethod().equals("PUT")) {
                        wireMockServer.stubFor(WireMock.put(WireMock.urlPathEqualTo(sd.getPath()))
                                .withRequestBody(contentPattern)
                                .willReturn(WireMock.aResponse()
                                        .withHeaders(sd.getHttpHeaders())
                                        .withBody(sd.getResponse())));
                    }
                    if (sd.getMethod().equals("PATCH")) {
                        wireMockServer.stubFor(WireMock.patch(WireMock.urlPathEqualTo(sd.getPath()))
                                .withRequestBody(contentPattern)
                                .willReturn(WireMock.aResponse()
                                        .withHeaders(sd.getHttpHeaders())
                                        .withBody(sd.getResponse())));
                    }
                }
        );

    }

    private static Collection<StubData> getStubData(InputStream dataResource, Map<String, String> properties) throws IOException {

        Collection<StubData> content = Lists.newArrayList();

        LineNumberReader reader = new LineNumberReader(new InputStreamReader(dataResource));
        String line;
        Section section;

        String request = null;
        String response = null;
        String method = null;
        String path = null;

        Map<String, String> headers = Maps.newHashMap();

        StringBuilder buffer = new StringBuilder();
        boolean startedContent = false;
        while ((line = reader.readLine()) != null) {
            if (startWithVerb(line)) {
                if (startedContent) {
                    response = buffer.toString();
                    content.add(new StubData(method, path, subTokens(request, properties), subTokens(response, properties), headers));
                    headers = Maps.newHashMap();
                }
                buffer.setLength(0);
                String[] parts = line.split(" ");
                method = parts[0];
                path = parts[1];
                startedContent = true;
            } else {
                if (startedContent) {
                    if (line.startsWith("--")) {
                        request = buffer.toString();
                        buffer.setLength(0);
                        continue;
                    }
                    if (line.startsWith("H ")) {
                        String headerPair = line.substring(2);
                        String[] pair = headerPair.split(":");
                        if (pair.length == 2) {
                            headers.put(pair[0], pair[1]);
                        }
                        continue;
                    }
                    buffer.append(line);
                }
            }
        }
        if (startedContent) {
            content.add(new StubData(method, path, subTokens(request, properties), subTokens(buffer.toString(), properties), headers));
        }

        return content;
    }

    private static String subTokens(String response, Map<String, String> properties) {
        for (String key : properties.keySet()) {
            String propertyValue = properties.get(key);
            if("RandomLong".equals(propertyValue)) {
                propertyValue = Long.toString(RandomUtils.nextLong());
            } else if("RandomInt".equals(propertyValue)) {
                propertyValue = Long.toString(RandomUtils.nextInt());
            }
            response = StringUtils.replace(response, "${" + key + "}", propertyValue);
        }
        return response;
    }

    private static boolean startWithVerb(String line) {
        return verbs.stream().anyMatch(line::startsWith);
    }

    private static class StubData {

        private String method;
        private String path;
        private Map<String, String> headers;
        private String request;
        private String response;

        public StubData(String method, String path, String request, String response, Map<String, String> headers) {
            this.method = method;
            this.path = path;
            this.request = request;
            this.response = response;
            this.headers = headers;
        }

        public String getMethod() {
            return method;
        }

        public String getPath() {
            return path;
        }

        public Map<String, String> getHeaders() {
            return headers;
        }

        public String getRequest() {
            return request;
        }

        public String getResponse() {
            return response;
        }

        public HttpHeaders getHttpHeaders() {
            return new HttpHeaders(
                    getHeaders().
                            entrySet().
                            stream().
                            map(e -> new HttpHeader(e.getKey(), e.getValue())).collect(Collectors.toList())
            );
        }
    }

    private Map<String, String> getQueryParam(String urlString) {
        Map<String, String> queryParamMap = new HashMap<>();

        String query = "";
        if (StringUtils.isEmpty(urlString) || StringUtils.isEmpty((query = URI.create(urlString).getQuery()))) {
            return queryParamMap;
        }
        String[] keyAndValues = query.split("&");
        Arrays.stream(keyAndValues).forEach(kv -> getQueryParam(kv, queryParamMap));
        return queryParamMap;
    }

    private void getQueryParam(String keyValue, Map<String, String> queryParam) {
        String[] kv = keyValue.split("=");
        queryParam.put(kv[0], kv[1]);
    }

    private String getPath(String path) {
        return StringUtils.contains(path, "?") ? URI.create(path).getPath() : path;
    }

    private void putQueryParam(MappingBuilder mappingBuilder, Map<String, String> queryParams) {
        if ((!Objects.isNull(mappingBuilder) && !Objects.isNull(queryParams) && !queryParams.isEmpty())) {
            queryParams.forEach((key, value) -> mappingBuilder.withQueryParam(key, equalTo(value)));
        }
    }
}

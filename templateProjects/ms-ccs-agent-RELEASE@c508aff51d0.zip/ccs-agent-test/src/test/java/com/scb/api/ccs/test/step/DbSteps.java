package com.scb.api.ccs.test.step;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Lists;
import com.google.common.collect.Ordering;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

@SuppressWarnings("unused")
public class DbSteps {

    @Autowired
    private StepUtils stepUtils;

    @Autowired
    private JsonMessageMarshaller messageMarshaller;

    @Autowired
    @Qualifier("oracleJdbcTemplate")
    private JdbcTemplate oracleJdbcTemplate;

    @Autowired
    @Qualifier("ccsAgentJdbcTemplate")
    private JdbcTemplate ccsAgentJdbcTemplate;

    private final Joiner dbJoiner = Joiner.on('.');
    private final Joiner columnJoiner = Joiner.on(", ");

    private static final Logger logger = LoggerFactory.getLogger(DbSteps.class);

    @Given("table {word} in schema {word} is emptied")
    public void clearTable(String table, String schema) {
        Objects.requireNonNull(getJdbcTemplate(schema)).execute("delete from " + dbJoiner.join(schema, table));
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Given("an existing outbound message {word} is in DB")
    public void existingOutboundMessage(String jsonFile) throws JsonProcessingException {
        String json = stepUtils.loadContent(jsonFile);
        Map map = new ObjectMapper().readValue(json, Map.class);
        this.insertAndReturnKey("CC_CCS_S2BCCSQ", "CCS_API_MAILBOX_OUTBOUND", "id", map);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Given("an existing ccsAgentMessageRoute {word} is in DB")
    public void existingCCSAgentMessageRoute(String jsonFile) throws JsonProcessingException {
        String json = stepUtils.loadContent(jsonFile);
        Map map = new ObjectMapper().readValue(json, Map.class);
        this.insertAndReturnKey("CC_API_CCS_AGENT", "ccs_agent_message_route", "id", map);
    }

    @Then("table {word} in schema {word} contains {int} row(s)")
    public void verifyDb(String table, String schema, int num) {
        List<Map<String, Object>> result = Objects.requireNonNull(getJdbcTemplate(schema))
                .queryForList("select * from " + dbJoiner.join(schema, table));

        logger.info("Queried {} rows from {}", result.size(), table);
        assertEquals(num, result.size());
    }

    @SuppressWarnings("rawtypes")
    @Then("table {word} in schema {word} contains {int} row(s) with details")
    public void verifyDbWithDetails(String table, String schema, int num, DataTable dataTable) {
        List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);
        List<String> columns = Lists.newArrayList(details.get(0).keySet());
        List<Map<String, Object>> result = Objects.requireNonNull(getJdbcTemplate(schema))
                .queryForList("select " + columnJoiner.join(columns) + " from " + dbJoiner.join(schema, table));

        logger.info("Queried {} rows from {}", result.size(), table);
        assertEquals(num, result.size());

        Comparator<Map> comparator = mapComparator(columns);
        List<Map<String, String>> detailList = Ordering.from(comparator).sortedCopy(details);
        List<Map<String, Object>> resultList = Ordering.from(comparator).sortedCopy(result);

        for (int i = 0; i < num; ++i) {
            Map<String, Object> dbResult = resultList.get(i);
            detailList.get(i).forEach((k, v) -> {
                assertTrue(dbResult.containsKey(k));
                assertEquals(v, StringUtils.isBlank(String.valueOf(dbResult.get(k))) ? null: dbResult.get(k));
            });
        }
    }

    @SuppressWarnings("rawtypes")
    private Comparator<Map> mapComparator(List<String> fields) {
        return (o1, o2) -> {
            ComparisonChain chain = ComparisonChain.start();
            fields.forEach(c -> chain.compare((String) o1.get(c), (String) o2.get(c)));
            return chain.result();
        };
    }

    @SuppressWarnings("SameParameterValue")
    private void insertAndReturnKey(String schema, String table, String key, Map<String, Object> paramMap) {
        SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(Objects.requireNonNull(getJdbcTemplate(schema)));
        simpleJdbcInsert.withSchemaName(schema).withTableName(table);

        simpleJdbcInsert.execute(paramMap);
    }

    private JdbcTemplate getJdbcTemplate(String schema) {
        if ("CC_CCS_S2BCCSQ".equalsIgnoreCase(schema)) {
            return oracleJdbcTemplate;
        } else if ("CC_API_CCS_AGENT".equalsIgnoreCase(schema)) {
            return ccsAgentJdbcTemplate;
        }

        throw new RuntimeException("Invalid schema");
    }
}

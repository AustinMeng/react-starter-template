package com.scb.api.ccs.test.wiremock;

import com.github.tomakehurst.wiremock.common.ListOrSingle;
import com.scb.channels.foundation.commons.shared.crypto.EncryptDecrypt;
import java.security.PrivateKey;
import java.security.PublicKey;
import wiremock.com.github.jknack.handlebars.Helper;
import wiremock.com.github.jknack.handlebars.Options;

@SuppressWarnings({"unused", "rawtypes"})
public class SignHandlebarFunction implements Helper<ListOrSingle> {

    public static final String PRIVATE_STR = "MIICXAIBAAKBgQDtiCAUPrSS2IOok+w3s6vPUjH5L8ZYqxkqGceeRCHH4Clpfs4/GI+QGi9uTBfxrztYVoB1G2xOsSxNrsiES3j4cMYroZCB/5MM4/d7gQTD6E97NWejIroU1MAXRKzWShp1oC9KPYzdLDcdPZ76Kgq+Uppj+obPclBWgWnAV1jXdwIDAQABAoGBAIMgea0TbLYAJrZiaq3ZVwiNdJ7+e72pPqwaLTO2ovtnSRU+9naohWBkxDhcc39tYBKFNkbvy5upfS6pRXKbA3z6vrbLypkeEZ2HnOxYsQ/zH2DsezxJm1r0WXiwaPC6p683C/3xgl/ME2jrLzrvi+4+uMSDCtAQ6NzeOVVpfckZAkEA/2Vr3kKSolfLw8x6Jx+B2CPMkYGJbbUM7DDmKx1V5mH3FPh0QMkIACVlxtYSvgPXVQ/5sR17uZ+0ZQbQDMs51QJBAO4X5Di6Bwy3Y+b4VbhdBUs1uPx5YzLlV0YtjQC6BuCi3TbsndYZj/6j6ZXulRv6WeCruhyVSCztP0mxNULzxhsCQDC0VLfUFkajW5aBXiIr3gUr/o0ZGO41ArvgL2S1eXYv5IC5SOI59C6i8x/SH0zhSqVMIJ/oMXoavLovbGmkL+kCQElG3RyAVG8begm54FfveROeoyJBEcC2SNf2aPEST8+PEFo5FJKyJ1kNhXR5izajJEo7T/pAD4iUM+gwO94xPIUCQBYC6cZYmyE6J8s1i7xyrp2zQxvYVeAlsbCG4LaXRWEcvufKHw9Q5QPtMuBdEoUeXapBkugfO0rMCAo+4///NXw=";

    public static final String PUBLIC_STR = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDtiCAUPrSS2IOok+w3s6vPUjH5L8ZYqxkqGceeRCHH4Clpfs4/GI+QGi9uTBfxrztYVoB1G2xOsSxNrsiES3j4cMYroZCB/5MM4/d7gQTD6E97NWejIroU1MAXRKzWShp1oC9KPYzdLDcdPZ76Kgq+Uppj+obPclBWgWnAV1jXdwIDAQAB";

    @Override
    public Object apply(ListOrSingle context, Options options) {
        return EncryptDecrypt.getDefaultInstance().sign(privateKey(), context.get(0).toString());
    }

    public static PrivateKey privateKey() {
        return EncryptDecrypt.convertStringToPrivateKey(PRIVATE_STR);
    }

    public static PublicKey publicKey() {
        return EncryptDecrypt.convertStringToPublicKey(PUBLIC_STR);
    }

}


package com.scb.s2b.api.ccs.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PayloadEntity {
    private String type;
    private String dateTime;
    private String fileName;
    private String umi;
    private String batchNumber;
    private String channelIndicator;
    private String statusCode;
    private String statusRemarks;
    private String product;
}

package com.scb.s2b.api.ccs.parser;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;

import com.scb.s2b.api.ccs.entity.PayloadEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PipeDelimiterMessageParserTest {

    @InjectMocks
    private PipeDelimiterMessageParser parser;

    @Test
    public void test_parse_invalid_payload() {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> parser.parse(null));
        assertEquals("Payload message is empty.", e.getMessage());

        String shortPayload0 = "ACK3";
        IllegalArgumentException e0 = assertThrows(IllegalArgumentException.class,
                () -> parser.parse(shortPayload0));
        assertEquals("Invalid payload message.", e0.getMessage());

        String shortPayload1 = "ACK3|";
        IllegalArgumentException e1 = assertThrows(IllegalArgumentException.class,
                () -> parser.parse(shortPayload1));
        assertEquals("Invalid payload message.", e1.getMessage());

        String shortPayload2 = "ACK3||";
        IllegalArgumentException e2 = assertThrows(IllegalArgumentException.class,
                () -> parser.parse(shortPayload2));
        assertEquals("Invalid payload message.", e2.getMessage());

        String shortPayload3 = "ACK3|AAA||";
        IllegalArgumentException e3 = assertThrows(IllegalArgumentException.class,
                () -> parser.parse(shortPayload3));
        assertEquals("Invalid payload message.", e3.getMessage());

        String shortPayload4 = "ACK3|AAA|BBB|SSS|";
        IllegalArgumentException e4 = assertThrows(IllegalArgumentException.class,
                () -> parser.parse(shortPayload4));
        assertEquals("Invalid payload message.", e4.getMessage());
    }

    @Test
    public void test_payload() {
        String ack3Payload = "ACK3|21042008071836|GroupID.PAYMENTS.20080421031425.60843.Test.txt|08042115fp880000088170000|D0000345|H2H|75130|(INFO) File Sent|PAYSTS_XML";
        PayloadEntity ack3Entity = parser.parse(ack3Payload);
        assertEquals("ACK3", ack3Entity.getType());
        assertEquals("21042008071836", ack3Entity.getDateTime());
        assertEquals("GroupID.PAYMENTS.20080421031425.60843.Test.txt", ack3Entity.getFileName());
        assertEquals("08042115fp880000088170000", ack3Entity.getUmi());
        assertEquals("D0000345", ack3Entity.getBatchNumber());
        assertEquals("H2H", ack3Entity.getChannelIndicator());
        assertEquals("75130", ack3Entity.getStatusCode());
        assertEquals("(INFO) File Sent", ack3Entity.getStatusRemarks());
        assertEquals("PAYSTS_XML", ack3Entity.getProduct());

        String rej3Payload = "REJ3|21042008071836|GroupID.PAYMENTS.20080421031425.60843.Test.txt|08042115fp880000088170000||H2H|49130|(WARNING) File is duplicated|PAYMENTS";
        PayloadEntity rej3Entity = parser.parse(rej3Payload);
        assertEquals("REJ3", rej3Entity.getType());
        assertEquals("21042008071836", rej3Entity.getDateTime());
        assertEquals("GroupID.PAYMENTS.20080421031425.60843.Test.txt", rej3Entity.getFileName());
        assertEquals("08042115fp880000088170000", rej3Entity.getUmi());
        assertNull(rej3Entity.getBatchNumber());
        assertEquals("H2H", rej3Entity.getChannelIndicator());
        assertEquals("49130", rej3Entity.getStatusCode());
        assertEquals("(WARNING) File is duplicated", rej3Entity.getStatusRemarks());
        assertEquals("PAYMENTS", rej3Entity.getProduct());

        String payload0 = "REJ3|21042008071836|GroupID.PAYMENTS.20080421031425.60843.Test.txt";
        PayloadEntity entity0 = parser.parse(payload0);
        assertEquals("REJ3", entity0.getType());
        assertEquals("21042008071836", entity0.getDateTime());
        assertEquals("GroupID.PAYMENTS.20080421031425.60843.Test.txt", entity0.getFileName());
        assertNull(entity0.getUmi());
        assertNull(entity0.getBatchNumber());
        assertNull(entity0.getChannelIndicator());
        assertNull(entity0.getStatusCode());
        assertNull(entity0.getStatusRemarks());
        assertNull(entity0.getProduct());

        String payload1 = "ACK3|21042008071836|GroupID.PAYMENTS.20080421031425.60843.Test.txt|08042115fp880000088170000|D0000345|H2H|75130|(INFO) File Sent";
        PayloadEntity entity1 = parser.parse(payload1);
        assertEquals("ACK3", entity1.getType());
        assertEquals("21042008071836", entity1.getDateTime());
        assertEquals("GroupID.PAYMENTS.20080421031425.60843.Test.txt", entity1.getFileName());
        assertEquals("08042115fp880000088170000", entity1.getUmi());
        assertEquals("D0000345", entity1.getBatchNumber());
        assertEquals("H2H", entity1.getChannelIndicator());
        assertEquals("75130", entity1.getStatusCode());
        assertEquals("(INFO) File Sent", entity1.getStatusRemarks());
        assertNull(entity1.getProduct());
    }
}
package com.scb.s2b.api.ccs.repository.mailbox;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.scb.s2b.api.ccs.config.JpaTestConfig;
import com.scb.s2b.api.ccs.entity.OutboundMessageStatus;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import java.math.BigInteger;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@SuppressWarnings("unused")
@DataJpaTest
@ContextConfiguration(classes = JpaTestConfig.class)
@RunWith(SpringRunner.class)
@EnableJpaRepositories("com.scb.s2b.api.ccs.repository")
@ActiveProfiles("test")
public class CCSMailBoxOutboundRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private CCSMailBoxOutboundRepository repository;

    private final String umi = "umi";
    private final String source = "API";
    private final String noun = "PAYMENTS";
    private final String format = "ACK3";
    private final String grpId = "groupId";
    private final String fileName = "test_file";
    private final String createdBy = "API";
    private final BigInteger fileSize = BigInteger.valueOf(1024L);
    private final Integer status = OutboundMessageStatus.IN_PROGRESS.code();

    private BigInteger entityId;

    private static final String raw = "ACK3|21042008071836|GroupID.PAYMENTS.20080421031425.60843.Test.txt|08042115fp880000088170000|D0000345|H2H|75130|(INFO) File Sent|PAYSTS_XML";

    @Before
    public void setUp() {
        CCSMailBoxOutbound mailBoxOutbound = CCSMailBoxOutbound.builder()
                .umi(umi)
                .source(source)
                .noun(noun)
                .format(format)
                .grpId(grpId)
                .payload(raw.getBytes())
                .fileName(fileName)
                .createdBy(createdBy)
                .fileSize(fileSize)
                .status(status)
                .build();
        entityManager.persist(mailBoxOutbound);
        entityId = entityManager.getId(mailBoxOutbound, BigInteger.class);
    }

    @Test
    public void test_find_by_id() {
        Optional<CCSMailBoxOutbound> opt = repository.findById(entityId);
        assertTrue(opt.isPresent());
        CCSMailBoxOutbound outbound = opt.get();
        assertEquals(umi, outbound.getUmi());
        assertEquals(source, outbound.getSource());
        assertEquals(noun, outbound.getNoun());
        assertEquals(format, outbound.getFormat());
        assertEquals(grpId, outbound.getGrpId());
        assertEquals(fileName, outbound.getFileName());
        assertEquals(createdBy, outbound.getCreatedBy());
        assertEquals(fileSize, outbound.getFileSize());
        assertEquals(status, outbound.getStatus());
    }

    @Test
    public void test_update_ccs_mailbox_outbound() {
        String channelId = "API";
        Optional<CCSMailBoxOutbound> opt = repository.findById(entityId);
        assertTrue(opt.isPresent());
        CCSMailBoxOutbound outbound = opt.get();
        outbound.setStatus(OutboundMessageStatus.PROCESSED.code());
        outbound.setModifiedBy(channelId);
        repository.save(outbound);

        CCSMailBoxOutbound out = entityManager.find(CCSMailBoxOutbound.class, entityId);
        assertEquals(channelId, out.getModifiedBy());
        assertEquals(OutboundMessageStatus.PROCESSED.code(), out.getStatus());
    }
}

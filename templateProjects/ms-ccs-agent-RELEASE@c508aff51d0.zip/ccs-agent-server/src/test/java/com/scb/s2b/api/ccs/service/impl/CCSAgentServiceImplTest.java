package com.scb.s2b.api.ccs.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.ccs.camel.KafkaProducerAdapter;
import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.ccs.entity.PayloadEntity;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.ccs.marshaller.XmlMessageMarshaller;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRepository;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRouteRepository;
import com.scb.s2b.api.ccs.repository.mailbox.CCSMailBoxInboundRepository;
import com.scb.s2b.api.ccs.route.RouteHandler;
import com.scb.s2b.api.ccs.service.CCSOutboundMessageService;
import com.scb.s2b.api.ccs.transformer.CCSMailBoxTransformer;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CCSAgentServiceImplTest {

    private static final String ACK3_FORMAT = "ACK3";
    private static final String REJ3_FORMAT = "REJ3";

    @Spy
    @InjectMocks
    private CCSAgentServiceImpl service;

    @Mock
    private CCSMailBoxInboundRepository ccsMailBoxInboundRepository;

    @Mock
    private CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository;

    @Mock
    private CCSAgentMessageRepository ccsAgentMessageRepository;

    @Mock
    private CCSMailBoxTransformer ccsMailBoxTransformer;

    @Mock
    private ProducerTemplate producer;

    @Mock
    private KafkaProducerAdapter kafkaProducer;

    @Spy
    private final Map<String, Function<byte[], PayloadEntity>> payloadProcessors = new HashMap<>();

    @Mock
    private Function<byte[], PayloadEntity> ack3Processor;

    @Mock
    private Function<byte[], PayloadEntity> rej3Processor;

    @Mock
    private XmlMessageMarshaller xmlMessageMarshaller;

    @Mock
    private JsonMessageMarshaller jsonMessageMarshaller;

    @Mock
    private CCSOutboundMessageService ccsOutboundMessageService;

    @Mock
    private RouteHandler routeHandler;

    private PayloadEntity payloadEntity;

    private static final String outboundPayloadType = "ACK3";
    private static final String outboundPayloadDateTime = "21042008071836";
    private static final String outboundPayloadFileName = "GroupID.PAYMENTS.20080421031425.60843.Test.txt";
    private static final String outboundPayloadUmi = "08042115fp880000088170000";
    private static final String outboundPayloadBatchNumber = "D0000345";
    private static final String outboundPayloadChannelIndicator = "H2H";
    private static final String outboundPayloadChannelStatusCode = "75130";
    private static final String outboundPayloadChannelStatusRemarks = "(INFO) File Sent";
    private static final String outboundPayloadChannelProduct = "PAYSTS_XML";

    @Before
    public void setUp() throws Exception {
        service = new CCSAgentServiceImpl(
                ccsMailBoxInboundRepository,
                ccsAgentMessageRouteRepository,
                ccsAgentMessageRepository,
                ccsMailBoxTransformer,
                producer,
                null,
                xmlMessageMarshaller,
                jsonMessageMarshaller,
                kafkaProducer,
                payloadProcessors,
                ccsOutboundMessageService,
                routeHandler);
        payloadProcessors.putAll(ImmutableMap.of(ACK3_FORMAT, ack3Processor, REJ3_FORMAT, rej3Processor));
        payloadEntity = PayloadEntity.builder()
                .type(outboundPayloadType)
                .dateTime(outboundPayloadDateTime)
                .fileName(outboundPayloadFileName)
                .umi(outboundPayloadUmi)
                .batchNumber(outboundPayloadBatchNumber)
                .channelIndicator(outboundPayloadChannelIndicator)
                .statusCode(outboundPayloadChannelStatusCode)
                .statusRemarks(outboundPayloadChannelStatusRemarks)
                .product(outboundPayloadChannelProduct)
                .build();
        when(ack3Processor.apply(any(byte[].class))).thenReturn(payloadEntity);
    }

    @Test
    public void test_persist_ccs_inbound_message() {
        CCSAgentInboundIns ccsAgentInboundIns = CCSAgentInboundIns.builder().build();
        service.persistCCSInboundMessage(ccsAgentInboundIns);

        verify(ccsMailBoxTransformer).ccsAgentInsToMailBoxInbound(ccsAgentInboundIns);
        verify(ccsMailBoxInboundRepository).save(any());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_process_ccs_outbound_message_when_empty_record_received() {
        BigInteger id = BigInteger.ONE;
        CCSMailBoxOutbound entity = mock(CCSMailBoxOutbound.class);
        when(ccsOutboundMessageService.findOutboundById(id)).thenReturn(Optional.empty(), Optional.of(entity));
        service.processCCSOutboundMessage(id);
        verify(ccsOutboundMessageService).findOutboundById(eq(id));
        verify(ack3Processor, never()).apply(any(byte[].class));
        verify(rej3Processor, never()).apply(any(byte[].class));
        verify(ccsMailBoxTransformer, never())
                .mailBoxOutboundToCCSAgentOutboundIns(any(CCSMailBoxOutbound.class), any(PayloadEntity.class));
        verify(kafkaProducer, never()).publishCCSAgentOutboundIns(any(CCSAgentOutboundIns.class), any(String.class));
    }

    @Test
    public void test_process_ccs_outbound_message() {
        BigInteger id = BigInteger.ONE;
        CCSMailBoxOutbound entity = mock(CCSMailBoxOutbound.class);
        CCSAgentOutboundIns ins = CCSAgentOutboundIns.builder()
                .raw("raw")
                .source("source")
                .umi("umi")
                .noun("noun")
                .format(ACK3_FORMAT)
                .groupId("groupId")
                .filename("filename")
                .payload(payloadEntity)
                .build();
        when(ccsOutboundMessageService.findOutboundById(id)).thenReturn(Optional.of(entity));
        when(entity.getPayload()).thenReturn("test_payload".getBytes());
        when(entity.getFormat()).thenReturn("ACK3");
        when(ccsMailBoxTransformer
                .mailBoxOutboundToCCSAgentOutboundIns(any(CCSMailBoxOutbound.class), any(PayloadEntity.class)))
                .thenReturn(ins);
        when(routeHandler.getRoute("noun", ACK3_FORMAT, "groupId", "filename"))
                .thenReturn("KAFKA:test");
        service.processCCSOutboundMessage(id);
        ArgumentCaptor<BigInteger> idArg = ArgumentCaptor.forClass(BigInteger.class);
        verify(ccsOutboundMessageService).findOutboundById(idArg.capture());
        assertEquals(id, idArg.getValue());
        verify(ccsOutboundMessageService).findOutboundById(eq(id));
        verify(ack3Processor).apply(any(byte[].class));
        verify(rej3Processor, never()).apply(any(byte[].class));
        verify(ccsMailBoxTransformer).mailBoxOutboundToCCSAgentOutboundIns(eq(entity), eq(payloadEntity));
        verify(kafkaProducer).publishCCSAgentOutboundIns(eq(ins), eq("KAFKA:test"));
    }
}
package com.scb.s2b.api.ccs.camel;


import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;

import com.scb.s2b.api.ccs.entity.RequestMessage;
import com.scb.s2b.api.ccs.marshaller.XmlMessageMarshaller;
import com.scb.s2b.api.ccs.service.CCSAgentService;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class JmsConsumerAdapterTest {

    @InjectMocks
    private JmsConsumerAdapter adapter;

    @Mock
    private CCSAgentService ccsAgentService;

    @Spy
    private final XmlMessageMarshaller xmlMessageMarshaller = new XmlMessageMarshaller();

    @Test
    public void test_consumeCCSOutbound() throws IOException {
        String text = outboundMessageText();
        adapter.consumeCCSOutbound(text);
        verify(xmlMessageMarshaller).unmarshal(text, RequestMessage.class);
        verify(ccsAgentService).processCCSOutboundMessage(BigInteger.valueOf(200000000288L));
    }

    private String outboundMessageText() throws IOException {
        try (InputStream is = JmsConsumerAdapterTest.class.getClassLoader()
                .getResourceAsStream("outbound/request-message.xml")) {
            assertNotNull(is);
            return IOUtils.toString(is, StandardCharsets.ISO_8859_1);
        }
    }
}
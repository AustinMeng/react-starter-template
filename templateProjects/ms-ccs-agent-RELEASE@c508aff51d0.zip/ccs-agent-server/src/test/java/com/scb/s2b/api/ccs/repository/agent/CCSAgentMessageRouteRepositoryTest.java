package com.scb.s2b.api.ccs.repository.agent;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.scb.s2b.api.ccs.config.JpaTestConfig;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessageRoute;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@DataJpaTest
@ContextConfiguration(classes = JpaTestConfig.class)
@RunWith(SpringRunner.class)
@EnableJpaRepositories("com.scb.s2b.api.ccs.repository")
@ActiveProfiles("test")
public class CCSAgentMessageRouteRepositoryTest {

    @Autowired
    CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository;

    @Test
    public void test_find_by_name() {
        CCSAgentMessageRoute ccsAgentMessageRoute = CCSAgentMessageRoute.builder().callback("ccs").noun("PAYMENTS")
                .fileName("fileName001").build();
        ccsAgentMessageRouteRepository.save(ccsAgentMessageRoute);
        CCSAgentMessageRoute result = ccsAgentMessageRouteRepository.findByFileName("fileName001");

        assertNotNull(result);
        assertEquals("ccs", result.getCallback());
        assertEquals("PAYMENTS", result.getNoun());
    }

    @Test
    public void test_exist_by_name() {
        CCSAgentMessageRoute ccsAgentMessageRoute = CCSAgentMessageRoute.builder().callback("ccs").noun("PAYMENTS")
                .fileName("fileName001").build();
        ccsAgentMessageRouteRepository.save(ccsAgentMessageRoute);
        boolean result = ccsAgentMessageRouteRepository.existsCCSAgentMessageRouteByFileName("fileName001");

        assertTrue(result);
    }

    @Test
    public void test_exist_by_name_and_noun() {
        CCSAgentMessageRoute ccsAgentMessageRoute = CCSAgentMessageRoute.builder().callback("ccs").noun("PAYMENTS")
                .fileName("fileName001").build();
        ccsAgentMessageRouteRepository.save(ccsAgentMessageRoute);
        boolean result = ccsAgentMessageRouteRepository.existsCCSAgentMessageRouteByFileNameAndNoun("fileName001", "PAYMENTS");

        assertTrue(result);
    }

}
package com.scb.s2b.api.ccs.util;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.junit.Ignore;
import org.junit.Test;

@Slf4j
@Ignore("Not working in Jenkins without JCE")
public class EncDecTest {

    private final StandardPBEStringEncryptor encryptor;

    private static final String ALGO = "PBEWITHSHA256AND256BITAES-CBC-BC";

    public EncDecTest() throws IOException {
        String key = IOUtils.toString(
                Objects.requireNonNull(this.getClass().getResourceAsStream("/config/jasypt.pwd")),
                StandardCharsets.UTF_8);

        encryptor = new StandardPBEStringEncryptor();
        encryptor.setProvider(new BouncyCastleProvider());
        encryptor.setAlgorithm(ALGO);
        encryptor.setPassword(key);
    }

    @Test
    public void encrypt() {
        log.info("ENC({})", encryptor.encrypt("s2bccsq"));
    }

    @Test
    public void decrypt() {
        log.info(encryptor.decrypt("j+F2OrlqCabt9MshWYHzNiSOHoKEIxqXyL3d2rHMz+o="));
    }

    @Test
    public void encrypt_decrypt() {
        String str = "qwerty";
        String encrypted = encryptor.encrypt(str);
        String decrypted = encryptor.decrypt(encrypted);

        assertEquals(str, decrypted);
    }

    @Test
    public void transform_128_to_256() {
        StandardPBEStringEncryptor encryptor128 = new StandardPBEStringEncryptor();
        encryptor128.setProvider(new BouncyCastleProvider());
        encryptor128.setAlgorithm("PBEWITHSHA256AND128BITAES-CBC-BC");
        encryptor128.setPassword("Vit425bdJ");

        String encrypted128 = "VrxKVCSrWrj5grv7nVYKpHvz1ABq+74KtQOCc5E6S7Q=";
        String original = encryptor128.decrypt(encrypted128);
        String encrypted256 = encryptor.encrypt(original);

        log.info("ENC({}) -> {} -> ENC({})", encrypted128, original, encrypted256);
    }

}

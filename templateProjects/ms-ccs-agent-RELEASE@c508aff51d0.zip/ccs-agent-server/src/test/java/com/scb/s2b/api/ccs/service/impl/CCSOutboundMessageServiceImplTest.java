package com.scb.s2b.api.ccs.service.impl;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CHANNEL_API;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.scb.s2b.api.ccs.entity.OutboundMessageStatus;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import com.scb.s2b.api.ccs.repository.mailbox.CCSMailBoxOutboundRepository;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.Random;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CCSOutboundMessageServiceImplTest {

    @InjectMocks
    private CCSOutboundMessageServiceImpl messageService;

    @Mock
    private CCSMailBoxOutboundRepository ccsMailBoxOutboundRepository;

    @Mock
    private CCSMailBoxOutbound outbound;

    private BigInteger id;

    @Before
    public void setUp() throws Exception {
        Random random = new Random();
        id = BigInteger.valueOf(random.nextInt());
        when(ccsMailBoxOutboundRepository.findById(id)).thenReturn(Optional.of(outbound));
    }

    @Test
    public void test_update_outbound_message_status() {
        messageService.updateOutboundMessageStatus(outbound, OutboundMessageStatus.PROCESSED);
        verify(outbound).setModifiedBy(CHANNEL_API);
        verify(outbound).setStatus(OutboundMessageStatus.PROCESSED.code());
        verify(outbound).setModifiedDate(any(Timestamp.class));
        verify(ccsMailBoxOutboundRepository).save(outbound);
    }

    @Test
    public void test_find_Outbound_by_id() {
        Optional<CCSMailBoxOutbound> messageOptional = messageService.findOutboundById(id);
        verify(ccsMailBoxOutboundRepository).findById(id);
        assertTrue(messageOptional.isPresent());
        assertEquals(outbound, messageOptional.get());
    }
}
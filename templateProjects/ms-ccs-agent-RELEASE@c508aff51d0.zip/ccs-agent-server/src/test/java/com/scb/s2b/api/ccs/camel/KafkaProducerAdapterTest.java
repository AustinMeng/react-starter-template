package com.scb.s2b.api.ccs.camel;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class KafkaProducerAdapterTest {

    @InjectMocks
    private KafkaProducerAdapter producerAdapter;

    @Mock
    private ProducerTemplate producer;

    @Mock
    private JsonMessageMarshaller jsonMessageMarshaller;

    @Mock
    private CCSAgentOutboundIns outboundIns;

    private static final String DUMMY_ENDPOINT = "CCS_DUMMY_ENDPOINT";
    private static final String DUMMY_UMI = "CCS_DUMMY_UMI";

    @Before
    public void setUp() throws Exception {
        when(outboundIns.getUmi()).thenReturn(DUMMY_UMI);
    }

    @Test
    public void test_publish_CCSAgentOutboundIns() {
        byte[] message = new byte[64];
        when(jsonMessageMarshaller.marshallToJsonByteArray(outboundIns)).thenReturn(message);
        producerAdapter.publishCCSAgentOutboundIns(outboundIns, DUMMY_ENDPOINT);
        verify(producer).sendBody(Mockito.eq(DUMMY_ENDPOINT), Mockito.any(byte[].class));
    }

    @Test
    public void test_publish_CCSAgentOutboundIns_with_empty_endpoint() {
        producerAdapter.publishCCSAgentOutboundIns(outboundIns, null);
        verify(producer, never()).sendBody(anyString(), Mockito.any(byte[].class));

        producerAdapter.publishCCSAgentOutboundIns(outboundIns, "");
        verify(producer, never()).sendBody(anyString(), Mockito.any(byte[].class));

        producerAdapter.publishCCSAgentOutboundIns(outboundIns, "  ");
        verify(producer, never()).sendBody(anyString(), Mockito.any(byte[].class));
    }
}
package com.scb.s2b.api.ccs.service.impl;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CHANNEL_API;

import com.scb.s2b.api.ccs.entity.OutboundMessageStatus;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import com.scb.s2b.api.ccs.repository.mailbox.CCSMailBoxOutboundRepository;
import com.scb.s2b.api.ccs.service.CCSOutboundMessageService;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
public class CCSOutboundMessageServiceImpl implements CCSOutboundMessageService {

    private final CCSMailBoxOutboundRepository ccsMailBoxOutboundRepository;

    public CCSOutboundMessageServiceImpl(
            CCSMailBoxOutboundRepository ccsMailBoxOutboundRepository) {
        this.ccsMailBoxOutboundRepository = ccsMailBoxOutboundRepository;
    }

    @Override
    @Transactional(transactionManager = "oracleTransactionManager", propagation = Propagation.REQUIRES_NEW)
    public void updateOutboundMessageStatus(CCSMailBoxOutbound outboundMessage, OutboundMessageStatus status) {
        log.info("Updating ccs outbound message id={}, statusCode={}", outboundMessage.getId(), status.code());
        outboundMessage.setModifiedBy(CHANNEL_API);
        outboundMessage.setStatus(status.code());
        outboundMessage.setModifiedDate(Timestamp.from(LocalDateTime.now().toInstant(ZoneOffset.of("+8"))));
        ccsMailBoxOutboundRepository.save(outboundMessage);
    }

    @Override
    @Transactional(transactionManager = "oracleTransactionManager", propagation = Propagation.SUPPORTS)
    public Optional<CCSMailBoxOutbound> findOutboundById(BigInteger id) {
        log.info("Querying ccs outbound message for id={}", id);
        return ccsMailBoxOutboundRepository.findById(id);
    }
}

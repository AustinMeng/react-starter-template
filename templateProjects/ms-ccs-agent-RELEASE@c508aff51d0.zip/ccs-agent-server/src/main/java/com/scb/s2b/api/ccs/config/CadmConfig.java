package com.scb.s2b.api.ccs.config;

import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.channels.foundation.commons.cadm.impl.CadmClientImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

@SuppressWarnings("unused")
public class CadmConfig {
    @Value("${cadm.baseUrl}")
    private String cadmBaseUrl;

    @Value("${security.masterKeystore}")
    private String masterKeystore;

    @Value("${security.masterKeystorePassword}")
    private String masterKeystorePassword;

    @Bean
    @Profile("!test")
    public CadmClient cadmClient() {
        return new CadmClientImpl(cadmBaseUrl, masterKeystore, masterKeystorePassword);
    }
}

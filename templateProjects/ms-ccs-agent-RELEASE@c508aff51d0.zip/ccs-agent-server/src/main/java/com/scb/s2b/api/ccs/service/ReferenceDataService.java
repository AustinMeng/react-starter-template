package com.scb.s2b.api.ccs.service;

import com.scb.s2b.api.ccs.entity.refdata.RoutingProperties;

public interface ReferenceDataService {
    String META_CACHE = "MetaData";

    String META_ROUTING_PROPERTIES = "scb.internal.routing.ccsAgentProperties";

    RoutingProperties getRoutingProperties();

    String getCountryCodeByGroupId(String groupId);

}

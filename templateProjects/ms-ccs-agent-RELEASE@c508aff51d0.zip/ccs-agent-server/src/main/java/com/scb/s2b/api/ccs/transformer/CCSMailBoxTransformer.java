package com.scb.s2b.api.ccs.transformer;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CHANNEL_API;

import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.ccs.entity.InboundMessageStatus;
import com.scb.s2b.api.ccs.entity.PayloadEntity;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import java.nio.charset.StandardCharsets;
import org.apache.commons.lang3.StringUtils;

import java.util.Optional;

public class CCSMailBoxTransformer {

    private static final String ACK3_EXTENSION = ".ack3";
    private static final String REJ3_EXTENSION = ".rej3";

    public CCSMailBoxInbound ccsAgentInsToMailBoxInbound(CCSAgentInboundIns ccsAgentInboundIns) {
        return CCSMailBoxInbound.builder().fileName(ccsAgentInboundIns.getFileName())
                .fileSize(ccsAgentInboundIns.getFileSize()).createdBy(CHANNEL_API)
                .grpId(ccsAgentInboundIns.getGroupId()).format(ccsAgentInboundIns.getFormat())
                .noun(ccsAgentInboundIns.getNoun())
                .payload(ccsAgentInboundIns.getPayload().getBytes(StandardCharsets.UTF_8))
                .source(Optional.ofNullable(ccsAgentInboundIns.getSource()).orElse(CHANNEL_API))
                .status(InboundMessageStatus.INITIALIZED.getCode())
                .build();
    }

    public CCSAgentOutboundIns mailBoxOutboundToCCSAgentOutboundIns(CCSMailBoxOutbound outbound,
            PayloadEntity payload) {
        String filename = outbound.getFileName();
        filename = truncateFilenameExtension(filename, ACK3_EXTENSION);
        filename = truncateFilenameExtension(filename, REJ3_EXTENSION);
        return CCSAgentOutboundIns.builder()
                .umi(outbound.getUmi())
                .source(outbound.getSource())
                .noun(outbound.getNoun())
                .format(outbound.getFormat())
                .groupId(outbound.getGrpId())
                .raw(new String(outbound.getPayload(), StandardCharsets.UTF_8))
                .filename(filename)
                .payload(payload)
                .build();
    }

    private String truncateFilenameExtension(String filename, String extension) {
        int index = StringUtils.lastIndexOf(filename, extension);
        if (index != -1 && filename.length() == (index + extension.length())) {
            return filename.substring(0, index);
        }
        return filename;
    }
}

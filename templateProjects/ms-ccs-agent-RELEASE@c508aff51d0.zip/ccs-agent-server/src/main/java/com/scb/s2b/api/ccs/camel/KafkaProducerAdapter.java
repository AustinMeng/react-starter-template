package com.scb.s2b.api.ccs.camel;

import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KafkaProducerAdapter {

    private final ProducerTemplate producer;

    private final JsonMessageMarshaller jsonMessageMarshaller;

    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerAdapter.class);

    public KafkaProducerAdapter(ProducerTemplate producer,
            JsonMessageMarshaller jsonMessageMarshaller) {
        this.producer = producer;
        this.jsonMessageMarshaller = jsonMessageMarshaller;
    }

    public void publishCCSAgentOutboundIns(CCSAgentOutboundIns instruction, String exportEndpoint) {
        String umi = instruction != null ? instruction.getUmi() : null;
        if (StringUtils.isBlank(exportEndpoint)) {
            logger.error("export endpoint is empty for umi={}, and stop sending message", umi);
        } else {
            logger.info("CCSAgentOutboundInst with umi={} will be sent to {}", umi, exportEndpoint);
            producer.sendBody(exportEndpoint, jsonMessageMarshaller.marshallToJsonByteArray(instruction));
            logger.info("CCSAgentOutboundInst with umi={} is sent to {}", umi, exportEndpoint);
        }
    }
}

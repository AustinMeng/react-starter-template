package com.scb.s2b.api.ccs.marshaller;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializer;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Instant;

@SuppressWarnings("unused")
public class JsonMessageMarshaller {

    private final ObjectMapper objectMapper;

    public JsonMessageMarshaller() {
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(Instant.class, new InstantWithNanosSerializer());
        this.objectMapper = new ObjectMapper()
                .registerModule(javaTimeModule)
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .enable(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS)
                .enable(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
    }

    public <T> String marshallToJsonString(T instance) {
        try {
            return objectMapper.writeValueAsString(instance);
        } catch (JsonProcessingException ex) {
            throw new RuntimeException(ex);
        }
    }

    public <T> byte[] marshallToJsonByteArray(T instance) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            objectMapper.writeValue(outputStream, instance);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }

        return outputStream.toByteArray();
    }

    public <T> T unmarshal(String json, Class<T> type) {
        try {
            return objectMapper.readValue(json, type);
        } catch (JsonProcessingException ex) {
            throw new RuntimeException(ex);
        }
    }

    public <T> T unmarshal(byte[] data, Class<T> type) {
        try {
            return objectMapper.readValue(data, type);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public static class InstantWithNanosSerializer extends InstantSerializer {

        public InstantWithNanosSerializer() {
            super(InstantSerializer.INSTANCE, true, true, null);
        }

        @Override
        protected JsonFormat.Value findFormatOverrides(SerializerProvider provider, BeanProperty prop,
                Class<?> typeForDefaults) {
            //return null so that the format override doesnt replace this serializer with the default Instant serializer
            return null;
        }
    }
}

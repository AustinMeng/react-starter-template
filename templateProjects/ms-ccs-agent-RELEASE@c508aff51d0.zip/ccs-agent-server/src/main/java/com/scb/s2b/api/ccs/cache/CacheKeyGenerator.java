package com.scb.s2b.api.ccs.cache;

import java.lang.reflect.Method;
import java.util.Objects;
import javax.annotation.Nonnull;
import org.springframework.cache.interceptor.KeyGenerator;

public class CacheKeyGenerator implements KeyGenerator {

    private static final char DOT = '.';
    private static final int NO_PARAM_KEY = 0;

    @Override
    @Nonnull
    public Object generate(Object o, Method method, Object... params) {

        StringBuilder sb = new StringBuilder();

        sb.append(o.getClass().getSimpleName())
                .append(DOT)
                .append(method.getName())
                .append(DOT);

        if (params.length == 0) {
            sb.append(NO_PARAM_KEY);
        } else {
            sb.append(Objects.hash(params));
        }

        return sb.toString();
    }
}

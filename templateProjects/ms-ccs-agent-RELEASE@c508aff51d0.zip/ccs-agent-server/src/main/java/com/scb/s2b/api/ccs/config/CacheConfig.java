package com.scb.s2b.api.ccs.config;

import com.scb.s2b.api.ccs.cache.CacheKeyGenerator;
import com.scb.s2b.api.ccs.config.property.CacheProperties;
import com.scb.s2b.api.ccs.service.ReferenceDataService;
import java.time.Duration;
import javax.cache.Caching;
import javax.cache.spi.CachingProvider;
import org.ehcache.config.builders.CacheConfigurationBuilder;
import org.ehcache.config.builders.ExpiryPolicyBuilder;
import org.ehcache.config.builders.ResourcePoolsBuilder;
import org.ehcache.jsr107.Eh107Configuration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.context.annotation.Bean;

@SuppressWarnings("unused")
public class CacheConfig {

    private static final int expireAfter60Minutes = 60 * 60;

    private static final int cacheEntries = 500;

    @Bean(name="ehCacheManager")
    public CacheManager ehCacheManager() {
        CachingProvider cp = Caching.getCachingProvider("org.ehcache.jsr107.EhcacheCachingProvider");
        javax.cache.CacheManager cm = cp.getCacheManager();

        CacheConfigurationBuilder<String, Object> configurationBuilder = CacheConfigurationBuilder
                .newCacheConfigurationBuilder(String.class, Object.class,
                        ResourcePoolsBuilder.heap(cacheEntries))
                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofSeconds(expireAfter60Minutes)));

        cm.createCache(ReferenceDataService.META_CACHE, Eh107Configuration.fromEhcacheCacheConfiguration(configurationBuilder));

        return new JCacheCacheManager(cm);
    }

    @Bean
    public KeyGenerator cacheKeyGenerator() {
        return new CacheKeyGenerator();
    }

    @Bean
    @ConfigurationProperties("cache.config")
    public CacheProperties cacheProperties() {
        return new CacheProperties();
    }
}

package com.scb.s2b.api.ccs.service;

import com.scb.s2b.api.ccs.entity.OutboundMessageStatus;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import java.math.BigInteger;
import java.util.Optional;

public interface CCSOutboundMessageService {

    Optional<CCSMailBoxOutbound> findOutboundById(BigInteger id);

    void updateOutboundMessageStatus(CCSMailBoxOutbound outboundMessage, OutboundMessageStatus status);
}

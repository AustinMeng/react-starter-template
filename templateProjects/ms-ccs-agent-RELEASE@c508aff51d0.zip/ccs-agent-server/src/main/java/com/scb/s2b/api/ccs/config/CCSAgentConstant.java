package com.scb.s2b.api.ccs.config;

public interface CCSAgentConstant {

    String CHANNEL_API = "API";
    String OUTBOUND_PAYLOAD_FORMAT_ACK3 = "ACK3";
    String OUTBOUND_PAYLOAD_FORMAT_REJ3 = "REJ3";
    String OUTBOUND_PAYLOAD_FORMAT_DUPL = "DUPL";

    String CALLBACK_ENDPOINT_HEADER = "CCSCallbackEndpoint";

    String IMPORT_RETRY_HEADER = "CCSImport.retry";
    String CCS_IMPORT_SUSPEND_TO_HEADER = "CCSImport.SuspendTo";

    String ENTITY_TYPE_CCS_INBOUND_MSG = "ccs_inbound_message";
    String ENTITY_TYPE_CCS_OUTBOUND_MSG = "ccs_outbound_message";

    String SYSTEM = "SYSTEM";
    String CCS_ENDPOINT_SUFFIX = "_CCS_ENDPOINT";

    String TAG_CCS_IMPORT = "ccsImport";
    String TAG_DEF_CALLBACK = "defaultCallback";
}

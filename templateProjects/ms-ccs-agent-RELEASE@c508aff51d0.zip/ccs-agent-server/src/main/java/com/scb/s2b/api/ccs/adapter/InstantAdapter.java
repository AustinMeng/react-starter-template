package com.scb.s2b.api.ccs.adapter;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import javax.xml.bind.annotation.adapters.XmlAdapter;

public class InstantAdapter extends XmlAdapter<String, Instant> {

    private static final String PATTERN = "yyyy-MM-dd HH:mm:ss";

    @Override
    public Instant unmarshal(String text) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(PATTERN);
        return LocalDateTime.parse(text, formatter).atZone(ZoneId.of("Asia/Hong_Kong")).toInstant();
    }

    @Override
    public String marshal(Instant instant) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(PATTERN);
        return LocalDateTime.ofInstant(instant, ZoneId.of("Asia/Hong_Kong")).format(formatter);
    }
}

package com.scb.s2b.api.ccs.repository.agent;

import com.scb.s2b.api.ccs.model.agent.MetaDescriptor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaRepository extends JpaRepository<MetaDescriptor, String> {
    MetaDescriptor findTop1ByGroupIdAndNameOrderByVersionDesc(String groupId, String name);
}

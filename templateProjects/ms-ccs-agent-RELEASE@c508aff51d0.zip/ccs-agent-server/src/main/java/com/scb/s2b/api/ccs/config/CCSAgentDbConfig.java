package com.scb.s2b.api.ccs.config;


import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.util.Objects;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SuppressWarnings("unused")
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = "com.scb.s2b.api.ccs.repository.agent",
        entityManagerFactoryRef = "ccsAgentEntityManagerFactory",
        transactionManagerRef = "ccsAgentTransactionManager"
)
public class CCSAgentDbConfig {

    @Bean(name = "ccsAgentDataSourceProps")
    @ConfigurationProperties("datasource.ccsagent")
    public HikariConfig ccsAgentDataSourceProperties() {
        return new HikariConfig();
    }

    @Bean(name = "ccsAgentDataSource")
    public DataSource dataSource(@Qualifier("ccsAgentDataSourceProps") HikariConfig dataSourceProperties) {
        return new HikariDataSource(dataSourceProperties);
    }

    @Bean(name = "ccsAgentEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean ccsAgentEntityManagerFactory(
            @Qualifier("ccsAgentDataSource") DataSource dataSource, EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(dataSource)
                .packages("com.scb.s2b.api.ccs.model.agent")
                .persistenceUnit("ccsAgentPersistenceUnit")
                .build();
    }

    @Bean(name = "ccsAgentTransactionManager")
    public PlatformTransactionManager ccsAgentTxManager(
            @Qualifier("ccsAgentEntityManagerFactory") LocalContainerEntityManagerFactoryBean entityManagerFactory) {
        return new JpaTransactionManager(Objects.requireNonNull(entityManagerFactory.getObject()));
    }

}

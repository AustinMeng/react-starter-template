package com.scb.s2b.api.ccs.entity;

import com.scb.s2b.api.ccs.adapter.InstantAdapter;
import java.math.BigInteger;
import java.time.Instant;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(name = "RequestMessage")
@XmlAccessorType(XmlAccessType.FIELD)
public class RequestMessage {

    public static final String API_INBOUND_SERVICE = "API_INBOUND_SERVICE";

    @XmlElement(name = "ReferenceKey")
    private ReferenceKey referenceKey;

    @XmlElement(name = "ServiceName")
    private String serviceName;

    @XmlElement(name = "Priority")
    private String priority;

    @XmlElement(name = "CreatedDate")
    @XmlJavaTypeAdapter(InstantAdapter.class)
    @Builder.Default
    private Instant instant = Instant.now();

    @SuppressWarnings("unused")
    public static RequestMessage assembleRequestMessage(BigInteger id, Priority priority, String serviceName) {
        KeyValue keyValue = KeyValue.builder().id(id).build();
        return RequestMessage.builder().referenceKey(ReferenceKey.builder().keyValue(keyValue).build())
                .priority(priority.code())
                .serviceName("API_INBOUND_SERVICE")
                .build();
    }

    @SuppressWarnings("unused")
    public enum Priority {
        single("500"), bulk("100");
        private final String code;

        Priority(String code) {
            this.code = code;
        }

        public String code() {
            return code;
        }
    }
}

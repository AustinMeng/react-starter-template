package com.scb.s2b.api.ccs.route;

public abstract class RouteHandler {

    public String getRoute(String noun, String format, String groupId, String filename) {
        return getEndpoint(noun, format, groupId, filename);
    }

    public abstract void setNext(RouteHandler next);

    protected abstract RouteHandler getNext();

    protected abstract String getEndpointInt(String noun, String format, String groupId, String filename);

    private String getEndpoint(String noun, String format, String groupId, String filename) {
        String endpoint = this.getEndpointInt(noun, format, groupId, filename);

        if(endpoint == null && getNext() != null) {
            return getNext().getEndpoint(noun, format, groupId, filename);
        }

        return endpoint;
    }
}

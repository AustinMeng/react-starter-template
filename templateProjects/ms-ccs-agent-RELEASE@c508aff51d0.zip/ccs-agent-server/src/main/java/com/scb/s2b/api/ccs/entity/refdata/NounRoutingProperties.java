package com.scb.s2b.api.ccs.entity.refdata;

import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class NounRoutingProperties {

    private Map<String, FormatRoutingProperties> formats = new HashMap<>();

}

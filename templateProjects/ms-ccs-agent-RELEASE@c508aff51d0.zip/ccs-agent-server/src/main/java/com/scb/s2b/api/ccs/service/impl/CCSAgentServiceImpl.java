package com.scb.s2b.api.ccs.service.impl;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.ENTITY_TYPE_CCS_OUTBOUND_MSG;

import com.scb.s2b.api.ccs.camel.KafkaProducerAdapter;
import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.ccs.entity.OutboundMessageStatus;
import com.scb.s2b.api.ccs.entity.PayloadEntity;
import com.scb.s2b.api.ccs.entity.RequestMessage;
import com.scb.s2b.api.ccs.entity.RequestMessage.Priority;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.ccs.marshaller.XmlMessageMarshaller;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessage;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessageRoute;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRepository;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRouteRepository;
import com.scb.s2b.api.ccs.repository.mailbox.CCSMailBoxInboundRepository;
import com.scb.s2b.api.ccs.route.RouteHandler;
import com.scb.s2b.api.ccs.service.CCSAgentService;
import com.scb.s2b.api.ccs.service.CCSOutboundMessageService;
import com.scb.s2b.api.ccs.transformer.CCSMailBoxTransformer;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
public class CCSAgentServiceImpl implements CCSAgentService {

    private final CCSMailBoxInboundRepository ccsMailBoxInboundRepository;

    private final CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository;

    private final CCSAgentMessageRepository ccsAgentMessageRepository;

    private final CCSMailBoxTransformer ccsMailBoxTransformer;

    private final ProducerTemplate producer;

    private final String ccsInboundAQEndpoint;

    private final XmlMessageMarshaller xmlMessageMarshaller;

    private final JsonMessageMarshaller jsonMessageMarshaller;

    private final KafkaProducerAdapter kafkaProducer;

    private final Map<String, Function<byte[], PayloadEntity>> payloadProcessors;

    private final CCSOutboundMessageService ccsOutboundMessageService;

    private final RouteHandler routeHandler;

    public CCSAgentServiceImpl(CCSMailBoxInboundRepository ccsMailBoxInboundRepository,
            CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository,
            CCSAgentMessageRepository ccsAgentMessageRepository,
            CCSMailBoxTransformer ccsMailBoxTransformer,
            ProducerTemplate producer,
            String ccsInboundAQEndpoint,
            XmlMessageMarshaller xmlMessageMarshaller,
            JsonMessageMarshaller jsonMessageMarshaller,
            KafkaProducerAdapter kafkaProducer,
            Map<String, Function<byte[], PayloadEntity>> payloadProcessors,
            CCSOutboundMessageService ccsOutboundMessageService,
            RouteHandler routeHandler) {
        this.ccsMailBoxInboundRepository = ccsMailBoxInboundRepository;
        this.ccsAgentMessageRouteRepository = ccsAgentMessageRouteRepository;
        this.ccsAgentMessageRepository = ccsAgentMessageRepository;
        this.ccsMailBoxTransformer = ccsMailBoxTransformer;
        this.producer = producer;
        this.ccsInboundAQEndpoint = ccsInboundAQEndpoint;
        this.xmlMessageMarshaller = xmlMessageMarshaller;
        this.jsonMessageMarshaller = jsonMessageMarshaller;
        this.kafkaProducer = kafkaProducer;
        this.payloadProcessors = payloadProcessors;
        this.ccsOutboundMessageService = ccsOutboundMessageService;
        this.routeHandler = routeHandler;
    }

    @Override
    @Transactional(transactionManager = "oracleTransactionManager")
    public CCSMailBoxInbound persistCCSInboundMessage(CCSAgentInboundIns ccsAgentInboundIns) {
        return ccsMailBoxInboundRepository
                .save(ccsMailBoxTransformer.ccsAgentInsToMailBoxInbound(ccsAgentInboundIns));
    }

    @Override
    public CCSMailBoxInbound getCCSInboundMessage(String fileName) {
        return ccsMailBoxInboundRepository.findCCSMailBoxInboundByFileName(fileName);
    }

    @Override
    public void publishInboundMessage(BigInteger id) {
        String message = xmlMessageMarshaller.marshallToString(RequestMessage.assembleRequestMessage(id,
                Priority.single, RequestMessage.API_INBOUND_SERVICE));
        producer.sendBody(ccsInboundAQEndpoint, message);
        log.info("Inbound AQ Message {} has been sent", message);
    }

    @Override
    @Transactional(transactionManager = "oracleTransactionManager")
    public void processCCSOutboundMessage(BigInteger id) {
        log.info("Process ccs out bound message for messageId={}", id);
        Optional<CCSMailBoxOutbound> outBoundOptional = ccsOutboundMessageService.findOutboundById(id);
        if (!outBoundOptional.isPresent()) {
            log.warn("invalid out bound message id {}", id);
            return;
        }
        CCSMailBoxOutbound outboundMessage = outBoundOptional.get();
        try {
            ccsOutboundMessageService.updateOutboundMessageStatus(outboundMessage, OutboundMessageStatus.IN_PROGRESS);
            // parse payload
            String rawPayload = new String(outboundMessage.getPayload(), StandardCharsets.UTF_8);
            log.info("Processing format={}, rawPayload={}.", outboundMessage.getFormat(), rawPayload);
            PayloadEntity payload = payloadProcessors.getOrDefault(outboundMessage.getFormat(), bytes -> null)
                    .apply(outboundMessage.getPayload());
            // transform outbound message
            CCSAgentOutboundIns instruction = ccsMailBoxTransformer
                    .mailBoxOutboundToCCSAgentOutboundIns(outboundMessage, payload);

            //Audit outbound message
            CCSAgentMessage ccsAgentMessage = CCSAgentMessage.builder()
                    .messageId(Optional.ofNullable(instruction.getFilename()).orElse(
                            UUID.randomUUID().toString()))
                    .entityType(ENTITY_TYPE_CCS_OUTBOUND_MSG)
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .content(jsonMessageMarshaller.marshallToJsonString(instruction))
                    .build();
            persistCCSAgentMessage(ccsAgentMessage);

            kafkaProducer.publishCCSAgentOutboundIns(instruction, callbackForOutboundIns(instruction));
            ccsOutboundMessageService.updateOutboundMessageStatus(outboundMessage, OutboundMessageStatus.PROCESSED);
        } catch (Exception e) {
            log.error("Failed to process outbound message.", e);
            ccsOutboundMessageService.updateOutboundMessageStatus(outboundMessage, OutboundMessageStatus.REJECTED);
        }
    }

    @Override
    @Transactional(transactionManager = "ccsAgentTransactionManager")
    public void persistCCSAgentMessageRoute(CCSAgentInboundIns ccsAgentInboundIns, String callback) {
        CCSAgentMessageRoute ccsAgentMessageRoute = CCSAgentMessageRoute.builder()
                .callback(callback).fileName(ccsAgentInboundIns.getFileName())
                .noun(ccsAgentInboundIns.getNoun()).build();
        ccsAgentMessageRouteRepository.save(ccsAgentMessageRoute);
    }

    @Override
    public boolean isCCSAgentMsgRouteExisted(String fileName, String noun) {
        return ccsAgentMessageRouteRepository.existsCCSAgentMessageRouteByFileNameAndNoun(fileName, noun);
    }

    @Override
    public void publishExceptionTOCallback(CCSAgentInboundIns ccsAgentInboundIns, String callback, String format) {
        log.info("Exception happened and send REJ3 to callback={} for filename={}", callback,
                ccsAgentInboundIns.getFileName());
        CCSAgentOutboundIns instruction = CCSAgentOutboundIns.builder()
                .noun(ccsAgentInboundIns.getNoun())
                .format(format)
                .groupId(ccsAgentInboundIns.getGroupId())
                .filename(ccsAgentInboundIns.getFileName())
                .build();
        kafkaProducer.publishCCSAgentOutboundIns(instruction, callback);
    }

    @Override
    public void persistCCSAgentMessage(CCSAgentMessage ccsAgentMessage) {
        ccsAgentMessageRepository.save(ccsAgentMessage);
    }

    private String callbackForOutboundIns(CCSAgentOutboundIns outboundIns) {
        String groupId = outboundIns.getGroupId();
        String umi = outboundIns.getUmi();
        String noun = outboundIns.getNoun();
        String format = outboundIns.getFormat();
        String filename = outboundIns.getFilename();
        String endpoint = routeHandler.getRoute(noun, format, groupId, filename);

        log.info("Get endpoint={} for outbound ins groupId={}, umi={}, noun={}, format={}, filename={}",
                endpoint, groupId, umi, noun, format, filename);
        return endpoint;
    }
}

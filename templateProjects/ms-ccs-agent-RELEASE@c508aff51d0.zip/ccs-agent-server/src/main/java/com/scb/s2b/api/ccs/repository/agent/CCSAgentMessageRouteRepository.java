package com.scb.s2b.api.ccs.repository.agent;

import com.scb.s2b.api.ccs.model.agent.CCSAgentMessageRoute;
import java.math.BigInteger;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

public interface CCSAgentMessageRouteRepository extends JpaRepository<CCSAgentMessageRoute, BigInteger> {

    CCSAgentMessageRoute findByFileName(String fileName);

    boolean existsCCSAgentMessageRouteByFileName(@Param("fileName") String fileName);

    boolean existsCCSAgentMessageRouteByFileNameAndNoun(@Param("fileName") String fileName, @Param("noun") String noun);
}

package com.scb.s2b.api.ccs.route;

import com.google.common.base.Strings;
import com.scb.s2b.api.ccs.entity.refdata.CountryRoutingProperties;
import com.scb.s2b.api.ccs.entity.refdata.FormatRoutingProperties;
import com.scb.s2b.api.ccs.entity.refdata.NounRoutingProperties;
import com.scb.s2b.api.ccs.entity.refdata.RoutingProperties;
import com.scb.s2b.api.ccs.service.ReferenceDataService;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class MetaRouteHandler extends RouteHandler {

    private final ReferenceDataService referenceDataService;

    private RouteHandler next;

    public MetaRouteHandler(ReferenceDataService referenceDataService) {
        this.referenceDataService = referenceDataService;
    }

    @Override
    public void setNext(RouteHandler next) {
        this.next = next;
    }

    @Override
    protected RouteHandler getNext() {
        return next;
    }

    @Override
    protected String getEndpointInt(String noun, String format, String groupId, String filename) {
        String endpoint = null;

        try {
            RoutingProperties routingProps = referenceDataService.getRoutingProperties();
            String countyCode = referenceDataService.getCountryCodeByGroupId(groupId);

            if (routingProps != null && routingProps.getNouns() != null) {
                Map<String, NounRoutingProperties> nouns = routingProps.getNouns();

                if (nouns.containsKey(noun)) {
                    NounRoutingProperties nounProperties = nouns.get(noun);

                    if (nounProperties.getFormats() != null && nounProperties.getFormats().containsKey(format)) {
                        FormatRoutingProperties formatProperties = nounProperties.getFormats().get(format);
                        CountryRoutingProperties countryRoutingProperties = formatProperties.getCountries().get(countyCode);
                        List exclusionGroups = Collections.emptyList();
                        if(countryRoutingProperties != null && countryRoutingProperties.getExclusionGroups() != null) {
                            exclusionGroups = countryRoutingProperties.getExclusionGroups();
                        }
                        if (formatProperties.getGroups() != null) {
                            endpoint = formatProperties.getGroups().get(groupId);
                        }
                        if (endpoint == null && StringUtils.isNotBlank(countyCode)
                                && !exclusionGroups.contains(groupId)) {
                            endpoint = countryRoutingProperties.getEndPoint();
                        }
                    }
                }
            }
        } catch(Throwable ex) {
            log.error("Failed to generate endpoint from meta: {}", ex.getMessage());
        }

        if (StringUtils.isNotBlank(endpoint)) {
            log.info("Generating endpoint from meta for noun={}, format={}, group={}", noun, format, groupId);
        }

        return Strings.emptyToNull(endpoint);
    }
}

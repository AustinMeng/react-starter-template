create table ccs_agent.ccs_agent_message_route (
    id                              bigserial   NOT NULL,
    callback                        text,
    filename                        text        NOT NULL,
    noun                            text        NOT NULL,
    createddate                     timestamp   NOT NULL,
    PRIMARY KEY(id)
);
CREATE UNIQUE INDEX uniq_ccs_amr_index1 ON ccs_agent.ccs_agent_message_route(filename, noun);
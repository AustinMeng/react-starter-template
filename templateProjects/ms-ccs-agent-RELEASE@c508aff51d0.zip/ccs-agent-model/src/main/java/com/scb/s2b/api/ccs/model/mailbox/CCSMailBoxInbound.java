package com.scb.s2b.api.ccs.model.mailbox;


import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ccs_api_mailbox_inbound", schema = "CC_CCS_S2BCCSQ")
public class CCSMailBoxInbound {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(generator = "CCSInboundIDGenerator")
    @GenericGenerator(name = "CCSInboundIDGenerator", strategy = "com.scb.s2b.api.ccs.model.generator.CCSIDGenerator", parameters = {
            @Parameter(name = "sequence_name", value = "CC_CCS_S2BCCSQ.SEQ_API_MAILBOX_INBOUND"),
            @Parameter(name = "initial_value", value = "1"),
            @Parameter(name = "increment_size", value = "1")
    })
    private BigInteger id;

    @Column(name = "umi")
    private String umi;

    @Column(name = "source", nullable = false)
    private String source;

    @Column(name = "noun", nullable = false)
    private String noun;

    @Column(name = "format", nullable = false)
    private String format;

    @Column(name = "grpid", nullable = false)
    private String grpId;

    @Column(name = "filename", nullable = false)
    private String fileName;

    @Column(name = "file_size", nullable = false)
    private BigInteger fileSize;

    @Lob
    @Basic(fetch = FetchType.EAGER)
    @Column(name = "payload", columnDefinition = "BLOB", nullable = false)
    private byte[] payload;

    @Column(name = "status", nullable = false)
    private Integer status;

    @Column(name = "createdby", nullable = false)
    @Default
    private String createdBy = "API";

    @Column(name = "createddate", nullable = false)
    @Default
    private Timestamp createdDate = Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Hong_Kong")));

    @Column(name = "modifiedby")
    private Timestamp modifiedBy;

    @Column(name = "modifieddate", nullable = false)
    @Default
    private Timestamp modifiedDate = Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Hong_Kong")));
}

package com.scb.s2b.api.ccs.model.agent;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ccs_agent_message_route", schema = "CC_API_CCS_AGENT")
public class CCSAgentMessageRoute {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    @Column(name = "callback")
    private String callback;

    @Column(name = "filename", nullable = false)
    private String fileName;

    @Column(name = "noun", nullable = false)
    private String noun;

    @Column(name = "createddate", nullable = false)
    @Default
    private Timestamp createdDate = Timestamp.from(Instant.now());

}

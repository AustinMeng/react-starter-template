package com.scb.s2b.api.payment.model;

import java.math.BigInteger;
import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "additional_credit_trans_info", schema = "payment",
        indexes = {
                @Index(name = "act_index1", columnList = "payment_txn_id"),
                @Index(name = "uniq_act_index2", columnList = "additional_id", unique = true)
        }
)
public class AdditionalCreditTransInfo {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id ;

    @Column(name = "additional_id", nullable = false)
    private String additionalId;

    @Column(name = "credit_trans_txn_id")
    private String creditTransTxnId;

    @Column(name = "message_id")
    private String messageId;

    @Column(name = "tracking_id")
    private String trackingId;

    @Column(name = "id_type")
    private String idType;

    @Column(name = "timestamp", nullable = false)
    private Instant timestamp;

    @ManyToOne(targetEntity = PaymentTxn.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "payment_txn_id", referencedColumnName = "id", nullable = false)
    private PaymentTxn paymentTxn;
}

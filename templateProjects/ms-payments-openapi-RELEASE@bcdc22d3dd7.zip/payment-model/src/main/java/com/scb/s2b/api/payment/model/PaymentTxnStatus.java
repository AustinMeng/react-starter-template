package com.scb.s2b.api.payment.model;

import lombok.*;

import javax.persistence.*;
import java.math.BigInteger;
import java.time.Instant;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "payment_txn_status", schema = "payment",
    indexes = {
        @Index(name = "pts_index1", columnList = "group_id, client_reference_id"),
        @Index(name = "pts_index2", columnList = "payment_txn_id"),
        @Index(name = "pts_index3", columnList = "group_id, end_to_end_id"),
        @Index(name = "pts_index4", columnList = "tracking_id")
    }
)
public class PaymentTxnStatus {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    @Column(name = "group_id", nullable = false)
    private String groupId;

    @Column(name = "client_reference_id", nullable = false)
    private String clientReferenceId;

    @Column(name = "end_to_end_id", nullable = false)
    private String endToEndId;

    @Column(name = "tracking_id", nullable = false)
    private String trackingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_txn_id", referencedColumnName = "id", nullable = false)
    private PaymentTxn paymentTxn;

    @Column(name = "message_id")
    private String messageId;

    @Column(name = "status_code")
    private String statusCode;

    @Column(name = "status_string")
    private String statusString;

    @Column(name = "reason_code")
    private String reasonCode;

    @Column(name = "reason_info")
    private String reasonInfo;

    @Column(name = "last_assignee")
    private String lastAssignee;

    @Column(name = "payload", nullable = false)
    private String payload;

    @Column(name = "timestamp", nullable = false)
    private Instant timestamp;
}

CREATE TABLE payment.payment_txn_status (
    id                              bigserial   NOT NULL,
    group_id                        text        NOT NULL,
    client_reference_id             text        NOT NULL,
    end_to_end_id                   text        NOT NULL,
    tracking_id                     text        NOT NULL,
    payment_txn_id                  bigint      NOT NULL references payment.payment_txn(id),
    message_id                      text,
    status_code                     text,
    status_string                   text,
    reason_code                     text,
    reason_info                     text,
    last_assignee                   text,
    timestamp                       timestamp   NOT NULL,
    payload                         jsonb       NOT NULL,
    PRIMARY KEY(id)
);

CREATE INDEX pts_index1 ON payment.payment_txn_status (group_id, client_reference_id);
CREATE INDEX pts_index2 ON payment.payment_txn_status (payment_txn_id);
CREATE INDEX pts_index3 ON payment.payment_txn_status (group_id, end_to_end_id);
CREATE INDEX pts_index4 ON payment.payment_txn_status (tracking_id);
create table payment.payment_txn (
    id                              bigserial   NOT NULL,
    request_id                      text,
    group_id                        text        NOT NULL,
    client_reference_id             text        NOT NULL,
    batch_id                        text,
    message_id                      text        NOT NULL,
    timestamp                       timestamp   NOT NULL,
    payload                         jsonb       NOT NULL,
    required_execution_date         date        NOT NULL,
    PRIMARY KEY(id)
);
CREATE UNIQUE INDEX uniq_pt_index1 ON payment.payment_txn (group_id, client_reference_id);
CREATE INDEX pt_index2 ON payment.payment_txn (request_id);
CREATE INDEX pt_index3 ON payment.payment_txn (group_id, batch_id);
CREATE INDEX pt_index4 ON payment.payment_txn (group_id, timestamp);
CREATE INDEX pt_index5 ON payment.payment_txn (group_id, required_execution_date);
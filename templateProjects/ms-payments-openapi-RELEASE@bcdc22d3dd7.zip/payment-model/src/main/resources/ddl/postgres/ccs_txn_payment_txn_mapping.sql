create table payment.ccs_txn_payment_txn_mapping (
    ccs_txn_id                      bigint   NOT NULL references payment.ccs_txn(id),
    payment_txn_id                  bigint   NOT NULL references payment.payment_txn(id),
    PRIMARY KEY(ccs_txn_id, payment_txn_id)
);
CREATE INDEX ccs_payment_index1 ON payment.ccs_txn_payment_txn_mapping(ccs_txn_id);
CREATE UNIQUE INDEX uniq_ccs_payment_index2 ON payment.ccs_txn_payment_txn_mapping(payment_txn_id);
CREATE TABLE payment.runtime_property (
    id                bigserial    NOT NULL,
    name              text         NOT NULL,
    value             text         NOT NULL,
    message_id        text         NOT NULL,
    updated_time      timestamp    NOT NULL,
    PRIMARY KEY(id)
);

CREATE UNIQUE INDEX uniq_rp_index1 ON payment.runtime_property (name);

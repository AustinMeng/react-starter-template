CREATE TABLE if not exists payment.id_seq (
    id                              bigserial        NOT NULL,
    group_id                        varchar(10)      NOT NULL,
    payment_type                    varchar(10)      NOT NULL,
    seq_range                       bigint           NOT NULL,
    PRIMARY KEY(id)
);

CREATE UNIQUE INDEX uniq_is_index1 ON payment.id_seq (group_id, payment_type);

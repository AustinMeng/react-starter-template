CREATE TABLE if not exists payment.additional_credit_trans_info (
    id                              bigserial        NOT NULL,
    additional_id                   text             NOT NULL,
    payment_txn_id                  bigint           NOT NULL references payment.payment_txn(id),
    credit_trans_txn_id             text,
    message_id                      text,
    tracking_id                     text,
    id_type                         text,
    timestamp                       timestamp        NOT NULL,
    PRIMARY KEY(id)
);
CREATE INDEX if not exists act_index1 ON payment.additional_credit_trans_info (payment_txn_id);
CREATE UNIQUE INDEX if not exists uniq_act_index2 ON payment.additional_credit_trans_info (additional_id);
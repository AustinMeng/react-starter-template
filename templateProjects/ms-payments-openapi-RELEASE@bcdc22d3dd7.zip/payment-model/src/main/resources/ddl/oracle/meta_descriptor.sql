create table payment.meta_descriptor(
    id                        varchar2(60)        NOT NULL,
    group_id                  varchar2(15)        NOT NULL,
    name                      varchar2(255)       NOT NULL,
    version                   number(10)          NOT NULL,
    change_reference          varchar2(30),
    comments                  varchar2(255),
    frozen_values             clob                NOT NULL,
    previous_version_id       varchar2(60),
    timestamp                 timestamp           NOT NULL,
    PRIMARY KEY(id),
    UNIQUE(group_id, name, version)
);
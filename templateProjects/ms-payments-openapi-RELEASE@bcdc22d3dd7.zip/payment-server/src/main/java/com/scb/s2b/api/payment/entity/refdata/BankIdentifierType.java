package com.scb.s2b.api.payment.entity.refdata;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class BankIdentifierType implements Serializable {

    private String bankCodeType;

    private int length;

    private List<String> paymentTypes;
}

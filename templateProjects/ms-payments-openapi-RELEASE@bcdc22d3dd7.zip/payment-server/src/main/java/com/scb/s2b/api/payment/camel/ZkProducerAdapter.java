package com.scb.s2b.api.payment.camel;

import com.scb.s2b.api.payment.config.property.ScpayProperties;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;

@Slf4j
public class ZkProducerAdapter {

    private final String signOnOffNotificationEndpoint;

    private final String bankDefaultBroadcastNotificationEndpoint;

    private final String bankStatusBroadcastNotificationEndpoint;

    private final String systemStatusBroadcastNotificationEndpoint;

    private final String bankStatusBroadcastForPHNotificationEndpoint;

    private final ProducerTemplate producer;

    public ZkProducerAdapter(String zkBrokers,
            ScpayProperties scpayProperties, ProducerTemplate producer) {
        this.signOnOffNotificationEndpoint = String.format(scpayProperties.getNotification().getSignOnOff().getNotificationTemplate(), zkBrokers);
        this.bankDefaultBroadcastNotificationEndpoint = String.format(scpayProperties.getNotification().getBankDefaultBroadcast().getNotificationTemplate(), zkBrokers);
        this.bankStatusBroadcastNotificationEndpoint = String.format(scpayProperties.getNotification().getBankStatusBroadcast().getNotificationTemplate(), zkBrokers);
        this.systemStatusBroadcastNotificationEndpoint = String.format(scpayProperties.getNotification().getSystemStatusBroadcast().getNotificationTemplate(), zkBrokers);
        this.bankStatusBroadcastForPHNotificationEndpoint = String.format(scpayProperties.getNotification().getBankStatusBroadcastPH().getNotificationTemplate(), zkBrokers);
        this.producer = producer;
    }

    public void publishSignOnOffNotification(String messageId) {
        log.info("Publishing maintenance notification for referenceId={}", messageId);
        byte[] bytes = messageId.getBytes(StandardCharsets.UTF_8);
        producer.sendBody(signOnOffNotificationEndpoint, bytes);
    }

    public void publishBankDefaultBroadcastNotification(String messageId) {
        log.info("Publishing bank default broadcast notification for referenceId={}", messageId);
        byte[] bytes = messageId.getBytes(StandardCharsets.UTF_8);
        producer.sendBody(bankDefaultBroadcastNotificationEndpoint, bytes);
    }

    public void publishBankStatusBroadcastNotification(String messageId) {
        log.info("Publishing bank status broadcast notification for referenceId={}", messageId);
        byte[] bytes = messageId.getBytes(StandardCharsets.UTF_8);
        producer.sendBody(bankStatusBroadcastNotificationEndpoint, bytes);
    }

    public void publishSystemStatusBroadcastNotification(String messageId) {
        log.info("Publishing system status broadcast notification for referenceId={}", messageId);
        byte[] bytes = messageId.getBytes(StandardCharsets.UTF_8);
        producer.sendBody(systemStatusBroadcastNotificationEndpoint, bytes);
    }

    public void publishBankStatusBroadcastForPHNotification(String messageId) {
        log.info("Publishing bank status broadcast for ph notification for referenceId={}", messageId);
        byte[] bytes = messageId.getBytes(StandardCharsets.UTF_8);
        producer.sendBody(bankStatusBroadcastForPHNotificationEndpoint, bytes);
    }
}

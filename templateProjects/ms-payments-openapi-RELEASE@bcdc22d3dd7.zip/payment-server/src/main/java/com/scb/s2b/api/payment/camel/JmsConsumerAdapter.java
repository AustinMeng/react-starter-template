package com.scb.s2b.api.payment.camel;

import static com.scb.s2b.api.payment.config.PaymentConstant.ENTITY_TYPE_NOTIFICATION_REQ;
import static com.scb.s2b.api.payment.config.PaymentConstant.ENTITY_TYPE_SCPAY_BENE_ACK;
import static com.scb.s2b.api.payment.config.PaymentConstant.ENTITY_TYPE_SCPAY_PAY_ACK;
import static com.scb.s2b.api.payment.config.PaymentConstant.ENTITY_TYPE_SCPAY_PRXY_ACK;
import static com.scb.s2b.api.payment.util.AdapterUtil.isDupException;

import com.scb.s2b.api.payment.camel.notification.processor.SNMNotificationProcessor;
import com.scb.s2b.api.payment.entity.scpay.beneficiary.response.BeneRes;
import com.scb.s2b.api.payment.entity.scpay.initiate.response.PaymentRes;
import com.scb.s2b.api.payment.entity.scpay.initiate.response.data.Data;
import com.scb.s2b.api.payment.entity.scpay.initiate.response.data.PmtId;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.proxy.response.ProxyLookupRes;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.PaymentStatusService;
import com.scb.s2b.api.payment.util.IdGenerator;
import com.scb.s2b.api.payment.validation.DBPersistenceException;
import com.scb.s2b.api.payment.validation.NoSuchInstructionException;
import java.util.Optional;
import javax.persistence.PersistenceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

public class JmsConsumerAdapter {

    private final PaymentStatusService paymentStatusService;

    private final JsonMessageMarshaller messageMarshaller;

    private final SNMNotificationProcessor notificationProcessor;

    private final IdGenerator idGenerator;

    private static final Logger logger = LoggerFactory.getLogger(JmsConsumerAdapter.class);

    public JmsConsumerAdapter(PaymentStatusService paymentStatusService, JsonMessageMarshaller messageMarshaller,
            SNMNotificationProcessor notificationProcessor, IdGenerator idGenerator) {
        this.paymentStatusService = paymentStatusService;
        this.messageMarshaller = messageMarshaller;
        this.notificationProcessor = notificationProcessor;
        this.idGenerator = idGenerator;
    }

    public void consumeScpayPaymentStatus(PaymentRes paymentRes) {
        String message = messageMarshaller.marshallToJsonString(paymentRes);
        String messageId = idGenerator.messageId();

        logger.info("Received Scpay PaymentStatus messageId={}, originalMessageId={}",
                messageId, paymentRes.getResult().getMsgId());
        paymentRes.getResult().setMsgId(messageId);

        String trackingId = Optional.ofNullable(paymentRes.getData()).map(Data::getPmtId).map(PmtId::getUETR)
                .orElse(null);
        try {
            if(paymentStatusService.checkPaymentByTrackingId(trackingId)) {
                paymentStatusService
                        .persistPaymentMessage(message, ENTITY_TYPE_SCPAY_PAY_ACK, paymentRes.getResult().getMsgId());
                paymentStatusService.processScpayPaymentStatus(paymentRes);
            } else {
                String errMsg = "No Payment found for paymentRes messageId=" + messageId + ", trackingId=" + trackingId;
                throw new NoSuchInstructionException(errMsg);
            }
        } catch (Throwable ex) {
            handleException(ex, "PaymentStatus", messageId);
        }
    }

    public void consumeBeneResponse(BeneRes beneRes) {
        String message = messageMarshaller.marshallToJsonString(beneRes);

        String messageId = idGenerator.messageId();
        logger.info("Received Scpay Beneficiary Response messageId={}, originalMessageId={}",
                messageId, beneRes.getResult().getMsgId());

        beneRes.getResult().setMsgId(messageId);

        String trackingId = Optional.ofNullable(beneRes.getData())
                .map(com.scb.s2b.api.payment.entity.scpay.beneficiary.response.data.Data::getPmtId)
                .map(com.scb.s2b.api.payment.entity.scpay.beneficiary.response.data.PmtId::getUETR)
                .orElse(null);

        try {
            if(paymentStatusService.checkPaymentByAdditionalId(trackingId)) {
                paymentStatusService
                        .persistPaymentMessage(message, ENTITY_TYPE_SCPAY_BENE_ACK, messageId);
                paymentStatusService.processBeneficiaryResponse(beneRes);
            } else {
                String errMsg = "No Payment found for beneRes messageId=" + messageId + ", trackingId=" + trackingId;
                throw new NoSuchInstructionException(errMsg);            }
        } catch (Throwable ex) {
            handleException(ex, "BeneResponse", messageId);
        }
    }

    public void consumeProxylookupResponse(ProxyLookupRes proxyLookupRes) {
        String message = messageMarshaller.marshallToJsonString(proxyLookupRes);
        String messageId = idGenerator.messageId();

        logger.info("Received proxyLookup Response messageId={}, trackingId={}", messageId,
                proxyLookupRes.getResult().getOrgnlId());
        String additional = Optional.ofNullable(proxyLookupRes.getResult())
                .map(com.scb.s2b.api.payment.entity.scpay.proxy.response.result.Result::getOrgnlId)
                .orElse(null);
        try {
            if(paymentStatusService.checkPaymentByAdditionalId(additional)) {
                paymentStatusService
                        .persistPaymentMessage(message, ENTITY_TYPE_SCPAY_PRXY_ACK, messageId);
                paymentStatusService.processProxyLookupRes(messageId, proxyLookupRes);
            }else {
                String errMsg = "No Payment found for proxy lookup response messageId=" + messageId + ", additionalId="
                        + additional;
                throw new NoSuchInstructionException(errMsg);
            }
        } catch (Throwable ex) {
            handleException(ex, "Proxy Lookup Response", messageId);
        }
    }

    public void receiveNotification(Notification notification) {
        try {
            String messageId = notification.getHeader().getMessageId();
            String message = messageMarshaller.marshallToJsonString(notification);
            logger.info("Received notification messageId={}.", messageId);
            notificationProcessor.persistNotificationMessage(message, ENTITY_TYPE_NOTIFICATION_REQ, messageId);
            notificationProcessor.processingNotification(notification);
        } catch (Throwable e) {
            logger.error("Error processing notification", e);
        }
    }

    private void handleException(Throwable e, String resType, String messageId) throws RuntimeException {
        if (e instanceof PersistenceException || e instanceof org.springframework.transaction.TransactionException
                || e instanceof DataAccessException) {
            if (isDupException(e)) {
                logger.warn("Ignore duplicated messageId={}", messageId);
            } else {
                logger.error("Error processing SCPay {} to be retried: ", resType, e);
                throw new DBPersistenceException(e.getMessage());
            }
        } else if (e instanceof NoSuchInstructionException) {
            logger.info(e.getMessage());
            throw new NoSuchInstructionException(e.getMessage());
        } else {
            logger.error("Error processing SCPay BeneResponse", e);
        }
    }
}

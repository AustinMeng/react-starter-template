package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.PaymentRequestValidator;
import java.util.Map;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public abstract class FastPaymentApiBase extends ApiBase{
    private final PaymentRequestValidator paymentRequestValidator;

    private final RequestProcessor requestProcessor;

    private final OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;

    private final PaymentService paymentService;

    public Response paymentInitiate(String preVerified, OpenApiPaymentInstruction body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);
        log.info("PaymentInitiate requestId={}, groupId={}, clientReferenceId={}", requestId, groupId,
                body.getInstruction().getReferenceId());

        paymentRequestValidator.validate(groupId, body);
        Map<String, String> headersMap = this.getHeaders(headers);

        boolean isPreVerified = "true".equalsIgnoreCase(preVerified);
        PaymentInstruction paymentInstruction = openApiPaymentInstructionTransformer
                .toPaymentInstruction(body, isPreVerified, headersMap);

        requestProcessor.process(paymentInstruction);
        paymentService.initiate(paymentInstruction);
        paymentRequestValidator.cache(paymentInstruction);

        OpenApiPaymentId openApiPaymentId = openApiPaymentInstructionTransformer.toOpenApiPaymentId(paymentInstruction);

        return Response.ok(openApiPaymentId).build();
    }
}

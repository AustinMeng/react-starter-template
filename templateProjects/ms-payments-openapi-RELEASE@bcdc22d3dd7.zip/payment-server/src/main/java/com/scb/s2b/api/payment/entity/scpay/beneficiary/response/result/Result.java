
package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.result;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "txCtry",
    "instgChanl",
    "instgSubChanl",
    "msgId",
    "creDtTm",
    "nbOfTxs",
    "ctrlSum",
    "prePrcr",
    "payrollInd",
    "pmtTp",
    "subPmtTp",
    "instrPrty",
    "cdtDbtInd",
    "clrMsgTp",
    "clrMd",
    "vrsnNb",
    "prtryLclInstrm",
    "txSts",
    "prcgDt",
    "prcgSts",
    "prcgSubSts",
    "btchBookg",
    "svcNm",
    "subSvcNm",
    "txEvtSts",
    "txEvtCd",
    "actnTp",
    "brnchCd",
    "txRcvdDtTm",
    "tellerId",
    "applNm",
    "chanlCutOffInd",
    "replayInd",
    "msgDefIdr",
    "s2bGrpId",
    "stsCustId",
    "instgBtchRef",
    "rtgPty",
    "orgnlMsgId",
    "orgnlCreDtTm"
})
public class Result {

    @JsonProperty("txCtry")
    private String txCtry;
    @JsonProperty("instgChanl")
    private String instgChanl;
    @JsonProperty("instgSubChanl")
    private String instgSubChanl;
    @JsonProperty("msgId")
    private String msgId;
    @JsonProperty("creDtTm")
    private String creDtTm;
    @JsonProperty("nbOfTxs")
    private String nbOfTxs;
    @JsonProperty("ctrlSum")
    private String ctrlSum;
    @JsonProperty("prePrcr")
    private String prePrcr;
    @JsonProperty("payrollInd")
    private String payrollInd;
    @JsonProperty("pmtTp")
    private String pmtTp;
    @JsonProperty("subPmtTp")
    private String subPmtTp;
    @JsonProperty("instrPrty")
    private String instrPrty;
    @JsonProperty("cdtDbtInd")
    private String cdtDbtInd;
    @JsonProperty("clrMsgTp")
    private String clrMsgTp;
    @JsonProperty("clrMd")
    private String clrMd;
    @JsonProperty("vrsnNb")
    private String vrsnNb;
    @JsonProperty("prtryLclInstrm")
    private String prtryLclInstrm;
    @JsonProperty("txSts")
    private String txSts;
    @JsonProperty("prcgDt")
    private String prcgDt;
    @JsonProperty("prcgSts")
    private String prcgSts;
    @JsonProperty("prcgSubSts")
    private String prcgSubSts;
    @JsonProperty("btchBookg")
    private String btchBookg;
    @JsonProperty("svcNm")
    private String svcNm;
    @JsonProperty("subSvcNm")
    private String subSvcNm;
    @JsonProperty("txEvtSts")
    private String txEvtSts;
    @JsonProperty("txEvtCd")
    private String txEvtCd;
    @JsonProperty("actnTp")
    private String actnTp;
    @JsonProperty("brnchCd")
    private String brnchCd;
    @JsonProperty("txRcvdDtTm")
    private String txRcvdDtTm;
    @JsonProperty("tellerId")
    private String tellerId;
    @JsonProperty("applNm")
    private String applNm;
    @JsonProperty("chanlCutOffInd")
    private String chanlCutOffInd;
    @JsonProperty("replayInd")
    private String replayInd;
    @JsonProperty("msgDefIdr")
    private String msgDefIdr;
    @JsonProperty("s2bGrpId")
    private String s2bGrpId;
    @JsonProperty("stsCustId")
    private String stsCustId;
    @JsonProperty("instgBtchRef")
    private String instgBtchRef;
    @JsonProperty("rtgPty")
    private String rtgPty;
    @JsonProperty("orgnlMsgId")
    private String orgnlMsgId;
    @JsonProperty("orgnlCreDtTm")
    private String orgnlCreDtTm;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("txCtry")
    public String getTxCtry() {
        return txCtry;
    }

    @JsonProperty("txCtry")
    public void setTxCtry(String txCtry) {
        this.txCtry = txCtry;
    }

    public Result withTxCtry(String txCtry) {
        this.txCtry = txCtry;
        return this;
    }

    @JsonProperty("instgChanl")
    public String getInstgChanl() {
        return instgChanl;
    }

    @JsonProperty("instgChanl")
    public void setInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
    }

    public Result withInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
        return this;
    }

    @JsonProperty("instgSubChanl")
    public String getInstgSubChanl() {
        return instgSubChanl;
    }

    @JsonProperty("instgSubChanl")
    public void setInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
    }

    public Result withInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
        return this;
    }

    @JsonProperty("msgId")
    public String getMsgId() {
        return msgId;
    }

    @JsonProperty("msgId")
    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public Result withMsgId(String msgId) {
        this.msgId = msgId;
        return this;
    }

    @JsonProperty("creDtTm")
    public String getCreDtTm() {
        return creDtTm;
    }

    @JsonProperty("creDtTm")
    public void setCreDtTm(String creDtTm) {
        this.creDtTm = creDtTm;
    }

    public Result withCreDtTm(String creDtTm) {
        this.creDtTm = creDtTm;
        return this;
    }

    @JsonProperty("nbOfTxs")
    public String getNbOfTxs() {
        return nbOfTxs;
    }

    @JsonProperty("nbOfTxs")
    public void setNbOfTxs(String nbOfTxs) {
        this.nbOfTxs = nbOfTxs;
    }

    public Result withNbOfTxs(String nbOfTxs) {
        this.nbOfTxs = nbOfTxs;
        return this;
    }

    @JsonProperty("ctrlSum")
    public String getCtrlSum() {
        return ctrlSum;
    }

    @JsonProperty("ctrlSum")
    public void setCtrlSum(String ctrlSum) {
        this.ctrlSum = ctrlSum;
    }

    public Result withCtrlSum(String ctrlSum) {
        this.ctrlSum = ctrlSum;
        return this;
    }

    @JsonProperty("prePrcr")
    public String getPrePrcr() {
        return prePrcr;
    }

    @JsonProperty("prePrcr")
    public void setPrePrcr(String prePrcr) {
        this.prePrcr = prePrcr;
    }

    public Result withPrePrcr(String prePrcr) {
        this.prePrcr = prePrcr;
        return this;
    }

    @JsonProperty("payrollInd")
    public String getPayrollInd() {
        return payrollInd;
    }

    @JsonProperty("payrollInd")
    public void setPayrollInd(String payrollInd) {
        this.payrollInd = payrollInd;
    }

    public Result withPayrollInd(String payrollInd) {
        this.payrollInd = payrollInd;
        return this;
    }

    @JsonProperty("pmtTp")
    public String getPmtTp() {
        return pmtTp;
    }

    @JsonProperty("pmtTp")
    public void setPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
    }

    public Result withPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
        return this;
    }

    @JsonProperty("subPmtTp")
    public String getSubPmtTp() {
        return subPmtTp;
    }

    @JsonProperty("subPmtTp")
    public void setSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
    }

    public Result withSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
        return this;
    }

    @JsonProperty("instrPrty")
    public String getInstrPrty() {
        return instrPrty;
    }

    @JsonProperty("instrPrty")
    public void setInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
    }

    public Result withInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
        return this;
    }

    @JsonProperty("cdtDbtInd")
    public String getCdtDbtInd() {
        return cdtDbtInd;
    }

    @JsonProperty("cdtDbtInd")
    public void setCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
    }

    public Result withCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
        return this;
    }

    @JsonProperty("clrMsgTp")
    public String getClrMsgTp() {
        return clrMsgTp;
    }

    @JsonProperty("clrMsgTp")
    public void setClrMsgTp(String clrMsgTp) {
        this.clrMsgTp = clrMsgTp;
    }

    public Result withClrMsgTp(String clrMsgTp) {
        this.clrMsgTp = clrMsgTp;
        return this;
    }

    @JsonProperty("clrMd")
    public String getClrMd() {
        return clrMd;
    }

    @JsonProperty("clrMd")
    public void setClrMd(String clrMd) {
        this.clrMd = clrMd;
    }

    public Result withClrMd(String clrMd) {
        this.clrMd = clrMd;
        return this;
    }

    @JsonProperty("vrsnNb")
    public String getVrsnNb() {
        return vrsnNb;
    }

    @JsonProperty("vrsnNb")
    public void setVrsnNb(String vrsnNb) {
        this.vrsnNb = vrsnNb;
    }

    public Result withVrsnNb(String vrsnNb) {
        this.vrsnNb = vrsnNb;
        return this;
    }

    @JsonProperty("prtryLclInstrm")
    public String getPrtryLclInstrm() {
        return prtryLclInstrm;
    }

    @JsonProperty("prtryLclInstrm")
    public void setPrtryLclInstrm(String prtryLclInstrm) {
        this.prtryLclInstrm = prtryLclInstrm;
    }

    public Result withPrtryLclInstrm(String prtryLclInstrm) {
        this.prtryLclInstrm = prtryLclInstrm;
        return this;
    }

    @JsonProperty("txSts")
    public String getTxSts() {
        return txSts;
    }

    @JsonProperty("txSts")
    public void setTxSts(String txSts) {
        this.txSts = txSts;
    }

    public Result withTxSts(String txSts) {
        this.txSts = txSts;
        return this;
    }

    @JsonProperty("prcgDt")
    public String getPrcgDt() {
        return prcgDt;
    }

    @JsonProperty("prcgDt")
    public void setPrcgDt(String prcgDt) {
        this.prcgDt = prcgDt;
    }

    public Result withPrcgDt(String prcgDt) {
        this.prcgDt = prcgDt;
        return this;
    }

    @JsonProperty("prcgSts")
    public String getPrcgSts() {
        return prcgSts;
    }

    @JsonProperty("prcgSts")
    public void setPrcgSts(String prcgSts) {
        this.prcgSts = prcgSts;
    }

    public Result withPrcgSts(String prcgSts) {
        this.prcgSts = prcgSts;
        return this;
    }

    @JsonProperty("prcgSubSts")
    public String getPrcgSubSts() {
        return prcgSubSts;
    }

    @JsonProperty("prcgSubSts")
    public void setPrcgSubSts(String prcgSubSts) {
        this.prcgSubSts = prcgSubSts;
    }

    public Result withPrcgSubSts(String prcgSubSts) {
        this.prcgSubSts = prcgSubSts;
        return this;
    }

    @JsonProperty("btchBookg")
    public String getBtchBookg() {
        return btchBookg;
    }

    @JsonProperty("btchBookg")
    public void setBtchBookg(String btchBookg) {
        this.btchBookg = btchBookg;
    }

    public Result withBtchBookg(String btchBookg) {
        this.btchBookg = btchBookg;
        return this;
    }

    @JsonProperty("svcNm")
    public String getSvcNm() {
        return svcNm;
    }

    @JsonProperty("svcNm")
    public void setSvcNm(String svcNm) {
        this.svcNm = svcNm;
    }

    public Result withSvcNm(String svcNm) {
        this.svcNm = svcNm;
        return this;
    }

    @JsonProperty("subSvcNm")
    public String getSubSvcNm() {
        return subSvcNm;
    }

    @JsonProperty("subSvcNm")
    public void setSubSvcNm(String subSvcNm) {
        this.subSvcNm = subSvcNm;
    }

    public Result withSubSvcNm(String subSvcNm) {
        this.subSvcNm = subSvcNm;
        return this;
    }

    @JsonProperty("txEvtSts")
    public String getTxEvtSts() {
        return txEvtSts;
    }

    @JsonProperty("txEvtSts")
    public void setTxEvtSts(String txEvtSts) {
        this.txEvtSts = txEvtSts;
    }

    public Result withTxEvtSts(String txEvtSts) {
        this.txEvtSts = txEvtSts;
        return this;
    }

    @JsonProperty("txEvtCd")
    public String getTxEvtCd() {
        return txEvtCd;
    }

    @JsonProperty("txEvtCd")
    public void setTxEvtCd(String txEvtCd) {
        this.txEvtCd = txEvtCd;
    }

    public Result withTxEvtCd(String txEvtCd) {
        this.txEvtCd = txEvtCd;
        return this;
    }

    @JsonProperty("actnTp")
    public String getActnTp() {
        return actnTp;
    }

    @JsonProperty("actnTp")
    public void setActnTp(String actnTp) {
        this.actnTp = actnTp;
    }

    public Result withActnTp(String actnTp) {
        this.actnTp = actnTp;
        return this;
    }

    @JsonProperty("brnchCd")
    public String getBrnchCd() {
        return brnchCd;
    }

    @JsonProperty("brnchCd")
    public void setBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
    }

    public Result withBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
        return this;
    }

    @JsonProperty("txRcvdDtTm")
    public String getTxRcvdDtTm() {
        return txRcvdDtTm;
    }

    @JsonProperty("txRcvdDtTm")
    public void setTxRcvdDtTm(String txRcvdDtTm) {
        this.txRcvdDtTm = txRcvdDtTm;
    }

    public Result withTxRcvdDtTm(String txRcvdDtTm) {
        this.txRcvdDtTm = txRcvdDtTm;
        return this;
    }

    @JsonProperty("tellerId")
    public String getTellerId() {
        return tellerId;
    }

    @JsonProperty("tellerId")
    public void setTellerId(String tellerId) {
        this.tellerId = tellerId;
    }

    public Result withTellerId(String tellerId) {
        this.tellerId = tellerId;
        return this;
    }

    @JsonProperty("applNm")
    public String getApplNm() {
        return applNm;
    }

    @JsonProperty("applNm")
    public void setApplNm(String applNm) {
        this.applNm = applNm;
    }

    public Result withApplNm(String applNm) {
        this.applNm = applNm;
        return this;
    }

    @JsonProperty("chanlCutOffInd")
    public String getChanlCutOffInd() {
        return chanlCutOffInd;
    }

    @JsonProperty("chanlCutOffInd")
    public void setChanlCutOffInd(String chanlCutOffInd) {
        this.chanlCutOffInd = chanlCutOffInd;
    }

    public Result withChanlCutOffInd(String chanlCutOffInd) {
        this.chanlCutOffInd = chanlCutOffInd;
        return this;
    }

    @JsonProperty("replayInd")
    public String getReplayInd() {
        return replayInd;
    }

    @JsonProperty("replayInd")
    public void setReplayInd(String replayInd) {
        this.replayInd = replayInd;
    }

    public Result withReplayInd(String replayInd) {
        this.replayInd = replayInd;
        return this;
    }

    @JsonProperty("msgDefIdr")
    public String getMsgDefIdr() {
        return msgDefIdr;
    }

    @JsonProperty("msgDefIdr")
    public void setMsgDefIdr(String msgDefIdr) {
        this.msgDefIdr = msgDefIdr;
    }

    public Result withMsgDefIdr(String msgDefIdr) {
        this.msgDefIdr = msgDefIdr;
        return this;
    }

    @JsonProperty("s2bGrpId")
    public String getS2bGrpId() {
        return s2bGrpId;
    }

    @JsonProperty("s2bGrpId")
    public void setS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
    }

    public Result withS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
        return this;
    }

    @JsonProperty("stsCustId")
    public String getStsCustId() {
        return stsCustId;
    }

    @JsonProperty("stsCustId")
    public void setStsCustId(String stsCustId) {
        this.stsCustId = stsCustId;
    }

    public Result withStsCustId(String stsCustId) {
        this.stsCustId = stsCustId;
        return this;
    }

    @JsonProperty("instgBtchRef")
    public String getInstgBtchRef() {
        return instgBtchRef;
    }

    @JsonProperty("instgBtchRef")
    public void setInstgBtchRef(String instgBtchRef) {
        this.instgBtchRef = instgBtchRef;
    }

    public Result withInstgBtchRef(String instgBtchRef) {
        this.instgBtchRef = instgBtchRef;
        return this;
    }

    @JsonProperty("rtgPty")
    public String getRtgPty() {
        return rtgPty;
    }

    @JsonProperty("rtgPty")
    public void setRtgPty(String rtgPty) {
        this.rtgPty = rtgPty;
    }

    public Result withRtgPty(String rtgPty) {
        this.rtgPty = rtgPty;
        return this;
    }

    @JsonProperty("orgnlMsgId")
    public String getOrgnlMsgId() {
        return orgnlMsgId;
    }

    @JsonProperty("orgnlMsgId")
    public void setOrgnlMsgId(String orgnlMsgId) {
        this.orgnlMsgId = orgnlMsgId;
    }

    public Result withOrgnlMsgId(String orgnlMsgId) {
        this.orgnlMsgId = orgnlMsgId;
        return this;
    }

    @JsonProperty("orgnlCreDtTm")
    public String getOrgnlCreDtTm() {
        return orgnlCreDtTm;
    }

    @JsonProperty("orgnlCreDtTm")
    public void setOrgnlCreDtTm(String orgnlCreDtTm) {
        this.orgnlCreDtTm = orgnlCreDtTm;
    }

    public Result withOrgnlCreDtTm(String orgnlCreDtTm) {
        this.orgnlCreDtTm = orgnlCreDtTm;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Result withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(txCtry).append(instgChanl).append(instgSubChanl).append(msgId).append(creDtTm).append(nbOfTxs).append(ctrlSum).append(prePrcr).append(payrollInd).append(pmtTp).append(subPmtTp).append(instrPrty).append(cdtDbtInd).append(clrMsgTp).append(clrMd).append(vrsnNb).append(prtryLclInstrm).append(txSts).append(prcgDt).append(prcgSts).append(prcgSubSts).append(btchBookg).append(svcNm).append(subSvcNm).append(txEvtSts).append(txEvtCd).append(actnTp).append(brnchCd).append(txRcvdDtTm).append(tellerId).append(applNm).append(chanlCutOffInd).append(replayInd).append(msgDefIdr).append(s2bGrpId).append(stsCustId).append(instgBtchRef).append(rtgPty).append(orgnlMsgId).append(orgnlCreDtTm).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Result) == false) {
            return false;
        }
        Result rhs = ((Result) other);
        return new EqualsBuilder().append(txCtry, rhs.txCtry).append(instgChanl, rhs.instgChanl).append(instgSubChanl, rhs.instgSubChanl).append(msgId, rhs.msgId).append(creDtTm, rhs.creDtTm).append(nbOfTxs, rhs.nbOfTxs).append(ctrlSum, rhs.ctrlSum).append(prePrcr, rhs.prePrcr).append(payrollInd, rhs.payrollInd).append(pmtTp, rhs.pmtTp).append(subPmtTp, rhs.subPmtTp).append(instrPrty, rhs.instrPrty).append(cdtDbtInd, rhs.cdtDbtInd).append(clrMsgTp, rhs.clrMsgTp).append(clrMd, rhs.clrMd).append(vrsnNb, rhs.vrsnNb).append(prtryLclInstrm, rhs.prtryLclInstrm).append(txSts, rhs.txSts).append(prcgDt, rhs.prcgDt).append(prcgSts, rhs.prcgSts).append(prcgSubSts, rhs.prcgSubSts).append(btchBookg, rhs.btchBookg).append(svcNm, rhs.svcNm).append(subSvcNm, rhs.subSvcNm).append(txEvtSts, rhs.txEvtSts).append(txEvtCd, rhs.txEvtCd).append(actnTp, rhs.actnTp).append(brnchCd, rhs.brnchCd).append(txRcvdDtTm, rhs.txRcvdDtTm).append(tellerId, rhs.tellerId).append(applNm, rhs.applNm).append(chanlCutOffInd, rhs.chanlCutOffInd).append(replayInd, rhs.replayInd).append(msgDefIdr, rhs.msgDefIdr).append(s2bGrpId, rhs.s2bGrpId).append(stsCustId, rhs.stsCustId).append(instgBtchRef, rhs.instgBtchRef).append(rtgPty, rhs.rtgPty).append(orgnlMsgId, rhs.orgnlMsgId).append(orgnlCreDtTm, rhs.orgnlCreDtTm).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

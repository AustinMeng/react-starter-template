package com.scb.s2b.api.payment.camel;

import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.payment.entity.PaymentTransaction;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.util.KafkaUtil;
import java.util.Map;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KafkaProducerAdapter {

    private final String paymentInitiateEndpoint;

    private final String ccsAgentImportEndpoint;

    private final ProducerTemplate producer;

    private final JsonMessageMarshaller messageMarshaller;

    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerAdapter.class);

    public KafkaProducerAdapter(String paymentInitiateEndpoint,
            String ccsAgentImportEndpoint,
            ProducerTemplate producer,
            JsonMessageMarshaller messageMarshaller) {
        this.paymentInitiateEndpoint = paymentInitiateEndpoint;
        this.ccsAgentImportEndpoint = ccsAgentImportEndpoint;
        this.producer = producer;
        this.messageMarshaller = messageMarshaller;
    }

    public void publishPaymentTransaction(PaymentTransaction paymentTransaction) {
        KafkaUtil.sendToKafka(producer, paymentInitiateEndpoint, paymentTransaction, paymentTransaction::getGroupId, paymentTransaction::getMessageId);
    }

    public void publishPaymentTransactionToCCSAgentWithHeaders(CCSAgentInboundIns inboundIns,
            Map<String, Object> headers) {
        logger.info("Send payment transaction groupId={}, noum={}, fileName={} to ccs agent", inboundIns.getGroupId(),
                inboundIns.getNoun(), inboundIns.getFileName());
        logger.info("Headers is {}", headers);
        byte[] bytes = messageMarshaller.marshallToJsonByteArray(inboundIns);
        producer.sendBodyAndHeaders(ccsAgentImportEndpoint, bytes, headers);
    }
}

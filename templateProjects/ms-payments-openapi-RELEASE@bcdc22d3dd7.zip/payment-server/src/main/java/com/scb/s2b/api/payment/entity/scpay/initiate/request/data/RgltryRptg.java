
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dbtCdtRptgInd",
    "authrtyNm",
    "authrtyCtry",
    "dtls"
})
public class RgltryRptg {

    @JsonProperty("dbtCdtRptgInd")
    private String dbtCdtRptgInd;
    @JsonProperty("authrtyNm")
    private String authrtyNm;
    @JsonProperty("authrtyCtry")
    private String authrtyCtry;
    @JsonProperty("dtls")
    private List<Dtl> dtls = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dbtCdtRptgInd")
    public String getDbtCdtRptgInd() {
        return dbtCdtRptgInd;
    }

    @JsonProperty("dbtCdtRptgInd")
    public void setDbtCdtRptgInd(String dbtCdtRptgInd) {
        this.dbtCdtRptgInd = dbtCdtRptgInd;
    }

    public RgltryRptg withDbtCdtRptgInd(String dbtCdtRptgInd) {
        this.dbtCdtRptgInd = dbtCdtRptgInd;
        return this;
    }

    @JsonProperty("authrtyNm")
    public String getAuthrtyNm() {
        return authrtyNm;
    }

    @JsonProperty("authrtyNm")
    public void setAuthrtyNm(String authrtyNm) {
        this.authrtyNm = authrtyNm;
    }

    public RgltryRptg withAuthrtyNm(String authrtyNm) {
        this.authrtyNm = authrtyNm;
        return this;
    }

    @JsonProperty("authrtyCtry")
    public String getAuthrtyCtry() {
        return authrtyCtry;
    }

    @JsonProperty("authrtyCtry")
    public void setAuthrtyCtry(String authrtyCtry) {
        this.authrtyCtry = authrtyCtry;
    }

    public RgltryRptg withAuthrtyCtry(String authrtyCtry) {
        this.authrtyCtry = authrtyCtry;
        return this;
    }

    @JsonProperty("dtls")
    public List<Dtl> getDtls() {
        return dtls;
    }

    @JsonProperty("dtls")
    public void setDtls(List<Dtl> dtls) {
        this.dtls = dtls;
    }

    public RgltryRptg withDtls(List<Dtl> dtls) {
        this.dtls = dtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RgltryRptg withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dbtCdtRptgInd).append(authrtyNm).append(authrtyCtry).append(dtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RgltryRptg) == false) {
            return false;
        }
        RgltryRptg rhs = ((RgltryRptg) other);
        return new EqualsBuilder().append(dbtCdtRptgInd, rhs.dbtCdtRptgInd).append(authrtyNm, rhs.authrtyNm).append(authrtyCtry, rhs.authrtyCtry).append(dtls, rhs.dtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

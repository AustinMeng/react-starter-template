
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "amt",
    "ccy",
    "BICFI",
    "clrSysIdCd",
    "clrSysIdPrtry",
    "clrSysMmbId",
    "LEI",
    "nm",
    "pstlAdr"
})
public class AgtChrgsInf {

    @JsonProperty("amt")
    private String amt;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("BICFI")
    private String bICFI;
    @JsonProperty("clrSysIdCd")
    private String clrSysIdCd;
    @JsonProperty("clrSysIdPrtry")
    private String clrSysIdPrtry;
    @JsonProperty("clrSysMmbId")
    private String clrSysMmbId;
    @JsonProperty("LEI")
    private String lEI;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("amt")
    public String getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(String amt) {
        this.amt = amt;
    }

    public AgtChrgsInf withAmt(String amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public AgtChrgsInf withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("BICFI")
    public String getBICFI() {
        return bICFI;
    }

    @JsonProperty("BICFI")
    public void setBICFI(String bICFI) {
        this.bICFI = bICFI;
    }

    public AgtChrgsInf withBICFI(String bICFI) {
        this.bICFI = bICFI;
        return this;
    }

    @JsonProperty("clrSysIdCd")
    public String getClrSysIdCd() {
        return clrSysIdCd;
    }

    @JsonProperty("clrSysIdCd")
    public void setClrSysIdCd(String clrSysIdCd) {
        this.clrSysIdCd = clrSysIdCd;
    }

    public AgtChrgsInf withClrSysIdCd(String clrSysIdCd) {
        this.clrSysIdCd = clrSysIdCd;
        return this;
    }

    @JsonProperty("clrSysIdPrtry")
    public String getClrSysIdPrtry() {
        return clrSysIdPrtry;
    }

    @JsonProperty("clrSysIdPrtry")
    public void setClrSysIdPrtry(String clrSysIdPrtry) {
        this.clrSysIdPrtry = clrSysIdPrtry;
    }

    public AgtChrgsInf withClrSysIdPrtry(String clrSysIdPrtry) {
        this.clrSysIdPrtry = clrSysIdPrtry;
        return this;
    }

    @JsonProperty("clrSysMmbId")
    public String getClrSysMmbId() {
        return clrSysMmbId;
    }

    @JsonProperty("clrSysMmbId")
    public void setClrSysMmbId(String clrSysMmbId) {
        this.clrSysMmbId = clrSysMmbId;
    }

    public AgtChrgsInf withClrSysMmbId(String clrSysMmbId) {
        this.clrSysMmbId = clrSysMmbId;
        return this;
    }

    @JsonProperty("LEI")
    public String getLEI() {
        return lEI;
    }

    @JsonProperty("LEI")
    public void setLEI(String lEI) {
        this.lEI = lEI;
    }

    public AgtChrgsInf withLEI(String lEI) {
        this.lEI = lEI;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public AgtChrgsInf withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public AgtChrgsInf withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AgtChrgsInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(amt).append(ccy).append(bICFI).append(clrSysIdCd).append(clrSysIdPrtry).append(clrSysMmbId).append(lEI).append(nm).append(pstlAdr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AgtChrgsInf) == false) {
            return false;
        }
        AgtChrgsInf rhs = ((AgtChrgsInf) other);
        return new EqualsBuilder().append(amt, rhs.amt).append(ccy, rhs.ccy).append(bICFI, rhs.bICFI).append(clrSysIdCd, rhs.clrSysIdCd).append(clrSysIdPrtry, rhs.clrSysIdPrtry).append(clrSysMmbId, rhs.clrSysMmbId).append(lEI, rhs.lEI).append(nm, rhs.nm).append(pstlAdr, rhs.pstlAdr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

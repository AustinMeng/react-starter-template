package com.scb.s2b.api.payment.config;

import com.google.common.collect.ImmutableList;
import com.hazelcast.config.ClasspathYamlConfig;
import com.hazelcast.config.Config;
import com.hazelcast.config.EvictionConfig;
import com.hazelcast.config.EvictionPolicy;
import com.hazelcast.config.FileSystemYamlConfig;
import com.hazelcast.config.MapConfig;
import com.hazelcast.config.MaxSizePolicy;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.spring.cache.HazelcastCacheManager;
import com.scb.s2b.api.payment.cache.CacheKeyGenerator;
import com.scb.s2b.api.payment.repository.impl.ClassicDbRepositoryImpl;
import com.scb.s2b.api.payment.service.ReferenceDataService;
import com.scb.s2b.api.payment.service.impl.CadmServiceImpl;
import com.scb.s2b.api.payment.service.impl.MaintenanceServiceImpl;
import com.scb.s2b.api.payment.validation.PaymentRequestValidator;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.List;
import javax.cache.Caching;
import javax.cache.spi.CachingProvider;
import org.apache.commons.lang.StringUtils;
import org.ehcache.config.builders.CacheConfigurationBuilder;
import org.ehcache.config.builders.ExpiryPolicyBuilder;
import org.ehcache.config.builders.ResourcePoolsBuilder;
import org.ehcache.jsr107.Eh107Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Profile("!test")
@SuppressWarnings("unused")
public class CacheConfig extends CachingConfigurerSupport {

    @Value("${spring.hazelcast.config}")
    private String hazelcastServerConfig;

    private static final int expireAfter15Minutes = 15 * 60;
    private static final int expireAfter30Minutes = 30 * 60;
    private static final int expireAfter60Minutes = 60 * 60;
    private static final int expireAfter6Hours = 6 * 60 * 60;
    private static final int expireAfter12Hours = 12 * 60 * 60;
    private static final int expireAfter24Hours = 24 * 60 * 60;

    private static final int cacheEntries = 500;

    private static final String CLASSPATH_PREFIX = "classpath:";
    private static final String SLASH = "/";

    @Bean(name="ehCacheManager")
    public CacheManager ehCacheManager() {
        CachingProvider cp = Caching.getCachingProvider("org.ehcache.jsr107.EhcacheCachingProvider");
        javax.cache.CacheManager cm = cp.getCacheManager();

        CacheConfigurationBuilder<String, Object> configurationBuilder = CacheConfigurationBuilder
                .newCacheConfigurationBuilder(String.class, Object.class,
                        ResourcePoolsBuilder.heap(cacheEntries))
                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofSeconds(expireAfter60Minutes)));

        cm.createCache(ReferenceDataService.META_CACHE, Eh107Configuration.fromEhcacheCacheConfiguration(configurationBuilder));

        return new JCacheCacheManager(cm);
    }

    @Primary
    @Bean(name = "hcCacheManager")
    public CacheManager hcCacheManager(HazelcastInstance hazelcastInstance) {
        return new HazelcastCacheManager(hazelcastInstance);
    }

    @Bean
    public Config hazelCastConfig(List<MapConfig> mapConfigList) throws FileNotFoundException {
        Config config = hazelcastServerConfig.startsWith(CLASSPATH_PREFIX)
                ? new ClasspathYamlConfig(this.getClasspathResource(hazelcastServerConfig))
                : new FileSystemYamlConfig(hazelcastServerConfig);

        for (MapConfig mapConfig : mapConfigList) {
            config.addMapConfig(mapConfig);
        }

        return config;
    }

    @Bean
    public List<MapConfig> initMapConfigs() {
        return ImmutableList.of(
                mapConfig(CadmServiceImpl.CADM_GROUPS_CACHE, 10000, expireAfter15Minutes),
                mapConfig(CadmServiceImpl.CADM_ACCOUNTS_CACHE, 10000, expireAfter15Minutes),
                mapConfig(CadmServiceImpl.CADM_CONSENTS_CACHE, 10000, expireAfter15Minutes),
                mapConfig(CadmServiceImpl.CADM_GROUP_COMPANIES, 10000, expireAfter15Minutes),
                mapConfig(CadmServiceImpl.CADM_PAY_CENTRE, 10000, expireAfter15Minutes),
                mapConfig(PaymentRequestValidator.PAYMENT_INITIATE_CACHE, 100000, expireAfter30Minutes),
                mapConfig(ClassicDbRepositoryImpl.CLASSIC_ACCOUNTS_CACHE, 50000, expireAfter6Hours),
                mapConfig(ClassicDbRepositoryImpl.CLASSIC_ENTITIES_CACHE, 300, expireAfter12Hours),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_SUSPENDED_COUNTRIES_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_REVOKED_COUNTRIES_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_BANK_STATUS_BROADCAST_SUSPENDED_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_BANK_STATUS_BROADCAST_REVOKED_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_BANK_STATUS_BROADCAST_PH_SUSPENDED_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_BANK_STATUS_BROADCAST_PH_REVOKED_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_BANK_DEFAULT_BROADCAST_SUSPENDED_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_BANK_DEFAULT_BROADCAST_REVOKED_CACHE, 100, expireAfter60Minutes),
                mapConfig(MaintenanceServiceImpl.MAINTENANCE_SYSTEM_STATUS_BROADCAST_CACHE, 1, expireAfter60Minutes)
        );
    }

    @Bean
    public HazelcastInstance hazelcastInstance(Config config) {
        return Hazelcast.newHazelcastInstance(config);
    }

    @Bean
    public KeyGenerator cacheKeyGenerator() {
        return new CacheKeyGenerator();
    }

    private MapConfig mapConfig(String mapName, int maxSize, int timeToLiveSeconds) {
        return new MapConfig()
                .setName(mapName)
                .setEvictionConfig(new EvictionConfig()
                        .setEvictionPolicy(EvictionPolicy.NONE)
                        .setMaxSizePolicy(MaxSizePolicy.PER_NODE)
                                .setSize(maxSize))
                .setTimeToLiveSeconds(timeToLiveSeconds);
    }

    private String getClasspathResource(String config) {
        String url = StringUtils.removeStart(config, CLASSPATH_PREFIX);
        return url.startsWith(SLASH) ? StringUtils.removeStart(url, SLASH) : url;
    }
}

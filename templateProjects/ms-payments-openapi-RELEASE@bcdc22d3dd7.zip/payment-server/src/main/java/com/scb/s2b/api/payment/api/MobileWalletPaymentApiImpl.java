package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.CcsPaymentInstruction;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.processor.request.CcsRequestProcessor;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.CcsPaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.MobileRequestValidator;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.inject.Singleton;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@SuppressWarnings("unused")
@Component
@Singleton
public class MobileWalletPaymentApiImpl extends ApiBase {

    @Autowired
    @Qualifier("mwpRequestProcessor")
    private RequestProcessor mwpRequestProcessor;

    @Autowired
    @Qualifier("mwpCcsRequestProcessor")
    private CcsRequestProcessor mwpCcsRequestProcessor;

    @Autowired
    private CcsPaymentService ccsPaymentService;

    @Autowired
    private MobileRequestValidator mobileRequestValidator;

    @Autowired
    private OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;

    private static final Logger logger = LoggerFactory.getLogger(MobileWalletPaymentApiImpl.class);

    public Response mobileWalletPaymentInitiate(String preVerified, OpenApiPaymentInstruction body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);
        logger.info("MWP Initiate requestId={}, groupId={}, clientReferenceId={}, paymentType={}", requestId, groupId,
                body.getInstruction().getReferenceId(), body.getInstruction().getPaymentType());

        mobileRequestValidator.validate(groupId, body);
        Map<String, String> headersMap = this.getHeaders(headers);

        boolean isPreVerified = "true".equalsIgnoreCase(preVerified);
        PaymentInstruction paymentInstruction = openApiPaymentInstructionTransformer
                .toPaymentInstruction(body, isPreVerified, headersMap);

        mwpRequestProcessor.process(paymentInstruction);
        CcsPaymentInstruction ccsPaymentInstruction = openApiPaymentInstructionTransformer.toMwpPaymentInstruction(body);
        List<PaymentInstruction> paymentInstructions = Collections.singletonList(paymentInstruction);
        mwpCcsRequestProcessor.process(ccsPaymentInstruction, paymentInstructions);
        ccsPaymentService
                .ccsPaymentInitiate(groupId, ccsPaymentInstruction, paymentInstructions);
        mobileRequestValidator.cache(paymentInstruction);

        OpenApiPaymentId openApiPaymentId = openApiPaymentInstructionTransformer.toOpenApiPaymentId(paymentInstruction);

        return Response.ok(openApiPaymentId).build();
    }
}
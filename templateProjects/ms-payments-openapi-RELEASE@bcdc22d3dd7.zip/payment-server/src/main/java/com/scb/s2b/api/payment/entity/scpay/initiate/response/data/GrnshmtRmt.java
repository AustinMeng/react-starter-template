
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tpCd",
    "tpPrtry",
    "tpIssr",
    "refNb",
    "dt",
    "rmtdAmt",
    "rmtdAmtCcy",
    "fmlyMdclInsrncInd",
    "mplyeeTermntnInd",
    "grnshee",
    "grnshmtAdmstr"
})
public class GrnshmtRmt {

    @JsonProperty("tpCd")
    private String tpCd;
    @JsonProperty("tpPrtry")
    private String tpPrtry;
    @JsonProperty("tpIssr")
    private String tpIssr;
    @JsonProperty("refNb")
    private String refNb;
    @JsonProperty("dt")
    private String dt;
    @JsonProperty("rmtdAmt")
    private String rmtdAmt;
    @JsonProperty("rmtdAmtCcy")
    private String rmtdAmtCcy;
    @JsonProperty("fmlyMdclInsrncInd")
    private String fmlyMdclInsrncInd;
    @JsonProperty("mplyeeTermntnInd")
    private String mplyeeTermntnInd;
    @JsonProperty("grnshee")
    private Grnshee grnshee;
    @JsonProperty("grnshmtAdmstr")
    private GrnshmtAdmstr grnshmtAdmstr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tpCd")
    public String getTpCd() {
        return tpCd;
    }

    @JsonProperty("tpCd")
    public void setTpCd(String tpCd) {
        this.tpCd = tpCd;
    }

    public GrnshmtRmt withTpCd(String tpCd) {
        this.tpCd = tpCd;
        return this;
    }

    @JsonProperty("tpPrtry")
    public String getTpPrtry() {
        return tpPrtry;
    }

    @JsonProperty("tpPrtry")
    public void setTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
    }

    public GrnshmtRmt withTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
        return this;
    }

    @JsonProperty("tpIssr")
    public String getTpIssr() {
        return tpIssr;
    }

    @JsonProperty("tpIssr")
    public void setTpIssr(String tpIssr) {
        this.tpIssr = tpIssr;
    }

    public GrnshmtRmt withTpIssr(String tpIssr) {
        this.tpIssr = tpIssr;
        return this;
    }

    @JsonProperty("refNb")
    public String getRefNb() {
        return refNb;
    }

    @JsonProperty("refNb")
    public void setRefNb(String refNb) {
        this.refNb = refNb;
    }

    public GrnshmtRmt withRefNb(String refNb) {
        this.refNb = refNb;
        return this;
    }

    @JsonProperty("dt")
    public String getDt() {
        return dt;
    }

    @JsonProperty("dt")
    public void setDt(String dt) {
        this.dt = dt;
    }

    public GrnshmtRmt withDt(String dt) {
        this.dt = dt;
        return this;
    }

    @JsonProperty("rmtdAmt")
    public String getRmtdAmt() {
        return rmtdAmt;
    }

    @JsonProperty("rmtdAmt")
    public void setRmtdAmt(String rmtdAmt) {
        this.rmtdAmt = rmtdAmt;
    }

    public GrnshmtRmt withRmtdAmt(String rmtdAmt) {
        this.rmtdAmt = rmtdAmt;
        return this;
    }

    @JsonProperty("rmtdAmtCcy")
    public String getRmtdAmtCcy() {
        return rmtdAmtCcy;
    }

    @JsonProperty("rmtdAmtCcy")
    public void setRmtdAmtCcy(String rmtdAmtCcy) {
        this.rmtdAmtCcy = rmtdAmtCcy;
    }

    public GrnshmtRmt withRmtdAmtCcy(String rmtdAmtCcy) {
        this.rmtdAmtCcy = rmtdAmtCcy;
        return this;
    }

    @JsonProperty("fmlyMdclInsrncInd")
    public String getFmlyMdclInsrncInd() {
        return fmlyMdclInsrncInd;
    }

    @JsonProperty("fmlyMdclInsrncInd")
    public void setFmlyMdclInsrncInd(String fmlyMdclInsrncInd) {
        this.fmlyMdclInsrncInd = fmlyMdclInsrncInd;
    }

    public GrnshmtRmt withFmlyMdclInsrncInd(String fmlyMdclInsrncInd) {
        this.fmlyMdclInsrncInd = fmlyMdclInsrncInd;
        return this;
    }

    @JsonProperty("mplyeeTermntnInd")
    public String getMplyeeTermntnInd() {
        return mplyeeTermntnInd;
    }

    @JsonProperty("mplyeeTermntnInd")
    public void setMplyeeTermntnInd(String mplyeeTermntnInd) {
        this.mplyeeTermntnInd = mplyeeTermntnInd;
    }

    public GrnshmtRmt withMplyeeTermntnInd(String mplyeeTermntnInd) {
        this.mplyeeTermntnInd = mplyeeTermntnInd;
        return this;
    }

    @JsonProperty("grnshee")
    public Grnshee getGrnshee() {
        return grnshee;
    }

    @JsonProperty("grnshee")
    public void setGrnshee(Grnshee grnshee) {
        this.grnshee = grnshee;
    }

    public GrnshmtRmt withGrnshee(Grnshee grnshee) {
        this.grnshee = grnshee;
        return this;
    }

    @JsonProperty("grnshmtAdmstr")
    public GrnshmtAdmstr getGrnshmtAdmstr() {
        return grnshmtAdmstr;
    }

    @JsonProperty("grnshmtAdmstr")
    public void setGrnshmtAdmstr(GrnshmtAdmstr grnshmtAdmstr) {
        this.grnshmtAdmstr = grnshmtAdmstr;
    }

    public GrnshmtRmt withGrnshmtAdmstr(GrnshmtAdmstr grnshmtAdmstr) {
        this.grnshmtAdmstr = grnshmtAdmstr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public GrnshmtRmt withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tpCd).append(tpPrtry).append(tpIssr).append(refNb).append(dt).append(rmtdAmt).append(rmtdAmtCcy).append(fmlyMdclInsrncInd).append(mplyeeTermntnInd).append(grnshee).append(grnshmtAdmstr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof GrnshmtRmt) == false) {
            return false;
        }
        GrnshmtRmt rhs = ((GrnshmtRmt) other);
        return new EqualsBuilder().append(tpCd, rhs.tpCd).append(tpPrtry, rhs.tpPrtry).append(tpIssr, rhs.tpIssr).append(refNb, rhs.refNb).append(dt, rhs.dt).append(rmtdAmt, rhs.rmtdAmt).append(rmtdAmtCcy, rhs.rmtdAmtCcy).append(fmlyMdclInsrncInd, rhs.fmlyMdclInsrncInd).append(mplyeeTermntnInd, rhs.mplyeeTermntnInd).append(grnshee, rhs.grnshee).append(grnshmtAdmstr, rhs.grnshmtAdmstr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

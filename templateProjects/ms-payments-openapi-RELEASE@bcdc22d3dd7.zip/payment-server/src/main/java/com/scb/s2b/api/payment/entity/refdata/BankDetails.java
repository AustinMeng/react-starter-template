package com.scb.s2b.api.payment.entity.refdata;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class BankDetails {

    private String name;

    private String bic;

}

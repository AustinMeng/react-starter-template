package com.scb.s2b.api.payment.camel.notification.handler;

import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_ID;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_SCP;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.SUCCESS_STATUS;

import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.scb.s2b.api.payment.camel.ZkProducerAdapter;
import com.scb.s2b.api.payment.camel.controller.CamelController;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.notification.data.NotificationData.DefaultStatusType;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class BankDefaultBroadcastHandler extends AbstractSNMNotificationHandler implements SNMNotificationHandler {

    private final MaintenanceService maintenanceService;

    private final ZkProducerAdapter zkProducer;

    private final ScpayProperties scpayProperties;

    private final CamelController camelController;

    private volatile String prevBankDefaultBroadcastNotificationMsgId;

    private final Set<String> localSuspendedBicCodes = new HashSet<>();

    private final Set<String> localRevokedBicCodes = new HashSet<>();

    private final ReentrantLock lock = new ReentrantLock();

    public BankDefaultBroadcastHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        super(exceptionProcessor, messageMarshaller);
        this.maintenanceService = maintenanceService;
        this.zkProducer = zkProducer;
        this.scpayProperties = scpayProperties;
        this.camelController = camelController;
    }

    @PostConstruct
    public void initiateBankDefaultBroadcastHandler() {
        if (scpayProperties.getNotification().isEnabled()) {
            // register notification node on zk
            log.info("Notification is enabled, just initiate bank default broadcast handler.");
            handleEvent(null);
            log.info("Initiating bank default broadcast handler has done.");
        }
    }

    @Override
    public List<EventCode> getCode() {
        return Collections.singletonList(EventCode.BANK_DEFAULT_BROADCAST);
    }

    @Override
    public void handleNotification(Notification notification) {
        String messageId = notification.getHeader().getMessageId();
        log.info("Start to handler snm notification messageId={}", messageId);

        try {
            DefaultStatusType defaultStatus = notification.getData().getDefaultStatus();
            if (defaultStatus == null) {
                log.error("/data/dftlSts is empty");
                throw new RuntimeException("/data/dftlSts is empty");
            }

            String bicCode = notification.getData().getBankSWIFTBIC();
            if (bicCode == null) {
                log.error("/data/bkSwiftBic is empty");
                throw new RuntimeException("/data/bkSwiftBic is empty");
            }

            log.info("Default status is {} and bicCode is {}", defaultStatus, bicCode);

            boolean needPublish = false;
            maintenanceService.refreshBankDefaultBroadcastSuspendedBicCodes();
            if (defaultStatus == DefaultStatusType.NORMAL) {
                // revoke Stop Payments for the Participant Bank BIC
                log.info("revoke Stop Payments for the bic code {}.", bicCode);
                if (!maintenanceService.bankDefaultBroadcastSuspendedBicCodeExists() ||
                        !maintenanceService.getBankDefaultBroadcastRevokedBicCodes().contains(bicCode)) {
                    needPublish = true;
                }
                maintenanceService.removeBankDefaultBroadcastBicCode(bicCode, messageId);
            } else {
                // Stop Payments for the Participant Bank BIC
                log.info("Stop Payments for the bic code {}", bicCode);
                if (!maintenanceService.bankDefaultBroadcastSuspendedBicCodeExists() ||
                        !maintenanceService.getBankDefaultBroadcastSuspendedBicCodes().contains(bicCode)) {
                    needPublish = true;
                }
                maintenanceService.addBankDefaultBroadcastBicCode(bicCode, messageId);
            }
            notification.getHeader().setResponseStatus(SUCCESS_STATUS);
            notification.getHeader().setChannelId(CHANNEL_ID);
            notification.getHeader().setDestination(CHANNEL_SCP);
            notification.getHeader().setProcessingDate(LocalDateTime.now());
            if (needPublish) {
                log.info("publish bank default broadcast notification with messageId={}.", messageId);
                zkProducer.publishBankDefaultBroadcastNotification(messageId);
            }
        } catch (Exception e) {
            log.error("Failed to handle bank status broadcast notification {}",
                    notification.getHeader().getTransactionReference(), e);
            throw new RuntimeException(e);
        }

    }

    @Override
    public void handleEvent(String messageId) {
        if (StringUtils.isNotEmpty(messageId) && StringUtils
                .equals(messageId, prevBankDefaultBroadcastNotificationMsgId)) {
            log.info("messageId={} has not been updated, skip refreshing bank default broadcast route.", messageId);
            return;
        }
        log.info("Refreshing Bank Default Broadcast route for messageId={}", messageId);
        refreshRouteStatus(false);
        log.info("Updating prevBankDefaultBroadcastNotificationMsgId={}", messageId);
        prevBankDefaultBroadcastNotificationMsgId = messageId;
    }

    @Override
    public void refreshRouteStatus(boolean daemon) {
        log.info("Starting to refresh bank default broadcast route status for daemon={}", daemon);
        maintenanceService.refreshBankDefaultBroadcastSuspendedBicCodes();
        boolean isLockAcquired;

        if (!daemon) {
            lock.lock();
        } else {
            isLockAcquired = lock.tryLock();

            if (!isLockAcquired) {
                log.info("Daemon task failed to acquire the lock for refreshing bank default broadcast route status, try on the next round.");
                return;
            }
        }

        try {
            if (daemon) {
                localSuspendedBicCodes.clear();
                localRevokedBicCodes.clear();
            }
            Set<String> bankDefaultBroadcastSuspendedBicCodes = maintenanceService.getBankDefaultBroadcastSuspendedBicCodes();
            SetView<String> diffSuspendedBicCodes = Sets.difference(bankDefaultBroadcastSuspendedBicCodes, localSuspendedBicCodes);
            if (diffSuspendedBicCodes.size() > 0) {
                log.info("{} changed bic codes found for updating suspended route status", diffSuspendedBicCodes.size());
            }
            diffSuspendedBicCodes.forEach(bicCode -> {
                String endpoint = String
                        .format(scpayProperties.getNotification().getBankDefaultBroadcast().getSuspendQueueTemplate(),
                                bicCode);
                String routeId = String
                        .format(scpayProperties.getNotification().getBankDefaultBroadcast().getSuspendRouteIdTemplate(),
                                bicCode);
                int maxAttempts = scpayProperties.getNotification().getBankDefaultBroadcast().getMaxAttempts();
                try {
                    log.info("add or suspend route for endpoint={}, routeId={}, code={}", endpoint, routeId, bicCode);
                    camelController.addOrSuspendRoute(routeId, maxAttempts, this.suspendedRouteBuilder(endpoint, routeId));
                    localSuspendedBicCodes.add(bicCode);
                    localRevokedBicCodes.remove(bicCode);
                } catch (Exception e) {
                    log.error("Failed to suspend endpoint={}", endpoint, e);
                }
            });
            Set<String> bankDefaultBroadcastRevokedBicCodes = maintenanceService.getBankDefaultBroadcastRevokedBicCodes();
            SetView<String> diffRevokedBicCodes = Sets
                    .difference(bankDefaultBroadcastRevokedBicCodes, localRevokedBicCodes);
            if (diffRevokedBicCodes.size() > 0) {
                log.info("{} bic codes found for updating revoked route status", diffRevokedBicCodes.size());
            }
            diffRevokedBicCodes.forEach(bicCode -> {
                String endpoint = String.format(
                        scpayProperties.getNotification().getBankDefaultBroadcast().getSuspendQueueTemplate(),
                        bicCode);
                String routeId = String
                        .format(scpayProperties.getNotification().getBankDefaultBroadcast().getSuspendRouteIdTemplate(),
                                bicCode);
                int maxAttempts = scpayProperties.getNotification().getBankDefaultBroadcast().getMaxAttempts();
                try {
                    log.info("try to revoke route for endpoint={}, routeId={}, bicCode={}", endpoint, routeId, bicCode);
                    camelController.addOrResumeRoute(routeId, maxAttempts, this.revokedRouteBuilder(endpoint, routeId));
                    localRevokedBicCodes.add(bicCode);
                    localSuspendedBicCodes.remove(bicCode);
                } catch (Exception e) {
                    log.error("Failed to revoke endpoint={}", endpoint, e);
                }
            });
        } finally {
            lock.unlock();
        }
    }
}

package com.scb.s2b.api.payment.api.v2;

import com.scb.s2b.api.openapi.payment.v2.PaymentsApi;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiBulkPaymentInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPayeeInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentClientReferences;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentStatusRequest;
import com.scb.s2b.api.payment.api.BulkPaymentApiImpl;
import com.scb.s2b.api.payment.api.CrossborderPaymentApiImpl;
import com.scb.s2b.api.payment.api.ImpsApiImpl;
import com.scb.s2b.api.payment.api.MobileWalletPaymentApiImpl;
import com.scb.s2b.api.payment.api.NonFastPaymentApiImpl;
import com.scb.s2b.api.payment.api.FastPaymentApiImpl;
import com.scb.s2b.api.payment.api.PaynowApiImpl;
import com.scb.s2b.api.payment.api.*;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.springframework.beans.factory.annotation.Autowired;

@SuppressWarnings("unused")
public class PaymentsApiFacade implements PaymentsApi {

    @Context
    private HttpHeaders headers;

    @Autowired
    private FastPaymentApiImpl paymentApi;

    @Autowired
    private NapasApiImpl napasApi;

    @Autowired
    private ImpsApiImpl impsApi;

    @Autowired
    private ImpsProxyApiImpl impsProxyApi;

    @Autowired
    private PaynowApiImpl paynowApi;

    @Autowired
    private CrossborderPaymentApiImpl crossborderApi;

    @Autowired
    private PayrollApiImpl payrollApi;

    @Autowired
    private MobileWalletPaymentApiImpl mwpApi;

    @Autowired
    private NonFastPaymentApiImpl nonFastPaymentApi;

    @Autowired
    private BulkPaymentApiImpl bulkPaymentApi;

    @Autowired
    private PSD2PaymentApiImpl psd2PaymentApi;

    @Autowired
    private InstaPayPaymentApiImpl instaPayBankTransferPaymentApi;

    @Autowired
    private InstaPayProxyPaymentApiImpl instaPayProxyPaymentApi;

    @Autowired
    private PaymentStatusApiImpl paymentStatusApi;

    @Autowired
    private PaymentRetrieveApiImpl paymentRetrieveApi;

    @Autowired
    private FpsPaymentApiImpl fpsPaymentApi;

    @Autowired
    private FpsProxyPaymentApiImpl fpsProxyPaymentApi;

    @Autowired
    private PromptPayPaymentApiImpl promptPayApi;

    @Autowired
    private PromptPayProxyPaymentApiImpl promptPayProxyApi;

    @Autowired
    private PayeesPaymentApiImpl payeePaymentApi;

    @Override
    public Response crossborderInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return crossborderApi.paymentCrossborderInitiate(preVerified, body, headers);
    }

    @Override
    public Response fastInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return paymentApi.paymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response napasBankTransferInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return napasApi.paymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response instaPayBankTransferInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return instaPayBankTransferPaymentApi.paymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response fpsInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return fpsPaymentApi.paymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response impsInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return impsApi.paymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response impsProxyInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return impsProxyApi.paymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response paynowInitiate(@Valid OpenApiPaymentInstruction body) {
        return paynowApi.paynowInitiate(body, headers);
    }

    @Override
    public Response paynowInitiateProxyValidation(@Valid OpenApiPaymentInstruction body) {
        return paynowApi.paynowInitiateProxyValidation(body, headers);
    }

    @Override
    public Response instaPayProxyPaymentInitiate(@Valid OpenApiPaymentInstruction body) {
        return instaPayProxyPaymentApi.paynowInitiate(body, headers);
    }

    @Override
    public Response instaPayProxyPaymentInitiateProxyValidation(@Valid OpenApiPaymentInstruction body) {
        return instaPayProxyPaymentApi.paynowInitiateProxyValidation(body, headers);
    }

    @Override
    public Response fpsProxyPaymentInitiate(@Valid OpenApiPaymentInstruction body) {
        return fpsProxyPaymentApi.paynowInitiate(body, headers);
    }

    @Override
    public Response fpsProxyPaymentInitiateProxyValidation(@Valid OpenApiPaymentInstruction body) {
        return fpsProxyPaymentApi.paynowInitiateProxyValidation(body, headers);
    }

    @Override
    public Response paynowStatus(@Valid OpenApiPaymentStatusRequest body) {
        return paymentStatusApi.paynowStatus(body, headers);
    }

    @Override
    public Response payrollInitiate(String preVerified, @Valid OpenApiBulkPaymentInstruction body) {
        return payrollApi.bulkPaymentInitiate(body, headers);
    }

    @Override
    public Response paymentRetrieve(@NotBlank String referenceId) {
        return paymentRetrieveApi.paymentRetrieve(referenceId, headers);
    }

    @Override
    public Response paymentsStatus(@Valid OpenApiPaymentClientReferences body) {
        return paymentStatusApi.paymentsStatus(body, headers);
    }

    @Override
    public Response mobileWalletPaymentInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return mwpApi.mobileWalletPaymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response nonFastPaymentInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return nonFastPaymentApi.paymentNonFastInitiate(preVerified, body, headers);
    }

    @Override
    public Response paymentsBulkInitiate(String preVerified, OpenApiBulkPaymentInstruction body) {
        return bulkPaymentApi.bulkPaymentInitiate(body, headers);
    }

    @Override
    public Response psd2PaymentInitiate(String preVerified, @Valid OpenApiPaymentInstruction body) {
        return psd2PaymentApi.psd2FasterpaymentInitiate(preVerified, body, headers);
    }

    @Override
    public Response promptPayBankTransferInitiate(@Valid OpenApiPaymentInstruction body) {
        return promptPayApi.paymentInitiate(body, headers);
    }

    @Override
    public Response promptPayProxyPaymentInitiate(@Valid OpenApiPaymentInstruction body) {
        return promptPayProxyApi.paymentInitiate(body, headers);
    }

    @Override
    public Response payeesInitiate(String preVerified, @Valid OpenApiPayeeInstruction body) {
        return payeePaymentApi.payeesPaymentInitiate(preVerified, body, headers);
    }
}

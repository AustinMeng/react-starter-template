package com.scb.s2b.api.payment.config.property;

import lombok.Data;

@Data
public class BeneficiaryEnquiryProperties {
    private boolean enabled = true;
    private String requestQueue;
    private String responseQueue;
}

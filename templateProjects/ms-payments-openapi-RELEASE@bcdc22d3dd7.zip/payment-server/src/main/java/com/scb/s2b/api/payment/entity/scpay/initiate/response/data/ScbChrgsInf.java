
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "chrgCd",
    "amt",
    "ccy",
    "pnlAcctNb",
    "ttlTaxAmt",
    "taxAmt"
})
public class ScbChrgsInf {

    @JsonProperty("chrgCd")
    private String chrgCd;
    @JsonProperty("amt")
    private String amt;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("pnlAcctNb")
    private String pnlAcctNb;
    @JsonProperty("ttlTaxAmt")
    private String ttlTaxAmt;
    @JsonProperty("taxAmt")
    private List<TaxAmt> taxAmt = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("chrgCd")
    public String getChrgCd() {
        return chrgCd;
    }

    @JsonProperty("chrgCd")
    public void setChrgCd(String chrgCd) {
        this.chrgCd = chrgCd;
    }

    public ScbChrgsInf withChrgCd(String chrgCd) {
        this.chrgCd = chrgCd;
        return this;
    }

    @JsonProperty("amt")
    public String getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(String amt) {
        this.amt = amt;
    }

    public ScbChrgsInf withAmt(String amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public ScbChrgsInf withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("pnlAcctNb")
    public String getPnlAcctNb() {
        return pnlAcctNb;
    }

    @JsonProperty("pnlAcctNb")
    public void setPnlAcctNb(String pnlAcctNb) {
        this.pnlAcctNb = pnlAcctNb;
    }

    public ScbChrgsInf withPnlAcctNb(String pnlAcctNb) {
        this.pnlAcctNb = pnlAcctNb;
        return this;
    }

    @JsonProperty("ttlTaxAmt")
    public String getTtlTaxAmt() {
        return ttlTaxAmt;
    }

    @JsonProperty("ttlTaxAmt")
    public void setTtlTaxAmt(String ttlTaxAmt) {
        this.ttlTaxAmt = ttlTaxAmt;
    }

    public ScbChrgsInf withTtlTaxAmt(String ttlTaxAmt) {
        this.ttlTaxAmt = ttlTaxAmt;
        return this;
    }

    @JsonProperty("taxAmt")
    public List<TaxAmt> getTaxAmt() {
        return taxAmt;
    }

    @JsonProperty("taxAmt")
    public void setTaxAmt(List<TaxAmt> taxAmt) {
        this.taxAmt = taxAmt;
    }

    public ScbChrgsInf withTaxAmt(List<TaxAmt> taxAmt) {
        this.taxAmt = taxAmt;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ScbChrgsInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(chrgCd).append(amt).append(ccy).append(pnlAcctNb).append(ttlTaxAmt).append(taxAmt).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ScbChrgsInf) == false) {
            return false;
        }
        ScbChrgsInf rhs = ((ScbChrgsInf) other);
        return new EqualsBuilder().append(chrgCd, rhs.chrgCd).append(amt, rhs.amt).append(ccy, rhs.ccy).append(pnlAcctNb, rhs.pnlAcctNb).append(ttlTaxAmt, rhs.ttlTaxAmt).append(taxAmt, rhs.taxAmt).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

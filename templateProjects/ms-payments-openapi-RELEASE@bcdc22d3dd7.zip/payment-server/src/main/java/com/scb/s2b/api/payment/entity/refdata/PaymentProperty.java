package com.scb.s2b.api.payment.entity.refdata;

import com.scb.s2b.api.payment.entity.PaymentSystem;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@Data
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class PaymentProperty implements Serializable {

    @Builder.Default
    private Set<String> cities = new HashSet<>();

    @Builder.Default
    private PaymentSystem system = PaymentSystem.SCPAY;

    private String chargerBearer;

    @Builder.Default
    private String categoryPurpose = "OTHR";

    private String defaultCity;

    @Builder.Default
    private String paymentMethod = "TRF";

    @Builder.Default
    private boolean inferPaymentType = true;

    @Builder.Default
    private List<String> supportedPaymentTypes = new ArrayList<>();
}

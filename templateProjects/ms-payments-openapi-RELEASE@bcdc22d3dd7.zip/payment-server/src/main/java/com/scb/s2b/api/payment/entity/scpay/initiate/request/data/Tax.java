
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cdtrTaxId",
    "cdtrRegnId",
    "cdtrTaxTp",
    "dbtrTaxId",
    "dbtrRegnId",
    "dbtrTaxTp",
    "dbtrAuthstnTitl",
    "dbtrAuthstnNm",
    "admstnZone",
    "refNb",
    "mtd",
    "ttlTaxblBaseAmt",
    "ttlTaxblBaseAmtCcy",
    "ttlTaxAmt",
    "ttlTaxAmtCcy",
    "dt",
    "seqNb",
    "rcrd",
    "WHTInf"
})
public class Tax {

    @JsonProperty("cdtrTaxId")
    private String cdtrTaxId;
    @JsonProperty("cdtrRegnId")
    private String cdtrRegnId;
    @JsonProperty("cdtrTaxTp")
    private String cdtrTaxTp;
    @JsonProperty("dbtrTaxId")
    private String dbtrTaxId;
    @JsonProperty("dbtrRegnId")
    private String dbtrRegnId;
    @JsonProperty("dbtrTaxTp")
    private String dbtrTaxTp;
    @JsonProperty("dbtrAuthstnTitl")
    private String dbtrAuthstnTitl;
    @JsonProperty("dbtrAuthstnNm")
    private String dbtrAuthstnNm;
    @JsonProperty("admstnZone")
    private String admstnZone;
    @JsonProperty("refNb")
    private String refNb;
    @JsonProperty("mtd")
    private String mtd;
    @JsonProperty("ttlTaxblBaseAmt")
    private String ttlTaxblBaseAmt;
    @JsonProperty("ttlTaxblBaseAmtCcy")
    private String ttlTaxblBaseAmtCcy;
    @JsonProperty("ttlTaxAmt")
    private String ttlTaxAmt;
    @JsonProperty("ttlTaxAmtCcy")
    private String ttlTaxAmtCcy;
    @JsonProperty("dt")
    private String dt;
    @JsonProperty("seqNb")
    private String seqNb;
    @JsonProperty("rcrd")
    private List<Rcrd> rcrd = null;
    @JsonProperty("WHTInf")
    private WHTInf wHTInf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cdtrTaxId")
    public String getCdtrTaxId() {
        return cdtrTaxId;
    }

    @JsonProperty("cdtrTaxId")
    public void setCdtrTaxId(String cdtrTaxId) {
        this.cdtrTaxId = cdtrTaxId;
    }

    public Tax withCdtrTaxId(String cdtrTaxId) {
        this.cdtrTaxId = cdtrTaxId;
        return this;
    }

    @JsonProperty("cdtrRegnId")
    public String getCdtrRegnId() {
        return cdtrRegnId;
    }

    @JsonProperty("cdtrRegnId")
    public void setCdtrRegnId(String cdtrRegnId) {
        this.cdtrRegnId = cdtrRegnId;
    }

    public Tax withCdtrRegnId(String cdtrRegnId) {
        this.cdtrRegnId = cdtrRegnId;
        return this;
    }

    @JsonProperty("cdtrTaxTp")
    public String getCdtrTaxTp() {
        return cdtrTaxTp;
    }

    @JsonProperty("cdtrTaxTp")
    public void setCdtrTaxTp(String cdtrTaxTp) {
        this.cdtrTaxTp = cdtrTaxTp;
    }

    public Tax withCdtrTaxTp(String cdtrTaxTp) {
        this.cdtrTaxTp = cdtrTaxTp;
        return this;
    }

    @JsonProperty("dbtrTaxId")
    public String getDbtrTaxId() {
        return dbtrTaxId;
    }

    @JsonProperty("dbtrTaxId")
    public void setDbtrTaxId(String dbtrTaxId) {
        this.dbtrTaxId = dbtrTaxId;
    }

    public Tax withDbtrTaxId(String dbtrTaxId) {
        this.dbtrTaxId = dbtrTaxId;
        return this;
    }

    @JsonProperty("dbtrRegnId")
    public String getDbtrRegnId() {
        return dbtrRegnId;
    }

    @JsonProperty("dbtrRegnId")
    public void setDbtrRegnId(String dbtrRegnId) {
        this.dbtrRegnId = dbtrRegnId;
    }

    public Tax withDbtrRegnId(String dbtrRegnId) {
        this.dbtrRegnId = dbtrRegnId;
        return this;
    }

    @JsonProperty("dbtrTaxTp")
    public String getDbtrTaxTp() {
        return dbtrTaxTp;
    }

    @JsonProperty("dbtrTaxTp")
    public void setDbtrTaxTp(String dbtrTaxTp) {
        this.dbtrTaxTp = dbtrTaxTp;
    }

    public Tax withDbtrTaxTp(String dbtrTaxTp) {
        this.dbtrTaxTp = dbtrTaxTp;
        return this;
    }

    @JsonProperty("dbtrAuthstnTitl")
    public String getDbtrAuthstnTitl() {
        return dbtrAuthstnTitl;
    }

    @JsonProperty("dbtrAuthstnTitl")
    public void setDbtrAuthstnTitl(String dbtrAuthstnTitl) {
        this.dbtrAuthstnTitl = dbtrAuthstnTitl;
    }

    public Tax withDbtrAuthstnTitl(String dbtrAuthstnTitl) {
        this.dbtrAuthstnTitl = dbtrAuthstnTitl;
        return this;
    }

    @JsonProperty("dbtrAuthstnNm")
    public String getDbtrAuthstnNm() {
        return dbtrAuthstnNm;
    }

    @JsonProperty("dbtrAuthstnNm")
    public void setDbtrAuthstnNm(String dbtrAuthstnNm) {
        this.dbtrAuthstnNm = dbtrAuthstnNm;
    }

    public Tax withDbtrAuthstnNm(String dbtrAuthstnNm) {
        this.dbtrAuthstnNm = dbtrAuthstnNm;
        return this;
    }

    @JsonProperty("admstnZone")
    public String getAdmstnZone() {
        return admstnZone;
    }

    @JsonProperty("admstnZone")
    public void setAdmstnZone(String admstnZone) {
        this.admstnZone = admstnZone;
    }

    public Tax withAdmstnZone(String admstnZone) {
        this.admstnZone = admstnZone;
        return this;
    }

    @JsonProperty("refNb")
    public String getRefNb() {
        return refNb;
    }

    @JsonProperty("refNb")
    public void setRefNb(String refNb) {
        this.refNb = refNb;
    }

    public Tax withRefNb(String refNb) {
        this.refNb = refNb;
        return this;
    }

    @JsonProperty("mtd")
    public String getMtd() {
        return mtd;
    }

    @JsonProperty("mtd")
    public void setMtd(String mtd) {
        this.mtd = mtd;
    }

    public Tax withMtd(String mtd) {
        this.mtd = mtd;
        return this;
    }

    @JsonProperty("ttlTaxblBaseAmt")
    public String getTtlTaxblBaseAmt() {
        return ttlTaxblBaseAmt;
    }

    @JsonProperty("ttlTaxblBaseAmt")
    public void setTtlTaxblBaseAmt(String ttlTaxblBaseAmt) {
        this.ttlTaxblBaseAmt = ttlTaxblBaseAmt;
    }

    public Tax withTtlTaxblBaseAmt(String ttlTaxblBaseAmt) {
        this.ttlTaxblBaseAmt = ttlTaxblBaseAmt;
        return this;
    }

    @JsonProperty("ttlTaxblBaseAmtCcy")
    public String getTtlTaxblBaseAmtCcy() {
        return ttlTaxblBaseAmtCcy;
    }

    @JsonProperty("ttlTaxblBaseAmtCcy")
    public void setTtlTaxblBaseAmtCcy(String ttlTaxblBaseAmtCcy) {
        this.ttlTaxblBaseAmtCcy = ttlTaxblBaseAmtCcy;
    }

    public Tax withTtlTaxblBaseAmtCcy(String ttlTaxblBaseAmtCcy) {
        this.ttlTaxblBaseAmtCcy = ttlTaxblBaseAmtCcy;
        return this;
    }

    @JsonProperty("ttlTaxAmt")
    public String getTtlTaxAmt() {
        return ttlTaxAmt;
    }

    @JsonProperty("ttlTaxAmt")
    public void setTtlTaxAmt(String ttlTaxAmt) {
        this.ttlTaxAmt = ttlTaxAmt;
    }

    public Tax withTtlTaxAmt(String ttlTaxAmt) {
        this.ttlTaxAmt = ttlTaxAmt;
        return this;
    }

    @JsonProperty("ttlTaxAmtCcy")
    public String getTtlTaxAmtCcy() {
        return ttlTaxAmtCcy;
    }

    @JsonProperty("ttlTaxAmtCcy")
    public void setTtlTaxAmtCcy(String ttlTaxAmtCcy) {
        this.ttlTaxAmtCcy = ttlTaxAmtCcy;
    }

    public Tax withTtlTaxAmtCcy(String ttlTaxAmtCcy) {
        this.ttlTaxAmtCcy = ttlTaxAmtCcy;
        return this;
    }

    @JsonProperty("dt")
    public String getDt() {
        return dt;
    }

    @JsonProperty("dt")
    public void setDt(String dt) {
        this.dt = dt;
    }

    public Tax withDt(String dt) {
        this.dt = dt;
        return this;
    }

    @JsonProperty("seqNb")
    public String getSeqNb() {
        return seqNb;
    }

    @JsonProperty("seqNb")
    public void setSeqNb(String seqNb) {
        this.seqNb = seqNb;
    }

    public Tax withSeqNb(String seqNb) {
        this.seqNb = seqNb;
        return this;
    }

    @JsonProperty("rcrd")
    public List<Rcrd> getRcrd() {
        return rcrd;
    }

    @JsonProperty("rcrd")
    public void setRcrd(List<Rcrd> rcrd) {
        this.rcrd = rcrd;
    }

    public Tax withRcrd(List<Rcrd> rcrd) {
        this.rcrd = rcrd;
        return this;
    }

    @JsonProperty("WHTInf")
    public WHTInf getWHTInf() {
        return wHTInf;
    }

    @JsonProperty("WHTInf")
    public void setWHTInf(WHTInf wHTInf) {
        this.wHTInf = wHTInf;
    }

    public Tax withWHTInf(WHTInf wHTInf) {
        this.wHTInf = wHTInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Tax withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cdtrTaxId).append(cdtrRegnId).append(cdtrTaxTp).append(dbtrTaxId).append(dbtrRegnId).append(dbtrTaxTp).append(dbtrAuthstnTitl).append(dbtrAuthstnNm).append(admstnZone).append(refNb).append(mtd).append(ttlTaxblBaseAmt).append(ttlTaxblBaseAmtCcy).append(ttlTaxAmt).append(ttlTaxAmtCcy).append(dt).append(seqNb).append(rcrd).append(wHTInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Tax) == false) {
            return false;
        }
        Tax rhs = ((Tax) other);
        return new EqualsBuilder().append(cdtrTaxId, rhs.cdtrTaxId).append(cdtrRegnId, rhs.cdtrRegnId).append(cdtrTaxTp, rhs.cdtrTaxTp).append(dbtrTaxId, rhs.dbtrTaxId).append(dbtrRegnId, rhs.dbtrRegnId).append(dbtrTaxTp, rhs.dbtrTaxTp).append(dbtrAuthstnTitl, rhs.dbtrAuthstnTitl).append(dbtrAuthstnNm, rhs.dbtrAuthstnNm).append(admstnZone, rhs.admstnZone).append(refNb, rhs.refNb).append(mtd, rhs.mtd).append(ttlTaxblBaseAmt, rhs.ttlTaxblBaseAmt).append(ttlTaxblBaseAmtCcy, rhs.ttlTaxblBaseAmtCcy).append(ttlTaxAmt, rhs.ttlTaxAmt).append(ttlTaxAmtCcy, rhs.ttlTaxAmtCcy).append(dt, rhs.dt).append(seqNb, rhs.seqNb).append(rcrd, rhs.rcrd).append(wHTInf, rhs.wHTInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

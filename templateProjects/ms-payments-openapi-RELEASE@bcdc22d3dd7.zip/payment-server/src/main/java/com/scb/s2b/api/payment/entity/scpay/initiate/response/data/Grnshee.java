
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "nm",
    "ctryOfRes",
    "pstlAdr",
    "orgId",
    "prvtId",
    "ctctDtls"
})
public class Grnshee {

    @JsonProperty("nm")
    private String nm;
    @JsonProperty("ctryOfRes")
    private String ctryOfRes;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonProperty("orgId")
    private OrgId orgId;
    @JsonProperty("prvtId")
    private PrvtId prvtId;
    @JsonProperty("ctctDtls")
    private CtctDtls ctctDtls;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public Grnshee withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("ctryOfRes")
    public String getCtryOfRes() {
        return ctryOfRes;
    }

    @JsonProperty("ctryOfRes")
    public void setCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
    }

    public Grnshee withCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public Grnshee withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @JsonProperty("orgId")
    public OrgId getOrgId() {
        return orgId;
    }

    @JsonProperty("orgId")
    public void setOrgId(OrgId orgId) {
        this.orgId = orgId;
    }

    public Grnshee withOrgId(OrgId orgId) {
        this.orgId = orgId;
        return this;
    }

    @JsonProperty("prvtId")
    public PrvtId getPrvtId() {
        return prvtId;
    }

    @JsonProperty("prvtId")
    public void setPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
    }

    public Grnshee withPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
        return this;
    }

    @JsonProperty("ctctDtls")
    public CtctDtls getCtctDtls() {
        return ctctDtls;
    }

    @JsonProperty("ctctDtls")
    public void setCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
    }

    public Grnshee withCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Grnshee withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(nm).append(ctryOfRes).append(pstlAdr).append(orgId).append(prvtId).append(ctctDtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Grnshee) == false) {
            return false;
        }
        Grnshee rhs = ((Grnshee) other);
        return new EqualsBuilder().append(nm, rhs.nm).append(ctryOfRes, rhs.ctryOfRes).append(pstlAdr, rhs.pstlAdr).append(orgId, rhs.orgId).append(prvtId, rhs.prvtId).append(ctctDtls, rhs.ctctDtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

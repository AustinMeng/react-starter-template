
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "chqTp",
    "chqNb",
    "cstmrAssgndChqNb",
    "chqFr",
    "nm",
    "dlvryMtdCd",
    "dlvryMtdPrtry",
    "instrPrty",
    "chqMtrtyDt",
    "frmsCd",
    "memoFld",
    "rgnlClrZone",
    "prtLctn",
    "sgntr",
    "chqIsseDt",
    "xtrnlMemo",
    "drweeBkCd",
    "rltdInf",
    "imprtSeqRef",
    "pstlAdr",
    "dlvrTo"
})
public class ChqInstr {

    @JsonProperty("chqTp")
    private String chqTp;
    @JsonProperty("chqNb")
    private String chqNb;
    @JsonProperty("cstmrAssgndChqNb")
    private String cstmrAssgndChqNb;
    @JsonProperty("chqFr")
    private String chqFr;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("dlvryMtdCd")
    private String dlvryMtdCd;
    @JsonProperty("dlvryMtdPrtry")
    private String dlvryMtdPrtry;
    @JsonProperty("instrPrty")
    private String instrPrty;
    @JsonProperty("chqMtrtyDt")
    private String chqMtrtyDt;
    @JsonProperty("frmsCd")
    private String frmsCd;
    @JsonProperty("memoFld")
    private String memoFld;
    @JsonProperty("rgnlClrZone")
    private String rgnlClrZone;
    @JsonProperty("prtLctn")
    private String prtLctn;
    @JsonProperty("sgntr")
    private List<String> sgntr = null;
    @JsonProperty("chqIsseDt")
    private String chqIsseDt;
    @JsonProperty("xtrnlMemo")
    private String xtrnlMemo;
    @JsonProperty("drweeBkCd")
    private String drweeBkCd;
    @JsonProperty("rltdInf")
    private String rltdInf;
    @JsonProperty("imprtSeqRef")
    private String imprtSeqRef;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonProperty("dlvrTo")
    private DlvrTo dlvrTo;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("chqTp")
    public String getChqTp() {
        return chqTp;
    }

    @JsonProperty("chqTp")
    public void setChqTp(String chqTp) {
        this.chqTp = chqTp;
    }

    public ChqInstr withChqTp(String chqTp) {
        this.chqTp = chqTp;
        return this;
    }

    @JsonProperty("chqNb")
    public String getChqNb() {
        return chqNb;
    }

    @JsonProperty("chqNb")
    public void setChqNb(String chqNb) {
        this.chqNb = chqNb;
    }

    public ChqInstr withChqNb(String chqNb) {
        this.chqNb = chqNb;
        return this;
    }

    @JsonProperty("cstmrAssgndChqNb")
    public String getCstmrAssgndChqNb() {
        return cstmrAssgndChqNb;
    }

    @JsonProperty("cstmrAssgndChqNb")
    public void setCstmrAssgndChqNb(String cstmrAssgndChqNb) {
        this.cstmrAssgndChqNb = cstmrAssgndChqNb;
    }

    public ChqInstr withCstmrAssgndChqNb(String cstmrAssgndChqNb) {
        this.cstmrAssgndChqNb = cstmrAssgndChqNb;
        return this;
    }

    @JsonProperty("chqFr")
    public String getChqFr() {
        return chqFr;
    }

    @JsonProperty("chqFr")
    public void setChqFr(String chqFr) {
        this.chqFr = chqFr;
    }

    public ChqInstr withChqFr(String chqFr) {
        this.chqFr = chqFr;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public ChqInstr withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("dlvryMtdCd")
    public String getDlvryMtdCd() {
        return dlvryMtdCd;
    }

    @JsonProperty("dlvryMtdCd")
    public void setDlvryMtdCd(String dlvryMtdCd) {
        this.dlvryMtdCd = dlvryMtdCd;
    }

    public ChqInstr withDlvryMtdCd(String dlvryMtdCd) {
        this.dlvryMtdCd = dlvryMtdCd;
        return this;
    }

    @JsonProperty("dlvryMtdPrtry")
    public String getDlvryMtdPrtry() {
        return dlvryMtdPrtry;
    }

    @JsonProperty("dlvryMtdPrtry")
    public void setDlvryMtdPrtry(String dlvryMtdPrtry) {
        this.dlvryMtdPrtry = dlvryMtdPrtry;
    }

    public ChqInstr withDlvryMtdPrtry(String dlvryMtdPrtry) {
        this.dlvryMtdPrtry = dlvryMtdPrtry;
        return this;
    }

    @JsonProperty("instrPrty")
    public String getInstrPrty() {
        return instrPrty;
    }

    @JsonProperty("instrPrty")
    public void setInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
    }

    public ChqInstr withInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
        return this;
    }

    @JsonProperty("chqMtrtyDt")
    public String getChqMtrtyDt() {
        return chqMtrtyDt;
    }

    @JsonProperty("chqMtrtyDt")
    public void setChqMtrtyDt(String chqMtrtyDt) {
        this.chqMtrtyDt = chqMtrtyDt;
    }

    public ChqInstr withChqMtrtyDt(String chqMtrtyDt) {
        this.chqMtrtyDt = chqMtrtyDt;
        return this;
    }

    @JsonProperty("frmsCd")
    public String getFrmsCd() {
        return frmsCd;
    }

    @JsonProperty("frmsCd")
    public void setFrmsCd(String frmsCd) {
        this.frmsCd = frmsCd;
    }

    public ChqInstr withFrmsCd(String frmsCd) {
        this.frmsCd = frmsCd;
        return this;
    }

    @JsonProperty("memoFld")
    public String getMemoFld() {
        return memoFld;
    }

    @JsonProperty("memoFld")
    public void setMemoFld(String memoFld) {
        this.memoFld = memoFld;
    }

    public ChqInstr withMemoFld(String memoFld) {
        this.memoFld = memoFld;
        return this;
    }

    @JsonProperty("rgnlClrZone")
    public String getRgnlClrZone() {
        return rgnlClrZone;
    }

    @JsonProperty("rgnlClrZone")
    public void setRgnlClrZone(String rgnlClrZone) {
        this.rgnlClrZone = rgnlClrZone;
    }

    public ChqInstr withRgnlClrZone(String rgnlClrZone) {
        this.rgnlClrZone = rgnlClrZone;
        return this;
    }

    @JsonProperty("prtLctn")
    public String getPrtLctn() {
        return prtLctn;
    }

    @JsonProperty("prtLctn")
    public void setPrtLctn(String prtLctn) {
        this.prtLctn = prtLctn;
    }

    public ChqInstr withPrtLctn(String prtLctn) {
        this.prtLctn = prtLctn;
        return this;
    }

    @JsonProperty("sgntr")
    public List<String> getSgntr() {
        return sgntr;
    }

    @JsonProperty("sgntr")
    public void setSgntr(List<String> sgntr) {
        this.sgntr = sgntr;
    }

    public ChqInstr withSgntr(List<String> sgntr) {
        this.sgntr = sgntr;
        return this;
    }

    @JsonProperty("chqIsseDt")
    public String getChqIsseDt() {
        return chqIsseDt;
    }

    @JsonProperty("chqIsseDt")
    public void setChqIsseDt(String chqIsseDt) {
        this.chqIsseDt = chqIsseDt;
    }

    public ChqInstr withChqIsseDt(String chqIsseDt) {
        this.chqIsseDt = chqIsseDt;
        return this;
    }

    @JsonProperty("xtrnlMemo")
    public String getXtrnlMemo() {
        return xtrnlMemo;
    }

    @JsonProperty("xtrnlMemo")
    public void setXtrnlMemo(String xtrnlMemo) {
        this.xtrnlMemo = xtrnlMemo;
    }

    public ChqInstr withXtrnlMemo(String xtrnlMemo) {
        this.xtrnlMemo = xtrnlMemo;
        return this;
    }

    @JsonProperty("drweeBkCd")
    public String getDrweeBkCd() {
        return drweeBkCd;
    }

    @JsonProperty("drweeBkCd")
    public void setDrweeBkCd(String drweeBkCd) {
        this.drweeBkCd = drweeBkCd;
    }

    public ChqInstr withDrweeBkCd(String drweeBkCd) {
        this.drweeBkCd = drweeBkCd;
        return this;
    }

    @JsonProperty("rltdInf")
    public String getRltdInf() {
        return rltdInf;
    }

    @JsonProperty("rltdInf")
    public void setRltdInf(String rltdInf) {
        this.rltdInf = rltdInf;
    }

    public ChqInstr withRltdInf(String rltdInf) {
        this.rltdInf = rltdInf;
        return this;
    }

    @JsonProperty("imprtSeqRef")
    public String getImprtSeqRef() {
        return imprtSeqRef;
    }

    @JsonProperty("imprtSeqRef")
    public void setImprtSeqRef(String imprtSeqRef) {
        this.imprtSeqRef = imprtSeqRef;
    }

    public ChqInstr withImprtSeqRef(String imprtSeqRef) {
        this.imprtSeqRef = imprtSeqRef;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public ChqInstr withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @JsonProperty("dlvrTo")
    public DlvrTo getDlvrTo() {
        return dlvrTo;
    }

    @JsonProperty("dlvrTo")
    public void setDlvrTo(DlvrTo dlvrTo) {
        this.dlvrTo = dlvrTo;
    }

    public ChqInstr withDlvrTo(DlvrTo dlvrTo) {
        this.dlvrTo = dlvrTo;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ChqInstr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(chqTp).append(chqNb).append(cstmrAssgndChqNb).append(chqFr).append(nm).append(dlvryMtdCd).append(dlvryMtdPrtry).append(instrPrty).append(chqMtrtyDt).append(frmsCd).append(memoFld).append(rgnlClrZone).append(prtLctn).append(sgntr).append(chqIsseDt).append(xtrnlMemo).append(drweeBkCd).append(rltdInf).append(imprtSeqRef).append(pstlAdr).append(dlvrTo).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChqInstr) == false) {
            return false;
        }
        ChqInstr rhs = ((ChqInstr) other);
        return new EqualsBuilder().append(chqTp, rhs.chqTp).append(chqNb, rhs.chqNb).append(cstmrAssgndChqNb, rhs.cstmrAssgndChqNb).append(chqFr, rhs.chqFr).append(nm, rhs.nm).append(dlvryMtdCd, rhs.dlvryMtdCd).append(dlvryMtdPrtry, rhs.dlvryMtdPrtry).append(instrPrty, rhs.instrPrty).append(chqMtrtyDt, rhs.chqMtrtyDt).append(frmsCd, rhs.frmsCd).append(memoFld, rhs.memoFld).append(rgnlClrZone, rhs.rgnlClrZone).append(prtLctn, rhs.prtLctn).append(sgntr, rhs.sgntr).append(chqIsseDt, rhs.chqIsseDt).append(xtrnlMemo, rhs.xtrnlMemo).append(drweeBkCd, rhs.drweeBkCd).append(rltdInf, rhs.rltdInf).append(imprtSeqRef, rhs.imprtSeqRef).append(pstlAdr, rhs.pstlAdr).append(dlvrTo, rhs.dlvrTo).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

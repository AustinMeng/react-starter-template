package com.scb.s2b.api.payment.entity.classic;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountDetail implements Serializable {

    private String groupId;

    private String accountId;

    private String branchId;

    private String currencyCode;

    private String accountName;

    private String accountType;

    private String cashAccountType;

    private String iban;

    private String s2bCustomerId;

    private String contactName;

    private String contactNamePrefix;

    private String contactPhoneNumber;

    private String contactMobileNumber;

    private String contactFaxNumber;

    private String contactEmailAddress;

    private String contactOther;

    private String agentBicfi;

    private String agentClearingMemberIdentifier;

    private String agentName;

    private String agentS2bCustomerId;

    private String agentBranchIdentifier;

    private String buildingNumber;

    private String countryCode;

    private String postCode;

    private List<String> addressLines;

    private String partyName;

    private String partyIdentifier;

    private String leId;

    private String countryOfResidence;

    private String stsId;
}

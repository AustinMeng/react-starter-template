package com.scb.s2b.api.payment.entity.payee.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiFinancialInstitution;
import lombok.Getter;

@Getter
public class FinancialInstitution extends OpenApiFinancialInstitution{

    public static final String JSON_PROPERTY_SUB_BRANCH_CODE = "subBranchcode";
    @JsonProperty(JSON_PROPERTY_SUB_BRANCH_CODE)
    private String subBranchCode;

    private String clearingSystemId;
}

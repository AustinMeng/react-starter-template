
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cd",
    "prtry",
    "sndrPurpCd",
    "rcvrPurpCd",
    "sndrPurpDesc",
    "rcvrPurpDesc"
})
public class Purp {

    @JsonProperty("cd")
    private String cd;
    @JsonProperty("prtry")
    private String prtry;
    @JsonProperty("sndrPurpCd")
    private String sndrPurpCd;
    @JsonProperty("rcvrPurpCd")
    private String rcvrPurpCd;
    @JsonProperty("sndrPurpDesc")
    private String sndrPurpDesc;
    @JsonProperty("rcvrPurpDesc")
    private String rcvrPurpDesc;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cd")
    public String getCd() {
        return cd;
    }

    @JsonProperty("cd")
    public void setCd(String cd) {
        this.cd = cd;
    }

    public Purp withCd(String cd) {
        this.cd = cd;
        return this;
    }

    @JsonProperty("prtry")
    public String getPrtry() {
        return prtry;
    }

    @JsonProperty("prtry")
    public void setPrtry(String prtry) {
        this.prtry = prtry;
    }

    public Purp withPrtry(String prtry) {
        this.prtry = prtry;
        return this;
    }

    @JsonProperty("sndrPurpCd")
    public String getSndrPurpCd() {
        return sndrPurpCd;
    }

    @JsonProperty("sndrPurpCd")
    public void setSndrPurpCd(String sndrPurpCd) {
        this.sndrPurpCd = sndrPurpCd;
    }

    public Purp withSndrPurpCd(String sndrPurpCd) {
        this.sndrPurpCd = sndrPurpCd;
        return this;
    }

    @JsonProperty("rcvrPurpCd")
    public String getRcvrPurpCd() {
        return rcvrPurpCd;
    }

    @JsonProperty("rcvrPurpCd")
    public void setRcvrPurpCd(String rcvrPurpCd) {
        this.rcvrPurpCd = rcvrPurpCd;
    }

    public Purp withRcvrPurpCd(String rcvrPurpCd) {
        this.rcvrPurpCd = rcvrPurpCd;
        return this;
    }

    @JsonProperty("sndrPurpDesc")
    public String getSndrPurpDesc() {
        return sndrPurpDesc;
    }

    @JsonProperty("sndrPurpDesc")
    public void setSndrPurpDesc(String sndrPurpDesc) {
        this.sndrPurpDesc = sndrPurpDesc;
    }

    public Purp withSndrPurpDesc(String sndrPurpDesc) {
        this.sndrPurpDesc = sndrPurpDesc;
        return this;
    }

    @JsonProperty("rcvrPurpDesc")
    public String getRcvrPurpDesc() {
        return rcvrPurpDesc;
    }

    @JsonProperty("rcvrPurpDesc")
    public void setRcvrPurpDesc(String rcvrPurpDesc) {
        this.rcvrPurpDesc = rcvrPurpDesc;
    }

    public Purp withRcvrPurpDesc(String rcvrPurpDesc) {
        this.rcvrPurpDesc = rcvrPurpDesc;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Purp withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cd).append(prtry).append(sndrPurpCd).append(rcvrPurpCd).append(sndrPurpDesc).append(rcvrPurpDesc).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Purp) == false) {
            return false;
        }
        Purp rhs = ((Purp) other);
        return new EqualsBuilder().append(cd, rhs.cd).append(prtry, rhs.prtry).append(sndrPurpCd, rhs.sndrPurpCd).append(rcvrPurpCd, rhs.rcvrPurpCd).append(sndrPurpDesc, rhs.sndrPurpDesc).append(rcvrPurpDesc, rhs.rcvrPurpDesc).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}


package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instrPrty",
    "clrChanl",
    "reqdPmtTp",
    "reqdSubPmtTp",
    "pmtTp",
    "subPmtTp",
    "lclInstrmCd",
    "lclInstrmPrtry",
    "ctgyPurpCd",
    "ctgyPurpPrtry",
    "stdPmtPdctCd",
    "apprvlMd",
    "xcssAmtInd",
    "pmtTpDrvdInd",
    "payrollInd",
    "rmtThrghInd",
    "ntrOfTx",
    "ACUInd",
    "byOrdrOfSelfInd",
    "pmtPrxyTp",
    "CASPmtInd",
    "prefrdDnmtn",
    "txPrcgCd",
    "svcLvl"
})
public class PmtTpInf {

    @JsonProperty("instrPrty")
    private String instrPrty;
    @JsonProperty("clrChanl")
    private String clrChanl;
    @JsonProperty("reqdPmtTp")
    private String reqdPmtTp;
    @JsonProperty("reqdSubPmtTp")
    private String reqdSubPmtTp;
    @JsonProperty("pmtTp")
    private String pmtTp;
    @JsonProperty("subPmtTp")
    private String subPmtTp;
    @JsonProperty("lclInstrmCd")
    private String lclInstrmCd;
    @JsonProperty("lclInstrmPrtry")
    private String lclInstrmPrtry;
    @JsonProperty("ctgyPurpCd")
    private String ctgyPurpCd;
    @JsonProperty("ctgyPurpPrtry")
    private String ctgyPurpPrtry;
    @JsonProperty("stdPmtPdctCd")
    private String stdPmtPdctCd;
    @JsonProperty("apprvlMd")
    private String apprvlMd;
    @JsonProperty("xcssAmtInd")
    private String xcssAmtInd;
    @JsonProperty("pmtTpDrvdInd")
    private String pmtTpDrvdInd;
    @JsonProperty("payrollInd")
    private String payrollInd;
    @JsonProperty("rmtThrghInd")
    private String rmtThrghInd;
    @JsonProperty("ntrOfTx")
    private String ntrOfTx;
    @JsonProperty("ACUInd")
    private String aCUInd;
    @JsonProperty("byOrdrOfSelfInd")
    private String byOrdrOfSelfInd;
    @JsonProperty("pmtPrxyTp")
    private String pmtPrxyTp;
    @JsonProperty("CASPmtInd")
    private String cASPmtInd;
    @JsonProperty("prefrdDnmtn")
    private String prefrdDnmtn;
    @JsonProperty("txPrcgCd")
    private String txPrcgCd;
    @JsonProperty("svcLvl")
    private List<SvcLvl> svcLvl = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instrPrty")
    public String getInstrPrty() {
        return instrPrty;
    }

    @JsonProperty("instrPrty")
    public void setInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
    }

    public PmtTpInf withInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
        return this;
    }

    @JsonProperty("clrChanl")
    public String getClrChanl() {
        return clrChanl;
    }

    @JsonProperty("clrChanl")
    public void setClrChanl(String clrChanl) {
        this.clrChanl = clrChanl;
    }

    public PmtTpInf withClrChanl(String clrChanl) {
        this.clrChanl = clrChanl;
        return this;
    }

    @JsonProperty("reqdPmtTp")
    public String getReqdPmtTp() {
        return reqdPmtTp;
    }

    @JsonProperty("reqdPmtTp")
    public void setReqdPmtTp(String reqdPmtTp) {
        this.reqdPmtTp = reqdPmtTp;
    }

    public PmtTpInf withReqdPmtTp(String reqdPmtTp) {
        this.reqdPmtTp = reqdPmtTp;
        return this;
    }

    @JsonProperty("reqdSubPmtTp")
    public String getReqdSubPmtTp() {
        return reqdSubPmtTp;
    }

    @JsonProperty("reqdSubPmtTp")
    public void setReqdSubPmtTp(String reqdSubPmtTp) {
        this.reqdSubPmtTp = reqdSubPmtTp;
    }

    public PmtTpInf withReqdSubPmtTp(String reqdSubPmtTp) {
        this.reqdSubPmtTp = reqdSubPmtTp;
        return this;
    }

    @JsonProperty("pmtTp")
    public String getPmtTp() {
        return pmtTp;
    }

    @JsonProperty("pmtTp")
    public void setPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
    }

    public PmtTpInf withPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
        return this;
    }

    @JsonProperty("subPmtTp")
    public String getSubPmtTp() {
        return subPmtTp;
    }

    @JsonProperty("subPmtTp")
    public void setSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
    }

    public PmtTpInf withSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
        return this;
    }

    @JsonProperty("lclInstrmCd")
    public String getLclInstrmCd() {
        return lclInstrmCd;
    }

    @JsonProperty("lclInstrmCd")
    public void setLclInstrmCd(String lclInstrmCd) {
        this.lclInstrmCd = lclInstrmCd;
    }

    public PmtTpInf withLclInstrmCd(String lclInstrmCd) {
        this.lclInstrmCd = lclInstrmCd;
        return this;
    }

    @JsonProperty("lclInstrmPrtry")
    public String getLclInstrmPrtry() {
        return lclInstrmPrtry;
    }

    @JsonProperty("lclInstrmPrtry")
    public void setLclInstrmPrtry(String lclInstrmPrtry) {
        this.lclInstrmPrtry = lclInstrmPrtry;
    }

    public PmtTpInf withLclInstrmPrtry(String lclInstrmPrtry) {
        this.lclInstrmPrtry = lclInstrmPrtry;
        return this;
    }

    @JsonProperty("ctgyPurpCd")
    public String getCtgyPurpCd() {
        return ctgyPurpCd;
    }

    @JsonProperty("ctgyPurpCd")
    public void setCtgyPurpCd(String ctgyPurpCd) {
        this.ctgyPurpCd = ctgyPurpCd;
    }

    public PmtTpInf withCtgyPurpCd(String ctgyPurpCd) {
        this.ctgyPurpCd = ctgyPurpCd;
        return this;
    }

    @JsonProperty("ctgyPurpPrtry")
    public String getCtgyPurpPrtry() {
        return ctgyPurpPrtry;
    }

    @JsonProperty("ctgyPurpPrtry")
    public void setCtgyPurpPrtry(String ctgyPurpPrtry) {
        this.ctgyPurpPrtry = ctgyPurpPrtry;
    }

    public PmtTpInf withCtgyPurpPrtry(String ctgyPurpPrtry) {
        this.ctgyPurpPrtry = ctgyPurpPrtry;
        return this;
    }

    @JsonProperty("stdPmtPdctCd")
    public String getStdPmtPdctCd() {
        return stdPmtPdctCd;
    }

    @JsonProperty("stdPmtPdctCd")
    public void setStdPmtPdctCd(String stdPmtPdctCd) {
        this.stdPmtPdctCd = stdPmtPdctCd;
    }

    public PmtTpInf withStdPmtPdctCd(String stdPmtPdctCd) {
        this.stdPmtPdctCd = stdPmtPdctCd;
        return this;
    }

    @JsonProperty("apprvlMd")
    public String getApprvlMd() {
        return apprvlMd;
    }

    @JsonProperty("apprvlMd")
    public void setApprvlMd(String apprvlMd) {
        this.apprvlMd = apprvlMd;
    }

    public PmtTpInf withApprvlMd(String apprvlMd) {
        this.apprvlMd = apprvlMd;
        return this;
    }

    @JsonProperty("xcssAmtInd")
    public String getXcssAmtInd() {
        return xcssAmtInd;
    }

    @JsonProperty("xcssAmtInd")
    public void setXcssAmtInd(String xcssAmtInd) {
        this.xcssAmtInd = xcssAmtInd;
    }

    public PmtTpInf withXcssAmtInd(String xcssAmtInd) {
        this.xcssAmtInd = xcssAmtInd;
        return this;
    }

    @JsonProperty("pmtTpDrvdInd")
    public String getPmtTpDrvdInd() {
        return pmtTpDrvdInd;
    }

    @JsonProperty("pmtTpDrvdInd")
    public void setPmtTpDrvdInd(String pmtTpDrvdInd) {
        this.pmtTpDrvdInd = pmtTpDrvdInd;
    }

    public PmtTpInf withPmtTpDrvdInd(String pmtTpDrvdInd) {
        this.pmtTpDrvdInd = pmtTpDrvdInd;
        return this;
    }

    @JsonProperty("payrollInd")
    public String getPayrollInd() {
        return payrollInd;
    }

    @JsonProperty("payrollInd")
    public void setPayrollInd(String payrollInd) {
        this.payrollInd = payrollInd;
    }

    public PmtTpInf withPayrollInd(String payrollInd) {
        this.payrollInd = payrollInd;
        return this;
    }

    @JsonProperty("rmtThrghInd")
    public String getRmtThrghInd() {
        return rmtThrghInd;
    }

    @JsonProperty("rmtThrghInd")
    public void setRmtThrghInd(String rmtThrghInd) {
        this.rmtThrghInd = rmtThrghInd;
    }

    public PmtTpInf withRmtThrghInd(String rmtThrghInd) {
        this.rmtThrghInd = rmtThrghInd;
        return this;
    }

    @JsonProperty("ntrOfTx")
    public String getNtrOfTx() {
        return ntrOfTx;
    }

    @JsonProperty("ntrOfTx")
    public void setNtrOfTx(String ntrOfTx) {
        this.ntrOfTx = ntrOfTx;
    }

    public PmtTpInf withNtrOfTx(String ntrOfTx) {
        this.ntrOfTx = ntrOfTx;
        return this;
    }

    @JsonProperty("ACUInd")
    public String getACUInd() {
        return aCUInd;
    }

    @JsonProperty("ACUInd")
    public void setACUInd(String aCUInd) {
        this.aCUInd = aCUInd;
    }

    public PmtTpInf withACUInd(String aCUInd) {
        this.aCUInd = aCUInd;
        return this;
    }

    @JsonProperty("byOrdrOfSelfInd")
    public String getByOrdrOfSelfInd() {
        return byOrdrOfSelfInd;
    }

    @JsonProperty("byOrdrOfSelfInd")
    public void setByOrdrOfSelfInd(String byOrdrOfSelfInd) {
        this.byOrdrOfSelfInd = byOrdrOfSelfInd;
    }

    public PmtTpInf withByOrdrOfSelfInd(String byOrdrOfSelfInd) {
        this.byOrdrOfSelfInd = byOrdrOfSelfInd;
        return this;
    }

    @JsonProperty("pmtPrxyTp")
    public String getPmtPrxyTp() {
        return pmtPrxyTp;
    }

    @JsonProperty("pmtPrxyTp")
    public void setPmtPrxyTp(String pmtPrxyTp) {
        this.pmtPrxyTp = pmtPrxyTp;
    }

    public PmtTpInf withPmtPrxyTp(String pmtPrxyTp) {
        this.pmtPrxyTp = pmtPrxyTp;
        return this;
    }

    @JsonProperty("CASPmtInd")
    public String getCASPmtInd() {
        return cASPmtInd;
    }

    @JsonProperty("CASPmtInd")
    public void setCASPmtInd(String cASPmtInd) {
        this.cASPmtInd = cASPmtInd;
    }

    public PmtTpInf withCASPmtInd(String cASPmtInd) {
        this.cASPmtInd = cASPmtInd;
        return this;
    }

    @JsonProperty("prefrdDnmtn")
    public String getPrefrdDnmtn() {
        return prefrdDnmtn;
    }

    @JsonProperty("prefrdDnmtn")
    public void setPrefrdDnmtn(String prefrdDnmtn) {
        this.prefrdDnmtn = prefrdDnmtn;
    }

    public PmtTpInf withPrefrdDnmtn(String prefrdDnmtn) {
        this.prefrdDnmtn = prefrdDnmtn;
        return this;
    }

    @JsonProperty("txPrcgCd")
    public String getTxPrcgCd() {
        return txPrcgCd;
    }

    @JsonProperty("txPrcgCd")
    public void setTxPrcgCd(String txPrcgCd) {
        this.txPrcgCd = txPrcgCd;
    }

    public PmtTpInf withTxPrcgCd(String txPrcgCd) {
        this.txPrcgCd = txPrcgCd;
        return this;
    }

    @JsonProperty("svcLvl")
    public List<SvcLvl> getSvcLvl() {
        return svcLvl;
    }

    @JsonProperty("svcLvl")
    public void setSvcLvl(List<SvcLvl> svcLvl) {
        this.svcLvl = svcLvl;
    }

    public PmtTpInf withSvcLvl(List<SvcLvl> svcLvl) {
        this.svcLvl = svcLvl;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PmtTpInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instrPrty).append(clrChanl).append(reqdPmtTp).append(reqdSubPmtTp).append(pmtTp).append(subPmtTp).append(lclInstrmCd).append(lclInstrmPrtry).append(ctgyPurpCd).append(ctgyPurpPrtry).append(stdPmtPdctCd).append(apprvlMd).append(xcssAmtInd).append(pmtTpDrvdInd).append(payrollInd).append(rmtThrghInd).append(ntrOfTx).append(aCUInd).append(byOrdrOfSelfInd).append(pmtPrxyTp).append(cASPmtInd).append(prefrdDnmtn).append(txPrcgCd).append(svcLvl).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PmtTpInf) == false) {
            return false;
        }
        PmtTpInf rhs = ((PmtTpInf) other);
        return new EqualsBuilder().append(instrPrty, rhs.instrPrty).append(clrChanl, rhs.clrChanl).append(reqdPmtTp, rhs.reqdPmtTp).append(reqdSubPmtTp, rhs.reqdSubPmtTp).append(pmtTp, rhs.pmtTp).append(subPmtTp, rhs.subPmtTp).append(lclInstrmCd, rhs.lclInstrmCd).append(lclInstrmPrtry, rhs.lclInstrmPrtry).append(ctgyPurpCd, rhs.ctgyPurpCd).append(ctgyPurpPrtry, rhs.ctgyPurpPrtry).append(stdPmtPdctCd, rhs.stdPmtPdctCd).append(apprvlMd, rhs.apprvlMd).append(xcssAmtInd, rhs.xcssAmtInd).append(pmtTpDrvdInd, rhs.pmtTpDrvdInd).append(payrollInd, rhs.payrollInd).append(rmtThrghInd, rhs.rmtThrghInd).append(ntrOfTx, rhs.ntrOfTx).append(aCUInd, rhs.aCUInd).append(byOrdrOfSelfInd, rhs.byOrdrOfSelfInd).append(pmtPrxyTp, rhs.pmtPrxyTp).append(cASPmtInd, rhs.cASPmtInd).append(prefrdDnmtn, rhs.prefrdDnmtn).append(txPrcgCd, rhs.txPrcgCd).append(svcLvl, rhs.svcLvl).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

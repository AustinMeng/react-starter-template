package com.scb.s2b.api.payment.camel;


import static com.scb.s2b.api.payment.config.PaymentConstant.KAFKA_RETRY_HEADER;
import static com.scb.s2b.api.payment.config.PaymentConstant.KAFKA_SUSPEND_TO_HEADER;
import static com.scb.s2b.api.payment.util.AdapterUtil.getHeader;

import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.payment.util.AdapterUtil;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;


@Slf4j
@RequiredArgsConstructor
public class CommonStatusConsumerAdapter<T> {

    private final long retryInterval;

    private final int maxRetry;

    private final String txnRetryEndpoint;

    private final ProducerTemplate producer;

    private final Function<T, byte[]> messageTransformer;

    private final BiConsumer<T, Integer> messageAccepter;

    private final Consumer<T> messageRejecter;

    public Long calculateDelay(Map<String, Object> headers) {
        return AdapterUtil.calculateDelay(headers, retryInterval);
    }

    public void consumeWithRetry(T body, Map<String, Object> headers) {
        int retry = getHeader(headers, KAFKA_RETRY_HEADER, Integer::parseInt, 0);
        log.info("Consuming retry message, retried times = {}", retry);
        this.doPublish(body, retry);
    }

    private void doPublish(T body, int retry) {
        try {
            messageAccepter.accept(body, retry);
        } catch (Throwable ex) {
            if (retry >= maxRetry && maxRetry != -1) {
                log.info("Dropping/Rejecting after maximum retries message={}, retried times={}", body, retry);
                messageRejecter.accept(body);
            } else {
                this.doRetry(body, ++retry);
            }
        }
    }

    private void doRetry(T body, int retry) {
        byte[] bytes = messageTransformer.apply(body);
        Map<String, Object> headers = ImmutableMap.of(
                KAFKA_SUSPEND_TO_HEADER, String.valueOf(System.currentTimeMillis() + retryInterval),
                KAFKA_RETRY_HEADER, String.valueOf(retry)
        );
        log.info("Sending retry message to {}", txnRetryEndpoint);
        producer.sendBodyAndHeaders(txnRetryEndpoint, bytes, headers);
    }
}
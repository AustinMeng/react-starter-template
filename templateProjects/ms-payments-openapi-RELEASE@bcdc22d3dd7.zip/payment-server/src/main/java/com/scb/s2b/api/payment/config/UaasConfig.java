package com.scb.s2b.api.payment.config;

import com.scb.channels.foundation.commons.uaas.UaasClient;
import com.scb.channels.foundation.commons.uaas.impl.UaasClientImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

@SuppressWarnings("unused")
@Profile("!test")
public class UaasConfig {

    @Value("${uaas.baseUrl}")
    private String baseUrl;

    @Value("${security.masterKeystore}")
    private String masterKeystore;

    @Value("${security.masterKeystorePassword}")
    private String masterKeystorePassword;

    @Bean
    @Profile("!test")
    public UaasClient uaasClient() {
        return new UaasClientImpl(baseUrl, masterKeystore, masterKeystorePassword);
    }
}

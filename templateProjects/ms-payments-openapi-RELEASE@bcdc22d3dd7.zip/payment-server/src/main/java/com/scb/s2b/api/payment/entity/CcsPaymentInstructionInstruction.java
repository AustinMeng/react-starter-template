package com.scb.s2b.api.payment.entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstructionInstruction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class CcsPaymentInstructionInstruction extends OpenApiPaymentInstructionInstruction {

    public static final String JSON_PROPERTY_UETR = "uetr";
    @JsonProperty(JSON_PROPERTY_UETR)
    private String uetr;

    public static final String JSON_PROPERTY_RECORD_TYPE = "recordType";
    @JsonProperty(JSON_PROPERTY_RECORD_TYPE)
    private String recordType;

    public static final String JSON_PROPERTY_PROCESSING_MODE = "processingMode";
    @JsonProperty(JSON_PROPERTY_PROCESSING_MODE)
    private String processingMode;
}

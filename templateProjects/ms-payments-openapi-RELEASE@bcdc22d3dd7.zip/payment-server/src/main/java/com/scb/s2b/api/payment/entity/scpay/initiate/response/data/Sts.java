
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "txSts",
    "rsnCd",
    "rsnInf",
    "chanlRjctStsCd",
    "chanlRjctRsn",
    "chanlRjctDt",
    "prxyLookupSts",
    "SNASLookupSts",
    "GPITrckrSts",
    "GPITrckrRsnCd"
})
public class Sts {

    @JsonProperty("txSts")
    private String txSts;
    @JsonProperty("rsnCd")
    private String rsnCd;
    @JsonProperty("rsnInf")
    private String rsnInf;
    @JsonProperty("chanlRjctStsCd")
    private String chanlRjctStsCd;
    @JsonProperty("chanlRjctRsn")
    private String chanlRjctRsn;
    @JsonProperty("chanlRjctDt")
    private String chanlRjctDt;
    @JsonProperty("prxyLookupSts")
    private String prxyLookupSts;
    @JsonProperty("SNASLookupSts")
    private String sNASLookupSts;
    @JsonProperty("GPITrckrSts")
    private String gPITrckrSts;
    @JsonProperty("GPITrckrRsnCd")
    private String gPITrckrRsnCd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("txSts")
    public String getTxSts() {
        return txSts;
    }

    @JsonProperty("txSts")
    public void setTxSts(String txSts) {
        this.txSts = txSts;
    }

    public Sts withTxSts(String txSts) {
        this.txSts = txSts;
        return this;
    }

    @JsonProperty("rsnCd")
    public String getRsnCd() {
        return rsnCd;
    }

    @JsonProperty("rsnCd")
    public void setRsnCd(String rsnCd) {
        this.rsnCd = rsnCd;
    }

    public Sts withRsnCd(String rsnCd) {
        this.rsnCd = rsnCd;
        return this;
    }

    @JsonProperty("rsnInf")
    public String getRsnInf() {
        return rsnInf;
    }

    @JsonProperty("rsnInf")
    public void setRsnInf(String rsnInf) {
        this.rsnInf = rsnInf;
    }

    public Sts withRsnInf(String rsnInf) {
        this.rsnInf = rsnInf;
        return this;
    }

    @JsonProperty("chanlRjctStsCd")
    public String getChanlRjctStsCd() {
        return chanlRjctStsCd;
    }

    @JsonProperty("chanlRjctStsCd")
    public void setChanlRjctStsCd(String chanlRjctStsCd) {
        this.chanlRjctStsCd = chanlRjctStsCd;
    }

    public Sts withChanlRjctStsCd(String chanlRjctStsCd) {
        this.chanlRjctStsCd = chanlRjctStsCd;
        return this;
    }

    @JsonProperty("chanlRjctRsn")
    public String getChanlRjctRsn() {
        return chanlRjctRsn;
    }

    @JsonProperty("chanlRjctRsn")
    public void setChanlRjctRsn(String chanlRjctRsn) {
        this.chanlRjctRsn = chanlRjctRsn;
    }

    public Sts withChanlRjctRsn(String chanlRjctRsn) {
        this.chanlRjctRsn = chanlRjctRsn;
        return this;
    }

    @JsonProperty("chanlRjctDt")
    public String getChanlRjctDt() {
        return chanlRjctDt;
    }

    @JsonProperty("chanlRjctDt")
    public void setChanlRjctDt(String chanlRjctDt) {
        this.chanlRjctDt = chanlRjctDt;
    }

    public Sts withChanlRjctDt(String chanlRjctDt) {
        this.chanlRjctDt = chanlRjctDt;
        return this;
    }

    @JsonProperty("prxyLookupSts")
    public String getPrxyLookupSts() {
        return prxyLookupSts;
    }

    @JsonProperty("prxyLookupSts")
    public void setPrxyLookupSts(String prxyLookupSts) {
        this.prxyLookupSts = prxyLookupSts;
    }

    public Sts withPrxyLookupSts(String prxyLookupSts) {
        this.prxyLookupSts = prxyLookupSts;
        return this;
    }

    @JsonProperty("SNASLookupSts")
    public String getSNASLookupSts() {
        return sNASLookupSts;
    }

    @JsonProperty("SNASLookupSts")
    public void setSNASLookupSts(String sNASLookupSts) {
        this.sNASLookupSts = sNASLookupSts;
    }

    public Sts withSNASLookupSts(String sNASLookupSts) {
        this.sNASLookupSts = sNASLookupSts;
        return this;
    }

    @JsonProperty("GPITrckrSts")
    public String getGPITrckrSts() {
        return gPITrckrSts;
    }

    @JsonProperty("GPITrckrSts")
    public void setGPITrckrSts(String gPITrckrSts) {
        this.gPITrckrSts = gPITrckrSts;
    }

    public Sts withGPITrckrSts(String gPITrckrSts) {
        this.gPITrckrSts = gPITrckrSts;
        return this;
    }

    @JsonProperty("GPITrckrRsnCd")
    public String getGPITrckrRsnCd() {
        return gPITrckrRsnCd;
    }

    @JsonProperty("GPITrckrRsnCd")
    public void setGPITrckrRsnCd(String gPITrckrRsnCd) {
        this.gPITrckrRsnCd = gPITrckrRsnCd;
    }

    public Sts withGPITrckrRsnCd(String gPITrckrRsnCd) {
        this.gPITrckrRsnCd = gPITrckrRsnCd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Sts withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(txSts).append(rsnCd).append(rsnInf).append(chanlRjctStsCd).append(chanlRjctRsn).append(chanlRjctDt).append(prxyLookupSts).append(sNASLookupSts).append(gPITrckrSts).append(gPITrckrRsnCd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Sts) == false) {
            return false;
        }
        Sts rhs = ((Sts) other);
        return new EqualsBuilder().append(txSts, rhs.txSts).append(rsnCd, rhs.rsnCd).append(rsnInf, rhs.rsnInf).append(chanlRjctStsCd, rhs.chanlRjctStsCd).append(chanlRjctRsn, rhs.chanlRjctRsn).append(chanlRjctDt, rhs.chanlRjctDt).append(prxyLookupSts, rhs.prxyLookupSts).append(sNASLookupSts, rhs.sNASLookupSts).append(gPITrckrSts, rhs.gPITrckrSts).append(gPITrckrRsnCd, rhs.gPITrckrRsnCd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

package com.scb.s2b.api.payment.config.property;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "payment.camel.controller", ignoreInvalidFields = true)
public class CamelControllerProperties {
    private Long suspendTimeout = 30L;
}


package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BICFI",
    "clrSysIdCd",
    "clrSysIdPrtry",
    "clrSysMmbId",
    "LEI",
    "nm",
    "pstlAdr"
})
public class InstgRmbrsmntAgt {

    @JsonProperty("BICFI")
    private String bICFI;
    @JsonProperty("clrSysIdCd")
    private String clrSysIdCd;
    @JsonProperty("clrSysIdPrtry")
    private String clrSysIdPrtry;
    @JsonProperty("clrSysMmbId")
    private String clrSysMmbId;
    @JsonProperty("LEI")
    private String lEI;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("BICFI")
    public String getBICFI() {
        return bICFI;
    }

    @JsonProperty("BICFI")
    public void setBICFI(String bICFI) {
        this.bICFI = bICFI;
    }

    public InstgRmbrsmntAgt withBICFI(String bICFI) {
        this.bICFI = bICFI;
        return this;
    }

    @JsonProperty("clrSysIdCd")
    public String getClrSysIdCd() {
        return clrSysIdCd;
    }

    @JsonProperty("clrSysIdCd")
    public void setClrSysIdCd(String clrSysIdCd) {
        this.clrSysIdCd = clrSysIdCd;
    }

    public InstgRmbrsmntAgt withClrSysIdCd(String clrSysIdCd) {
        this.clrSysIdCd = clrSysIdCd;
        return this;
    }

    @JsonProperty("clrSysIdPrtry")
    public String getClrSysIdPrtry() {
        return clrSysIdPrtry;
    }

    @JsonProperty("clrSysIdPrtry")
    public void setClrSysIdPrtry(String clrSysIdPrtry) {
        this.clrSysIdPrtry = clrSysIdPrtry;
    }

    public InstgRmbrsmntAgt withClrSysIdPrtry(String clrSysIdPrtry) {
        this.clrSysIdPrtry = clrSysIdPrtry;
        return this;
    }

    @JsonProperty("clrSysMmbId")
    public String getClrSysMmbId() {
        return clrSysMmbId;
    }

    @JsonProperty("clrSysMmbId")
    public void setClrSysMmbId(String clrSysMmbId) {
        this.clrSysMmbId = clrSysMmbId;
    }

    public InstgRmbrsmntAgt withClrSysMmbId(String clrSysMmbId) {
        this.clrSysMmbId = clrSysMmbId;
        return this;
    }

    @JsonProperty("LEI")
    public String getLEI() {
        return lEI;
    }

    @JsonProperty("LEI")
    public void setLEI(String lEI) {
        this.lEI = lEI;
    }

    public InstgRmbrsmntAgt withLEI(String lEI) {
        this.lEI = lEI;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public InstgRmbrsmntAgt withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public InstgRmbrsmntAgt withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InstgRmbrsmntAgt withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(bICFI).append(clrSysIdCd).append(clrSysIdPrtry).append(clrSysMmbId).append(lEI).append(nm).append(pstlAdr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstgRmbrsmntAgt) == false) {
            return false;
        }
        InstgRmbrsmntAgt rhs = ((InstgRmbrsmntAgt) other);
        return new EqualsBuilder().append(bICFI, rhs.bICFI).append(clrSysIdCd, rhs.clrSysIdCd).append(clrSysIdPrtry, rhs.clrSysIdPrtry).append(clrSysMmbId, rhs.clrSysMmbId).append(lEI, rhs.lEI).append(nm, rhs.nm).append(pstlAdr, rhs.pstlAdr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}


package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dstnSys",
    "msgId",
    "creDtTm",
    "sgmtCd",
    "pdctCd",
    "buySellInd",
    "ccyOrgtrInd",
    "cstmrId",
    "cstmrRef",
    "acctId",
    "stffInd"
})
public class DealInf {

    @JsonProperty("dstnSys")
    private String dstnSys;
    @JsonProperty("msgId")
    private String msgId;
    @JsonProperty("creDtTm")
    private String creDtTm;
    @JsonProperty("sgmtCd")
    private String sgmtCd;
    @JsonProperty("pdctCd")
    private String pdctCd;
    @JsonProperty("buySellInd")
    private String buySellInd;
    @JsonProperty("ccyOrgtrInd")
    private String ccyOrgtrInd;
    @JsonProperty("cstmrId")
    private String cstmrId;
    @JsonProperty("cstmrRef")
    private String cstmrRef;
    @JsonProperty("acctId")
    private String acctId;
    @JsonProperty("stffInd")
    private String stffInd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dstnSys")
    public String getDstnSys() {
        return dstnSys;
    }

    @JsonProperty("dstnSys")
    public void setDstnSys(String dstnSys) {
        this.dstnSys = dstnSys;
    }

    public DealInf withDstnSys(String dstnSys) {
        this.dstnSys = dstnSys;
        return this;
    }

    @JsonProperty("msgId")
    public String getMsgId() {
        return msgId;
    }

    @JsonProperty("msgId")
    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public DealInf withMsgId(String msgId) {
        this.msgId = msgId;
        return this;
    }

    @JsonProperty("creDtTm")
    public String getCreDtTm() {
        return creDtTm;
    }

    @JsonProperty("creDtTm")
    public void setCreDtTm(String creDtTm) {
        this.creDtTm = creDtTm;
    }

    public DealInf withCreDtTm(String creDtTm) {
        this.creDtTm = creDtTm;
        return this;
    }

    @JsonProperty("sgmtCd")
    public String getSgmtCd() {
        return sgmtCd;
    }

    @JsonProperty("sgmtCd")
    public void setSgmtCd(String sgmtCd) {
        this.sgmtCd = sgmtCd;
    }

    public DealInf withSgmtCd(String sgmtCd) {
        this.sgmtCd = sgmtCd;
        return this;
    }

    @JsonProperty("pdctCd")
    public String getPdctCd() {
        return pdctCd;
    }

    @JsonProperty("pdctCd")
    public void setPdctCd(String pdctCd) {
        this.pdctCd = pdctCd;
    }

    public DealInf withPdctCd(String pdctCd) {
        this.pdctCd = pdctCd;
        return this;
    }

    @JsonProperty("buySellInd")
    public String getBuySellInd() {
        return buySellInd;
    }

    @JsonProperty("buySellInd")
    public void setBuySellInd(String buySellInd) {
        this.buySellInd = buySellInd;
    }

    public DealInf withBuySellInd(String buySellInd) {
        this.buySellInd = buySellInd;
        return this;
    }

    @JsonProperty("ccyOrgtrInd")
    public String getCcyOrgtrInd() {
        return ccyOrgtrInd;
    }

    @JsonProperty("ccyOrgtrInd")
    public void setCcyOrgtrInd(String ccyOrgtrInd) {
        this.ccyOrgtrInd = ccyOrgtrInd;
    }

    public DealInf withCcyOrgtrInd(String ccyOrgtrInd) {
        this.ccyOrgtrInd = ccyOrgtrInd;
        return this;
    }

    @JsonProperty("cstmrId")
    public String getCstmrId() {
        return cstmrId;
    }

    @JsonProperty("cstmrId")
    public void setCstmrId(String cstmrId) {
        this.cstmrId = cstmrId;
    }

    public DealInf withCstmrId(String cstmrId) {
        this.cstmrId = cstmrId;
        return this;
    }

    @JsonProperty("cstmrRef")
    public String getCstmrRef() {
        return cstmrRef;
    }

    @JsonProperty("cstmrRef")
    public void setCstmrRef(String cstmrRef) {
        this.cstmrRef = cstmrRef;
    }

    public DealInf withCstmrRef(String cstmrRef) {
        this.cstmrRef = cstmrRef;
        return this;
    }

    @JsonProperty("acctId")
    public String getAcctId() {
        return acctId;
    }

    @JsonProperty("acctId")
    public void setAcctId(String acctId) {
        this.acctId = acctId;
    }

    public DealInf withAcctId(String acctId) {
        this.acctId = acctId;
        return this;
    }

    @JsonProperty("stffInd")
    public String getStffInd() {
        return stffInd;
    }

    @JsonProperty("stffInd")
    public void setStffInd(String stffInd) {
        this.stffInd = stffInd;
    }

    public DealInf withStffInd(String stffInd) {
        this.stffInd = stffInd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DealInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dstnSys).append(msgId).append(creDtTm).append(sgmtCd).append(pdctCd).append(buySellInd).append(ccyOrgtrInd).append(cstmrId).append(cstmrRef).append(acctId).append(stffInd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DealInf) == false) {
            return false;
        }
        DealInf rhs = ((DealInf) other);
        return new EqualsBuilder().append(dstnSys, rhs.dstnSys).append(msgId, rhs.msgId).append(creDtTm, rhs.creDtTm).append(sgmtCd, rhs.sgmtCd).append(pdctCd, rhs.pdctCd).append(buySellInd, rhs.buySellInd).append(ccyOrgtrInd, rhs.ccyOrgtrInd).append(cstmrId, rhs.cstmrId).append(cstmrRef, rhs.cstmrRef).append(acctId, rhs.acctId).append(stffInd, rhs.stffInd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

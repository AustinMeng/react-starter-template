
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "rsnCd",
    "rsnInf",
    "chanlRjctStsCd",
    "chanlRjctRsn",
    "chanlRjctDt",
    "prxyLookupSts"
})
public class Sts {

    @JsonProperty("rsnCd")
    private String rsnCd;
    @JsonProperty("rsnInf")
    private String rsnInf;
    @JsonProperty("chanlRjctStsCd")
    private String chanlRjctStsCd;
    @JsonProperty("chanlRjctRsn")
    private String chanlRjctRsn;
    @JsonProperty("chanlRjctDt")
    private String chanlRjctDt;
    @JsonProperty("prxyLookupSts")
    private String prxyLookupSts;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("rsnCd")
    public String getRsnCd() {
        return rsnCd;
    }

    @JsonProperty("rsnCd")
    public void setRsnCd(String rsnCd) {
        this.rsnCd = rsnCd;
    }

    public Sts withRsnCd(String rsnCd) {
        this.rsnCd = rsnCd;
        return this;
    }

    @JsonProperty("rsnInf")
    public String getRsnInf() {
        return rsnInf;
    }

    @JsonProperty("rsnInf")
    public void setRsnInf(String rsnInf) {
        this.rsnInf = rsnInf;
    }

    public Sts withRsnInf(String rsnInf) {
        this.rsnInf = rsnInf;
        return this;
    }

    @JsonProperty("chanlRjctStsCd")
    public String getChanlRjctStsCd() {
        return chanlRjctStsCd;
    }

    @JsonProperty("chanlRjctStsCd")
    public void setChanlRjctStsCd(String chanlRjctStsCd) {
        this.chanlRjctStsCd = chanlRjctStsCd;
    }

    public Sts withChanlRjctStsCd(String chanlRjctStsCd) {
        this.chanlRjctStsCd = chanlRjctStsCd;
        return this;
    }

    @JsonProperty("chanlRjctRsn")
    public String getChanlRjctRsn() {
        return chanlRjctRsn;
    }

    @JsonProperty("chanlRjctRsn")
    public void setChanlRjctRsn(String chanlRjctRsn) {
        this.chanlRjctRsn = chanlRjctRsn;
    }

    public Sts withChanlRjctRsn(String chanlRjctRsn) {
        this.chanlRjctRsn = chanlRjctRsn;
        return this;
    }

    @JsonProperty("chanlRjctDt")
    public String getChanlRjctDt() {
        return chanlRjctDt;
    }

    @JsonProperty("chanlRjctDt")
    public void setChanlRjctDt(String chanlRjctDt) {
        this.chanlRjctDt = chanlRjctDt;
    }

    public Sts withChanlRjctDt(String chanlRjctDt) {
        this.chanlRjctDt = chanlRjctDt;
        return this;
    }

    @JsonProperty("prxyLookupSts")
    public String getPrxyLookupSts() {
        return prxyLookupSts;
    }

    @JsonProperty("prxyLookupSts")
    public void setPrxyLookupSts(String prxyLookupSts) {
        this.prxyLookupSts = prxyLookupSts;
    }

    public Sts withPrxyLookupSts(String prxyLookupSts) {
        this.prxyLookupSts = prxyLookupSts;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Sts withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(rsnCd).append(rsnInf).append(chanlRjctStsCd).append(chanlRjctRsn).append(chanlRjctDt).append(prxyLookupSts).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Sts) == false) {
            return false;
        }
        Sts rhs = ((Sts) other);
        return new EqualsBuilder().append(rsnCd, rhs.rsnCd).append(rsnInf, rhs.rsnInf).append(chanlRjctStsCd, rhs.chanlRjctStsCd).append(chanlRjctRsn, rhs.chanlRjctRsn).append(chanlRjctDt, rhs.chanlRjctDt).append(prxyLookupSts, rhs.prxyLookupSts).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}


package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "s2bGrpId",
    "stsCustId",
    "qlCustId",
    "prty",
    "srcOfFnd",
    "memo",
    "lstdCpnyCd"
})
public class Cstmr {

    @JsonProperty("s2bGrpId")
    private String s2bGrpId;
    @JsonProperty("stsCustId")
    private String stsCustId;
    @JsonProperty("qlCustId")
    private String qlCustId;
    @JsonProperty("prty")
    private String prty;
    @JsonProperty("srcOfFnd")
    private String srcOfFnd;
    @JsonProperty("memo")
    private String memo;
    @JsonProperty("lstdCpnyCd")
    private String lstdCpnyCd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("s2bGrpId")
    public String getS2bGrpId() {
        return s2bGrpId;
    }

    @JsonProperty("s2bGrpId")
    public void setS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
    }

    public Cstmr withS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
        return this;
    }

    @JsonProperty("stsCustId")
    public String getStsCustId() {
        return stsCustId;
    }

    @JsonProperty("stsCustId")
    public void setStsCustId(String stsCustId) {
        this.stsCustId = stsCustId;
    }

    public Cstmr withStsCustId(String stsCustId) {
        this.stsCustId = stsCustId;
        return this;
    }

    @JsonProperty("qlCustId")
    public String getQlCustId() {
        return qlCustId;
    }

    @JsonProperty("qlCustId")
    public void setQlCustId(String qlCustId) {
        this.qlCustId = qlCustId;
    }

    public Cstmr withQlCustId(String qlCustId) {
        this.qlCustId = qlCustId;
        return this;
    }

    @JsonProperty("prty")
    public String getPrty() {
        return prty;
    }

    @JsonProperty("prty")
    public void setPrty(String prty) {
        this.prty = prty;
    }

    public Cstmr withPrty(String prty) {
        this.prty = prty;
        return this;
    }

    @JsonProperty("srcOfFnd")
    public String getSrcOfFnd() {
        return srcOfFnd;
    }

    @JsonProperty("srcOfFnd")
    public void setSrcOfFnd(String srcOfFnd) {
        this.srcOfFnd = srcOfFnd;
    }

    public Cstmr withSrcOfFnd(String srcOfFnd) {
        this.srcOfFnd = srcOfFnd;
        return this;
    }

    @JsonProperty("memo")
    public String getMemo() {
        return memo;
    }

    @JsonProperty("memo")
    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Cstmr withMemo(String memo) {
        this.memo = memo;
        return this;
    }

    @JsonProperty("lstdCpnyCd")
    public String getLstdCpnyCd() {
        return lstdCpnyCd;
    }

    @JsonProperty("lstdCpnyCd")
    public void setLstdCpnyCd(String lstdCpnyCd) {
        this.lstdCpnyCd = lstdCpnyCd;
    }

    public Cstmr withLstdCpnyCd(String lstdCpnyCd) {
        this.lstdCpnyCd = lstdCpnyCd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Cstmr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(s2bGrpId).append(stsCustId).append(qlCustId).append(prty).append(srcOfFnd).append(memo).append(lstdCpnyCd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Cstmr) == false) {
            return false;
        }
        Cstmr rhs = ((Cstmr) other);
        return new EqualsBuilder().append(s2bGrpId, rhs.s2bGrpId).append(stsCustId, rhs.stsCustId).append(qlCustId, rhs.qlCustId).append(prty, rhs.prty).append(srcOfFnd, rhs.srcOfFnd).append(memo, rhs.memo).append(lstdCpnyCd, rhs.lstdCpnyCd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

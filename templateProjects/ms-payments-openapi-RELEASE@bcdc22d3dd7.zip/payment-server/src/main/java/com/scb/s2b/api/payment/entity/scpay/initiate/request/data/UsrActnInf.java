
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "makerId",
    "makerDtTm",
    "checkerId",
    "checkerDtTm",
    "approverId",
    "approverDtTm",
    "prcgAddtlInf",
    "dplctOvrrdInd",
    "forcPstInd",
    "insffcntFndsInd",
    "usrApprvdTx",
    "xtrnlRjctRsn",
    "intlRjctRsn",
    "accptRjctFlg"
})
public class UsrActnInf {

    @JsonProperty("makerId")
    private String makerId;
    @JsonProperty("makerDtTm")
    private String makerDtTm;
    @JsonProperty("checkerId")
    private String checkerId;
    @JsonProperty("checkerDtTm")
    private String checkerDtTm;
    @JsonProperty("approverId")
    private String approverId;
    @JsonProperty("approverDtTm")
    private String approverDtTm;
    @JsonProperty("prcgAddtlInf")
    private String prcgAddtlInf;
    @JsonProperty("dplctOvrrdInd")
    private String dplctOvrrdInd;
    @JsonProperty("forcPstInd")
    private String forcPstInd;
    @JsonProperty("insffcntFndsInd")
    private String insffcntFndsInd;
    @JsonProperty("usrApprvdTx")
    private String usrApprvdTx;
    @JsonProperty("xtrnlRjctRsn")
    private String xtrnlRjctRsn;
    @JsonProperty("intlRjctRsn")
    private String intlRjctRsn;
    @JsonProperty("accptRjctFlg")
    private String accptRjctFlg;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("makerId")
    public String getMakerId() {
        return makerId;
    }

    @JsonProperty("makerId")
    public void setMakerId(String makerId) {
        this.makerId = makerId;
    }

    public UsrActnInf withMakerId(String makerId) {
        this.makerId = makerId;
        return this;
    }

    @JsonProperty("makerDtTm")
    public String getMakerDtTm() {
        return makerDtTm;
    }

    @JsonProperty("makerDtTm")
    public void setMakerDtTm(String makerDtTm) {
        this.makerDtTm = makerDtTm;
    }

    public UsrActnInf withMakerDtTm(String makerDtTm) {
        this.makerDtTm = makerDtTm;
        return this;
    }

    @JsonProperty("checkerId")
    public String getCheckerId() {
        return checkerId;
    }

    @JsonProperty("checkerId")
    public void setCheckerId(String checkerId) {
        this.checkerId = checkerId;
    }

    public UsrActnInf withCheckerId(String checkerId) {
        this.checkerId = checkerId;
        return this;
    }

    @JsonProperty("checkerDtTm")
    public String getCheckerDtTm() {
        return checkerDtTm;
    }

    @JsonProperty("checkerDtTm")
    public void setCheckerDtTm(String checkerDtTm) {
        this.checkerDtTm = checkerDtTm;
    }

    public UsrActnInf withCheckerDtTm(String checkerDtTm) {
        this.checkerDtTm = checkerDtTm;
        return this;
    }

    @JsonProperty("approverId")
    public String getApproverId() {
        return approverId;
    }

    @JsonProperty("approverId")
    public void setApproverId(String approverId) {
        this.approverId = approverId;
    }

    public UsrActnInf withApproverId(String approverId) {
        this.approverId = approverId;
        return this;
    }

    @JsonProperty("approverDtTm")
    public String getApproverDtTm() {
        return approverDtTm;
    }

    @JsonProperty("approverDtTm")
    public void setApproverDtTm(String approverDtTm) {
        this.approverDtTm = approverDtTm;
    }

    public UsrActnInf withApproverDtTm(String approverDtTm) {
        this.approverDtTm = approverDtTm;
        return this;
    }

    @JsonProperty("prcgAddtlInf")
    public String getPrcgAddtlInf() {
        return prcgAddtlInf;
    }

    @JsonProperty("prcgAddtlInf")
    public void setPrcgAddtlInf(String prcgAddtlInf) {
        this.prcgAddtlInf = prcgAddtlInf;
    }

    public UsrActnInf withPrcgAddtlInf(String prcgAddtlInf) {
        this.prcgAddtlInf = prcgAddtlInf;
        return this;
    }

    @JsonProperty("dplctOvrrdInd")
    public String getDplctOvrrdInd() {
        return dplctOvrrdInd;
    }

    @JsonProperty("dplctOvrrdInd")
    public void setDplctOvrrdInd(String dplctOvrrdInd) {
        this.dplctOvrrdInd = dplctOvrrdInd;
    }

    public UsrActnInf withDplctOvrrdInd(String dplctOvrrdInd) {
        this.dplctOvrrdInd = dplctOvrrdInd;
        return this;
    }

    @JsonProperty("forcPstInd")
    public String getForcPstInd() {
        return forcPstInd;
    }

    @JsonProperty("forcPstInd")
    public void setForcPstInd(String forcPstInd) {
        this.forcPstInd = forcPstInd;
    }

    public UsrActnInf withForcPstInd(String forcPstInd) {
        this.forcPstInd = forcPstInd;
        return this;
    }

    @JsonProperty("insffcntFndsInd")
    public String getInsffcntFndsInd() {
        return insffcntFndsInd;
    }

    @JsonProperty("insffcntFndsInd")
    public void setInsffcntFndsInd(String insffcntFndsInd) {
        this.insffcntFndsInd = insffcntFndsInd;
    }

    public UsrActnInf withInsffcntFndsInd(String insffcntFndsInd) {
        this.insffcntFndsInd = insffcntFndsInd;
        return this;
    }

    @JsonProperty("usrApprvdTx")
    public String getUsrApprvdTx() {
        return usrApprvdTx;
    }

    @JsonProperty("usrApprvdTx")
    public void setUsrApprvdTx(String usrApprvdTx) {
        this.usrApprvdTx = usrApprvdTx;
    }

    public UsrActnInf withUsrApprvdTx(String usrApprvdTx) {
        this.usrApprvdTx = usrApprvdTx;
        return this;
    }

    @JsonProperty("xtrnlRjctRsn")
    public String getXtrnlRjctRsn() {
        return xtrnlRjctRsn;
    }

    @JsonProperty("xtrnlRjctRsn")
    public void setXtrnlRjctRsn(String xtrnlRjctRsn) {
        this.xtrnlRjctRsn = xtrnlRjctRsn;
    }

    public UsrActnInf withXtrnlRjctRsn(String xtrnlRjctRsn) {
        this.xtrnlRjctRsn = xtrnlRjctRsn;
        return this;
    }

    @JsonProperty("intlRjctRsn")
    public String getIntlRjctRsn() {
        return intlRjctRsn;
    }

    @JsonProperty("intlRjctRsn")
    public void setIntlRjctRsn(String intlRjctRsn) {
        this.intlRjctRsn = intlRjctRsn;
    }

    public UsrActnInf withIntlRjctRsn(String intlRjctRsn) {
        this.intlRjctRsn = intlRjctRsn;
        return this;
    }

    @JsonProperty("accptRjctFlg")
    public String getAccptRjctFlg() {
        return accptRjctFlg;
    }

    @JsonProperty("accptRjctFlg")
    public void setAccptRjctFlg(String accptRjctFlg) {
        this.accptRjctFlg = accptRjctFlg;
    }

    public UsrActnInf withAccptRjctFlg(String accptRjctFlg) {
        this.accptRjctFlg = accptRjctFlg;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public UsrActnInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(makerId).append(makerDtTm).append(checkerId).append(checkerDtTm).append(approverId).append(approverDtTm).append(prcgAddtlInf).append(dplctOvrrdInd).append(forcPstInd).append(insffcntFndsInd).append(usrApprvdTx).append(xtrnlRjctRsn).append(intlRjctRsn).append(accptRjctFlg).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UsrActnInf) == false) {
            return false;
        }
        UsrActnInf rhs = ((UsrActnInf) other);
        return new EqualsBuilder().append(makerId, rhs.makerId).append(makerDtTm, rhs.makerDtTm).append(checkerId, rhs.checkerId).append(checkerDtTm, rhs.checkerDtTm).append(approverId, rhs.approverId).append(approverDtTm, rhs.approverDtTm).append(prcgAddtlInf, rhs.prcgAddtlInf).append(dplctOvrrdInd, rhs.dplctOvrrdInd).append(forcPstInd, rhs.forcPstInd).append(insffcntFndsInd, rhs.insffcntFndsInd).append(usrApprvdTx, rhs.usrApprvdTx).append(xtrnlRjctRsn, rhs.xtrnlRjctRsn).append(intlRjctRsn, rhs.intlRjctRsn).append(accptRjctFlg, rhs.accptRjctFlg).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

package com.scb.s2b.api.payment;

import co.elastic.apm.attach.ElasticApmAttacher;
import com.scb.s2b.api.client.notification.configuration.NotificationClientConfiguration;
import com.scb.s2b.api.instrumentation.config.InstrumentationConfiguration;
import com.scb.s2b.api.payment.config.CacheConfig;
import com.scb.s2b.api.payment.config.CadmConfig;
import com.scb.s2b.api.payment.config.CamelConfig;
import com.scb.s2b.api.payment.config.DbConfig;
import com.scb.s2b.api.payment.config.NotificationConfig;
import com.scb.s2b.api.payment.config.RestTemplateConfig;
import com.scb.s2b.api.payment.config.PaymentConfig;
import com.scb.s2b.api.payment.config.UaasConfig;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableJpaRepositories
@EnableTransactionManagement
@Configuration
@EnableCaching
@Import({
        CacheConfig.class,
        PaymentConfig.class,
        CamelConfig.class,
        CadmConfig.class,
        UaasConfig.class,
        DbConfig.class,
        RestTemplateConfig.class,
        NotificationConfig.class,
        NotificationClientConfiguration.class,
        InstrumentationConfiguration.class
})
@ComponentScan(basePackages = {"com.scb.s2b.api.payment","com.scb.s2b.api.payroll"})
public class PaymentApiApp {

    private static final String APM_CONFIG = "elastic.apm.config";

    private static final String JAVA_DNS_CACHE_CONFIG = "java.dns.cache.config";

    private static final Logger logger = LoggerFactory.getLogger(PaymentApiApp.class);

    public static void main(String[] args) {
        String apmConfig = System.getenv(APM_CONFIG);
        if (StringUtils.isBlank(apmConfig)) {
            apmConfig = System.getProperty(APM_CONFIG);
        }

        if (StringUtils.isNotBlank(apmConfig)) {
            logger.info("Initiating Elastic APM from {}", apmConfig);
            ElasticApmAttacher.attach(apmConfig);
        }

        String dnsCacheConfig = System.getenv(JAVA_DNS_CACHE_CONFIG);
        if (StringUtils.isBlank(dnsCacheConfig)) {
            dnsCacheConfig = System.getProperty(JAVA_DNS_CACHE_CONFIG);
        }

        if (StringUtils.isNotBlank(dnsCacheConfig) && Boolean.parseBoolean(dnsCacheConfig)) {
            logger.info("Initiating JAVA DNS Cache config.");
            // Sets internal TTL to match the Aurora RO Endpoint TTL
            java.security.Security.setProperty("networkaddress.cache.ttl" , "1");
            // If the lookup fails, default to something like small to retry
            java.security.Security.setProperty("networkaddress.cache.negative.ttl" , "3");
        }

        SpringApplication.run(PaymentApiApp.class, args);
    }
}
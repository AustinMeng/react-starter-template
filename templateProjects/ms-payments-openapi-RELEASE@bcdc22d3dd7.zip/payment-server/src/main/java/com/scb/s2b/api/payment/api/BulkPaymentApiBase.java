package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiBulkPaymentIds;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiBulkPaymentInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstructionInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.CcsPaymentInstruction;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.processor.request.CcsRequestProcessor;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.CcsPaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiBulkPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.BulkPaymentRequestValidator;
import java.util.List;
import java.util.stream.Collectors;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RequiredArgsConstructor
public abstract class BulkPaymentApiBase extends ApiBase {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final OpenApiBulkPaymentInstructionTransformer openApiBulkPaymentInstructionTransformer;

    private final BulkPaymentRequestValidator bulkPaymentRequestValidator;

    private final RequestProcessor requestProcessor;

    private final CcsRequestProcessor ccsRequestProcessor;

    private final CcsPaymentService ccsPaymentService;

    public Response bulkPaymentInitiate(OpenApiBulkPaymentInstruction body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);

        logger.info("BulkPaymentInitiate requestId={}, groupId={}, clientReferenceId={}", requestId, groupId,
                body.getInstructions().stream().map(OpenApiPaymentInstructionInstruction::getReferenceId)
                        .collect(Collectors.joining(",")));

        List<OpenApiPaymentInstruction> openApiPaymentInstructions = openApiBulkPaymentInstructionTransformer
                .toOpenApiPaymentInstruction(body);

        bulkPaymentRequestValidator.validate(groupId, openApiPaymentInstructions);

        List<PaymentInstruction> paymentInstructions = openApiBulkPaymentInstructionTransformer
                .toPaymentInstructions(openApiPaymentInstructions, false, this.getHeaders(headers));

        requestProcessor.process(paymentInstructions);

        CcsPaymentInstruction ccsPaymentInstruction = openApiBulkPaymentInstructionTransformer
                .toCCSPaymentInstruction(openApiPaymentInstructions);

        ccsRequestProcessor.process(ccsPaymentInstruction, paymentInstructions);
        ccsPaymentService.ccsPaymentInitiate(groupId, ccsPaymentInstruction, paymentInstructions);
        bulkPaymentRequestValidator.cache(paymentInstructions);

        OpenApiBulkPaymentIds openApiBulkPaymentIds = openApiBulkPaymentInstructionTransformer
                .toOpenApiBulkPaymentIds(openApiPaymentInstructions);

        return Response.ok(openApiBulkPaymentIds).build();
    }
}

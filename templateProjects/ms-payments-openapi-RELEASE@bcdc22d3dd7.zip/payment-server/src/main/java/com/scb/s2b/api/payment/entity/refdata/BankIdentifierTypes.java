package com.scb.s2b.api.payment.entity.refdata;

import com.google.common.collect.Maps;
import com.scb.s2b.api.payment.entity.refdata.BankIdentifierType;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class BankIdentifierTypes {

    private final Map<String, Set<BankIdentifierType>> bankIdentifierTypes = Maps.newHashMap();

    public Map<String, Set<BankIdentifierType>> getBankIdentifierTypes() {
        return bankIdentifierTypes;
    }

    public Optional<BankIdentifierType> resolveBankCodeType(String countryCode, String paymentType) {
        return Optional.ofNullable(getBankIdentifierTypes().get(countryCode))
                .flatMap(l -> Optional
                        .of(l.stream().filter(bct -> bct.getPaymentTypes().contains(paymentType)).findFirst())
                ).orElse(Optional.empty());
    }
}


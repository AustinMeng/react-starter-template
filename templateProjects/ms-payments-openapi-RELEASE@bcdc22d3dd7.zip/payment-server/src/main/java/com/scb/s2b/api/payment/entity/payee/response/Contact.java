package com.scb.s2b.api.payment.entity.payee.response;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiContact;
import lombok.Getter;

@Getter
public class Contact extends OpenApiContact {
    private String taxId;
}

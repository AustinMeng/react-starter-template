package com.scb.s2b.api.payment.config.property;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class ScpayProperties {

  private List<TopicProperties> initiateTopics;

  private List<String> statusQueues;

  private NotificationProperties notification;

  private BeneficiaryEnquiryProperties beneficiaryEnquiry;

  private ProxyLookupProperties proxyLookup;

  public Map<String, String> getInitiateTopicMap() {
    return initiateTopics.stream().collect(Collectors.toMap(TopicProperties::getRegion, TopicProperties::getTemplate));
  }
}
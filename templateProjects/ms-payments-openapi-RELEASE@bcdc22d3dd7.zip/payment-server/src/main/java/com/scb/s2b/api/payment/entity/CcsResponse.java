package com.scb.s2b.api.payment.entity;

public enum CcsResponse {
    BANSTA("ccs-bansta-report", "CSV-BANSTA"),
    CCSRESP("ccs-payment-resp", "PAYRESP");

    private final String type;
    private final String format;

    CcsResponse(String type, String format) {
        this.type = type;
        this.format = format;
    }

    public String getType() {
        return this.type;
    }
    public String getFormat() {
        return this.format;
    }
}

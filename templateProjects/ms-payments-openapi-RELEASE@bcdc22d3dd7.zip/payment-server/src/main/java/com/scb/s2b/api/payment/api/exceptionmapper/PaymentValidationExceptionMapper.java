package com.scb.s2b.api.payment.api.exceptionmapper;

import static com.scb.s2b.api.payment.validation.ValidationErrorCode.ERROR_CODE;
import static com.scb.s2b.api.payment.validation.ValidationErrorCode.ERROR_MESSAGE;
import static org.apache.commons.lang3.StringUtils.isEmpty;

import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.payment.validation.PaymentValidationException;
import com.scb.s2b.api.payment.validation.ValidationErrorCode;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

public class PaymentValidationExceptionMapper implements ExceptionMapper<ValidationException> {

    private static final Splitter splitter = Splitter.on('.');

    @Override
    public Response toResponse(ValidationException ve) {
        if (ve instanceof ConstraintViolationException) {
            return this.mapConstraintViolationException((ConstraintViolationException) ve);
        } else if (ve instanceof PaymentValidationException) {
            return this.mapPaymentValidationException((PaymentValidationException) ve);
        }

        return Response.status(Response.Status.BAD_REQUEST).entity(ValidationErrorCode.AER_1000.getFullMessage(null))
                .build();
    }

    private Response mapConstraintViolationException(ConstraintViolationException cve) {
        ValidationErrorCode errorCode = null;
        String field = null;
        String orginalMessage = "";

        if(!cve.getConstraintViolations().isEmpty()) {
            Optional<ConstraintViolation<?>> violationOpt = cve.getConstraintViolations().stream().min((kVio, vVio) -> {
                String kVioType = getViolationType(kVio.getConstraintDescriptor().getMessageTemplate());
                String vVioType = getViolationType(vVio.getConstraintDescriptor().getMessageTemplate());
                if (getViolationTypePriority(kVioType) == getViolationTypePriority(vVioType)) {
                    ValidationErrorCode kVioCode = ValidationErrorCode
                            .getErrorCode(kVio.getPropertyPath().toString(), kVioType);
                    ValidationErrorCode vVioCode = ValidationErrorCode
                            .getErrorCode(vVio.getPropertyPath().toString(), vVioType);
                    return kVioCode.toString().compareTo(vVioCode.toString());
                } else {
                    return getViolationTypePriority(kVioType) - getViolationTypePriority(vVioType);
                }
            });

            if(violationOpt.isPresent()) {
                ConstraintViolation<?> violation = violationOpt.get();
                field = violation.getPropertyPath().toString();
                orginalMessage = violation.getMessage();
                String type = this.getViolationType(violation.getConstraintDescriptor().getMessageTemplate());
                errorCode = ValidationErrorCode.getErrorCode(field, type);
            }
        }

        if (errorCode == null) {
            errorCode = ValidationErrorCode.AER_1000;
        }

        return Response.status(Response.Status.BAD_REQUEST).entity(errorCode.getFullMessage(field, orginalMessage))
                .build();
    }

    private Response mapPaymentValidationException(PaymentValidationException pve) {
        ValidationErrorCode errorCode = Optional.ofNullable(pve.getErrorCode()).orElse(ValidationErrorCode.AER_1000);
        Map<String, Object> fullMessage = isEmpty(pve.getMessage()) ? errorCode.getFullMessage(null)
                : ImmutableMap.of(ERROR_MESSAGE, pve.getMessage(), ERROR_CODE, errorCode.getCode());
        return Response.status(Response.Status.BAD_REQUEST).entity(fullMessage)
                .build();
    }

    String getViolationType(String anno) {
        List<String> parts = splitter.splitToList(anno);
        if (parts.size() > 1) {
            return parts.get(parts.size() - 2);
        }

        return null;
    }

    private int getViolationTypePriority(String type) {
        int ret = Integer.MAX_VALUE;
        if ("NOTNULL".equalsIgnoreCase(type)) {
            ret = 1;
        } else if ("NOTBLANK".equalsIgnoreCase(type)) {
            ret = 2;
        } else if ("SIZE".equalsIgnoreCase(type)) {
            ret = 3;
        } else if ("PATTERN".equalsIgnoreCase(type)){
            ret = 4;
        }
        return ret;
    }
}


package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "s2bGrpId"
})
public class Cstmr {

    @JsonProperty("s2bGrpId")
    private String s2bGrpId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("s2bGrpId")
    public String getS2bGrpId() {
        return s2bGrpId;
    }

    @JsonProperty("s2bGrpId")
    public void setS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
    }

    public Cstmr withS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Cstmr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(s2bGrpId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Cstmr) == false) {
            return false;
        }
        Cstmr rhs = ((Cstmr) other);
        return new EqualsBuilder().append(s2bGrpId, rhs.s2bGrpId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

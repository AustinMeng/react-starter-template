
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sndrPurpCd",
    "rcvrPurpCd"
})
public class Purp {

    @JsonProperty("sndrPurpCd")
    private String sndrPurpCd;
    @JsonProperty("rcvrPurpCd")
    private String rcvrPurpCd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("sndrPurpCd")
    public String getSndrPurpCd() {
        return sndrPurpCd;
    }

    @JsonProperty("sndrPurpCd")
    public void setSndrPurpCd(String sndrPurpCd) {
        this.sndrPurpCd = sndrPurpCd;
    }

    public Purp withSndrPurpCd(String sndrPurpCd) {
        this.sndrPurpCd = sndrPurpCd;
        return this;
    }

    @JsonProperty("rcvrPurpCd")
    public String getRcvrPurpCd() {
        return rcvrPurpCd;
    }

    @JsonProperty("rcvrPurpCd")
    public void setRcvrPurpCd(String rcvrPurpCd) {
        this.rcvrPurpCd = rcvrPurpCd;
    }

    public Purp withRcvrPurpCd(String rcvrPurpCd) {
        this.rcvrPurpCd = rcvrPurpCd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Purp withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sndrPurpCd).append(rcvrPurpCd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Purp) == false) {
            return false;
        }
        Purp rhs = ((Purp) other);
        return new EqualsBuilder().append(sndrPurpCd, rhs.sndrPurpCd).append(rcvrPurpCd, rhs.rcvrPurpCd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

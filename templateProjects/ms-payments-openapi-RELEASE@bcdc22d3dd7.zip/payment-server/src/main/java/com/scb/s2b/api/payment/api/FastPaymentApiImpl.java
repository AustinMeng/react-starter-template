package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.FastPaymentRequestValidator;
import javax.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Singleton
public class FastPaymentApiImpl extends FastPaymentApiBase {

    @Autowired
    public FastPaymentApiImpl(FastPaymentRequestValidator paymentRequestValidator,
            @Qualifier("fastRequestProcessor") RequestProcessor requestProcessor,
            OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer,
            PaymentService paymentService) {
        super(paymentRequestValidator, requestProcessor, openApiPaymentInstructionTransformer, paymentService);
    }
}

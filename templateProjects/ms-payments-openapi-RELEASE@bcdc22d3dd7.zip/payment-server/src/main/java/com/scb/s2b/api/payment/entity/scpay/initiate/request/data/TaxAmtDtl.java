
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "prdYr",
    "prdTp",
    "prdFrDt",
    "prdToDt",
    "amt",
    "ccy"
})
public class TaxAmtDtl {

    @JsonProperty("prdYr")
    private String prdYr;
    @JsonProperty("prdTp")
    private String prdTp;
    @JsonProperty("prdFrDt")
    private String prdFrDt;
    @JsonProperty("prdToDt")
    private String prdToDt;
    @JsonProperty("amt")
    private String amt;
    @JsonProperty("ccy")
    private String ccy;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("prdYr")
    public String getPrdYr() {
        return prdYr;
    }

    @JsonProperty("prdYr")
    public void setPrdYr(String prdYr) {
        this.prdYr = prdYr;
    }

    public TaxAmtDtl withPrdYr(String prdYr) {
        this.prdYr = prdYr;
        return this;
    }

    @JsonProperty("prdTp")
    public String getPrdTp() {
        return prdTp;
    }

    @JsonProperty("prdTp")
    public void setPrdTp(String prdTp) {
        this.prdTp = prdTp;
    }

    public TaxAmtDtl withPrdTp(String prdTp) {
        this.prdTp = prdTp;
        return this;
    }

    @JsonProperty("prdFrDt")
    public String getPrdFrDt() {
        return prdFrDt;
    }

    @JsonProperty("prdFrDt")
    public void setPrdFrDt(String prdFrDt) {
        this.prdFrDt = prdFrDt;
    }

    public TaxAmtDtl withPrdFrDt(String prdFrDt) {
        this.prdFrDt = prdFrDt;
        return this;
    }

    @JsonProperty("prdToDt")
    public String getPrdToDt() {
        return prdToDt;
    }

    @JsonProperty("prdToDt")
    public void setPrdToDt(String prdToDt) {
        this.prdToDt = prdToDt;
    }

    public TaxAmtDtl withPrdToDt(String prdToDt) {
        this.prdToDt = prdToDt;
        return this;
    }

    @JsonProperty("amt")
    public String getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(String amt) {
        this.amt = amt;
    }

    public TaxAmtDtl withAmt(String amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public TaxAmtDtl withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public TaxAmtDtl withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(prdYr).append(prdTp).append(prdFrDt).append(prdToDt).append(amt).append(ccy).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TaxAmtDtl) == false) {
            return false;
        }
        TaxAmtDtl rhs = ((TaxAmtDtl) other);
        return new EqualsBuilder().append(prdYr, rhs.prdYr).append(prdTp, rhs.prdTp).append(prdFrDt, rhs.prdFrDt).append(prdToDt, rhs.prdToDt).append(amt, rhs.amt).append(ccy, rhs.ccy).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

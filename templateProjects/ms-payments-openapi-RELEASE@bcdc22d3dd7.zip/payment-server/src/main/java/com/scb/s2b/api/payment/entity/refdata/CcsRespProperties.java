package com.scb.s2b.api.payment.entity.refdata;

import java.io.Serializable;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class CcsRespProperties implements Serializable {

    private String defaultSource;
    private Map<String, String> groupSources;
}


package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "mtd",
    "elctrncAdr",
    "nm",
    "pstlAdr"
})
public class RmtLctnDtl {

    @JsonProperty("mtd")
    private String mtd;
    @JsonProperty("elctrncAdr")
    private String elctrncAdr;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("mtd")
    public String getMtd() {
        return mtd;
    }

    @JsonProperty("mtd")
    public void setMtd(String mtd) {
        this.mtd = mtd;
    }

    public RmtLctnDtl withMtd(String mtd) {
        this.mtd = mtd;
        return this;
    }

    @JsonProperty("elctrncAdr")
    public String getElctrncAdr() {
        return elctrncAdr;
    }

    @JsonProperty("elctrncAdr")
    public void setElctrncAdr(String elctrncAdr) {
        this.elctrncAdr = elctrncAdr;
    }

    public RmtLctnDtl withElctrncAdr(String elctrncAdr) {
        this.elctrncAdr = elctrncAdr;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public RmtLctnDtl withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public RmtLctnDtl withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RmtLctnDtl withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(mtd).append(elctrncAdr).append(nm).append(pstlAdr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RmtLctnDtl) == false) {
            return false;
        }
        RmtLctnDtl rhs = ((RmtLctnDtl) other);
        return new EqualsBuilder().append(mtd, rhs.mtd).append(elctrncAdr, rhs.elctrncAdr).append(nm, rhs.nm).append(pstlAdr, rhs.pstlAdr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}


package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "fileCnt",
    "fileNm",
    "btchFileNm",
    "A2FormNm",
    "FEMADclrtnFormNm",
    "filenetRef",
    "purpGrpNm",
    "invcTmpltNm",
    "freeFrmtInvcDtls",
    "BOPOverseaOrDmstInd",
    "BOPUnitCd",
    "BOPResdtCtryRgnNmCd",
    "BOPBddGoodsInd",
    "BOPPmtTerm",
    "BOPNtrOfPmt",
    "BOPTxCd1",
    "BOPTxCd2",
    "BOPAmt1",
    "BOPCcy1",
    "BOPAmt2",
    "BOPCcy2",
    "BOPTxRemarks1",
    "BOPTxRemarks2",
    "BOPCtrctNb",
    "BOPInvcNb",
    "BOPChinaSafeApprvdFilgNbRefNb",
    "RMBDclrtnUnitCd",
    "RMBDclrtnTtlAmt",
    "RMBDclrtnBOPNrrtn",
    "RMBDclrtnTradAmt",
    "RMBDclrtnAdvncdPmtAmt",
    "RMBDclrtnPctAmt",
    "RMBDclrtnCstmClrcDays",
    "RMBDclrtnCstmClrcBizUnit",
    "RMBDclrtnBizUnitCd",
    "RMBDclrtnCstmDclrtnCNY",
    "RMBDclrtnCstmDclrtnFCY",
    "RMBDclrtnGnlTradAmt",
    "RMBDclrtnFeedgPrcgTradAmt",
    "RMBDclrtnOthrTradAmt",
    "RMBDclrtnFrntrTradAmt",
    "RMBDclrtnInOutGoodsAmt",
    "RMBDclrtnTrnstTradAmt",
    "RMBDclrtnOthrAmt",
    "RMBDclrtnSvcTradAmt",
    "RMBDclrtnBOPTxCd1",
    "RMBDclrtnBOPTxCd2",
    "RMBDclrtnBOPTxCd3",
    "RMBDclrtnBOPTxCd4",
    "RMBDclrtnBOPTxCd5",
    "RMBDclrtnBOPTxCd6",
    "RMBDclrtnBOPTxCd7",
    "RMBDclrtnInvstmtIncmAmt",
    "RMBDclrtnApprvlCertNbDrctInvstmt",
    "RMBDclrtnApprvlCertNb",
    "RMBDclrtnCurTrfAmt",
    "RMBDclrtnCptlAcctAmt",
    "RMBDclrtnDrctInvstmtAmt",
    "RMBDclrtnSctyInvstmtAmt",
    "RMBDclrtnOthrInvstmtAmt",
    "RMBDclrtnRemarks",
    "RMBDclrtnInd",
    "RMBDclrtnCtctNm",
    "RMBDclrtnPhne",
    "dgtlAuthntcnBllDt",
    "dgtlAuthntcnPmtCd",
    "dgtlAuthntcnBllTp",
    "dgtlAuthntcnVchrNb",
    "dgtlAuthntcnBypassInd",
    "dgtlAuthntcnOvrrdRsn",
    "dgtlAuthntcnVrfctnSts",
    "formANb",
    "formAPurpCd",
    "CCIRltdInd",
    "vldFxInd",
    "docChckList"
})
public class RgltryDocVrfctnInf {

    @JsonProperty("fileCnt")
    private String fileCnt;
    @JsonProperty("fileNm")
    private List<String> fileNm = null;
    @JsonProperty("btchFileNm")
    private String btchFileNm;
    @JsonProperty("A2FormNm")
    private String a2FormNm;
    @JsonProperty("FEMADclrtnFormNm")
    private String fEMADclrtnFormNm;
    @JsonProperty("filenetRef")
    private String filenetRef;
    @JsonProperty("purpGrpNm")
    private String purpGrpNm;
    @JsonProperty("invcTmpltNm")
    private String invcTmpltNm;
    @JsonProperty("freeFrmtInvcDtls")
    private String freeFrmtInvcDtls;
    @JsonProperty("BOPOverseaOrDmstInd")
    private String bOPOverseaOrDmstInd;
    @JsonProperty("BOPUnitCd")
    private String bOPUnitCd;
    @JsonProperty("BOPResdtCtryRgnNmCd")
    private String bOPResdtCtryRgnNmCd;
    @JsonProperty("BOPBddGoodsInd")
    private String bOPBddGoodsInd;
    @JsonProperty("BOPPmtTerm")
    private String bOPPmtTerm;
    @JsonProperty("BOPNtrOfPmt")
    private String bOPNtrOfPmt;
    @JsonProperty("BOPTxCd1")
    private String bOPTxCd1;
    @JsonProperty("BOPTxCd2")
    private String bOPTxCd2;
    @JsonProperty("BOPAmt1")
    private String bOPAmt1;
    @JsonProperty("BOPCcy1")
    private String bOPCcy1;
    @JsonProperty("BOPAmt2")
    private String bOPAmt2;
    @JsonProperty("BOPCcy2")
    private String bOPCcy2;
    @JsonProperty("BOPTxRemarks1")
    private String bOPTxRemarks1;
    @JsonProperty("BOPTxRemarks2")
    private String bOPTxRemarks2;
    @JsonProperty("BOPCtrctNb")
    private String bOPCtrctNb;
    @JsonProperty("BOPInvcNb")
    private String bOPInvcNb;
    @JsonProperty("BOPChinaSafeApprvdFilgNbRefNb")
    private String bOPChinaSafeApprvdFilgNbRefNb;
    @JsonProperty("RMBDclrtnUnitCd")
    private String rMBDclrtnUnitCd;
    @JsonProperty("RMBDclrtnTtlAmt")
    private String rMBDclrtnTtlAmt;
    @JsonProperty("RMBDclrtnBOPNrrtn")
    private String rMBDclrtnBOPNrrtn;
    @JsonProperty("RMBDclrtnTradAmt")
    private String rMBDclrtnTradAmt;
    @JsonProperty("RMBDclrtnAdvncdPmtAmt")
    private String rMBDclrtnAdvncdPmtAmt;
    @JsonProperty("RMBDclrtnPctAmt")
    private String rMBDclrtnPctAmt;
    @JsonProperty("RMBDclrtnCstmClrcDays")
    private String rMBDclrtnCstmClrcDays;
    @JsonProperty("RMBDclrtnCstmClrcBizUnit")
    private String rMBDclrtnCstmClrcBizUnit;
    @JsonProperty("RMBDclrtnBizUnitCd")
    private String rMBDclrtnBizUnitCd;
    @JsonProperty("RMBDclrtnCstmDclrtnCNY")
    private String rMBDclrtnCstmDclrtnCNY;
    @JsonProperty("RMBDclrtnCstmDclrtnFCY")
    private String rMBDclrtnCstmDclrtnFCY;
    @JsonProperty("RMBDclrtnGnlTradAmt")
    private String rMBDclrtnGnlTradAmt;
    @JsonProperty("RMBDclrtnFeedgPrcgTradAmt")
    private String rMBDclrtnFeedgPrcgTradAmt;
    @JsonProperty("RMBDclrtnOthrTradAmt")
    private String rMBDclrtnOthrTradAmt;
    @JsonProperty("RMBDclrtnFrntrTradAmt")
    private String rMBDclrtnFrntrTradAmt;
    @JsonProperty("RMBDclrtnInOutGoodsAmt")
    private String rMBDclrtnInOutGoodsAmt;
    @JsonProperty("RMBDclrtnTrnstTradAmt")
    private String rMBDclrtnTrnstTradAmt;
    @JsonProperty("RMBDclrtnOthrAmt")
    private String rMBDclrtnOthrAmt;
    @JsonProperty("RMBDclrtnSvcTradAmt")
    private String rMBDclrtnSvcTradAmt;
    @JsonProperty("RMBDclrtnBOPTxCd1")
    private String rMBDclrtnBOPTxCd1;
    @JsonProperty("RMBDclrtnBOPTxCd2")
    private String rMBDclrtnBOPTxCd2;
    @JsonProperty("RMBDclrtnBOPTxCd3")
    private String rMBDclrtnBOPTxCd3;
    @JsonProperty("RMBDclrtnBOPTxCd4")
    private String rMBDclrtnBOPTxCd4;
    @JsonProperty("RMBDclrtnBOPTxCd5")
    private String rMBDclrtnBOPTxCd5;
    @JsonProperty("RMBDclrtnBOPTxCd6")
    private String rMBDclrtnBOPTxCd6;
    @JsonProperty("RMBDclrtnBOPTxCd7")
    private String rMBDclrtnBOPTxCd7;
    @JsonProperty("RMBDclrtnInvstmtIncmAmt")
    private String rMBDclrtnInvstmtIncmAmt;
    @JsonProperty("RMBDclrtnApprvlCertNbDrctInvstmt")
    private String rMBDclrtnApprvlCertNbDrctInvstmt;
    @JsonProperty("RMBDclrtnApprvlCertNb")
    private String rMBDclrtnApprvlCertNb;
    @JsonProperty("RMBDclrtnCurTrfAmt")
    private String rMBDclrtnCurTrfAmt;
    @JsonProperty("RMBDclrtnCptlAcctAmt")
    private String rMBDclrtnCptlAcctAmt;
    @JsonProperty("RMBDclrtnDrctInvstmtAmt")
    private String rMBDclrtnDrctInvstmtAmt;
    @JsonProperty("RMBDclrtnSctyInvstmtAmt")
    private String rMBDclrtnSctyInvstmtAmt;
    @JsonProperty("RMBDclrtnOthrInvstmtAmt")
    private String rMBDclrtnOthrInvstmtAmt;
    @JsonProperty("RMBDclrtnRemarks")
    private String rMBDclrtnRemarks;
    @JsonProperty("RMBDclrtnInd")
    private String rMBDclrtnInd;
    @JsonProperty("RMBDclrtnCtctNm")
    private String rMBDclrtnCtctNm;
    @JsonProperty("RMBDclrtnPhne")
    private String rMBDclrtnPhne;
    @JsonProperty("dgtlAuthntcnBllDt")
    private String dgtlAuthntcnBllDt;
    @JsonProperty("dgtlAuthntcnPmtCd")
    private String dgtlAuthntcnPmtCd;
    @JsonProperty("dgtlAuthntcnBllTp")
    private String dgtlAuthntcnBllTp;
    @JsonProperty("dgtlAuthntcnVchrNb")
    private String dgtlAuthntcnVchrNb;
    @JsonProperty("dgtlAuthntcnBypassInd")
    private String dgtlAuthntcnBypassInd;
    @JsonProperty("dgtlAuthntcnOvrrdRsn")
    private String dgtlAuthntcnOvrrdRsn;
    @JsonProperty("dgtlAuthntcnVrfctnSts")
    private String dgtlAuthntcnVrfctnSts;
    @JsonProperty("formANb")
    private String formANb;
    @JsonProperty("formAPurpCd")
    private String formAPurpCd;
    @JsonProperty("CCIRltdInd")
    private String cCIRltdInd;
    @JsonProperty("vldFxInd")
    private String vldFxInd;
    @JsonProperty("docChckList")
    private List<DocChckList> docChckList = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("fileCnt")
    public String getFileCnt() {
        return fileCnt;
    }

    @JsonProperty("fileCnt")
    public void setFileCnt(String fileCnt) {
        this.fileCnt = fileCnt;
    }

    public RgltryDocVrfctnInf withFileCnt(String fileCnt) {
        this.fileCnt = fileCnt;
        return this;
    }

    @JsonProperty("fileNm")
    public List<String> getFileNm() {
        return fileNm;
    }

    @JsonProperty("fileNm")
    public void setFileNm(List<String> fileNm) {
        this.fileNm = fileNm;
    }

    public RgltryDocVrfctnInf withFileNm(List<String> fileNm) {
        this.fileNm = fileNm;
        return this;
    }

    @JsonProperty("btchFileNm")
    public String getBtchFileNm() {
        return btchFileNm;
    }

    @JsonProperty("btchFileNm")
    public void setBtchFileNm(String btchFileNm) {
        this.btchFileNm = btchFileNm;
    }

    public RgltryDocVrfctnInf withBtchFileNm(String btchFileNm) {
        this.btchFileNm = btchFileNm;
        return this;
    }

    @JsonProperty("A2FormNm")
    public String getA2FormNm() {
        return a2FormNm;
    }

    @JsonProperty("A2FormNm")
    public void setA2FormNm(String a2FormNm) {
        this.a2FormNm = a2FormNm;
    }

    public RgltryDocVrfctnInf withA2FormNm(String a2FormNm) {
        this.a2FormNm = a2FormNm;
        return this;
    }

    @JsonProperty("FEMADclrtnFormNm")
    public String getFEMADclrtnFormNm() {
        return fEMADclrtnFormNm;
    }

    @JsonProperty("FEMADclrtnFormNm")
    public void setFEMADclrtnFormNm(String fEMADclrtnFormNm) {
        this.fEMADclrtnFormNm = fEMADclrtnFormNm;
    }

    public RgltryDocVrfctnInf withFEMADclrtnFormNm(String fEMADclrtnFormNm) {
        this.fEMADclrtnFormNm = fEMADclrtnFormNm;
        return this;
    }

    @JsonProperty("filenetRef")
    public String getFilenetRef() {
        return filenetRef;
    }

    @JsonProperty("filenetRef")
    public void setFilenetRef(String filenetRef) {
        this.filenetRef = filenetRef;
    }

    public RgltryDocVrfctnInf withFilenetRef(String filenetRef) {
        this.filenetRef = filenetRef;
        return this;
    }

    @JsonProperty("purpGrpNm")
    public String getPurpGrpNm() {
        return purpGrpNm;
    }

    @JsonProperty("purpGrpNm")
    public void setPurpGrpNm(String purpGrpNm) {
        this.purpGrpNm = purpGrpNm;
    }

    public RgltryDocVrfctnInf withPurpGrpNm(String purpGrpNm) {
        this.purpGrpNm = purpGrpNm;
        return this;
    }

    @JsonProperty("invcTmpltNm")
    public String getInvcTmpltNm() {
        return invcTmpltNm;
    }

    @JsonProperty("invcTmpltNm")
    public void setInvcTmpltNm(String invcTmpltNm) {
        this.invcTmpltNm = invcTmpltNm;
    }

    public RgltryDocVrfctnInf withInvcTmpltNm(String invcTmpltNm) {
        this.invcTmpltNm = invcTmpltNm;
        return this;
    }

    @JsonProperty("freeFrmtInvcDtls")
    public String getFreeFrmtInvcDtls() {
        return freeFrmtInvcDtls;
    }

    @JsonProperty("freeFrmtInvcDtls")
    public void setFreeFrmtInvcDtls(String freeFrmtInvcDtls) {
        this.freeFrmtInvcDtls = freeFrmtInvcDtls;
    }

    public RgltryDocVrfctnInf withFreeFrmtInvcDtls(String freeFrmtInvcDtls) {
        this.freeFrmtInvcDtls = freeFrmtInvcDtls;
        return this;
    }

    @JsonProperty("BOPOverseaOrDmstInd")
    public String getBOPOverseaOrDmstInd() {
        return bOPOverseaOrDmstInd;
    }

    @JsonProperty("BOPOverseaOrDmstInd")
    public void setBOPOverseaOrDmstInd(String bOPOverseaOrDmstInd) {
        this.bOPOverseaOrDmstInd = bOPOverseaOrDmstInd;
    }

    public RgltryDocVrfctnInf withBOPOverseaOrDmstInd(String bOPOverseaOrDmstInd) {
        this.bOPOverseaOrDmstInd = bOPOverseaOrDmstInd;
        return this;
    }

    @JsonProperty("BOPUnitCd")
    public String getBOPUnitCd() {
        return bOPUnitCd;
    }

    @JsonProperty("BOPUnitCd")
    public void setBOPUnitCd(String bOPUnitCd) {
        this.bOPUnitCd = bOPUnitCd;
    }

    public RgltryDocVrfctnInf withBOPUnitCd(String bOPUnitCd) {
        this.bOPUnitCd = bOPUnitCd;
        return this;
    }

    @JsonProperty("BOPResdtCtryRgnNmCd")
    public String getBOPResdtCtryRgnNmCd() {
        return bOPResdtCtryRgnNmCd;
    }

    @JsonProperty("BOPResdtCtryRgnNmCd")
    public void setBOPResdtCtryRgnNmCd(String bOPResdtCtryRgnNmCd) {
        this.bOPResdtCtryRgnNmCd = bOPResdtCtryRgnNmCd;
    }

    public RgltryDocVrfctnInf withBOPResdtCtryRgnNmCd(String bOPResdtCtryRgnNmCd) {
        this.bOPResdtCtryRgnNmCd = bOPResdtCtryRgnNmCd;
        return this;
    }

    @JsonProperty("BOPBddGoodsInd")
    public String getBOPBddGoodsInd() {
        return bOPBddGoodsInd;
    }

    @JsonProperty("BOPBddGoodsInd")
    public void setBOPBddGoodsInd(String bOPBddGoodsInd) {
        this.bOPBddGoodsInd = bOPBddGoodsInd;
    }

    public RgltryDocVrfctnInf withBOPBddGoodsInd(String bOPBddGoodsInd) {
        this.bOPBddGoodsInd = bOPBddGoodsInd;
        return this;
    }

    @JsonProperty("BOPPmtTerm")
    public String getBOPPmtTerm() {
        return bOPPmtTerm;
    }

    @JsonProperty("BOPPmtTerm")
    public void setBOPPmtTerm(String bOPPmtTerm) {
        this.bOPPmtTerm = bOPPmtTerm;
    }

    public RgltryDocVrfctnInf withBOPPmtTerm(String bOPPmtTerm) {
        this.bOPPmtTerm = bOPPmtTerm;
        return this;
    }

    @JsonProperty("BOPNtrOfPmt")
    public String getBOPNtrOfPmt() {
        return bOPNtrOfPmt;
    }

    @JsonProperty("BOPNtrOfPmt")
    public void setBOPNtrOfPmt(String bOPNtrOfPmt) {
        this.bOPNtrOfPmt = bOPNtrOfPmt;
    }

    public RgltryDocVrfctnInf withBOPNtrOfPmt(String bOPNtrOfPmt) {
        this.bOPNtrOfPmt = bOPNtrOfPmt;
        return this;
    }

    @JsonProperty("BOPTxCd1")
    public String getBOPTxCd1() {
        return bOPTxCd1;
    }

    @JsonProperty("BOPTxCd1")
    public void setBOPTxCd1(String bOPTxCd1) {
        this.bOPTxCd1 = bOPTxCd1;
    }

    public RgltryDocVrfctnInf withBOPTxCd1(String bOPTxCd1) {
        this.bOPTxCd1 = bOPTxCd1;
        return this;
    }

    @JsonProperty("BOPTxCd2")
    public String getBOPTxCd2() {
        return bOPTxCd2;
    }

    @JsonProperty("BOPTxCd2")
    public void setBOPTxCd2(String bOPTxCd2) {
        this.bOPTxCd2 = bOPTxCd2;
    }

    public RgltryDocVrfctnInf withBOPTxCd2(String bOPTxCd2) {
        this.bOPTxCd2 = bOPTxCd2;
        return this;
    }

    @JsonProperty("BOPAmt1")
    public String getBOPAmt1() {
        return bOPAmt1;
    }

    @JsonProperty("BOPAmt1")
    public void setBOPAmt1(String bOPAmt1) {
        this.bOPAmt1 = bOPAmt1;
    }

    public RgltryDocVrfctnInf withBOPAmt1(String bOPAmt1) {
        this.bOPAmt1 = bOPAmt1;
        return this;
    }

    @JsonProperty("BOPCcy1")
    public String getBOPCcy1() {
        return bOPCcy1;
    }

    @JsonProperty("BOPCcy1")
    public void setBOPCcy1(String bOPCcy1) {
        this.bOPCcy1 = bOPCcy1;
    }

    public RgltryDocVrfctnInf withBOPCcy1(String bOPCcy1) {
        this.bOPCcy1 = bOPCcy1;
        return this;
    }

    @JsonProperty("BOPAmt2")
    public String getBOPAmt2() {
        return bOPAmt2;
    }

    @JsonProperty("BOPAmt2")
    public void setBOPAmt2(String bOPAmt2) {
        this.bOPAmt2 = bOPAmt2;
    }

    public RgltryDocVrfctnInf withBOPAmt2(String bOPAmt2) {
        this.bOPAmt2 = bOPAmt2;
        return this;
    }

    @JsonProperty("BOPCcy2")
    public String getBOPCcy2() {
        return bOPCcy2;
    }

    @JsonProperty("BOPCcy2")
    public void setBOPCcy2(String bOPCcy2) {
        this.bOPCcy2 = bOPCcy2;
    }

    public RgltryDocVrfctnInf withBOPCcy2(String bOPCcy2) {
        this.bOPCcy2 = bOPCcy2;
        return this;
    }

    @JsonProperty("BOPTxRemarks1")
    public String getBOPTxRemarks1() {
        return bOPTxRemarks1;
    }

    @JsonProperty("BOPTxRemarks1")
    public void setBOPTxRemarks1(String bOPTxRemarks1) {
        this.bOPTxRemarks1 = bOPTxRemarks1;
    }

    public RgltryDocVrfctnInf withBOPTxRemarks1(String bOPTxRemarks1) {
        this.bOPTxRemarks1 = bOPTxRemarks1;
        return this;
    }

    @JsonProperty("BOPTxRemarks2")
    public String getBOPTxRemarks2() {
        return bOPTxRemarks2;
    }

    @JsonProperty("BOPTxRemarks2")
    public void setBOPTxRemarks2(String bOPTxRemarks2) {
        this.bOPTxRemarks2 = bOPTxRemarks2;
    }

    public RgltryDocVrfctnInf withBOPTxRemarks2(String bOPTxRemarks2) {
        this.bOPTxRemarks2 = bOPTxRemarks2;
        return this;
    }

    @JsonProperty("BOPCtrctNb")
    public String getBOPCtrctNb() {
        return bOPCtrctNb;
    }

    @JsonProperty("BOPCtrctNb")
    public void setBOPCtrctNb(String bOPCtrctNb) {
        this.bOPCtrctNb = bOPCtrctNb;
    }

    public RgltryDocVrfctnInf withBOPCtrctNb(String bOPCtrctNb) {
        this.bOPCtrctNb = bOPCtrctNb;
        return this;
    }

    @JsonProperty("BOPInvcNb")
    public String getBOPInvcNb() {
        return bOPInvcNb;
    }

    @JsonProperty("BOPInvcNb")
    public void setBOPInvcNb(String bOPInvcNb) {
        this.bOPInvcNb = bOPInvcNb;
    }

    public RgltryDocVrfctnInf withBOPInvcNb(String bOPInvcNb) {
        this.bOPInvcNb = bOPInvcNb;
        return this;
    }

    @JsonProperty("BOPChinaSafeApprvdFilgNbRefNb")
    public String getBOPChinaSafeApprvdFilgNbRefNb() {
        return bOPChinaSafeApprvdFilgNbRefNb;
    }

    @JsonProperty("BOPChinaSafeApprvdFilgNbRefNb")
    public void setBOPChinaSafeApprvdFilgNbRefNb(String bOPChinaSafeApprvdFilgNbRefNb) {
        this.bOPChinaSafeApprvdFilgNbRefNb = bOPChinaSafeApprvdFilgNbRefNb;
    }

    public RgltryDocVrfctnInf withBOPChinaSafeApprvdFilgNbRefNb(String bOPChinaSafeApprvdFilgNbRefNb) {
        this.bOPChinaSafeApprvdFilgNbRefNb = bOPChinaSafeApprvdFilgNbRefNb;
        return this;
    }

    @JsonProperty("RMBDclrtnUnitCd")
    public String getRMBDclrtnUnitCd() {
        return rMBDclrtnUnitCd;
    }

    @JsonProperty("RMBDclrtnUnitCd")
    public void setRMBDclrtnUnitCd(String rMBDclrtnUnitCd) {
        this.rMBDclrtnUnitCd = rMBDclrtnUnitCd;
    }

    public RgltryDocVrfctnInf withRMBDclrtnUnitCd(String rMBDclrtnUnitCd) {
        this.rMBDclrtnUnitCd = rMBDclrtnUnitCd;
        return this;
    }

    @JsonProperty("RMBDclrtnTtlAmt")
    public String getRMBDclrtnTtlAmt() {
        return rMBDclrtnTtlAmt;
    }

    @JsonProperty("RMBDclrtnTtlAmt")
    public void setRMBDclrtnTtlAmt(String rMBDclrtnTtlAmt) {
        this.rMBDclrtnTtlAmt = rMBDclrtnTtlAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnTtlAmt(String rMBDclrtnTtlAmt) {
        this.rMBDclrtnTtlAmt = rMBDclrtnTtlAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPNrrtn")
    public String getRMBDclrtnBOPNrrtn() {
        return rMBDclrtnBOPNrrtn;
    }

    @JsonProperty("RMBDclrtnBOPNrrtn")
    public void setRMBDclrtnBOPNrrtn(String rMBDclrtnBOPNrrtn) {
        this.rMBDclrtnBOPNrrtn = rMBDclrtnBOPNrrtn;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPNrrtn(String rMBDclrtnBOPNrrtn) {
        this.rMBDclrtnBOPNrrtn = rMBDclrtnBOPNrrtn;
        return this;
    }

    @JsonProperty("RMBDclrtnTradAmt")
    public String getRMBDclrtnTradAmt() {
        return rMBDclrtnTradAmt;
    }

    @JsonProperty("RMBDclrtnTradAmt")
    public void setRMBDclrtnTradAmt(String rMBDclrtnTradAmt) {
        this.rMBDclrtnTradAmt = rMBDclrtnTradAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnTradAmt(String rMBDclrtnTradAmt) {
        this.rMBDclrtnTradAmt = rMBDclrtnTradAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnAdvncdPmtAmt")
    public String getRMBDclrtnAdvncdPmtAmt() {
        return rMBDclrtnAdvncdPmtAmt;
    }

    @JsonProperty("RMBDclrtnAdvncdPmtAmt")
    public void setRMBDclrtnAdvncdPmtAmt(String rMBDclrtnAdvncdPmtAmt) {
        this.rMBDclrtnAdvncdPmtAmt = rMBDclrtnAdvncdPmtAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnAdvncdPmtAmt(String rMBDclrtnAdvncdPmtAmt) {
        this.rMBDclrtnAdvncdPmtAmt = rMBDclrtnAdvncdPmtAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnPctAmt")
    public String getRMBDclrtnPctAmt() {
        return rMBDclrtnPctAmt;
    }

    @JsonProperty("RMBDclrtnPctAmt")
    public void setRMBDclrtnPctAmt(String rMBDclrtnPctAmt) {
        this.rMBDclrtnPctAmt = rMBDclrtnPctAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnPctAmt(String rMBDclrtnPctAmt) {
        this.rMBDclrtnPctAmt = rMBDclrtnPctAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnCstmClrcDays")
    public String getRMBDclrtnCstmClrcDays() {
        return rMBDclrtnCstmClrcDays;
    }

    @JsonProperty("RMBDclrtnCstmClrcDays")
    public void setRMBDclrtnCstmClrcDays(String rMBDclrtnCstmClrcDays) {
        this.rMBDclrtnCstmClrcDays = rMBDclrtnCstmClrcDays;
    }

    public RgltryDocVrfctnInf withRMBDclrtnCstmClrcDays(String rMBDclrtnCstmClrcDays) {
        this.rMBDclrtnCstmClrcDays = rMBDclrtnCstmClrcDays;
        return this;
    }

    @JsonProperty("RMBDclrtnCstmClrcBizUnit")
    public String getRMBDclrtnCstmClrcBizUnit() {
        return rMBDclrtnCstmClrcBizUnit;
    }

    @JsonProperty("RMBDclrtnCstmClrcBizUnit")
    public void setRMBDclrtnCstmClrcBizUnit(String rMBDclrtnCstmClrcBizUnit) {
        this.rMBDclrtnCstmClrcBizUnit = rMBDclrtnCstmClrcBizUnit;
    }

    public RgltryDocVrfctnInf withRMBDclrtnCstmClrcBizUnit(String rMBDclrtnCstmClrcBizUnit) {
        this.rMBDclrtnCstmClrcBizUnit = rMBDclrtnCstmClrcBizUnit;
        return this;
    }

    @JsonProperty("RMBDclrtnBizUnitCd")
    public String getRMBDclrtnBizUnitCd() {
        return rMBDclrtnBizUnitCd;
    }

    @JsonProperty("RMBDclrtnBizUnitCd")
    public void setRMBDclrtnBizUnitCd(String rMBDclrtnBizUnitCd) {
        this.rMBDclrtnBizUnitCd = rMBDclrtnBizUnitCd;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBizUnitCd(String rMBDclrtnBizUnitCd) {
        this.rMBDclrtnBizUnitCd = rMBDclrtnBizUnitCd;
        return this;
    }

    @JsonProperty("RMBDclrtnCstmDclrtnCNY")
    public String getRMBDclrtnCstmDclrtnCNY() {
        return rMBDclrtnCstmDclrtnCNY;
    }

    @JsonProperty("RMBDclrtnCstmDclrtnCNY")
    public void setRMBDclrtnCstmDclrtnCNY(String rMBDclrtnCstmDclrtnCNY) {
        this.rMBDclrtnCstmDclrtnCNY = rMBDclrtnCstmDclrtnCNY;
    }

    public RgltryDocVrfctnInf withRMBDclrtnCstmDclrtnCNY(String rMBDclrtnCstmDclrtnCNY) {
        this.rMBDclrtnCstmDclrtnCNY = rMBDclrtnCstmDclrtnCNY;
        return this;
    }

    @JsonProperty("RMBDclrtnCstmDclrtnFCY")
    public String getRMBDclrtnCstmDclrtnFCY() {
        return rMBDclrtnCstmDclrtnFCY;
    }

    @JsonProperty("RMBDclrtnCstmDclrtnFCY")
    public void setRMBDclrtnCstmDclrtnFCY(String rMBDclrtnCstmDclrtnFCY) {
        this.rMBDclrtnCstmDclrtnFCY = rMBDclrtnCstmDclrtnFCY;
    }

    public RgltryDocVrfctnInf withRMBDclrtnCstmDclrtnFCY(String rMBDclrtnCstmDclrtnFCY) {
        this.rMBDclrtnCstmDclrtnFCY = rMBDclrtnCstmDclrtnFCY;
        return this;
    }

    @JsonProperty("RMBDclrtnGnlTradAmt")
    public String getRMBDclrtnGnlTradAmt() {
        return rMBDclrtnGnlTradAmt;
    }

    @JsonProperty("RMBDclrtnGnlTradAmt")
    public void setRMBDclrtnGnlTradAmt(String rMBDclrtnGnlTradAmt) {
        this.rMBDclrtnGnlTradAmt = rMBDclrtnGnlTradAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnGnlTradAmt(String rMBDclrtnGnlTradAmt) {
        this.rMBDclrtnGnlTradAmt = rMBDclrtnGnlTradAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnFeedgPrcgTradAmt")
    public String getRMBDclrtnFeedgPrcgTradAmt() {
        return rMBDclrtnFeedgPrcgTradAmt;
    }

    @JsonProperty("RMBDclrtnFeedgPrcgTradAmt")
    public void setRMBDclrtnFeedgPrcgTradAmt(String rMBDclrtnFeedgPrcgTradAmt) {
        this.rMBDclrtnFeedgPrcgTradAmt = rMBDclrtnFeedgPrcgTradAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnFeedgPrcgTradAmt(String rMBDclrtnFeedgPrcgTradAmt) {
        this.rMBDclrtnFeedgPrcgTradAmt = rMBDclrtnFeedgPrcgTradAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnOthrTradAmt")
    public String getRMBDclrtnOthrTradAmt() {
        return rMBDclrtnOthrTradAmt;
    }

    @JsonProperty("RMBDclrtnOthrTradAmt")
    public void setRMBDclrtnOthrTradAmt(String rMBDclrtnOthrTradAmt) {
        this.rMBDclrtnOthrTradAmt = rMBDclrtnOthrTradAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnOthrTradAmt(String rMBDclrtnOthrTradAmt) {
        this.rMBDclrtnOthrTradAmt = rMBDclrtnOthrTradAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnFrntrTradAmt")
    public String getRMBDclrtnFrntrTradAmt() {
        return rMBDclrtnFrntrTradAmt;
    }

    @JsonProperty("RMBDclrtnFrntrTradAmt")
    public void setRMBDclrtnFrntrTradAmt(String rMBDclrtnFrntrTradAmt) {
        this.rMBDclrtnFrntrTradAmt = rMBDclrtnFrntrTradAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnFrntrTradAmt(String rMBDclrtnFrntrTradAmt) {
        this.rMBDclrtnFrntrTradAmt = rMBDclrtnFrntrTradAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnInOutGoodsAmt")
    public String getRMBDclrtnInOutGoodsAmt() {
        return rMBDclrtnInOutGoodsAmt;
    }

    @JsonProperty("RMBDclrtnInOutGoodsAmt")
    public void setRMBDclrtnInOutGoodsAmt(String rMBDclrtnInOutGoodsAmt) {
        this.rMBDclrtnInOutGoodsAmt = rMBDclrtnInOutGoodsAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnInOutGoodsAmt(String rMBDclrtnInOutGoodsAmt) {
        this.rMBDclrtnInOutGoodsAmt = rMBDclrtnInOutGoodsAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnTrnstTradAmt")
    public String getRMBDclrtnTrnstTradAmt() {
        return rMBDclrtnTrnstTradAmt;
    }

    @JsonProperty("RMBDclrtnTrnstTradAmt")
    public void setRMBDclrtnTrnstTradAmt(String rMBDclrtnTrnstTradAmt) {
        this.rMBDclrtnTrnstTradAmt = rMBDclrtnTrnstTradAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnTrnstTradAmt(String rMBDclrtnTrnstTradAmt) {
        this.rMBDclrtnTrnstTradAmt = rMBDclrtnTrnstTradAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnOthrAmt")
    public String getRMBDclrtnOthrAmt() {
        return rMBDclrtnOthrAmt;
    }

    @JsonProperty("RMBDclrtnOthrAmt")
    public void setRMBDclrtnOthrAmt(String rMBDclrtnOthrAmt) {
        this.rMBDclrtnOthrAmt = rMBDclrtnOthrAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnOthrAmt(String rMBDclrtnOthrAmt) {
        this.rMBDclrtnOthrAmt = rMBDclrtnOthrAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnSvcTradAmt")
    public String getRMBDclrtnSvcTradAmt() {
        return rMBDclrtnSvcTradAmt;
    }

    @JsonProperty("RMBDclrtnSvcTradAmt")
    public void setRMBDclrtnSvcTradAmt(String rMBDclrtnSvcTradAmt) {
        this.rMBDclrtnSvcTradAmt = rMBDclrtnSvcTradAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnSvcTradAmt(String rMBDclrtnSvcTradAmt) {
        this.rMBDclrtnSvcTradAmt = rMBDclrtnSvcTradAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPTxCd1")
    public String getRMBDclrtnBOPTxCd1() {
        return rMBDclrtnBOPTxCd1;
    }

    @JsonProperty("RMBDclrtnBOPTxCd1")
    public void setRMBDclrtnBOPTxCd1(String rMBDclrtnBOPTxCd1) {
        this.rMBDclrtnBOPTxCd1 = rMBDclrtnBOPTxCd1;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPTxCd1(String rMBDclrtnBOPTxCd1) {
        this.rMBDclrtnBOPTxCd1 = rMBDclrtnBOPTxCd1;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPTxCd2")
    public String getRMBDclrtnBOPTxCd2() {
        return rMBDclrtnBOPTxCd2;
    }

    @JsonProperty("RMBDclrtnBOPTxCd2")
    public void setRMBDclrtnBOPTxCd2(String rMBDclrtnBOPTxCd2) {
        this.rMBDclrtnBOPTxCd2 = rMBDclrtnBOPTxCd2;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPTxCd2(String rMBDclrtnBOPTxCd2) {
        this.rMBDclrtnBOPTxCd2 = rMBDclrtnBOPTxCd2;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPTxCd3")
    public String getRMBDclrtnBOPTxCd3() {
        return rMBDclrtnBOPTxCd3;
    }

    @JsonProperty("RMBDclrtnBOPTxCd3")
    public void setRMBDclrtnBOPTxCd3(String rMBDclrtnBOPTxCd3) {
        this.rMBDclrtnBOPTxCd3 = rMBDclrtnBOPTxCd3;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPTxCd3(String rMBDclrtnBOPTxCd3) {
        this.rMBDclrtnBOPTxCd3 = rMBDclrtnBOPTxCd3;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPTxCd4")
    public String getRMBDclrtnBOPTxCd4() {
        return rMBDclrtnBOPTxCd4;
    }

    @JsonProperty("RMBDclrtnBOPTxCd4")
    public void setRMBDclrtnBOPTxCd4(String rMBDclrtnBOPTxCd4) {
        this.rMBDclrtnBOPTxCd4 = rMBDclrtnBOPTxCd4;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPTxCd4(String rMBDclrtnBOPTxCd4) {
        this.rMBDclrtnBOPTxCd4 = rMBDclrtnBOPTxCd4;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPTxCd5")
    public String getRMBDclrtnBOPTxCd5() {
        return rMBDclrtnBOPTxCd5;
    }

    @JsonProperty("RMBDclrtnBOPTxCd5")
    public void setRMBDclrtnBOPTxCd5(String rMBDclrtnBOPTxCd5) {
        this.rMBDclrtnBOPTxCd5 = rMBDclrtnBOPTxCd5;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPTxCd5(String rMBDclrtnBOPTxCd5) {
        this.rMBDclrtnBOPTxCd5 = rMBDclrtnBOPTxCd5;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPTxCd6")
    public String getRMBDclrtnBOPTxCd6() {
        return rMBDclrtnBOPTxCd6;
    }

    @JsonProperty("RMBDclrtnBOPTxCd6")
    public void setRMBDclrtnBOPTxCd6(String rMBDclrtnBOPTxCd6) {
        this.rMBDclrtnBOPTxCd6 = rMBDclrtnBOPTxCd6;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPTxCd6(String rMBDclrtnBOPTxCd6) {
        this.rMBDclrtnBOPTxCd6 = rMBDclrtnBOPTxCd6;
        return this;
    }

    @JsonProperty("RMBDclrtnBOPTxCd7")
    public String getRMBDclrtnBOPTxCd7() {
        return rMBDclrtnBOPTxCd7;
    }

    @JsonProperty("RMBDclrtnBOPTxCd7")
    public void setRMBDclrtnBOPTxCd7(String rMBDclrtnBOPTxCd7) {
        this.rMBDclrtnBOPTxCd7 = rMBDclrtnBOPTxCd7;
    }

    public RgltryDocVrfctnInf withRMBDclrtnBOPTxCd7(String rMBDclrtnBOPTxCd7) {
        this.rMBDclrtnBOPTxCd7 = rMBDclrtnBOPTxCd7;
        return this;
    }

    @JsonProperty("RMBDclrtnInvstmtIncmAmt")
    public String getRMBDclrtnInvstmtIncmAmt() {
        return rMBDclrtnInvstmtIncmAmt;
    }

    @JsonProperty("RMBDclrtnInvstmtIncmAmt")
    public void setRMBDclrtnInvstmtIncmAmt(String rMBDclrtnInvstmtIncmAmt) {
        this.rMBDclrtnInvstmtIncmAmt = rMBDclrtnInvstmtIncmAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnInvstmtIncmAmt(String rMBDclrtnInvstmtIncmAmt) {
        this.rMBDclrtnInvstmtIncmAmt = rMBDclrtnInvstmtIncmAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnApprvlCertNbDrctInvstmt")
    public String getRMBDclrtnApprvlCertNbDrctInvstmt() {
        return rMBDclrtnApprvlCertNbDrctInvstmt;
    }

    @JsonProperty("RMBDclrtnApprvlCertNbDrctInvstmt")
    public void setRMBDclrtnApprvlCertNbDrctInvstmt(String rMBDclrtnApprvlCertNbDrctInvstmt) {
        this.rMBDclrtnApprvlCertNbDrctInvstmt = rMBDclrtnApprvlCertNbDrctInvstmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnApprvlCertNbDrctInvstmt(String rMBDclrtnApprvlCertNbDrctInvstmt) {
        this.rMBDclrtnApprvlCertNbDrctInvstmt = rMBDclrtnApprvlCertNbDrctInvstmt;
        return this;
    }

    @JsonProperty("RMBDclrtnApprvlCertNb")
    public String getRMBDclrtnApprvlCertNb() {
        return rMBDclrtnApprvlCertNb;
    }

    @JsonProperty("RMBDclrtnApprvlCertNb")
    public void setRMBDclrtnApprvlCertNb(String rMBDclrtnApprvlCertNb) {
        this.rMBDclrtnApprvlCertNb = rMBDclrtnApprvlCertNb;
    }

    public RgltryDocVrfctnInf withRMBDclrtnApprvlCertNb(String rMBDclrtnApprvlCertNb) {
        this.rMBDclrtnApprvlCertNb = rMBDclrtnApprvlCertNb;
        return this;
    }

    @JsonProperty("RMBDclrtnCurTrfAmt")
    public String getRMBDclrtnCurTrfAmt() {
        return rMBDclrtnCurTrfAmt;
    }

    @JsonProperty("RMBDclrtnCurTrfAmt")
    public void setRMBDclrtnCurTrfAmt(String rMBDclrtnCurTrfAmt) {
        this.rMBDclrtnCurTrfAmt = rMBDclrtnCurTrfAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnCurTrfAmt(String rMBDclrtnCurTrfAmt) {
        this.rMBDclrtnCurTrfAmt = rMBDclrtnCurTrfAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnCptlAcctAmt")
    public String getRMBDclrtnCptlAcctAmt() {
        return rMBDclrtnCptlAcctAmt;
    }

    @JsonProperty("RMBDclrtnCptlAcctAmt")
    public void setRMBDclrtnCptlAcctAmt(String rMBDclrtnCptlAcctAmt) {
        this.rMBDclrtnCptlAcctAmt = rMBDclrtnCptlAcctAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnCptlAcctAmt(String rMBDclrtnCptlAcctAmt) {
        this.rMBDclrtnCptlAcctAmt = rMBDclrtnCptlAcctAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnDrctInvstmtAmt")
    public String getRMBDclrtnDrctInvstmtAmt() {
        return rMBDclrtnDrctInvstmtAmt;
    }

    @JsonProperty("RMBDclrtnDrctInvstmtAmt")
    public void setRMBDclrtnDrctInvstmtAmt(String rMBDclrtnDrctInvstmtAmt) {
        this.rMBDclrtnDrctInvstmtAmt = rMBDclrtnDrctInvstmtAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnDrctInvstmtAmt(String rMBDclrtnDrctInvstmtAmt) {
        this.rMBDclrtnDrctInvstmtAmt = rMBDclrtnDrctInvstmtAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnSctyInvstmtAmt")
    public String getRMBDclrtnSctyInvstmtAmt() {
        return rMBDclrtnSctyInvstmtAmt;
    }

    @JsonProperty("RMBDclrtnSctyInvstmtAmt")
    public void setRMBDclrtnSctyInvstmtAmt(String rMBDclrtnSctyInvstmtAmt) {
        this.rMBDclrtnSctyInvstmtAmt = rMBDclrtnSctyInvstmtAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnSctyInvstmtAmt(String rMBDclrtnSctyInvstmtAmt) {
        this.rMBDclrtnSctyInvstmtAmt = rMBDclrtnSctyInvstmtAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnOthrInvstmtAmt")
    public String getRMBDclrtnOthrInvstmtAmt() {
        return rMBDclrtnOthrInvstmtAmt;
    }

    @JsonProperty("RMBDclrtnOthrInvstmtAmt")
    public void setRMBDclrtnOthrInvstmtAmt(String rMBDclrtnOthrInvstmtAmt) {
        this.rMBDclrtnOthrInvstmtAmt = rMBDclrtnOthrInvstmtAmt;
    }

    public RgltryDocVrfctnInf withRMBDclrtnOthrInvstmtAmt(String rMBDclrtnOthrInvstmtAmt) {
        this.rMBDclrtnOthrInvstmtAmt = rMBDclrtnOthrInvstmtAmt;
        return this;
    }

    @JsonProperty("RMBDclrtnRemarks")
    public String getRMBDclrtnRemarks() {
        return rMBDclrtnRemarks;
    }

    @JsonProperty("RMBDclrtnRemarks")
    public void setRMBDclrtnRemarks(String rMBDclrtnRemarks) {
        this.rMBDclrtnRemarks = rMBDclrtnRemarks;
    }

    public RgltryDocVrfctnInf withRMBDclrtnRemarks(String rMBDclrtnRemarks) {
        this.rMBDclrtnRemarks = rMBDclrtnRemarks;
        return this;
    }

    @JsonProperty("RMBDclrtnInd")
    public String getRMBDclrtnInd() {
        return rMBDclrtnInd;
    }

    @JsonProperty("RMBDclrtnInd")
    public void setRMBDclrtnInd(String rMBDclrtnInd) {
        this.rMBDclrtnInd = rMBDclrtnInd;
    }

    public RgltryDocVrfctnInf withRMBDclrtnInd(String rMBDclrtnInd) {
        this.rMBDclrtnInd = rMBDclrtnInd;
        return this;
    }

    @JsonProperty("RMBDclrtnCtctNm")
    public String getRMBDclrtnCtctNm() {
        return rMBDclrtnCtctNm;
    }

    @JsonProperty("RMBDclrtnCtctNm")
    public void setRMBDclrtnCtctNm(String rMBDclrtnCtctNm) {
        this.rMBDclrtnCtctNm = rMBDclrtnCtctNm;
    }

    public RgltryDocVrfctnInf withRMBDclrtnCtctNm(String rMBDclrtnCtctNm) {
        this.rMBDclrtnCtctNm = rMBDclrtnCtctNm;
        return this;
    }

    @JsonProperty("RMBDclrtnPhne")
    public String getRMBDclrtnPhne() {
        return rMBDclrtnPhne;
    }

    @JsonProperty("RMBDclrtnPhne")
    public void setRMBDclrtnPhne(String rMBDclrtnPhne) {
        this.rMBDclrtnPhne = rMBDclrtnPhne;
    }

    public RgltryDocVrfctnInf withRMBDclrtnPhne(String rMBDclrtnPhne) {
        this.rMBDclrtnPhne = rMBDclrtnPhne;
        return this;
    }

    @JsonProperty("dgtlAuthntcnBllDt")
    public String getDgtlAuthntcnBllDt() {
        return dgtlAuthntcnBllDt;
    }

    @JsonProperty("dgtlAuthntcnBllDt")
    public void setDgtlAuthntcnBllDt(String dgtlAuthntcnBllDt) {
        this.dgtlAuthntcnBllDt = dgtlAuthntcnBllDt;
    }

    public RgltryDocVrfctnInf withDgtlAuthntcnBllDt(String dgtlAuthntcnBllDt) {
        this.dgtlAuthntcnBllDt = dgtlAuthntcnBllDt;
        return this;
    }

    @JsonProperty("dgtlAuthntcnPmtCd")
    public String getDgtlAuthntcnPmtCd() {
        return dgtlAuthntcnPmtCd;
    }

    @JsonProperty("dgtlAuthntcnPmtCd")
    public void setDgtlAuthntcnPmtCd(String dgtlAuthntcnPmtCd) {
        this.dgtlAuthntcnPmtCd = dgtlAuthntcnPmtCd;
    }

    public RgltryDocVrfctnInf withDgtlAuthntcnPmtCd(String dgtlAuthntcnPmtCd) {
        this.dgtlAuthntcnPmtCd = dgtlAuthntcnPmtCd;
        return this;
    }

    @JsonProperty("dgtlAuthntcnBllTp")
    public String getDgtlAuthntcnBllTp() {
        return dgtlAuthntcnBllTp;
    }

    @JsonProperty("dgtlAuthntcnBllTp")
    public void setDgtlAuthntcnBllTp(String dgtlAuthntcnBllTp) {
        this.dgtlAuthntcnBllTp = dgtlAuthntcnBllTp;
    }

    public RgltryDocVrfctnInf withDgtlAuthntcnBllTp(String dgtlAuthntcnBllTp) {
        this.dgtlAuthntcnBllTp = dgtlAuthntcnBllTp;
        return this;
    }

    @JsonProperty("dgtlAuthntcnVchrNb")
    public String getDgtlAuthntcnVchrNb() {
        return dgtlAuthntcnVchrNb;
    }

    @JsonProperty("dgtlAuthntcnVchrNb")
    public void setDgtlAuthntcnVchrNb(String dgtlAuthntcnVchrNb) {
        this.dgtlAuthntcnVchrNb = dgtlAuthntcnVchrNb;
    }

    public RgltryDocVrfctnInf withDgtlAuthntcnVchrNb(String dgtlAuthntcnVchrNb) {
        this.dgtlAuthntcnVchrNb = dgtlAuthntcnVchrNb;
        return this;
    }

    @JsonProperty("dgtlAuthntcnBypassInd")
    public String getDgtlAuthntcnBypassInd() {
        return dgtlAuthntcnBypassInd;
    }

    @JsonProperty("dgtlAuthntcnBypassInd")
    public void setDgtlAuthntcnBypassInd(String dgtlAuthntcnBypassInd) {
        this.dgtlAuthntcnBypassInd = dgtlAuthntcnBypassInd;
    }

    public RgltryDocVrfctnInf withDgtlAuthntcnBypassInd(String dgtlAuthntcnBypassInd) {
        this.dgtlAuthntcnBypassInd = dgtlAuthntcnBypassInd;
        return this;
    }

    @JsonProperty("dgtlAuthntcnOvrrdRsn")
    public String getDgtlAuthntcnOvrrdRsn() {
        return dgtlAuthntcnOvrrdRsn;
    }

    @JsonProperty("dgtlAuthntcnOvrrdRsn")
    public void setDgtlAuthntcnOvrrdRsn(String dgtlAuthntcnOvrrdRsn) {
        this.dgtlAuthntcnOvrrdRsn = dgtlAuthntcnOvrrdRsn;
    }

    public RgltryDocVrfctnInf withDgtlAuthntcnOvrrdRsn(String dgtlAuthntcnOvrrdRsn) {
        this.dgtlAuthntcnOvrrdRsn = dgtlAuthntcnOvrrdRsn;
        return this;
    }

    @JsonProperty("dgtlAuthntcnVrfctnSts")
    public String getDgtlAuthntcnVrfctnSts() {
        return dgtlAuthntcnVrfctnSts;
    }

    @JsonProperty("dgtlAuthntcnVrfctnSts")
    public void setDgtlAuthntcnVrfctnSts(String dgtlAuthntcnVrfctnSts) {
        this.dgtlAuthntcnVrfctnSts = dgtlAuthntcnVrfctnSts;
    }

    public RgltryDocVrfctnInf withDgtlAuthntcnVrfctnSts(String dgtlAuthntcnVrfctnSts) {
        this.dgtlAuthntcnVrfctnSts = dgtlAuthntcnVrfctnSts;
        return this;
    }

    @JsonProperty("formANb")
    public String getFormANb() {
        return formANb;
    }

    @JsonProperty("formANb")
    public void setFormANb(String formANb) {
        this.formANb = formANb;
    }

    public RgltryDocVrfctnInf withFormANb(String formANb) {
        this.formANb = formANb;
        return this;
    }

    @JsonProperty("formAPurpCd")
    public String getFormAPurpCd() {
        return formAPurpCd;
    }

    @JsonProperty("formAPurpCd")
    public void setFormAPurpCd(String formAPurpCd) {
        this.formAPurpCd = formAPurpCd;
    }

    public RgltryDocVrfctnInf withFormAPurpCd(String formAPurpCd) {
        this.formAPurpCd = formAPurpCd;
        return this;
    }

    @JsonProperty("CCIRltdInd")
    public String getCCIRltdInd() {
        return cCIRltdInd;
    }

    @JsonProperty("CCIRltdInd")
    public void setCCIRltdInd(String cCIRltdInd) {
        this.cCIRltdInd = cCIRltdInd;
    }

    public RgltryDocVrfctnInf withCCIRltdInd(String cCIRltdInd) {
        this.cCIRltdInd = cCIRltdInd;
        return this;
    }

    @JsonProperty("vldFxInd")
    public String getVldFxInd() {
        return vldFxInd;
    }

    @JsonProperty("vldFxInd")
    public void setVldFxInd(String vldFxInd) {
        this.vldFxInd = vldFxInd;
    }

    public RgltryDocVrfctnInf withVldFxInd(String vldFxInd) {
        this.vldFxInd = vldFxInd;
        return this;
    }

    @JsonProperty("docChckList")
    public List<DocChckList> getDocChckList() {
        return docChckList;
    }

    @JsonProperty("docChckList")
    public void setDocChckList(List<DocChckList> docChckList) {
        this.docChckList = docChckList;
    }

    public RgltryDocVrfctnInf withDocChckList(List<DocChckList> docChckList) {
        this.docChckList = docChckList;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RgltryDocVrfctnInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(fileCnt).append(fileNm).append(btchFileNm).append(a2FormNm).append(fEMADclrtnFormNm).append(filenetRef).append(purpGrpNm).append(invcTmpltNm).append(freeFrmtInvcDtls).append(bOPOverseaOrDmstInd).append(bOPUnitCd).append(bOPResdtCtryRgnNmCd).append(bOPBddGoodsInd).append(bOPPmtTerm).append(bOPNtrOfPmt).append(bOPTxCd1).append(bOPTxCd2).append(bOPAmt1).append(bOPCcy1).append(bOPAmt2).append(bOPCcy2).append(bOPTxRemarks1).append(bOPTxRemarks2).append(bOPCtrctNb).append(bOPInvcNb).append(bOPChinaSafeApprvdFilgNbRefNb).append(rMBDclrtnUnitCd).append(rMBDclrtnTtlAmt).append(rMBDclrtnBOPNrrtn).append(rMBDclrtnTradAmt).append(rMBDclrtnAdvncdPmtAmt).append(rMBDclrtnPctAmt).append(rMBDclrtnCstmClrcDays).append(rMBDclrtnCstmClrcBizUnit).append(rMBDclrtnBizUnitCd).append(rMBDclrtnCstmDclrtnCNY).append(rMBDclrtnCstmDclrtnFCY).append(rMBDclrtnGnlTradAmt).append(rMBDclrtnFeedgPrcgTradAmt).append(rMBDclrtnOthrTradAmt).append(rMBDclrtnFrntrTradAmt).append(rMBDclrtnInOutGoodsAmt).append(rMBDclrtnTrnstTradAmt).append(rMBDclrtnOthrAmt).append(rMBDclrtnSvcTradAmt).append(rMBDclrtnBOPTxCd1).append(rMBDclrtnBOPTxCd2).append(rMBDclrtnBOPTxCd3).append(rMBDclrtnBOPTxCd4).append(rMBDclrtnBOPTxCd5).append(rMBDclrtnBOPTxCd6).append(rMBDclrtnBOPTxCd7).append(rMBDclrtnInvstmtIncmAmt).append(rMBDclrtnApprvlCertNbDrctInvstmt).append(rMBDclrtnApprvlCertNb).append(rMBDclrtnCurTrfAmt).append(rMBDclrtnCptlAcctAmt).append(rMBDclrtnDrctInvstmtAmt).append(rMBDclrtnSctyInvstmtAmt).append(rMBDclrtnOthrInvstmtAmt).append(rMBDclrtnRemarks).append(rMBDclrtnInd).append(rMBDclrtnCtctNm).append(rMBDclrtnPhne).append(dgtlAuthntcnBllDt).append(dgtlAuthntcnPmtCd).append(dgtlAuthntcnBllTp).append(dgtlAuthntcnVchrNb).append(dgtlAuthntcnBypassInd).append(dgtlAuthntcnOvrrdRsn).append(dgtlAuthntcnVrfctnSts).append(formANb).append(formAPurpCd).append(cCIRltdInd).append(vldFxInd).append(docChckList).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RgltryDocVrfctnInf) == false) {
            return false;
        }
        RgltryDocVrfctnInf rhs = ((RgltryDocVrfctnInf) other);
        return new EqualsBuilder().append(fileCnt, rhs.fileCnt).append(fileNm, rhs.fileNm).append(btchFileNm, rhs.btchFileNm).append(a2FormNm, rhs.a2FormNm).append(fEMADclrtnFormNm, rhs.fEMADclrtnFormNm).append(filenetRef, rhs.filenetRef).append(purpGrpNm, rhs.purpGrpNm).append(invcTmpltNm, rhs.invcTmpltNm).append(freeFrmtInvcDtls, rhs.freeFrmtInvcDtls).append(bOPOverseaOrDmstInd, rhs.bOPOverseaOrDmstInd).append(bOPUnitCd, rhs.bOPUnitCd).append(bOPResdtCtryRgnNmCd, rhs.bOPResdtCtryRgnNmCd).append(bOPBddGoodsInd, rhs.bOPBddGoodsInd).append(bOPPmtTerm, rhs.bOPPmtTerm).append(bOPNtrOfPmt, rhs.bOPNtrOfPmt).append(bOPTxCd1, rhs.bOPTxCd1).append(bOPTxCd2, rhs.bOPTxCd2).append(bOPAmt1, rhs.bOPAmt1).append(bOPCcy1, rhs.bOPCcy1).append(bOPAmt2, rhs.bOPAmt2).append(bOPCcy2, rhs.bOPCcy2).append(bOPTxRemarks1, rhs.bOPTxRemarks1).append(bOPTxRemarks2, rhs.bOPTxRemarks2).append(bOPCtrctNb, rhs.bOPCtrctNb).append(bOPInvcNb, rhs.bOPInvcNb).append(bOPChinaSafeApprvdFilgNbRefNb, rhs.bOPChinaSafeApprvdFilgNbRefNb).append(rMBDclrtnUnitCd, rhs.rMBDclrtnUnitCd).append(rMBDclrtnTtlAmt, rhs.rMBDclrtnTtlAmt).append(rMBDclrtnBOPNrrtn, rhs.rMBDclrtnBOPNrrtn).append(rMBDclrtnTradAmt, rhs.rMBDclrtnTradAmt).append(rMBDclrtnAdvncdPmtAmt, rhs.rMBDclrtnAdvncdPmtAmt).append(rMBDclrtnPctAmt, rhs.rMBDclrtnPctAmt).append(rMBDclrtnCstmClrcDays, rhs.rMBDclrtnCstmClrcDays).append(rMBDclrtnCstmClrcBizUnit, rhs.rMBDclrtnCstmClrcBizUnit).append(rMBDclrtnBizUnitCd, rhs.rMBDclrtnBizUnitCd).append(rMBDclrtnCstmDclrtnCNY, rhs.rMBDclrtnCstmDclrtnCNY).append(rMBDclrtnCstmDclrtnFCY, rhs.rMBDclrtnCstmDclrtnFCY).append(rMBDclrtnGnlTradAmt, rhs.rMBDclrtnGnlTradAmt).append(rMBDclrtnFeedgPrcgTradAmt, rhs.rMBDclrtnFeedgPrcgTradAmt).append(rMBDclrtnOthrTradAmt, rhs.rMBDclrtnOthrTradAmt).append(rMBDclrtnFrntrTradAmt, rhs.rMBDclrtnFrntrTradAmt).append(rMBDclrtnInOutGoodsAmt, rhs.rMBDclrtnInOutGoodsAmt).append(rMBDclrtnTrnstTradAmt, rhs.rMBDclrtnTrnstTradAmt).append(rMBDclrtnOthrAmt, rhs.rMBDclrtnOthrAmt).append(rMBDclrtnSvcTradAmt, rhs.rMBDclrtnSvcTradAmt).append(rMBDclrtnBOPTxCd1, rhs.rMBDclrtnBOPTxCd1).append(rMBDclrtnBOPTxCd2, rhs.rMBDclrtnBOPTxCd2).append(rMBDclrtnBOPTxCd3, rhs.rMBDclrtnBOPTxCd3).append(rMBDclrtnBOPTxCd4, rhs.rMBDclrtnBOPTxCd4).append(rMBDclrtnBOPTxCd5, rhs.rMBDclrtnBOPTxCd5).append(rMBDclrtnBOPTxCd6, rhs.rMBDclrtnBOPTxCd6).append(rMBDclrtnBOPTxCd7, rhs.rMBDclrtnBOPTxCd7).append(rMBDclrtnInvstmtIncmAmt, rhs.rMBDclrtnInvstmtIncmAmt).append(rMBDclrtnApprvlCertNbDrctInvstmt, rhs.rMBDclrtnApprvlCertNbDrctInvstmt).append(rMBDclrtnApprvlCertNb, rhs.rMBDclrtnApprvlCertNb).append(rMBDclrtnCurTrfAmt, rhs.rMBDclrtnCurTrfAmt).append(rMBDclrtnCptlAcctAmt, rhs.rMBDclrtnCptlAcctAmt).append(rMBDclrtnDrctInvstmtAmt, rhs.rMBDclrtnDrctInvstmtAmt).append(rMBDclrtnSctyInvstmtAmt, rhs.rMBDclrtnSctyInvstmtAmt).append(rMBDclrtnOthrInvstmtAmt, rhs.rMBDclrtnOthrInvstmtAmt).append(rMBDclrtnRemarks, rhs.rMBDclrtnRemarks).append(rMBDclrtnInd, rhs.rMBDclrtnInd).append(rMBDclrtnCtctNm, rhs.rMBDclrtnCtctNm).append(rMBDclrtnPhne, rhs.rMBDclrtnPhne).append(dgtlAuthntcnBllDt, rhs.dgtlAuthntcnBllDt).append(dgtlAuthntcnPmtCd, rhs.dgtlAuthntcnPmtCd).append(dgtlAuthntcnBllTp, rhs.dgtlAuthntcnBllTp).append(dgtlAuthntcnVchrNb, rhs.dgtlAuthntcnVchrNb).append(dgtlAuthntcnBypassInd, rhs.dgtlAuthntcnBypassInd).append(dgtlAuthntcnOvrrdRsn, rhs.dgtlAuthntcnOvrrdRsn).append(dgtlAuthntcnVrfctnSts, rhs.dgtlAuthntcnVrfctnSts).append(formANb, rhs.formANb).append(formAPurpCd, rhs.formAPurpCd).append(cCIRltdInd, rhs.cCIRltdInd).append(vldFxInd, rhs.vldFxInd).append(docChckList, rhs.docChckList).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

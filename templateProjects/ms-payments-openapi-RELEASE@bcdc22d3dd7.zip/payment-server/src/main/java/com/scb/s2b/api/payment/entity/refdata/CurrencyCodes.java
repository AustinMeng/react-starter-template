package com.scb.s2b.api.payment.entity.refdata;


import com.scb.s2b.api.payment.entity.CurrencyCode;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class CurrencyCodes implements Serializable {

    private Set<CurrencyCode> currencyCodes = new HashSet<>();

    public boolean isValid(String currencyCode) {
        return currencyCodes.contains(CurrencyCode.of(currencyCode));
    }
}

package com.scb.s2b.api.payment.entity.refdata;

import com.scb.s2b.api.payment.entity.Country;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class CountryCodes implements Serializable {

    private Map<String, String> ctryByCurrency = new HashMap<>();

    public Country getCountry(String currencyCode) {
        if (ctryByCurrency.containsKey(currencyCode)) {
            return new Country(ctryByCurrency.get(currencyCode));
        }
        return null;
    }
}

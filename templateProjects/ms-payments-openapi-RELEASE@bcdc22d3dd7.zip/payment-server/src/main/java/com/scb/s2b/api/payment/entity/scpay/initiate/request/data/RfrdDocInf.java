
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tpCd",
    "tpPrtry",
    "tpIssr",
    "nb",
    "rltdDt",
    "lineDtls"
})
public class RfrdDocInf {

    @JsonProperty("tpCd")
    private String tpCd;
    @JsonProperty("tpPrtry")
    private String tpPrtry;
    @JsonProperty("tpIssr")
    private String tpIssr;
    @JsonProperty("nb")
    private String nb;
    @JsonProperty("rltdDt")
    private String rltdDt;
    @JsonProperty("lineDtls")
    private List<LineDtl> lineDtls = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tpCd")
    public String getTpCd() {
        return tpCd;
    }

    @JsonProperty("tpCd")
    public void setTpCd(String tpCd) {
        this.tpCd = tpCd;
    }

    public RfrdDocInf withTpCd(String tpCd) {
        this.tpCd = tpCd;
        return this;
    }

    @JsonProperty("tpPrtry")
    public String getTpPrtry() {
        return tpPrtry;
    }

    @JsonProperty("tpPrtry")
    public void setTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
    }

    public RfrdDocInf withTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
        return this;
    }

    @JsonProperty("tpIssr")
    public String getTpIssr() {
        return tpIssr;
    }

    @JsonProperty("tpIssr")
    public void setTpIssr(String tpIssr) {
        this.tpIssr = tpIssr;
    }

    public RfrdDocInf withTpIssr(String tpIssr) {
        this.tpIssr = tpIssr;
        return this;
    }

    @JsonProperty("nb")
    public String getNb() {
        return nb;
    }

    @JsonProperty("nb")
    public void setNb(String nb) {
        this.nb = nb;
    }

    public RfrdDocInf withNb(String nb) {
        this.nb = nb;
        return this;
    }

    @JsonProperty("rltdDt")
    public String getRltdDt() {
        return rltdDt;
    }

    @JsonProperty("rltdDt")
    public void setRltdDt(String rltdDt) {
        this.rltdDt = rltdDt;
    }

    public RfrdDocInf withRltdDt(String rltdDt) {
        this.rltdDt = rltdDt;
        return this;
    }

    @JsonProperty("lineDtls")
    public List<LineDtl> getLineDtls() {
        return lineDtls;
    }

    @JsonProperty("lineDtls")
    public void setLineDtls(List<LineDtl> lineDtls) {
        this.lineDtls = lineDtls;
    }

    public RfrdDocInf withLineDtls(List<LineDtl> lineDtls) {
        this.lineDtls = lineDtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RfrdDocInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tpCd).append(tpPrtry).append(tpIssr).append(nb).append(rltdDt).append(lineDtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RfrdDocInf) == false) {
            return false;
        }
        RfrdDocInf rhs = ((RfrdDocInf) other);
        return new EqualsBuilder().append(tpCd, rhs.tpCd).append(tpPrtry, rhs.tpPrtry).append(tpIssr, rhs.tpIssr).append(nb, rhs.nb).append(rltdDt, rhs.rltdDt).append(lineDtls, rhs.lineDtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

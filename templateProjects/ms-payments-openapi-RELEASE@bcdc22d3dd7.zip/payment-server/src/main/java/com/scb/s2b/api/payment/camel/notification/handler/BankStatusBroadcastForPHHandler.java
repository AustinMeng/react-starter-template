package com.scb.s2b.api.payment.camel.notification.handler;

import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_ID;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_SCP;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.SUCCESS_STATUS;

import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.scb.s2b.api.payment.camel.ZkProducerAdapter;
import com.scb.s2b.api.payment.camel.controller.CamelController;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.notification.data.NotificationData;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.util.Strings;

@Slf4j
public class BankStatusBroadcastForPHHandler extends AbstractSNMNotificationHandler implements
        SNMNotificationHandler {

    private final MaintenanceService maintenanceService;

    private final ZkProducerAdapter zkProducer;

    private final ScpayProperties scpayProperties;

    private final CamelController camelController;

    private volatile String prevBankStatusBroadcastForPHNotificationMsgId;

    private final Set<String> localSuspendedBicCodes = new HashSet<>();

    private final Set<String> localRevokedBicCodes = new HashSet<>();

    private final ReentrantLock lock = new ReentrantLock();

    private final String countryCodeForPH = "PH";

    public BankStatusBroadcastForPHHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        super(exceptionProcessor, messageMarshaller);
        this.maintenanceService = maintenanceService;
        this.zkProducer = zkProducer;
        this.scpayProperties = scpayProperties;
        this.camelController = camelController;
    }

    @PostConstruct
    public void initiateBankStatusBroadcastForPHHandler() {
        if (scpayProperties.getNotification().isEnabled()) {
            // register notification node on zk
            log.info("Notification is enabled, just initiate bank status ph broadcast handler.");
            handleEvent(null);
            log.info("Initiating bank status broadcast for ph handler has done.");
        }
    }

    @Override
    public List<EventCode> getCode() {
        return Collections.singletonList(EventCode.BANK_STATUS_BROADCAST_PH);
    }

    @Override
    public void handleNotification(Notification notification) {
        String messageId = notification.getHeader().getMessageId();
        log.info("Start to handler snm notification messageId={}", messageId);

        try {

            NotificationData notificationData = notification.getData();

            NotificationData.SignStatusType signOnType = notificationData.getSignOn();
            if (signOnType == null) {
                log.error("/data/sgnOn is empty");
                throw new RuntimeException("/data/sgnOn is empty");
            }

            String bicCode = notificationData.getBankSWIFTBIC();
            if (StringUtils.isBlank(bicCode)) {
                log.error("/data/bkSwiftBic is empty");
                throw new RuntimeException("/data/bkSwiftBic is empty");
            }

            NotificationData.AvailabilityType availability = notificationData.getAvailability();
            if (availability == null) {
                log.error("/data/avlbty is empty");
                throw new RuntimeException("/data/avlbty is empty");
            }

            String connectionIdentification = notificationData.getConnectionIdentification();
            if (StringUtils.isBlank(connectionIdentification)) {
                log.error("/data/cnnctnId is empty");
                throw new RuntimeException("/data/cnnctnId is empty");
            }

            String countryCode = Optional.ofNullable(notification.getHeader().getCountryCode())
                    .map(StringUtils::strip)
                    .map(Strings::toUpperCase)
                    .orElse(StringUtils.EMPTY);
            if (!countryCodeForPH.equalsIgnoreCase(countryCode)) {
                log.error("The country code {} is not allowed with event code 960.", countryCode);
                throw new Exception(
                        String.format("The country code %s is not allowed with event code 960.",
                                countryCode));
            }

            log.info(
                    "countryCode is {}, SignStatusType is {}, AvailabilityType is {}, bicCode is {} and connectionIdentification is {}"
                    , countryCode, signOnType, availability, bicCode, connectionIdentification);

            boolean needPublish = false;
            maintenanceService.refreshBankStatusBroadcastForPHSuspendedBicCodes();
            if (signOnType == NotificationData.SignStatusType.SIGN_ON
                    && availability == NotificationData.AvailabilityType.AVAILABLE) {
                // revoke Stop Payments for the Participant Bank BIC
                log.info("Revoke Stop Payments for the bic code {}.", bicCode);
                if (!maintenanceService.bankStatusBroadcastForPHSuspendedBicCodeExists() ||
                        !maintenanceService.getBankStatusBroadcastForPHRevokedBicCodes()
                                .contains(bicCode)) {
                    needPublish = true;
                }
                maintenanceService.removeBankStatusBroadcastForPHBicCode(bicCode, messageId);
            } else {
                // Stop Payments for the Participant Bank BIC
                log.info("Stop Payments for the bic code {}.", bicCode);
                if (!maintenanceService.bankStatusBroadcastForPHSuspendedBicCodeExists() ||
                        !maintenanceService.getBankStatusBroadcastForPHSuspendedBicCodes()
                                .contains(bicCode)) {
                    needPublish = true;
                }
                maintenanceService.addBankStatusBroadcastForPHBicCode(bicCode, messageId);
            }
            notification.getHeader().setResponseStatus(SUCCESS_STATUS);
            notification.getHeader().setChannelId(CHANNEL_ID);
            notification.getHeader().setDestination(CHANNEL_SCP);
            notification.getHeader().setProcessingDate(LocalDateTime.now());
            if (needPublish) {
                log.info("publish bank status broadcast for ph notification with messageId={}.",
                        messageId);
                zkProducer.publishBankStatusBroadcastForPHNotification(messageId);
            }
        } catch (Exception e) {
            log.error("Failed to handle bank status ph broadcast notification {}",
                    notification.getHeader().getTransactionReference(), e);
            throw new RuntimeException(e);
        }

    }

    @Override
    public void handleEvent(String messageId) {
        if (StringUtils.isNotEmpty(messageId) && StringUtils
                .equals(messageId, prevBankStatusBroadcastForPHNotificationMsgId)) {
            log.info(
                    "messageId={} has not been updated, skip refreshing bank default broadcast route.",
                    messageId);
            return;
        }
        log.info("Refreshing Bank Status Broadcast for PH route for messageId={}", messageId);
        refreshRouteStatus(false);
        log.info("Updating prevBankStatusBroadcastForPHNotificationMsgId={}", messageId);
        prevBankStatusBroadcastForPHNotificationMsgId = messageId;
    }

    @Override
    public void refreshRouteStatus(boolean daemon) {
        log.info("Starting to refresh bank status ph broadcast route status for daemon={}", daemon);
        maintenanceService.refreshBankStatusBroadcastForPHSuspendedBicCodes();
        boolean isLockAcquired;

        if (!daemon) {
            lock.lock();
        } else {
            isLockAcquired = lock.tryLock();

            if (!isLockAcquired) {
                log.info(
                        "Daemon task failed to acquire the lock for refreshing bank status ph broadcast route status, try on the next round.");
                return;
            }
        }

        try {
            if (daemon) {
                localSuspendedBicCodes.clear();
                localRevokedBicCodes.clear();
            }
            Set<String> bankStatusBroadcastForPHSuspendedBicCodes = maintenanceService
                    .getBankStatusBroadcastForPHSuspendedBicCodes();
            SetView<String> diffSuspendedBicCodes = Sets
                    .difference(bankStatusBroadcastForPHSuspendedBicCodes, localSuspendedBicCodes);
            if (diffSuspendedBicCodes.size() > 0) {
                log.info("{} changed bic codes found for updating suspended route status",
                        diffSuspendedBicCodes.size());
            }
            diffSuspendedBicCodes.forEach(bicCode -> {
                String endpoint = String
                        .format(scpayProperties.getNotification().getBankStatusBroadcastPH()
                                        .getSuspendQueueTemplate(),
                                bicCode);
                String routeId = String
                        .format(scpayProperties.getNotification().getBankStatusBroadcastPH()
                                        .getSuspendRouteIdTemplate(),
                                bicCode);
                int maxAttempts = scpayProperties.getNotification().getBankStatusBroadcastPH()
                        .getMaxAttempts();
                try {
                    log.info("add or suspend route for endpoint={}, routeId={}, code={}", endpoint,
                            routeId, bicCode);
                    camelController.addOrSuspendRoute(routeId, maxAttempts,
                            this.suspendedRouteBuilder(endpoint, routeId));
                    localSuspendedBicCodes.add(bicCode);
                    localRevokedBicCodes.remove(bicCode);
                } catch (Exception e) {
                    log.error("Failed to suspend endpoint={}", endpoint, e);
                }
            });
            Set<String> bankStatusBroadcastForPHRevokedBicCodes = maintenanceService
                    .getBankStatusBroadcastForPHRevokedBicCodes();
            SetView<String> diffRevokedBicCodes = Sets
                    .difference(bankStatusBroadcastForPHRevokedBicCodes, localRevokedBicCodes);
            if (diffRevokedBicCodes.size() > 0) {
                log.info("{} bic codes found for updating revoked route status",
                        diffRevokedBicCodes.size());
            }
            diffRevokedBicCodes.forEach(bicCode -> {
                String endpoint = String.format(
                        scpayProperties.getNotification().getBankStatusBroadcastPH()
                                .getSuspendQueueTemplate(),
                        bicCode);
                String routeId = String
                        .format(scpayProperties.getNotification().getBankStatusBroadcastPH()
                                        .getSuspendRouteIdTemplate(),
                                bicCode);
                int maxAttempts = scpayProperties.getNotification().getBankStatusBroadcastPH()
                        .getMaxAttempts();
                try {
                    log.info("try to revoke route for endpoint={}, routeId={}, bicCode={}",
                            endpoint, routeId, bicCode);
                    camelController.addOrResumeRoute(routeId, maxAttempts,
                            this.revokedRouteBuilder(endpoint, routeId));
                    localRevokedBicCodes.add(bicCode);
                    localSuspendedBicCodes.remove(bicCode);
                } catch (Exception e) {
                    log.error("Failed to revoke endpoint={}", endpoint, e);
                }
            });
        } finally {
            lock.unlock();
        }
    }
}

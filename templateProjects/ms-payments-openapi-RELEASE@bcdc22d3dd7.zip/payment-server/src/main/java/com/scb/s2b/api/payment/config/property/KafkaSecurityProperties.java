package com.scb.s2b.api.payment.config.property;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString(exclude = {"keystorePassword", "truststorePassword", "keyPassword"})
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class KafkaSecurityProperties {
    private String securityProtocol;
    private String keystore;
    private String keystorePassword;
    private String truststore;
    private String truststorePassword;
    private String keyPassword;
    private String endpointAlgorithm;
}

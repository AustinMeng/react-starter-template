package com.scb.s2b.api.payment.api.provider;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializer;
import java.time.Instant;
import java.time.format.DateTimeFormatterBuilder;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

@Provider
public class JacksonObjectMapperProvider implements ContextResolver<ObjectMapper> {

    final ObjectMapper objectMapper;

    public JacksonObjectMapperProvider() {
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        JodaModule jodaModule = new JodaModule();
        javaTimeModule.addSerializer(Instant.class, new InstantSerializerWithMilliSecondPrecision());
        this.objectMapper = new ObjectMapper()
                .registerModules(javaTimeModule, jodaModule)
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    @Override
    public ObjectMapper getContext(Class<?> aClass) {
        return this.objectMapper;
    }

    static class InstantSerializerWithMilliSecondPrecision extends InstantSerializer {
        InstantSerializerWithMilliSecondPrecision() {
            super(InstantSerializer.INSTANCE, false, (new DateTimeFormatterBuilder()).appendInstant(3).toFormatter());
        }
    }
}

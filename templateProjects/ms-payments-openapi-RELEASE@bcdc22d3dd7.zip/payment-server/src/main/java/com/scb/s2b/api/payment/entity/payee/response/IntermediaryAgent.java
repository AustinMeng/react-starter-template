package com.scb.s2b.api.payment.entity.payee.response;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class IntermediaryAgent {
    private IntermediaryAgentFinancialInstitution financialInstitution;
}

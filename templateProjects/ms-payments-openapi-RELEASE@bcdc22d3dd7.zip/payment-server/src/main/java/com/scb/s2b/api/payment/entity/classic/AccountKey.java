package com.scb.s2b.api.payment.entity.classic;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
public class AccountKey {

    private String accountId;

    private String currencyCode;

    private String bankCode;
}

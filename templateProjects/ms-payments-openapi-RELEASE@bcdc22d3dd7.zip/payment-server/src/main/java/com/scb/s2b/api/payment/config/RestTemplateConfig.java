package com.scb.s2b.api.payment.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.scb.channels.foundation.commons.shared.rest.RestTemplateFactory;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

public class RestTemplateConfig {

    @Value("${security.masterKeystore}")
    private String masterKeystore;

    @Value("${security.masterKeystorePassword}")
    private String masterKeystorePassword;

    @Bean
    @Profile("!test")
    public RestTemplate restTemplate() {
        RestTemplate restTemplate;
        try {
            restTemplate = RestTemplateFactory.restTemplate(masterKeystore, masterKeystorePassword);
        } catch (CertificateException | UnrecoverableKeyException | NoSuchAlgorithmException
                | KeyStoreException | KeyManagementException | IOException e) {
            restTemplate = RestTemplateFactory.getUnsafeInstance();
        }
        if (restTemplate != null) {
            restTemplate.getMessageConverters().add(0, createMappingJacksonHttpMessageConverter());
        }
        return restTemplate;
    }

    private MappingJackson2HttpMessageConverter createMappingJacksonHttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(this.createObjectMapper());
        return converter;
    }

    private ObjectMapper createObjectMapper() {
        return new ObjectMapper()
                .configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .registerModule(new JavaTimeModule());
    }
}

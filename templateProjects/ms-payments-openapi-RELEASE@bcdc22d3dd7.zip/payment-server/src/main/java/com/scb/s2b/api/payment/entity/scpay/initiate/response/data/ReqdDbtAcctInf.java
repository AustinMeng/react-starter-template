
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "acctId",
    "ccy",
    "ntrOfAcct"
})
public class ReqdDbtAcctInf {

    @JsonProperty("acctId")
    private String acctId;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("ntrOfAcct")
    private String ntrOfAcct;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("acctId")
    public String getAcctId() {
        return acctId;
    }

    @JsonProperty("acctId")
    public void setAcctId(String acctId) {
        this.acctId = acctId;
    }

    public ReqdDbtAcctInf withAcctId(String acctId) {
        this.acctId = acctId;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public ReqdDbtAcctInf withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("ntrOfAcct")
    public String getNtrOfAcct() {
        return ntrOfAcct;
    }

    @JsonProperty("ntrOfAcct")
    public void setNtrOfAcct(String ntrOfAcct) {
        this.ntrOfAcct = ntrOfAcct;
    }

    public ReqdDbtAcctInf withNtrOfAcct(String ntrOfAcct) {
        this.ntrOfAcct = ntrOfAcct;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ReqdDbtAcctInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(acctId).append(ccy).append(ntrOfAcct).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ReqdDbtAcctInf) == false) {
            return false;
        }
        ReqdDbtAcctInf rhs = ((ReqdDbtAcctInf) other);
        return new EqualsBuilder().append(acctId, rhs.acctId).append(ccy, rhs.ccy).append(ntrOfAcct, rhs.ntrOfAcct).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

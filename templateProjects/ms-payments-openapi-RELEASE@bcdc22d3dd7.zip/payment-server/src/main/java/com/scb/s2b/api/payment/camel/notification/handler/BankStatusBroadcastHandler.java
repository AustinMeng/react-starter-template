package com.scb.s2b.api.payment.camel.notification.handler;

import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_ID;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_SCP;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.SUCCESS_STATUS;

import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.scb.s2b.api.payment.camel.ZkProducerAdapter;
import com.scb.s2b.api.payment.camel.controller.CamelController;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.notification.data.NotificationData.AvailabilityType;
import com.scb.s2b.api.payment.entity.scpay.notification.data.NotificationData.SignStatusType;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class BankStatusBroadcastHandler extends AbstractSNMNotificationHandler implements SNMNotificationHandler {

    private final MaintenanceService maintenanceService;

    private final ZkProducerAdapter zkProducer;

    private final ScpayProperties scpayProperties;

    private final CamelController camelController;

    private volatile String prevBankStatusBroadcastNotificationMsgId;

    private final Set<String> localSuspendedBicCodes = new HashSet<>();

    private final Set<String> localRevokedBicCodes = new HashSet<>();

    private final ReentrantLock lock = new ReentrantLock();

    public BankStatusBroadcastHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        super(exceptionProcessor, messageMarshaller);
        this.maintenanceService = maintenanceService;
        this.zkProducer = zkProducer;
        this.scpayProperties = scpayProperties;
        this.camelController = camelController;
    }

    @PostConstruct
    public void initiateBankStatusBroadcastHandler() {
        if (scpayProperties.getNotification().isEnabled()) {
            // register notification node on zk
            log.info("Notification is enabled, just initiate bank status broadcast handler.");
            handleEvent(null);
            log.info("Initiating bank status broadcast handler has done.");
        }
    }

    @Override
    public List<EventCode> getCode() {
        return Collections.singletonList(EventCode.BANK_STATUS_BROADCAST);
    }

    @Override
    public void handleNotification(Notification notification) {
        String messageId = notification.getHeader().getMessageId();
        log.info("Start to handler snm notification messageId={}", messageId);
        try {
            SignStatusType signOnType = notification.getData().getSignOn();
            AvailabilityType availability = notification.getData().getAvailability();

            if (signOnType == null) {
                log.error("/data/sgnOn is empty");
                throw new RuntimeException("/data/sgnOn is empty");
            }

            if (availability == null) {
                log.error("/data/avlbty is empty");
                throw new RuntimeException("/data/sgnOn is empty");
            }

            String bicCode = notification.getData().getBankSWIFTBIC();
            if (bicCode == null) {
                log.error("/data/bkSwiftBic is empty");
                throw new RuntimeException("/data/bkSwiftBic is empty");
            }

            log.info("SignStatusType is {}, AvailabilityType is {} and bicCode is {}", signOnType, availability,
                    bicCode);
            boolean needPublish = false;
            maintenanceService.refreshBankStatusBroadcastSuspendedBicCodes();
            if (signOnType == SignStatusType.SIGN_ON && availability == AvailabilityType.AVAILABLE) {
                // revoke Stop Payments for the Participant Bank BIC
                log.info("Revoke Stop Payments for the bic code {}.", bicCode);
                if (!maintenanceService.bankStatusBroadcastSuspendedBicCodeExists() ||
                        !maintenanceService.getBankStatusBroadcastRevokedBicCodes().contains(bicCode)) {
                    needPublish = true;
                }
                maintenanceService.removeBankStatusBroadcastBicCode(bicCode, messageId);
            } else {
                // Stop Payments for the Participant Bank BIC
                log.info("Stop Payments for the bic code {}.", bicCode);
                if (!maintenanceService.bankStatusBroadcastSuspendedBicCodeExists() ||
                        !maintenanceService.getBankStatusBroadcastSuspendedBicCodes().contains(bicCode)) {
                    needPublish = true;
                }
                maintenanceService.addBankStatusBroadcastBicCode(bicCode, messageId);
            }
            notification.getHeader().setResponseStatus(SUCCESS_STATUS);
            notification.getHeader().setChannelId(CHANNEL_ID);
            notification.getHeader().setDestination(CHANNEL_SCP);
            notification.getHeader().setProcessingDate(LocalDateTime.now());
            if (needPublish) {
                log.info("publish bank status broadcast notification with messageId={}.", messageId);
                zkProducer.publishBankStatusBroadcastNotification(messageId);
            }
        } catch (Exception e) {
            log.error("Failed to handle bank status broadcast notification {}",
                    notification.getHeader().getTransactionReference(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void handleEvent(String messageId) {
        if (StringUtils.isNotEmpty(messageId) && StringUtils
                .equals(messageId, prevBankStatusBroadcastNotificationMsgId)) {
            log.info("messageId={} has not been updated, skip refreshing bank status broadcast route.", messageId);
            return;
        }
        log.info("Refreshing Bank Status Broadcast route for messageId={}", messageId);
        refreshRouteStatus(false);
        log.info("Updating prevBankStatusBroadcastNotificationMsgId={}", messageId);
        prevBankStatusBroadcastNotificationMsgId = messageId;
    }

    @Override
    public void refreshRouteStatus(boolean daemon) {
        log.info("Starting to refresh bank status broadcast route status for daemon={}", daemon);
        maintenanceService.refreshBankStatusBroadcastSuspendedBicCodes();
        boolean isLockAcquired;

        if (!daemon) {
            lock.lock();
        } else {
            isLockAcquired = lock.tryLock();

            if (!isLockAcquired) {
                log.info("Daemon task failed to acquire the lock for refreshing bank status broadcast route status, try on the next round.");
                return;
            }
        }

        try {
            if (daemon) {
                localSuspendedBicCodes.clear();
                localRevokedBicCodes.clear();
            }
            Set<String> bankStatusBroadcastSuspendedBicCodes = maintenanceService.getBankStatusBroadcastSuspendedBicCodes();
            SetView<String> diffSuspendedBicCodes = Sets
                    .difference(bankStatusBroadcastSuspendedBicCodes, localSuspendedBicCodes);
            if (diffSuspendedBicCodes.size() > 0) {
                log.info("{} changed bic codes found for updating suspended route status", diffSuspendedBicCodes.size());
            }
            diffSuspendedBicCodes.forEach(bicCode -> {
                String endpoint = String.format(
                        scpayProperties.getNotification().getBankStatusBroadcast().getSuspendQueueTemplate(),
                        bicCode);
                String routeId = String
                        .format(scpayProperties.getNotification().getBankStatusBroadcast().getSuspendRouteIdTemplate(),
                                bicCode);
                int maxAttempts = scpayProperties.getNotification().getBankStatusBroadcast().getMaxAttempts();
                try {
                    log.info("add or suspend route for endpoint={}, routeId={}, bicCode={}", endpoint, routeId, bicCode);
                    camelController.addOrSuspendRoute(routeId, maxAttempts, this.suspendedRouteBuilder(endpoint, routeId));
                    localSuspendedBicCodes.add(bicCode);
                    localRevokedBicCodes.remove(bicCode);
                } catch (Exception e) {
                    log.error("Failed to suspend endpoint={}", endpoint, e);
                }
            });
            Set<String> bankStatusBroadcastRevokedBicCodes = maintenanceService.getBankStatusBroadcastRevokedBicCodes();
            SetView<String> diffRevokedBicCodes = Sets
                    .difference(bankStatusBroadcastRevokedBicCodes, localRevokedBicCodes);
            if (diffRevokedBicCodes.size() > 0) {
                log.info("{} bic codes found for updating suspended route status", diffRevokedBicCodes.size());
            }
            diffRevokedBicCodes.forEach(bicCode -> {
                String endpoint = String
                        .format(scpayProperties.getNotification().getBankStatusBroadcast().getSuspendQueueTemplate(),
                                bicCode);
                String routeId = String
                        .format(scpayProperties.getNotification().getBankStatusBroadcast().getSuspendRouteIdTemplate(),
                                bicCode);
                int maxAttempts = scpayProperties.getNotification().getBankStatusBroadcast().getMaxAttempts();
                try {
                    log.info("add or revoke route for endpoint={}, routeId={}, bicCode={}", endpoint, routeId, bicCode);
                    camelController.addOrResumeRoute(routeId, maxAttempts, this.revokedRouteBuilder(endpoint, routeId));
                    localRevokedBicCodes.add(bicCode);
                    localSuspendedBicCodes.remove(bicCode);
                } catch (Exception e) {
                    log.error("Failed to revoke endpoint={}", endpoint, e);
                }
            });
        } finally {
            lock.unlock();
        }
    }
}

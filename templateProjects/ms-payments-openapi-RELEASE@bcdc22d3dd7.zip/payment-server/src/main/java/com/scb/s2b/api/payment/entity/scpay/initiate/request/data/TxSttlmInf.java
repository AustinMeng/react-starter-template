
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sttlmMtd",
    "sttlmAcct",
    "instgRmbrsmntAgt",
    "instgRmbrsmntAgtAcct",
    "instdRmbrsmntAgt",
    "instdRmbrsmntAgtAcct",
    "thrdRmbrsmntAgt",
    "thrdRmbrsmntAgtAcct"
})
public class TxSttlmInf {

    @JsonProperty("sttlmMtd")
    private String sttlmMtd;
    @JsonProperty("sttlmAcct")
    private SttlmAcct sttlmAcct;
    @JsonProperty("instgRmbrsmntAgt")
    private InstgRmbrsmntAgt instgRmbrsmntAgt;
    @JsonProperty("instgRmbrsmntAgtAcct")
    private InstgRmbrsmntAgtAcct instgRmbrsmntAgtAcct;
    @JsonProperty("instdRmbrsmntAgt")
    private InstdRmbrsmntAgt instdRmbrsmntAgt;
    @JsonProperty("instdRmbrsmntAgtAcct")
    private InstdRmbrsmntAgtAcct instdRmbrsmntAgtAcct;
    @JsonProperty("thrdRmbrsmntAgt")
    private ThrdRmbrsmntAgt thrdRmbrsmntAgt;
    @JsonProperty("thrdRmbrsmntAgtAcct")
    private ThrdRmbrsmntAgtAcct thrdRmbrsmntAgtAcct;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("sttlmMtd")
    public String getSttlmMtd() {
        return sttlmMtd;
    }

    @JsonProperty("sttlmMtd")
    public void setSttlmMtd(String sttlmMtd) {
        this.sttlmMtd = sttlmMtd;
    }

    public TxSttlmInf withSttlmMtd(String sttlmMtd) {
        this.sttlmMtd = sttlmMtd;
        return this;
    }

    @JsonProperty("sttlmAcct")
    public SttlmAcct getSttlmAcct() {
        return sttlmAcct;
    }

    @JsonProperty("sttlmAcct")
    public void setSttlmAcct(SttlmAcct sttlmAcct) {
        this.sttlmAcct = sttlmAcct;
    }

    public TxSttlmInf withSttlmAcct(SttlmAcct sttlmAcct) {
        this.sttlmAcct = sttlmAcct;
        return this;
    }

    @JsonProperty("instgRmbrsmntAgt")
    public InstgRmbrsmntAgt getInstgRmbrsmntAgt() {
        return instgRmbrsmntAgt;
    }

    @JsonProperty("instgRmbrsmntAgt")
    public void setInstgRmbrsmntAgt(InstgRmbrsmntAgt instgRmbrsmntAgt) {
        this.instgRmbrsmntAgt = instgRmbrsmntAgt;
    }

    public TxSttlmInf withInstgRmbrsmntAgt(InstgRmbrsmntAgt instgRmbrsmntAgt) {
        this.instgRmbrsmntAgt = instgRmbrsmntAgt;
        return this;
    }

    @JsonProperty("instgRmbrsmntAgtAcct")
    public InstgRmbrsmntAgtAcct getInstgRmbrsmntAgtAcct() {
        return instgRmbrsmntAgtAcct;
    }

    @JsonProperty("instgRmbrsmntAgtAcct")
    public void setInstgRmbrsmntAgtAcct(InstgRmbrsmntAgtAcct instgRmbrsmntAgtAcct) {
        this.instgRmbrsmntAgtAcct = instgRmbrsmntAgtAcct;
    }

    public TxSttlmInf withInstgRmbrsmntAgtAcct(InstgRmbrsmntAgtAcct instgRmbrsmntAgtAcct) {
        this.instgRmbrsmntAgtAcct = instgRmbrsmntAgtAcct;
        return this;
    }

    @JsonProperty("instdRmbrsmntAgt")
    public InstdRmbrsmntAgt getInstdRmbrsmntAgt() {
        return instdRmbrsmntAgt;
    }

    @JsonProperty("instdRmbrsmntAgt")
    public void setInstdRmbrsmntAgt(InstdRmbrsmntAgt instdRmbrsmntAgt) {
        this.instdRmbrsmntAgt = instdRmbrsmntAgt;
    }

    public TxSttlmInf withInstdRmbrsmntAgt(InstdRmbrsmntAgt instdRmbrsmntAgt) {
        this.instdRmbrsmntAgt = instdRmbrsmntAgt;
        return this;
    }

    @JsonProperty("instdRmbrsmntAgtAcct")
    public InstdRmbrsmntAgtAcct getInstdRmbrsmntAgtAcct() {
        return instdRmbrsmntAgtAcct;
    }

    @JsonProperty("instdRmbrsmntAgtAcct")
    public void setInstdRmbrsmntAgtAcct(InstdRmbrsmntAgtAcct instdRmbrsmntAgtAcct) {
        this.instdRmbrsmntAgtAcct = instdRmbrsmntAgtAcct;
    }

    public TxSttlmInf withInstdRmbrsmntAgtAcct(InstdRmbrsmntAgtAcct instdRmbrsmntAgtAcct) {
        this.instdRmbrsmntAgtAcct = instdRmbrsmntAgtAcct;
        return this;
    }

    @JsonProperty("thrdRmbrsmntAgt")
    public ThrdRmbrsmntAgt getThrdRmbrsmntAgt() {
        return thrdRmbrsmntAgt;
    }

    @JsonProperty("thrdRmbrsmntAgt")
    public void setThrdRmbrsmntAgt(ThrdRmbrsmntAgt thrdRmbrsmntAgt) {
        this.thrdRmbrsmntAgt = thrdRmbrsmntAgt;
    }

    public TxSttlmInf withThrdRmbrsmntAgt(ThrdRmbrsmntAgt thrdRmbrsmntAgt) {
        this.thrdRmbrsmntAgt = thrdRmbrsmntAgt;
        return this;
    }

    @JsonProperty("thrdRmbrsmntAgtAcct")
    public ThrdRmbrsmntAgtAcct getThrdRmbrsmntAgtAcct() {
        return thrdRmbrsmntAgtAcct;
    }

    @JsonProperty("thrdRmbrsmntAgtAcct")
    public void setThrdRmbrsmntAgtAcct(ThrdRmbrsmntAgtAcct thrdRmbrsmntAgtAcct) {
        this.thrdRmbrsmntAgtAcct = thrdRmbrsmntAgtAcct;
    }

    public TxSttlmInf withThrdRmbrsmntAgtAcct(ThrdRmbrsmntAgtAcct thrdRmbrsmntAgtAcct) {
        this.thrdRmbrsmntAgtAcct = thrdRmbrsmntAgtAcct;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public TxSttlmInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sttlmMtd).append(sttlmAcct).append(instgRmbrsmntAgt).append(instgRmbrsmntAgtAcct).append(instdRmbrsmntAgt).append(instdRmbrsmntAgtAcct).append(thrdRmbrsmntAgt).append(thrdRmbrsmntAgtAcct).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TxSttlmInf) == false) {
            return false;
        }
        TxSttlmInf rhs = ((TxSttlmInf) other);
        return new EqualsBuilder().append(sttlmMtd, rhs.sttlmMtd).append(sttlmAcct, rhs.sttlmAcct).append(instgRmbrsmntAgt, rhs.instgRmbrsmntAgt).append(instgRmbrsmntAgtAcct, rhs.instgRmbrsmntAgtAcct).append(instdRmbrsmntAgt, rhs.instdRmbrsmntAgt).append(instdRmbrsmntAgtAcct, rhs.instdRmbrsmntAgtAcct).append(thrdRmbrsmntAgt, rhs.thrdRmbrsmntAgt).append(thrdRmbrsmntAgtAcct, rhs.thrdRmbrsmntAgtAcct).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

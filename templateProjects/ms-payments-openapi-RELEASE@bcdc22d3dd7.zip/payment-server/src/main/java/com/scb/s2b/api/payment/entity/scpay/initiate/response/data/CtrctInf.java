
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "rate",
    "amt",
    "amtCcy",
    "dealrNm",
    "mtrtyDt"
})
public class CtrctInf {

    @JsonProperty("id")
    private String id;
    @JsonProperty("rate")
    private String rate;
    @JsonProperty("amt")
    private String amt;
    @JsonProperty("amtCcy")
    private String amtCcy;
    @JsonProperty("dealrNm")
    private String dealrNm;
    @JsonProperty("mtrtyDt")
    private String mtrtyDt;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public CtrctInf withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("rate")
    public String getRate() {
        return rate;
    }

    @JsonProperty("rate")
    public void setRate(String rate) {
        this.rate = rate;
    }

    public CtrctInf withRate(String rate) {
        this.rate = rate;
        return this;
    }

    @JsonProperty("amt")
    public String getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(String amt) {
        this.amt = amt;
    }

    public CtrctInf withAmt(String amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("amtCcy")
    public String getAmtCcy() {
        return amtCcy;
    }

    @JsonProperty("amtCcy")
    public void setAmtCcy(String amtCcy) {
        this.amtCcy = amtCcy;
    }

    public CtrctInf withAmtCcy(String amtCcy) {
        this.amtCcy = amtCcy;
        return this;
    }

    @JsonProperty("dealrNm")
    public String getDealrNm() {
        return dealrNm;
    }

    @JsonProperty("dealrNm")
    public void setDealrNm(String dealrNm) {
        this.dealrNm = dealrNm;
    }

    public CtrctInf withDealrNm(String dealrNm) {
        this.dealrNm = dealrNm;
        return this;
    }

    @JsonProperty("mtrtyDt")
    public String getMtrtyDt() {
        return mtrtyDt;
    }

    @JsonProperty("mtrtyDt")
    public void setMtrtyDt(String mtrtyDt) {
        this.mtrtyDt = mtrtyDt;
    }

    public CtrctInf withMtrtyDt(String mtrtyDt) {
        this.mtrtyDt = mtrtyDt;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CtrctInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(id).append(rate).append(amt).append(amtCcy).append(dealrNm).append(mtrtyDt).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CtrctInf) == false) {
            return false;
        }
        CtrctInf rhs = ((CtrctInf) other);
        return new EqualsBuilder().append(id, rhs.id).append(rate, rhs.rate).append(amt, rhs.amt).append(amtCcy, rhs.amtCcy).append(dealrNm, rhs.dealrNm).append(mtrtyDt, rhs.mtrtyDt).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

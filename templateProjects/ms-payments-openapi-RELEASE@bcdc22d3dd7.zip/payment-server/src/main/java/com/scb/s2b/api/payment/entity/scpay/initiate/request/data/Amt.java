
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instdAmt",
    "instdCcy",
    "baseCcy",
    "dbtAmt",
    "dbtAmtBaseCcyEqvt",
    "cdtAmt",
    "cdtCcy",
    "dscntAmt",
    "dscntAmtCcy",
    "VATAmt",
    "VATAmtCcy",
    "cdtAmtBaseCcyEqvt",
    "prtyInd",
    "ttlIntrBkSttlmAmt",
    "ttlIntrBkSttlmAmtCcy",
    "intrBkSttlmAmt",
    "intrBkSttlmAmtCcy",
    "VATTp",
    "dscntTp"
})
public class Amt {

    @JsonProperty("instdAmt")
    private String instdAmt;
    @JsonProperty("instdCcy")
    private String instdCcy;
    @JsonProperty("baseCcy")
    private String baseCcy;
    @JsonProperty("dbtAmt")
    private String dbtAmt;
    @JsonProperty("dbtAmtBaseCcyEqvt")
    private String dbtAmtBaseCcyEqvt;
    @JsonProperty("cdtAmt")
    private String cdtAmt;
    @JsonProperty("cdtCcy")
    private String cdtCcy;
    @JsonProperty("dscntAmt")
    private String dscntAmt;
    @JsonProperty("dscntAmtCcy")
    private String dscntAmtCcy;
    @JsonProperty("VATAmt")
    private String vATAmt;
    @JsonProperty("VATAmtCcy")
    private String vATAmtCcy;
    @JsonProperty("cdtAmtBaseCcyEqvt")
    private String cdtAmtBaseCcyEqvt;
    @JsonProperty("prtyInd")
    private String prtyInd;
    @JsonProperty("ttlIntrBkSttlmAmt")
    private String ttlIntrBkSttlmAmt;
    @JsonProperty("ttlIntrBkSttlmAmtCcy")
    private String ttlIntrBkSttlmAmtCcy;
    @JsonProperty("intrBkSttlmAmt")
    private String intrBkSttlmAmt;
    @JsonProperty("intrBkSttlmAmtCcy")
    private String intrBkSttlmAmtCcy;
    @JsonProperty("VATTp")
    private String vATTp;
    @JsonProperty("dscntTp")
    private String dscntTp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instdAmt")
    public String getInstdAmt() {
        return instdAmt;
    }

    @JsonProperty("instdAmt")
    public void setInstdAmt(String instdAmt) {
        this.instdAmt = instdAmt;
    }

    public Amt withInstdAmt(String instdAmt) {
        this.instdAmt = instdAmt;
        return this;
    }

    @JsonProperty("instdCcy")
    public String getInstdCcy() {
        return instdCcy;
    }

    @JsonProperty("instdCcy")
    public void setInstdCcy(String instdCcy) {
        this.instdCcy = instdCcy;
    }

    public Amt withInstdCcy(String instdCcy) {
        this.instdCcy = instdCcy;
        return this;
    }

    @JsonProperty("baseCcy")
    public String getBaseCcy() {
        return baseCcy;
    }

    @JsonProperty("baseCcy")
    public void setBaseCcy(String baseCcy) {
        this.baseCcy = baseCcy;
    }

    public Amt withBaseCcy(String baseCcy) {
        this.baseCcy = baseCcy;
        return this;
    }

    @JsonProperty("dbtAmt")
    public String getDbtAmt() {
        return dbtAmt;
    }

    @JsonProperty("dbtAmt")
    public void setDbtAmt(String dbtAmt) {
        this.dbtAmt = dbtAmt;
    }

    public Amt withDbtAmt(String dbtAmt) {
        this.dbtAmt = dbtAmt;
        return this;
    }

    @JsonProperty("dbtAmtBaseCcyEqvt")
    public String getDbtAmtBaseCcyEqvt() {
        return dbtAmtBaseCcyEqvt;
    }

    @JsonProperty("dbtAmtBaseCcyEqvt")
    public void setDbtAmtBaseCcyEqvt(String dbtAmtBaseCcyEqvt) {
        this.dbtAmtBaseCcyEqvt = dbtAmtBaseCcyEqvt;
    }

    public Amt withDbtAmtBaseCcyEqvt(String dbtAmtBaseCcyEqvt) {
        this.dbtAmtBaseCcyEqvt = dbtAmtBaseCcyEqvt;
        return this;
    }

    @JsonProperty("cdtAmt")
    public String getCdtAmt() {
        return cdtAmt;
    }

    @JsonProperty("cdtAmt")
    public void setCdtAmt(String cdtAmt) {
        this.cdtAmt = cdtAmt;
    }

    public Amt withCdtAmt(String cdtAmt) {
        this.cdtAmt = cdtAmt;
        return this;
    }

    @JsonProperty("cdtCcy")
    public String getCdtCcy() {
        return cdtCcy;
    }

    @JsonProperty("cdtCcy")
    public void setCdtCcy(String cdtCcy) {
        this.cdtCcy = cdtCcy;
    }

    public Amt withCdtCcy(String cdtCcy) {
        this.cdtCcy = cdtCcy;
        return this;
    }

    @JsonProperty("dscntAmt")
    public String getDscntAmt() {
        return dscntAmt;
    }

    @JsonProperty("dscntAmt")
    public void setDscntAmt(String dscntAmt) {
        this.dscntAmt = dscntAmt;
    }

    public Amt withDscntAmt(String dscntAmt) {
        this.dscntAmt = dscntAmt;
        return this;
    }

    @JsonProperty("dscntAmtCcy")
    public String getDscntAmtCcy() {
        return dscntAmtCcy;
    }

    @JsonProperty("dscntAmtCcy")
    public void setDscntAmtCcy(String dscntAmtCcy) {
        this.dscntAmtCcy = dscntAmtCcy;
    }

    public Amt withDscntAmtCcy(String dscntAmtCcy) {
        this.dscntAmtCcy = dscntAmtCcy;
        return this;
    }

    @JsonProperty("VATAmt")
    public String getVATAmt() {
        return vATAmt;
    }

    @JsonProperty("VATAmt")
    public void setVATAmt(String vATAmt) {
        this.vATAmt = vATAmt;
    }

    public Amt withVATAmt(String vATAmt) {
        this.vATAmt = vATAmt;
        return this;
    }

    @JsonProperty("VATAmtCcy")
    public String getVATAmtCcy() {
        return vATAmtCcy;
    }

    @JsonProperty("VATAmtCcy")
    public void setVATAmtCcy(String vATAmtCcy) {
        this.vATAmtCcy = vATAmtCcy;
    }

    public Amt withVATAmtCcy(String vATAmtCcy) {
        this.vATAmtCcy = vATAmtCcy;
        return this;
    }

    @JsonProperty("cdtAmtBaseCcyEqvt")
    public String getCdtAmtBaseCcyEqvt() {
        return cdtAmtBaseCcyEqvt;
    }

    @JsonProperty("cdtAmtBaseCcyEqvt")
    public void setCdtAmtBaseCcyEqvt(String cdtAmtBaseCcyEqvt) {
        this.cdtAmtBaseCcyEqvt = cdtAmtBaseCcyEqvt;
    }

    public Amt withCdtAmtBaseCcyEqvt(String cdtAmtBaseCcyEqvt) {
        this.cdtAmtBaseCcyEqvt = cdtAmtBaseCcyEqvt;
        return this;
    }

    @JsonProperty("prtyInd")
    public String getPrtyInd() {
        return prtyInd;
    }

    @JsonProperty("prtyInd")
    public void setPrtyInd(String prtyInd) {
        this.prtyInd = prtyInd;
    }

    public Amt withPrtyInd(String prtyInd) {
        this.prtyInd = prtyInd;
        return this;
    }

    @JsonProperty("ttlIntrBkSttlmAmt")
    public String getTtlIntrBkSttlmAmt() {
        return ttlIntrBkSttlmAmt;
    }

    @JsonProperty("ttlIntrBkSttlmAmt")
    public void setTtlIntrBkSttlmAmt(String ttlIntrBkSttlmAmt) {
        this.ttlIntrBkSttlmAmt = ttlIntrBkSttlmAmt;
    }

    public Amt withTtlIntrBkSttlmAmt(String ttlIntrBkSttlmAmt) {
        this.ttlIntrBkSttlmAmt = ttlIntrBkSttlmAmt;
        return this;
    }

    @JsonProperty("ttlIntrBkSttlmAmtCcy")
    public String getTtlIntrBkSttlmAmtCcy() {
        return ttlIntrBkSttlmAmtCcy;
    }

    @JsonProperty("ttlIntrBkSttlmAmtCcy")
    public void setTtlIntrBkSttlmAmtCcy(String ttlIntrBkSttlmAmtCcy) {
        this.ttlIntrBkSttlmAmtCcy = ttlIntrBkSttlmAmtCcy;
    }

    public Amt withTtlIntrBkSttlmAmtCcy(String ttlIntrBkSttlmAmtCcy) {
        this.ttlIntrBkSttlmAmtCcy = ttlIntrBkSttlmAmtCcy;
        return this;
    }

    @JsonProperty("intrBkSttlmAmt")
    public String getIntrBkSttlmAmt() {
        return intrBkSttlmAmt;
    }

    @JsonProperty("intrBkSttlmAmt")
    public void setIntrBkSttlmAmt(String intrBkSttlmAmt) {
        this.intrBkSttlmAmt = intrBkSttlmAmt;
    }

    public Amt withIntrBkSttlmAmt(String intrBkSttlmAmt) {
        this.intrBkSttlmAmt = intrBkSttlmAmt;
        return this;
    }

    @JsonProperty("intrBkSttlmAmtCcy")
    public String getIntrBkSttlmAmtCcy() {
        return intrBkSttlmAmtCcy;
    }

    @JsonProperty("intrBkSttlmAmtCcy")
    public void setIntrBkSttlmAmtCcy(String intrBkSttlmAmtCcy) {
        this.intrBkSttlmAmtCcy = intrBkSttlmAmtCcy;
    }

    public Amt withIntrBkSttlmAmtCcy(String intrBkSttlmAmtCcy) {
        this.intrBkSttlmAmtCcy = intrBkSttlmAmtCcy;
        return this;
    }

    @JsonProperty("VATTp")
    public String getVATTp() {
        return vATTp;
    }

    @JsonProperty("VATTp")
    public void setVATTp(String vATTp) {
        this.vATTp = vATTp;
    }

    public Amt withVATTp(String vATTp) {
        this.vATTp = vATTp;
        return this;
    }

    @JsonProperty("dscntTp")
    public String getDscntTp() {
        return dscntTp;
    }

    @JsonProperty("dscntTp")
    public void setDscntTp(String dscntTp) {
        this.dscntTp = dscntTp;
    }

    public Amt withDscntTp(String dscntTp) {
        this.dscntTp = dscntTp;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Amt withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instdAmt).append(instdCcy).append(baseCcy).append(dbtAmt).append(dbtAmtBaseCcyEqvt).append(cdtAmt).append(cdtCcy).append(dscntAmt).append(dscntAmtCcy).append(vATAmt).append(vATAmtCcy).append(cdtAmtBaseCcyEqvt).append(prtyInd).append(ttlIntrBkSttlmAmt).append(ttlIntrBkSttlmAmtCcy).append(intrBkSttlmAmt).append(intrBkSttlmAmtCcy).append(vATTp).append(dscntTp).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Amt) == false) {
            return false;
        }
        Amt rhs = ((Amt) other);
        return new EqualsBuilder().append(instdAmt, rhs.instdAmt).append(instdCcy, rhs.instdCcy).append(baseCcy, rhs.baseCcy).append(dbtAmt, rhs.dbtAmt).append(dbtAmtBaseCcyEqvt, rhs.dbtAmtBaseCcyEqvt).append(cdtAmt, rhs.cdtAmt).append(cdtCcy, rhs.cdtCcy).append(dscntAmt, rhs.dscntAmt).append(dscntAmtCcy, rhs.dscntAmtCcy).append(vATAmt, rhs.vATAmt).append(vATAmtCcy, rhs.vATAmtCcy).append(cdtAmtBaseCcyEqvt, rhs.cdtAmtBaseCcyEqvt).append(prtyInd, rhs.prtyInd).append(ttlIntrBkSttlmAmt, rhs.ttlIntrBkSttlmAmt).append(ttlIntrBkSttlmAmtCcy, rhs.ttlIntrBkSttlmAmtCcy).append(intrBkSttlmAmt, rhs.intrBkSttlmAmt).append(intrBkSttlmAmtCcy, rhs.intrBkSttlmAmtCcy).append(vATTp, rhs.vATTp).append(dscntTp, rhs.dscntTp).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

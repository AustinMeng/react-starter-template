
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dlvryMtd",
    "prtgLctn",
    "pickUpLctn",
    "nm",
    "adr",
    "formId",
    "taxId",
    "refNb",
    "tp",
    "desc",
    "grssAmt",
    "amt",
    "taxCharFillr",
    "taxNbFillr",
    "taxDtFillr"
})
public class WHTInf {

    @JsonProperty("dlvryMtd")
    private String dlvryMtd;
    @JsonProperty("prtgLctn")
    private String prtgLctn;
    @JsonProperty("pickUpLctn")
    private String pickUpLctn;
    @JsonProperty("nm")
    private List<String> nm = null;
    @JsonProperty("adr")
    private List<String> adr = null;
    @JsonProperty("formId")
    private String formId;
    @JsonProperty("taxId")
    private String taxId;
    @JsonProperty("refNb")
    private String refNb;
    @JsonProperty("tp")
    private List<String> tp = null;
    @JsonProperty("desc")
    private List<String> desc = null;
    @JsonProperty("grssAmt")
    private List<String> grssAmt = null;
    @JsonProperty("amt")
    private List<String> amt = null;
    @JsonProperty("taxCharFillr")
    private List<String> taxCharFillr = null;
    @JsonProperty("taxNbFillr")
    private List<String> taxNbFillr = null;
    @JsonProperty("taxDtFillr")
    private List<String> taxDtFillr = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dlvryMtd")
    public String getDlvryMtd() {
        return dlvryMtd;
    }

    @JsonProperty("dlvryMtd")
    public void setDlvryMtd(String dlvryMtd) {
        this.dlvryMtd = dlvryMtd;
    }

    public WHTInf withDlvryMtd(String dlvryMtd) {
        this.dlvryMtd = dlvryMtd;
        return this;
    }

    @JsonProperty("prtgLctn")
    public String getPrtgLctn() {
        return prtgLctn;
    }

    @JsonProperty("prtgLctn")
    public void setPrtgLctn(String prtgLctn) {
        this.prtgLctn = prtgLctn;
    }

    public WHTInf withPrtgLctn(String prtgLctn) {
        this.prtgLctn = prtgLctn;
        return this;
    }

    @JsonProperty("pickUpLctn")
    public String getPickUpLctn() {
        return pickUpLctn;
    }

    @JsonProperty("pickUpLctn")
    public void setPickUpLctn(String pickUpLctn) {
        this.pickUpLctn = pickUpLctn;
    }

    public WHTInf withPickUpLctn(String pickUpLctn) {
        this.pickUpLctn = pickUpLctn;
        return this;
    }

    @JsonProperty("nm")
    public List<String> getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(List<String> nm) {
        this.nm = nm;
    }

    public WHTInf withNm(List<String> nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("adr")
    public List<String> getAdr() {
        return adr;
    }

    @JsonProperty("adr")
    public void setAdr(List<String> adr) {
        this.adr = adr;
    }

    public WHTInf withAdr(List<String> adr) {
        this.adr = adr;
        return this;
    }

    @JsonProperty("formId")
    public String getFormId() {
        return formId;
    }

    @JsonProperty("formId")
    public void setFormId(String formId) {
        this.formId = formId;
    }

    public WHTInf withFormId(String formId) {
        this.formId = formId;
        return this;
    }

    @JsonProperty("taxId")
    public String getTaxId() {
        return taxId;
    }

    @JsonProperty("taxId")
    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public WHTInf withTaxId(String taxId) {
        this.taxId = taxId;
        return this;
    }

    @JsonProperty("refNb")
    public String getRefNb() {
        return refNb;
    }

    @JsonProperty("refNb")
    public void setRefNb(String refNb) {
        this.refNb = refNb;
    }

    public WHTInf withRefNb(String refNb) {
        this.refNb = refNb;
        return this;
    }

    @JsonProperty("tp")
    public List<String> getTp() {
        return tp;
    }

    @JsonProperty("tp")
    public void setTp(List<String> tp) {
        this.tp = tp;
    }

    public WHTInf withTp(List<String> tp) {
        this.tp = tp;
        return this;
    }

    @JsonProperty("desc")
    public List<String> getDesc() {
        return desc;
    }

    @JsonProperty("desc")
    public void setDesc(List<String> desc) {
        this.desc = desc;
    }

    public WHTInf withDesc(List<String> desc) {
        this.desc = desc;
        return this;
    }

    @JsonProperty("grssAmt")
    public List<String> getGrssAmt() {
        return grssAmt;
    }

    @JsonProperty("grssAmt")
    public void setGrssAmt(List<String> grssAmt) {
        this.grssAmt = grssAmt;
    }

    public WHTInf withGrssAmt(List<String> grssAmt) {
        this.grssAmt = grssAmt;
        return this;
    }

    @JsonProperty("amt")
    public List<String> getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(List<String> amt) {
        this.amt = amt;
    }

    public WHTInf withAmt(List<String> amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("taxCharFillr")
    public List<String> getTaxCharFillr() {
        return taxCharFillr;
    }

    @JsonProperty("taxCharFillr")
    public void setTaxCharFillr(List<String> taxCharFillr) {
        this.taxCharFillr = taxCharFillr;
    }

    public WHTInf withTaxCharFillr(List<String> taxCharFillr) {
        this.taxCharFillr = taxCharFillr;
        return this;
    }

    @JsonProperty("taxNbFillr")
    public List<String> getTaxNbFillr() {
        return taxNbFillr;
    }

    @JsonProperty("taxNbFillr")
    public void setTaxNbFillr(List<String> taxNbFillr) {
        this.taxNbFillr = taxNbFillr;
    }

    public WHTInf withTaxNbFillr(List<String> taxNbFillr) {
        this.taxNbFillr = taxNbFillr;
        return this;
    }

    @JsonProperty("taxDtFillr")
    public List<String> getTaxDtFillr() {
        return taxDtFillr;
    }

    @JsonProperty("taxDtFillr")
    public void setTaxDtFillr(List<String> taxDtFillr) {
        this.taxDtFillr = taxDtFillr;
    }

    public WHTInf withTaxDtFillr(List<String> taxDtFillr) {
        this.taxDtFillr = taxDtFillr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public WHTInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dlvryMtd).append(prtgLctn).append(pickUpLctn).append(nm).append(adr).append(formId).append(taxId).append(refNb).append(tp).append(desc).append(grssAmt).append(amt).append(taxCharFillr).append(taxNbFillr).append(taxDtFillr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof WHTInf) == false) {
            return false;
        }
        WHTInf rhs = ((WHTInf) other);
        return new EqualsBuilder().append(dlvryMtd, rhs.dlvryMtd).append(prtgLctn, rhs.prtgLctn).append(pickUpLctn, rhs.pickUpLctn).append(nm, rhs.nm).append(adr, rhs.adr).append(formId, rhs.formId).append(taxId, rhs.taxId).append(refNb, rhs.refNb).append(tp, rhs.tp).append(desc, rhs.desc).append(grssAmt, rhs.grssAmt).append(amt, rhs.amt).append(taxCharFillr, rhs.taxCharFillr).append(taxNbFillr, rhs.taxNbFillr).append(taxDtFillr, rhs.taxDtFillr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

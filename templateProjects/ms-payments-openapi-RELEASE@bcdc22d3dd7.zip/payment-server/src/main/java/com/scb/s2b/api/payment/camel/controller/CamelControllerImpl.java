package com.scb.s2b.api.payment.camel.controller;

import com.scb.s2b.api.payment.config.property.CamelControllerProperties;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.Route;
import org.apache.camel.ServiceStatus;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spi.RouteController;

@Slf4j
public class CamelControllerImpl implements CamelController {

    private final CamelContext camelContext;

    private final CamelControllerProperties camelControllerProperties;

    public CamelControllerImpl(CamelContext camelContext, CamelControllerProperties camelControllerProperties) {
        this.camelContext = camelContext;
        this.camelControllerProperties = camelControllerProperties;
    }

    void suspendRoute(String routeId, int maxAttempts) throws Exception {
        log.info("Start to suspend route {}", routeId);
        Route route = camelContext.getRoute(routeId);
        if (route == null) {
            log.error("Failed to find route {}, please check whether it exists.", routeId);
            throw new Exception(String.format("Failed to find route %s", routeId));
        }

        int attempt = 0;
        RouteController routeController = camelContext.getRouteController();
        ServiceStatus routeStatus = routeController.getRouteStatus(routeId);
        if (routeStatus.isStopped() || routeStatus.isSuspended()) {
            log.info("Current rout status is {}, skip suspend route for routeId={}", routeStatus, routeId);
            return;
        }
        while (routeStatus.isSuspendable() && attempt < maxAttempts) {
            log.debug("Route {} is suspendable, then execute suspend!", routeId);
            log.debug("It is the {} th attempt.", ++attempt);
            routeController.suspendRoute(routeId, camelControllerProperties.getSuspendTimeout(), TimeUnit.SECONDS);
            routeStatus = routeController.getRouteStatus(routeId);
        }
        routeStatus = routeController.getRouteStatus(routeId);
        if (routeStatus.isSuspendable()) {
            log.error("Oops, failed to suspend route {}.", routeId);
            throw new Exception(String.format("Failed to suspend route %s", routeId));
        }
    }

    @Override
    public void resumeRoute(String routeId, int maxAttempts) throws Exception {
        log.info("Start to resume route {}.", routeId);
        Route route = camelContext.getRoute(routeId);
        if (route == null) {
            log.error("Failed to find route {}, just do nothing. please check whether it exists.", routeId);
            return;
        }

        int attempt = 0;
        RouteController routeController = camelContext.getRouteController();
        ServiceStatus routeStatus = routeController.getRouteStatus(routeId);
        if (routeStatus.isStarted()) {
            log.info("Current rout status is {}, skip resume route for routeId={}", routeStatus, routeId);
            return;
        }
        while (routeStatus.isStartable() && attempt < maxAttempts) {
            log.debug("Route {} can be started, then execute resume!", routeId);
            log.debug("It is the {} th attempt.", ++attempt);
            routeController.resumeRoute(routeId);
            routeStatus = routeController.getRouteStatus(routeId);
        }
        routeStatus = routeController.getRouteStatus(routeId);
        if (routeStatus.isStartable()) {
            log.error("Oops, failed to resume route {}.", routeId);
            throw new Exception(String.format("Failed to resume route %s", routeId));
        }
    }

    @Override
    public void addOrSuspendRoute(String routeId, int maxAttempts, RouteBuilder builder) throws Exception {
        Route route = camelContext.getRoute(routeId);
        if (route == null) {
            camelContext.addRoutes(builder);
        } else {
            suspendRoute(routeId, maxAttempts);
        }
    }

    @Override
    public void addOrResumeRoute(String routeId, int maxAttempts, RouteBuilder builder) throws Exception {
        Route route = camelContext.getRoute(routeId);
        if (route == null) {
            camelContext.addRoutes(builder);
        } else {
            resumeRoute(routeId, maxAttempts);
        }
    }
}

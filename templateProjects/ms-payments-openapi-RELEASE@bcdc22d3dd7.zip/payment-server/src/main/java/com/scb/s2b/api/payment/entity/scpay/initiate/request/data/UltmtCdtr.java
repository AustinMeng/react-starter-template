
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "acctId",
    "nm",
    "nmLclLang",
    "pstlAdrLclLang",
    "brnchCd",
    "ctryOfRes",
    "orgId",
    "prvtId",
    "pstlAdr",
    "ctctDtls"
})
public class UltmtCdtr {

    @JsonProperty("acctId")
    private String acctId;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("nmLclLang")
    private String nmLclLang;
    @JsonProperty("pstlAdrLclLang")
    private String pstlAdrLclLang;
    @JsonProperty("brnchCd")
    private String brnchCd;
    @JsonProperty("ctryOfRes")
    private String ctryOfRes;
    @JsonProperty("orgId")
    private OrgId orgId;
    @JsonProperty("prvtId")
    private PrvtId prvtId;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonProperty("ctctDtls")
    private CtctDtls ctctDtls;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("acctId")
    public String getAcctId() {
        return acctId;
    }

    @JsonProperty("acctId")
    public void setAcctId(String acctId) {
        this.acctId = acctId;
    }

    public UltmtCdtr withAcctId(String acctId) {
        this.acctId = acctId;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public UltmtCdtr withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("nmLclLang")
    public String getNmLclLang() {
        return nmLclLang;
    }

    @JsonProperty("nmLclLang")
    public void setNmLclLang(String nmLclLang) {
        this.nmLclLang = nmLclLang;
    }

    public UltmtCdtr withNmLclLang(String nmLclLang) {
        this.nmLclLang = nmLclLang;
        return this;
    }

    @JsonProperty("pstlAdrLclLang")
    public String getPstlAdrLclLang() {
        return pstlAdrLclLang;
    }

    @JsonProperty("pstlAdrLclLang")
    public void setPstlAdrLclLang(String pstlAdrLclLang) {
        this.pstlAdrLclLang = pstlAdrLclLang;
    }

    public UltmtCdtr withPstlAdrLclLang(String pstlAdrLclLang) {
        this.pstlAdrLclLang = pstlAdrLclLang;
        return this;
    }

    @JsonProperty("brnchCd")
    public String getBrnchCd() {
        return brnchCd;
    }

    @JsonProperty("brnchCd")
    public void setBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
    }

    public UltmtCdtr withBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
        return this;
    }

    @JsonProperty("ctryOfRes")
    public String getCtryOfRes() {
        return ctryOfRes;
    }

    @JsonProperty("ctryOfRes")
    public void setCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
    }

    public UltmtCdtr withCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
        return this;
    }

    @JsonProperty("orgId")
    public OrgId getOrgId() {
        return orgId;
    }

    @JsonProperty("orgId")
    public void setOrgId(OrgId orgId) {
        this.orgId = orgId;
    }

    public UltmtCdtr withOrgId(OrgId orgId) {
        this.orgId = orgId;
        return this;
    }

    @JsonProperty("prvtId")
    public PrvtId getPrvtId() {
        return prvtId;
    }

    @JsonProperty("prvtId")
    public void setPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
    }

    public UltmtCdtr withPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public UltmtCdtr withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @JsonProperty("ctctDtls")
    public CtctDtls getCtctDtls() {
        return ctctDtls;
    }

    @JsonProperty("ctctDtls")
    public void setCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
    }

    public UltmtCdtr withCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public UltmtCdtr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(acctId).append(nm).append(nmLclLang).append(pstlAdrLclLang).append(brnchCd).append(ctryOfRes).append(orgId).append(prvtId).append(pstlAdr).append(ctctDtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UltmtCdtr) == false) {
            return false;
        }
        UltmtCdtr rhs = ((UltmtCdtr) other);
        return new EqualsBuilder().append(acctId, rhs.acctId).append(nm, rhs.nm).append(nmLclLang, rhs.nmLclLang).append(pstlAdrLclLang, rhs.pstlAdrLclLang).append(brnchCd, rhs.brnchCd).append(ctryOfRes, rhs.ctryOfRes).append(orgId, rhs.orgId).append(prvtId, rhs.prvtId).append(pstlAdr, rhs.pstlAdr).append(ctctDtls, rhs.ctctDtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

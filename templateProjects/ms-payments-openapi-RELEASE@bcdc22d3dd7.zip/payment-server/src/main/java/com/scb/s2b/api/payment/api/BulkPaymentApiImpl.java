package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.payment.processor.request.CcsRequestProcessor;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.CcsPaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiBulkPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.BulkPaymentRequestValidator;
import javax.inject.Singleton;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Singleton
public class BulkPaymentApiImpl extends BulkPaymentApiBase {

    @Autowired
    public BulkPaymentApiImpl(OpenApiBulkPaymentInstructionTransformer openApiBulkPaymentInstructionTransformer,
            BulkPaymentRequestValidator bulkPaymentRequestValidator,
            @Qualifier("bulkRequestProcessor") RequestProcessor requestProcessor,
            @Qualifier("ccsRequestProcessor") CcsRequestProcessor ccsRequestProcessor,
            CcsPaymentService ccsPaymentService) {
        super(openApiBulkPaymentInstructionTransformer, bulkPaymentRequestValidator, requestProcessor, ccsRequestProcessor,
                ccsPaymentService);
    }
}

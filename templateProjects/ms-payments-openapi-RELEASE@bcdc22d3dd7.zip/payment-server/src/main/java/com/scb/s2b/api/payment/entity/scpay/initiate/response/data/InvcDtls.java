
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "frmt",
    "cstmInvcHdr",
    "cstmInvcClmnAlgnmnt",
    "cstmInvcClmnWidth",
    "rcrd"
})
public class InvcDtls {

    @JsonProperty("frmt")
    private String frmt;
    @JsonProperty("cstmInvcHdr")
    private List<String> cstmInvcHdr = null;
    @JsonProperty("cstmInvcClmnAlgnmnt")
    private List<String> cstmInvcClmnAlgnmnt = null;
    @JsonProperty("cstmInvcClmnWidth")
    private List<String> cstmInvcClmnWidth = null;
    @JsonProperty("rcrd")
    private List<DtlsRcrd> rcrd = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("frmt")
    public String getFrmt() {
        return frmt;
    }

    @JsonProperty("frmt")
    public void setFrmt(String frmt) {
        this.frmt = frmt;
    }

    public InvcDtls withFrmt(String frmt) {
        this.frmt = frmt;
        return this;
    }

    @JsonProperty("cstmInvcHdr")
    public List<String> getCstmInvcHdr() {
        return cstmInvcHdr;
    }

    @JsonProperty("cstmInvcHdr")
    public void setCstmInvcHdr(List<String> cstmInvcHdr) {
        this.cstmInvcHdr = cstmInvcHdr;
    }

    public InvcDtls withCstmInvcHdr(List<String> cstmInvcHdr) {
        this.cstmInvcHdr = cstmInvcHdr;
        return this;
    }

    @JsonProperty("cstmInvcClmnAlgnmnt")
    public List<String> getCstmInvcClmnAlgnmnt() {
        return cstmInvcClmnAlgnmnt;
    }

    @JsonProperty("cstmInvcClmnAlgnmnt")
    public void setCstmInvcClmnAlgnmnt(List<String> cstmInvcClmnAlgnmnt) {
        this.cstmInvcClmnAlgnmnt = cstmInvcClmnAlgnmnt;
    }

    public InvcDtls withCstmInvcClmnAlgnmnt(List<String> cstmInvcClmnAlgnmnt) {
        this.cstmInvcClmnAlgnmnt = cstmInvcClmnAlgnmnt;
        return this;
    }

    @JsonProperty("cstmInvcClmnWidth")
    public List<String> getCstmInvcClmnWidth() {
        return cstmInvcClmnWidth;
    }

    @JsonProperty("cstmInvcClmnWidth")
    public void setCstmInvcClmnWidth(List<String> cstmInvcClmnWidth) {
        this.cstmInvcClmnWidth = cstmInvcClmnWidth;
    }

    public InvcDtls withCstmInvcClmnWidth(List<String> cstmInvcClmnWidth) {
        this.cstmInvcClmnWidth = cstmInvcClmnWidth;
        return this;
    }

    @JsonProperty("rcrd")
    public List<DtlsRcrd> getRcrd() {
        return rcrd;
    }

    @JsonProperty("rcrd")
    public void setRcrd(List<DtlsRcrd> rcrd) {
        this.rcrd = rcrd;
    }

    public InvcDtls withRcrd(List<DtlsRcrd> rcrd) {
        this.rcrd = rcrd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InvcDtls withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(frmt).append(cstmInvcHdr).append(cstmInvcClmnAlgnmnt).append(cstmInvcClmnWidth).append(rcrd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InvcDtls) == false) {
            return false;
        }
        InvcDtls rhs = ((InvcDtls) other);
        return new EqualsBuilder().append(frmt, rhs.frmt).append(cstmInvcHdr, rhs.cstmInvcHdr).append(cstmInvcClmnAlgnmnt, rhs.cstmInvcClmnAlgnmnt).append(cstmInvcClmnWidth, rhs.cstmInvcClmnWidth).append(rcrd, rhs.rcrd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

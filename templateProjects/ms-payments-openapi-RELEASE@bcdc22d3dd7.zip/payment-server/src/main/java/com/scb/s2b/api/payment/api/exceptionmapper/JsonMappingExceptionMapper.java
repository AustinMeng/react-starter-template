package com.scb.s2b.api.payment.api.exceptionmapper;

import static com.scb.s2b.api.payment.validation.ValidationErrorCode.AER_1005;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonMappingException.Reference;
import com.google.common.base.Throwables;
import com.scb.s2b.api.payment.util.StringUtils;
import com.scb.s2b.api.payment.validation.ValidationErrorCode;
import com.scb.s2b.api.payment.validation.ValidationErrorCode.ValidationErrorType;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

public class JsonMappingExceptionMapper implements ExceptionMapper<JsonMappingException> {

    @Override
    public Response toResponse(JsonMappingException e) {
        if (Throwables.getRootCause(e) instanceof JsonParseException) {
            return Response.status(Response.Status.BAD_REQUEST).entity(AER_1005.getFullMessage(e.getOriginalMessage()))
                    .build();
        }

        return this.convertToResponse(e);
    }

    Response convertToResponse(JsonMappingException e) {
        List<Reference> paths = e.getPath();

        ValidationErrorCode errorCode = ValidationErrorCode.AER_1000;
        String field = null;

        if (paths != null && !paths.isEmpty()) {
            field = paths.stream()
                    .map(path -> {
                        if (path.getFrom() instanceof List) {
                            return "[" + path.getIndex() + "]";
                        }
                        return path.getFieldName();
                    })
                    .reduce((a, b) -> {
                        if (StringUtils.startsWith(b, "[")) {
                            return a + b;
                        }
                        return a + "." + b;
                    })
                    .orElse(null);
            errorCode = ValidationErrorCode.getErrorCode(field, ValidationErrorType.FORMAT.getType());
            if (errorCode == null) {
                errorCode = ValidationErrorCode.AER_1001;
            }
        }

        return Response.status(Response.Status.BAD_REQUEST)
                .entity(errorCode.getFullMessage(field))
                .build();
    }
}

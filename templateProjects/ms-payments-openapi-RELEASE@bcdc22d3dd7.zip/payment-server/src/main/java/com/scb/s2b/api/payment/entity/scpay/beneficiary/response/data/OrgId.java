
package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "anyBIC",
    "LEI",
    "othr"
})
public class OrgId {

    @JsonProperty("anyBIC")
    private String anyBIC;
    @JsonProperty("LEI")
    private String lEI;
    @JsonProperty("othr")
    private List<Othr> othr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("anyBIC")
    public String getAnyBIC() {
        return anyBIC;
    }

    @JsonProperty("anyBIC")
    public void setAnyBIC(String anyBIC) {
        this.anyBIC = anyBIC;
    }

    public OrgId withAnyBIC(String anyBIC) {
        this.anyBIC = anyBIC;
        return this;
    }

    @JsonProperty("LEI")
    public String getLEI() {
        return lEI;
    }

    @JsonProperty("LEI")
    public void setLEI(String lEI) {
        this.lEI = lEI;
    }

    public OrgId withLEI(String lEI) {
        this.lEI = lEI;
        return this;
    }

    @JsonProperty("othr")
    public List<Othr> getOthr() {
        return othr;
    }

    @JsonProperty("othr")
    public void setOthr(List<Othr> othr) {
        this.othr = othr;
    }

    public OrgId withOthr(List<Othr> othr) {
        this.othr = othr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public OrgId withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(anyBIC).append(lEI).append(othr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OrgId) == false) {
            return false;
        }
        OrgId rhs = ((OrgId) other);
        return new EqualsBuilder().append(anyBIC, rhs.anyBIC).append(lEI, rhs.lEI).append(othr, rhs.othr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

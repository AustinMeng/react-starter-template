
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cd",
    "instrInf"
})
public class InstrForNxtAgt {

    @JsonProperty("cd")
    private String cd;
    @JsonProperty("instrInf")
    private String instrInf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cd")
    public String getCd() {
        return cd;
    }

    @JsonProperty("cd")
    public void setCd(String cd) {
        this.cd = cd;
    }

    public InstrForNxtAgt withCd(String cd) {
        this.cd = cd;
        return this;
    }

    @JsonProperty("instrInf")
    public String getInstrInf() {
        return instrInf;
    }

    @JsonProperty("instrInf")
    public void setInstrInf(String instrInf) {
        this.instrInf = instrInf;
    }

    public InstrForNxtAgt withInstrInf(String instrInf) {
        this.instrInf = instrInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InstrForNxtAgt withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cd).append(instrInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrForNxtAgt) == false) {
            return false;
        }
        InstrForNxtAgt rhs = ((InstrForNxtAgt) other);
        return new EqualsBuilder().append(cd, rhs.cd).append(instrInf, rhs.instrInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

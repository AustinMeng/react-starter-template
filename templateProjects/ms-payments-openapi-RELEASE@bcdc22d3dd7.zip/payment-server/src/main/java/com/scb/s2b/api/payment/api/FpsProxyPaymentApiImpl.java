package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.FpsProxyPaymentValidator;
import javax.inject.Singleton;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Singleton
public class FpsProxyPaymentApiImpl extends ProxyPaymentApiBase {

    @Autowired
    public FpsProxyPaymentApiImpl(PaymentService paymentService,
            FpsProxyPaymentValidator fpsProxyPaymentValidator,
            @Qualifier("fpsProxyRequestProcessor") RequestProcessor requestProcessor,
            OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer) {
        super(paymentService, fpsProxyPaymentValidator, requestProcessor, openApiPaymentInstructionTransformer);
    }
}

package com.scb.s2b.api.payment.entity.payee.response;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPartyExtension;
import java.util.List;
import lombok.Getter;

@Getter
public class PayeeExtension extends OpenApiPartyExtension {
    private List<String> notesToPayeeLocalLanguage = null;
}


package com.scb.s2b.api.payment.entity.scpay.beneficiary.request;

import com.fasterxml.jackson.annotation.*;
import com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data.Datum;
import com.scb.s2b.api.payment.entity.scpay.beneficiary.request.error.Error;
import com.scb.s2b.api.payment.entity.scpay.beneficiary.request.header.Header;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "header",
    "data",
    "error"
})
public class BeneReq {

    @JsonProperty("header")
    private Header header;
    @JsonProperty("data")
    private List<Datum> data;
    @JsonProperty("error")
    private Error error;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("header")
    public Header getHeader() {
        return header;
    }

    @JsonProperty("header")
    public void setHeader(Header header) {
        this.header = header;
    }

    public BeneReq withHeader(Header header) {
        this.header = header;
        return this;
    }

    @JsonProperty("data")
    public List<Datum> getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(List<Datum> data) {
        this.data = data;
    }

    public BeneReq withData(List<Datum> data) {
        this.data = data;
        return this;
    }

    @JsonProperty("error")
    public Error getError() {
        return error;
    }

    @JsonProperty("error")
    public void setError(Error error) {
        this.error = error;
    }

    public BeneReq withError(Error error) {
        this.error = error;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BeneReq withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(header).append(data).append(error).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BeneReq) == false) {
            return false;
        }
        BeneReq rhs = ((BeneReq) other);
        return new EqualsBuilder().append(header, rhs.header).append(data, rhs.data).append(error, rhs.error).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

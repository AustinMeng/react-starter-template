package com.scb.s2b.api.payment.config;

import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.channels.foundation.commons.cadm.impl.CadmClientImpl;
import com.scb.s2b.api.payment.service.CadmService;
import com.scb.s2b.api.payment.service.impl.CadmServiceImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

@SuppressWarnings("unused")
public class CadmConfig {

    @Value("${cadm.baseUrl}")
    private String cadmBaseUrl;

    @Value("${security.masterKeystore}")
    private String masterKeystore;

    @Value("${security.masterKeystorePassword}")
    private String masterKeystorePassword;

    @Bean
    @Profile("!test")
    public CadmClient cadmClient() {
        return new CadmClientImpl(cadmBaseUrl, masterKeystore, masterKeystorePassword);
    }

    @Bean
    public CadmService cadmService(CadmClient cadmClient){
        return new CadmServiceImpl(cadmClient);
    }
}

package com.scb.s2b.api.payment.camel.notification.handler;

import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import java.util.List;

public interface SNMNotificationHandler {
    default List<EventCode> getCode() {return null;}

    default void handleNotification(Notification notification){}

    default void handleEvent(String messageId){}

    default void refreshRouteStatus(boolean daemon){}
}

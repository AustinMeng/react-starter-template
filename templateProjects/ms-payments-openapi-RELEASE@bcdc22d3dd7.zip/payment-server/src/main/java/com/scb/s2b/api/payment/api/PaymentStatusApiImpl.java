package com.scb.s2b.api.payment.api;

import com.google.common.base.Strings;
import com.google.common.collect.Sets;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentClientReferences;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentStatus;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentStatusRequest;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentStatuses;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.PaymentTransactionStatus;
import com.scb.s2b.api.payment.service.PaymentStatusService;
import com.scb.s2b.api.payment.transformer.PaymentTransactionStatusTransformer;
import com.scb.s2b.api.payment.validation.PaymentValidationException;
import com.scb.s2b.api.payment.validation.PaynowRequestValidator;
import com.scb.s2b.api.payment.validation.ValidationErrorCode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.stream.Collectors;
import javax.inject.Singleton;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Singleton
public class PaymentStatusApiImpl extends ApiBase {

    private final PaymentStatusService paymentStatusService;
    private final PaymentTransactionStatusTransformer paymentTransactionStatusTransformer;
    private final PaynowRequestValidator paymentRequestValidator;

    @Autowired
    public PaymentStatusApiImpl(PaymentStatusService paymentStatusService,
            PaymentTransactionStatusTransformer paymentTransactionStatusTransformer,
            @Qualifier("paynowRequestValidator") PaynowRequestValidator paymentRequestValidator) {
        this.paymentStatusService = paymentStatusService;
        this.paymentTransactionStatusTransformer = paymentTransactionStatusTransformer;
        this.paymentRequestValidator = paymentRequestValidator;
    }

    public Response paymentsStatus(OpenApiPaymentClientReferences body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        log.info("PaymentsStatus requestId={}, groupId={}, clientReferenceIds={}",
                headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER), groupId,
                StringUtils.join(body.getClientReferenceIds()));

        Collection<PaymentTransactionStatus> status = paymentStatusService
                .getTransactionStatus(groupId,
                        Sets.newTreeSet(body.getClientReferenceIds().stream()
                                .filter(StringUtils::isNotEmpty)
                                .collect(Collectors.toList())));
        if (status.isEmpty()) {
            throw new NotFoundException();
        }

        OpenApiPaymentStatuses openApiPaymentStatuses = new OpenApiPaymentStatuses()
                .statuses(status.stream()
                        .map(paymentTransactionStatusTransformer::paymentTransactionStatusToOpenApiPaymentStatus)
                        .sorted((s1, s2) -> StringUtils.compare(s1.getReferenceId(), s2.getReferenceId()))
                        .collect(Collectors.toList()));
        return Response.ok().entity(openApiPaymentStatuses).build();
    }

    public Response paynowStatus(OpenApiPaymentStatusRequest body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        log.info("PaymentsStatus requestId={}, groupId={}",
                headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER), groupId);

        this.validate(body);
        Collection<PaymentTransactionStatus> statusCollection;
        if (body.getClientReferenceIds() != null) {
            statusCollection = paymentStatusService
                    .getTransactionStatus(groupId,
                            Sets.newTreeSet(body.getClientReferenceIds().stream()
                                    .filter(StringUtils::isNotEmpty)
                                    .collect(Collectors.toList())));
        } else {
            statusCollection = paymentStatusService.getTransactionStatusByDateRange(groupId,
                    body.getFromDateTime().plusMillis(TimeZone.getDefault().getRawOffset()),
                    body.getToDateTime().plusMillis(TimeZone.getDefault().getRawOffset()));

            Set<String> codeSet = StringUtils.isNotBlank(body.getReasonCodes()) ?
                    Arrays.stream(StringUtils.split(body.getReasonCodes(), ","))
                            .filter(StringUtils::isNotBlank)
                            .map(StringUtils::trim)
                            .map(StringUtils::lowerCase)
                            .collect(Collectors.toSet())
                    : Collections.emptySet();

            if (!codeSet.isEmpty()) {
                statusCollection = statusCollection.stream()
                        .filter(s -> codeSet.contains(Strings.nullToEmpty(s.getReasonCode()).toLowerCase()))
                        .collect(Collectors.toList());
            }
        }
        if (statusCollection.isEmpty()) {
            throw new NotFoundException();
        }

        List<PaymentTransactionStatus> result = new ArrayList<>();
        statusCollection.stream()
                .collect(Collectors.groupingBy(PaymentTransactionStatus::getEndToEndId))
                .forEach((k, v) -> v.stream().max(Comparator.comparing(PaymentTransactionStatus::getTimestamp))
                        .ifPresent(result::add));

        List<OpenApiPaymentStatus> paymentStatuses = result.stream()
                .map(paymentTransactionStatusTransformer::paymentTransactionStatusToOpenApiPaymentStatus)
                .sorted((s1, s2) -> StringUtils.compare(s1.getReferenceId(), s2.getReferenceId()))
                .collect(Collectors.toList());

        return Response.ok().entity(new OpenApiPaymentStatuses()
                .statuses(paymentStatuses)).build();
    }

    private void validate(OpenApiPaymentStatusRequest paymentStatusRequest) {
        if (paymentStatusRequest.getClientReferenceIds() != null && rangeParametersPresent(paymentStatusRequest)) {
            throw new PaymentValidationException(ValidationErrorCode.AER_1185);
        }
        if (paymentStatusRequest.getClientReferenceIds() == null && !rangeParametersPresent(paymentStatusRequest)) {
            throw new PaymentValidationException(ValidationErrorCode.AER_1186);
        }

        if (rangeParametersPresent(paymentStatusRequest)) {
            paymentRequestValidator
                    .validateTimestamp(paymentStatusRequest.getFromDateTime(), ValidationErrorCode.AER_1180);
            paymentRequestValidator
                    .validateTimestamp(paymentStatusRequest.getToDateTime(), ValidationErrorCode.AER_1181);
        }
    }

    private boolean rangeParametersPresent(OpenApiPaymentStatusRequest paymentStatusRequest) {
        return paymentStatusRequest.getFromDateTime() != null ||
                paymentStatusRequest.getToDateTime() != null ||
                StringUtils.isNotEmpty(paymentStatusRequest.getReasonCodes());
    }
}

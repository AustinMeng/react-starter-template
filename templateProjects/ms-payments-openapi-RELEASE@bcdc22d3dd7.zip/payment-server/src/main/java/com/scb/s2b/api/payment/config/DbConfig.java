package com.scb.s2b.api.payment.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@SuppressWarnings("unused")
public class DbConfig {

    @Primary
    @Bean(name = "apibankingDataSourceProps")
    @ConfigurationProperties("datasource.apibanking")
    public HikariConfig apibankingDataSourceProperties(){
        return new HikariConfig();
    }

    @Primary
    @Bean(name = "apibankingDataSource")
    public DataSource dataSource(@Qualifier("apibankingDataSourceProps") HikariConfig dataSourceProperties){
        return new HikariDataSource(dataSourceProperties);
    }
    
    @Primary
    @Bean(name = "apibankingJdbcTemplate")
    public JdbcTemplate apibankingJdbcTemplate(@Qualifier("apibankingDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "transactionManager")
    public PlatformTransactionManager apibankingTxManager(EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    @Bean(name = "classicDataSourceProps")
    @ConfigurationProperties("datasource.classic")
    public HikariConfig classicDataSourceProperties() {
        return new HikariConfig();
    }

    @Bean(name = "classicDataSource")
    public DataSource classicDataSource(@Qualifier("classicDataSourceProps") HikariConfig dataSourceProperties) {
        return new HikariDataSource(dataSourceProperties);
    }

    @Bean
    @Qualifier("classicTxManager")
    public PlatformTransactionManager classicTxManager(@Qualifier("classicDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    @Qualifier("classicJdbcTemplate")
    public JdbcTemplate classicJdbcTemplate(@Qualifier("classicDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}

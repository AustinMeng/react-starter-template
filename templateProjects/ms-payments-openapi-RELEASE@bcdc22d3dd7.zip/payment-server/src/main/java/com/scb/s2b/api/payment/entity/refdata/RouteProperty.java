package com.scb.s2b.api.payment.entity.refdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@Data
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class RouteProperty implements Serializable {
    private String country;

    @Builder.Default
    private List<String> supportedPaymentTypes = new ArrayList<>();

    private String path;
}

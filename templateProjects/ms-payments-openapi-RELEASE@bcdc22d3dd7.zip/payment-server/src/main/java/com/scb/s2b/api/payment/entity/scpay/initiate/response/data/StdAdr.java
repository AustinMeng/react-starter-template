
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "adrTp",
    "adr",
    "twnNm",
    "ctrySubDvsn",
    "ctryCd",
    "pstCd",
    "lndmrk",
    "pstBx",
    "isMlngAdr",
    "ctctNm"
})
public class StdAdr {

    @JsonProperty("adrTp")
    private String adrTp;
    @JsonProperty("adr")
    private List<String> adr = null;
    @JsonProperty("twnNm")
    private String twnNm;
    @JsonProperty("ctrySubDvsn")
    private String ctrySubDvsn;
    @JsonProperty("ctryCd")
    private String ctryCd;
    @JsonProperty("pstCd")
    private String pstCd;
    @JsonProperty("lndmrk")
    private String lndmrk;
    @JsonProperty("pstBx")
    private String pstBx;
    @JsonProperty("isMlngAdr")
    private String isMlngAdr;
    @JsonProperty("ctctNm")
    private String ctctNm;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("adrTp")
    public String getAdrTp() {
        return adrTp;
    }

    @JsonProperty("adrTp")
    public void setAdrTp(String adrTp) {
        this.adrTp = adrTp;
    }

    public StdAdr withAdrTp(String adrTp) {
        this.adrTp = adrTp;
        return this;
    }

    @JsonProperty("adr")
    public List<String> getAdr() {
        return adr;
    }

    @JsonProperty("adr")
    public void setAdr(List<String> adr) {
        this.adr = adr;
    }

    public StdAdr withAdr(List<String> adr) {
        this.adr = adr;
        return this;
    }

    @JsonProperty("twnNm")
    public String getTwnNm() {
        return twnNm;
    }

    @JsonProperty("twnNm")
    public void setTwnNm(String twnNm) {
        this.twnNm = twnNm;
    }

    public StdAdr withTwnNm(String twnNm) {
        this.twnNm = twnNm;
        return this;
    }

    @JsonProperty("ctrySubDvsn")
    public String getCtrySubDvsn() {
        return ctrySubDvsn;
    }

    @JsonProperty("ctrySubDvsn")
    public void setCtrySubDvsn(String ctrySubDvsn) {
        this.ctrySubDvsn = ctrySubDvsn;
    }

    public StdAdr withCtrySubDvsn(String ctrySubDvsn) {
        this.ctrySubDvsn = ctrySubDvsn;
        return this;
    }

    @JsonProperty("ctryCd")
    public String getCtryCd() {
        return ctryCd;
    }

    @JsonProperty("ctryCd")
    public void setCtryCd(String ctryCd) {
        this.ctryCd = ctryCd;
    }

    public StdAdr withCtryCd(String ctryCd) {
        this.ctryCd = ctryCd;
        return this;
    }

    @JsonProperty("pstCd")
    public String getPstCd() {
        return pstCd;
    }

    @JsonProperty("pstCd")
    public void setPstCd(String pstCd) {
        this.pstCd = pstCd;
    }

    public StdAdr withPstCd(String pstCd) {
        this.pstCd = pstCd;
        return this;
    }

    @JsonProperty("lndmrk")
    public String getLndmrk() {
        return lndmrk;
    }

    @JsonProperty("lndmrk")
    public void setLndmrk(String lndmrk) {
        this.lndmrk = lndmrk;
    }

    public StdAdr withLndmrk(String lndmrk) {
        this.lndmrk = lndmrk;
        return this;
    }

    @JsonProperty("pstBx")
    public String getPstBx() {
        return pstBx;
    }

    @JsonProperty("pstBx")
    public void setPstBx(String pstBx) {
        this.pstBx = pstBx;
    }

    public StdAdr withPstBx(String pstBx) {
        this.pstBx = pstBx;
        return this;
    }

    @JsonProperty("isMlngAdr")
    public String getIsMlngAdr() {
        return isMlngAdr;
    }

    @JsonProperty("isMlngAdr")
    public void setIsMlngAdr(String isMlngAdr) {
        this.isMlngAdr = isMlngAdr;
    }

    public StdAdr withIsMlngAdr(String isMlngAdr) {
        this.isMlngAdr = isMlngAdr;
        return this;
    }

    @JsonProperty("ctctNm")
    public String getCtctNm() {
        return ctctNm;
    }

    @JsonProperty("ctctNm")
    public void setCtctNm(String ctctNm) {
        this.ctctNm = ctctNm;
    }

    public StdAdr withCtctNm(String ctctNm) {
        this.ctctNm = ctctNm;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public StdAdr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(adrTp).append(adr).append(twnNm).append(ctrySubDvsn).append(ctryCd).append(pstCd).append(lndmrk).append(pstBx).append(isMlngAdr).append(ctctNm).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StdAdr) == false) {
            return false;
        }
        StdAdr rhs = ((StdAdr) other);
        return new EqualsBuilder().append(adrTp, rhs.adrTp).append(adr, rhs.adr).append(twnNm, rhs.twnNm).append(ctrySubDvsn, rhs.ctrySubDvsn).append(ctryCd, rhs.ctryCd).append(pstCd, rhs.pstCd).append(lndmrk, rhs.lndmrk).append(pstBx, rhs.pstBx).append(isMlngAdr, rhs.isMlngAdr).append(ctctNm, rhs.ctctNm).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

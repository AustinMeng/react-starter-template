
package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "IBAN",
    "subDbtAcctId",
    "id",
    "idSchmeNmCd",
    "idSchmeNmPrtry",
    "idIssr",
    "tpCd",
    "tpPrtry",
    "ccy",
    "nm",
    "prxyTpCd",
    "prxyTpPrtry",
    "prxyId",
    "ntrOfAcct"
})
public class DbtrAcct {

    @JsonProperty("IBAN")
    private String iBAN;
    @JsonProperty("subDbtAcctId")
    private String subDbtAcctId;
    @JsonProperty("id")
    private String id;
    @JsonProperty("idSchmeNmCd")
    private String idSchmeNmCd;
    @JsonProperty("idSchmeNmPrtry")
    private String idSchmeNmPrtry;
    @JsonProperty("idIssr")
    private String idIssr;
    @JsonProperty("tpCd")
    private String tpCd;
    @JsonProperty("tpPrtry")
    private String tpPrtry;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("prxyTpCd")
    private String prxyTpCd;
    @JsonProperty("prxyTpPrtry")
    private String prxyTpPrtry;
    @JsonProperty("prxyId")
    private String prxyId;
    @JsonProperty("ntrOfAcct")
    private String ntrOfAcct;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("IBAN")
    public String getIBAN() {
        return iBAN;
    }

    @JsonProperty("IBAN")
    public void setIBAN(String iBAN) {
        this.iBAN = iBAN;
    }

    public DbtrAcct withIBAN(String iBAN) {
        this.iBAN = iBAN;
        return this;
    }

    @JsonProperty("subDbtAcctId")
    public String getSubDbtAcctId() {
        return subDbtAcctId;
    }

    @JsonProperty("subDbtAcctId")
    public void setSubDbtAcctId(String subDbtAcctId) {
        this.subDbtAcctId = subDbtAcctId;
    }

    public DbtrAcct withSubDbtAcctId(String subDbtAcctId) {
        this.subDbtAcctId = subDbtAcctId;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public DbtrAcct withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("idSchmeNmCd")
    public String getIdSchmeNmCd() {
        return idSchmeNmCd;
    }

    @JsonProperty("idSchmeNmCd")
    public void setIdSchmeNmCd(String idSchmeNmCd) {
        this.idSchmeNmCd = idSchmeNmCd;
    }

    public DbtrAcct withIdSchmeNmCd(String idSchmeNmCd) {
        this.idSchmeNmCd = idSchmeNmCd;
        return this;
    }

    @JsonProperty("idSchmeNmPrtry")
    public String getIdSchmeNmPrtry() {
        return idSchmeNmPrtry;
    }

    @JsonProperty("idSchmeNmPrtry")
    public void setIdSchmeNmPrtry(String idSchmeNmPrtry) {
        this.idSchmeNmPrtry = idSchmeNmPrtry;
    }

    public DbtrAcct withIdSchmeNmPrtry(String idSchmeNmPrtry) {
        this.idSchmeNmPrtry = idSchmeNmPrtry;
        return this;
    }

    @JsonProperty("idIssr")
    public String getIdIssr() {
        return idIssr;
    }

    @JsonProperty("idIssr")
    public void setIdIssr(String idIssr) {
        this.idIssr = idIssr;
    }

    public DbtrAcct withIdIssr(String idIssr) {
        this.idIssr = idIssr;
        return this;
    }

    @JsonProperty("tpCd")
    public String getTpCd() {
        return tpCd;
    }

    @JsonProperty("tpCd")
    public void setTpCd(String tpCd) {
        this.tpCd = tpCd;
    }

    public DbtrAcct withTpCd(String tpCd) {
        this.tpCd = tpCd;
        return this;
    }

    @JsonProperty("tpPrtry")
    public String getTpPrtry() {
        return tpPrtry;
    }

    @JsonProperty("tpPrtry")
    public void setTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
    }

    public DbtrAcct withTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public DbtrAcct withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public DbtrAcct withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("prxyTpCd")
    public String getPrxyTpCd() {
        return prxyTpCd;
    }

    @JsonProperty("prxyTpCd")
    public void setPrxyTpCd(String prxyTpCd) {
        this.prxyTpCd = prxyTpCd;
    }

    public DbtrAcct withPrxyTpCd(String prxyTpCd) {
        this.prxyTpCd = prxyTpCd;
        return this;
    }

    @JsonProperty("prxyTpPrtry")
    public String getPrxyTpPrtry() {
        return prxyTpPrtry;
    }

    @JsonProperty("prxyTpPrtry")
    public void setPrxyTpPrtry(String prxyTpPrtry) {
        this.prxyTpPrtry = prxyTpPrtry;
    }

    public DbtrAcct withPrxyTpPrtry(String prxyTpPrtry) {
        this.prxyTpPrtry = prxyTpPrtry;
        return this;
    }

    @JsonProperty("prxyId")
    public String getPrxyId() {
        return prxyId;
    }

    @JsonProperty("prxyId")
    public void setPrxyId(String prxyId) {
        this.prxyId = prxyId;
    }

    public DbtrAcct withPrxyId(String prxyId) {
        this.prxyId = prxyId;
        return this;
    }

    @JsonProperty("ntrOfAcct")
    public String getNtrOfAcct() {
        return ntrOfAcct;
    }

    @JsonProperty("ntrOfAcct")
    public void setNtrOfAcct(String ntrOfAcct) {
        this.ntrOfAcct = ntrOfAcct;
    }

    public DbtrAcct withNtrOfAcct(String ntrOfAcct) {
        this.ntrOfAcct = ntrOfAcct;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DbtrAcct withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(iBAN).append(subDbtAcctId).append(id).append(idSchmeNmCd).append(idSchmeNmPrtry).append(idIssr).append(tpCd).append(tpPrtry).append(ccy).append(nm).append(prxyTpCd).append(prxyTpPrtry).append(prxyId).append(ntrOfAcct).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DbtrAcct) == false) {
            return false;
        }
        DbtrAcct rhs = ((DbtrAcct) other);
        return new EqualsBuilder().append(iBAN, rhs.iBAN).append(subDbtAcctId, rhs.subDbtAcctId).append(id, rhs.id).append(idSchmeNmCd, rhs.idSchmeNmCd).append(idSchmeNmPrtry, rhs.idSchmeNmPrtry).append(idIssr, rhs.idIssr).append(tpCd, rhs.tpCd).append(tpPrtry, rhs.tpPrtry).append(ccy, rhs.ccy).append(nm, rhs.nm).append(prxyTpCd, rhs.prxyTpCd).append(prxyTpPrtry, rhs.prxyTpPrtry).append(prxyId, rhs.prxyId).append(ntrOfAcct, rhs.ntrOfAcct).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

package com.scb.s2b.api.payment.camel.notification.handler;

import com.scb.channels.foundation.notificationengine.KafkaStruct;
import com.scb.s2b.api.payment.entity.PaymentTransaction;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import com.scb.s2b.api.payment.util.LoggingUtility;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.kafka.KafkaConstants;
import org.apache.camel.component.kafka.KafkaManualCommit;

public abstract class AbstractSNMNotificationHandler implements SNMNotificationHandler {

    private final CamelAsynchExceptionProcessor exceptionProcessor;

    private final JsonMessageMarshaller messageMarshaller;

    protected AbstractSNMNotificationHandler(
            CamelAsynchExceptionProcessor exceptionProcessor, JsonMessageMarshaller messageMarshaller) {
        this.exceptionProcessor = exceptionProcessor;
        this.messageMarshaller = messageMarshaller;
    }

    protected RouteBuilder revokedRouteBuilder(String endpoint, String routeId) {
        return routeBuilder(endpoint, routeId, true);
    }

    protected RouteBuilder suspendedRouteBuilder(String endpoint, String routeId) {
        return routeBuilder(endpoint, routeId, false);
    }

    private RouteBuilder routeBuilder(String endpoint, String routeId, boolean autoStartup) {
        return new RouteBuilder() {
            @Override
            public void configure() {
                JacksonDataFormat paymentTransactionFormatter= new JacksonDataFormat(PaymentTransaction.class);
                paymentTransactionFormatter.setObjectMapper(messageMarshaller.getObjectMapper());

                from(endpoint)
                        .autoStartup(autoStartup)
                        .routeId(routeId)
                        .doTry()
                        .bean(KafkaStruct.class,"deserialise")
                        .setBody(simple("${body.messageWrapper.content}"))
                        .unmarshal(paymentTransactionFormatter).convertBodyTo(PaymentTransaction.class)
                        .bean(LoggingUtility.class, "asynchLogVars")
                        .bean("kafkaConsumerAdapter", "consumeSuspendedTransaction")
                        .process(exchange -> {
                            KafkaManualCommit manual = exchange.getIn()
                                    .getHeader(KafkaConstants.MANUAL_COMMIT, KafkaManualCommit.class);
                            if(manual != null) {
                                manual.commitSync();
                            }
                        })
                        .log(endpoint + " topic offset ${headers.kafka.OFFSET} committed")
                        .doCatch(Exception.class)
                        .log("Failed to process " + endpoint + " offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor)
                        .end();
            }
        };
    }
}

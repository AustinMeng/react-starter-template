package com.scb.s2b.api.payment.api.exceptionmapper;

import lombok.Data;

@Data
public class ErrorResponse {
    private String errorCode;
    private String errorMessage;
}

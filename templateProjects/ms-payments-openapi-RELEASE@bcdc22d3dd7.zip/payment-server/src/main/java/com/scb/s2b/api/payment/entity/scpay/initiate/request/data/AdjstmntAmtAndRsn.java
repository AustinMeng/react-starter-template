
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "amt",
    "ccy",
    "cdtDbtInd",
    "rsn",
    "addtlInf"
})
public class AdjstmntAmtAndRsn {

    @JsonProperty("amt")
    private String amt;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("cdtDbtInd")
    private String cdtDbtInd;
    @JsonProperty("rsn")
    private String rsn;
    @JsonProperty("addtlInf")
    private String addtlInf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("amt")
    public String getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(String amt) {
        this.amt = amt;
    }

    public AdjstmntAmtAndRsn withAmt(String amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public AdjstmntAmtAndRsn withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("cdtDbtInd")
    public String getCdtDbtInd() {
        return cdtDbtInd;
    }

    @JsonProperty("cdtDbtInd")
    public void setCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
    }

    public AdjstmntAmtAndRsn withCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
        return this;
    }

    @JsonProperty("rsn")
    public String getRsn() {
        return rsn;
    }

    @JsonProperty("rsn")
    public void setRsn(String rsn) {
        this.rsn = rsn;
    }

    public AdjstmntAmtAndRsn withRsn(String rsn) {
        this.rsn = rsn;
        return this;
    }

    @JsonProperty("addtlInf")
    public String getAddtlInf() {
        return addtlInf;
    }

    @JsonProperty("addtlInf")
    public void setAddtlInf(String addtlInf) {
        this.addtlInf = addtlInf;
    }

    public AdjstmntAmtAndRsn withAddtlInf(String addtlInf) {
        this.addtlInf = addtlInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AdjstmntAmtAndRsn withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(amt).append(ccy).append(cdtDbtInd).append(rsn).append(addtlInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AdjstmntAmtAndRsn) == false) {
            return false;
        }
        AdjstmntAmtAndRsn rhs = ((AdjstmntAmtAndRsn) other);
        return new EqualsBuilder().append(amt, rhs.amt).append(ccy, rhs.ccy).append(cdtDbtInd, rhs.cdtDbtInd).append(rsn, rhs.rsn).append(addtlInf, rhs.addtlInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

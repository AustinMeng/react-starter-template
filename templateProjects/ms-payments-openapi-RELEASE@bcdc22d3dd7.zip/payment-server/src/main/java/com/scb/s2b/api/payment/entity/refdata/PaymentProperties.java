package com.scb.s2b.api.payment.entity.refdata;

import com.scb.s2b.api.payment.entity.Country;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PaymentProperties implements Serializable {

    public static final PaymentProperties DEFAULT = new PaymentProperties();

    private Map<Country, PaymentProperty> countries = new HashMap<>();

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean isValidCountryAndCity(String countryCode, String cityCode) {
        Set<String> cities = countries.get(new Country(countryCode)).getCities();
        return (cities == null ? Collections.emptySet() : cities).contains(cityCode);
    }
}

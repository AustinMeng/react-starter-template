
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tp",
    "ctgy",
    "ctgyDtls",
    "dbtrSts",
    "certId",
    "frmsCd",
    "prdYr",
    "prdTp",
    "prdFrDt",
    "prdToDt",
    "taxAmtRate",
    "taxAmtTaxblBaseAmt",
    "taxAmtTaxblBaseAmtCcy",
    "taxAmtTtlAmt",
    "taxAmtTtlAmtCcy",
    "addtlInf",
    "taxAmtDtls"
})
public class Rcrd {

    @JsonProperty("tp")
    private String tp;
    @JsonProperty("ctgy")
    private String ctgy;
    @JsonProperty("ctgyDtls")
    private String ctgyDtls;
    @JsonProperty("dbtrSts")
    private String dbtrSts;
    @JsonProperty("certId")
    private String certId;
    @JsonProperty("frmsCd")
    private String frmsCd;
    @JsonProperty("prdYr")
    private String prdYr;
    @JsonProperty("prdTp")
    private String prdTp;
    @JsonProperty("prdFrDt")
    private String prdFrDt;
    @JsonProperty("prdToDt")
    private String prdToDt;
    @JsonProperty("taxAmtRate")
    private String taxAmtRate;
    @JsonProperty("taxAmtTaxblBaseAmt")
    private String taxAmtTaxblBaseAmt;
    @JsonProperty("taxAmtTaxblBaseAmtCcy")
    private String taxAmtTaxblBaseAmtCcy;
    @JsonProperty("taxAmtTtlAmt")
    private String taxAmtTtlAmt;
    @JsonProperty("taxAmtTtlAmtCcy")
    private String taxAmtTtlAmtCcy;
    @JsonProperty("addtlInf")
    private String addtlInf;
    @JsonProperty("taxAmtDtls")
    private List<TaxAmtDtl> taxAmtDtls = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tp")
    public String getTp() {
        return tp;
    }

    @JsonProperty("tp")
    public void setTp(String tp) {
        this.tp = tp;
    }

    public Rcrd withTp(String tp) {
        this.tp = tp;
        return this;
    }

    @JsonProperty("ctgy")
    public String getCtgy() {
        return ctgy;
    }

    @JsonProperty("ctgy")
    public void setCtgy(String ctgy) {
        this.ctgy = ctgy;
    }

    public Rcrd withCtgy(String ctgy) {
        this.ctgy = ctgy;
        return this;
    }

    @JsonProperty("ctgyDtls")
    public String getCtgyDtls() {
        return ctgyDtls;
    }

    @JsonProperty("ctgyDtls")
    public void setCtgyDtls(String ctgyDtls) {
        this.ctgyDtls = ctgyDtls;
    }

    public Rcrd withCtgyDtls(String ctgyDtls) {
        this.ctgyDtls = ctgyDtls;
        return this;
    }

    @JsonProperty("dbtrSts")
    public String getDbtrSts() {
        return dbtrSts;
    }

    @JsonProperty("dbtrSts")
    public void setDbtrSts(String dbtrSts) {
        this.dbtrSts = dbtrSts;
    }

    public Rcrd withDbtrSts(String dbtrSts) {
        this.dbtrSts = dbtrSts;
        return this;
    }

    @JsonProperty("certId")
    public String getCertId() {
        return certId;
    }

    @JsonProperty("certId")
    public void setCertId(String certId) {
        this.certId = certId;
    }

    public Rcrd withCertId(String certId) {
        this.certId = certId;
        return this;
    }

    @JsonProperty("frmsCd")
    public String getFrmsCd() {
        return frmsCd;
    }

    @JsonProperty("frmsCd")
    public void setFrmsCd(String frmsCd) {
        this.frmsCd = frmsCd;
    }

    public Rcrd withFrmsCd(String frmsCd) {
        this.frmsCd = frmsCd;
        return this;
    }

    @JsonProperty("prdYr")
    public String getPrdYr() {
        return prdYr;
    }

    @JsonProperty("prdYr")
    public void setPrdYr(String prdYr) {
        this.prdYr = prdYr;
    }

    public Rcrd withPrdYr(String prdYr) {
        this.prdYr = prdYr;
        return this;
    }

    @JsonProperty("prdTp")
    public String getPrdTp() {
        return prdTp;
    }

    @JsonProperty("prdTp")
    public void setPrdTp(String prdTp) {
        this.prdTp = prdTp;
    }

    public Rcrd withPrdTp(String prdTp) {
        this.prdTp = prdTp;
        return this;
    }

    @JsonProperty("prdFrDt")
    public String getPrdFrDt() {
        return prdFrDt;
    }

    @JsonProperty("prdFrDt")
    public void setPrdFrDt(String prdFrDt) {
        this.prdFrDt = prdFrDt;
    }

    public Rcrd withPrdFrDt(String prdFrDt) {
        this.prdFrDt = prdFrDt;
        return this;
    }

    @JsonProperty("prdToDt")
    public String getPrdToDt() {
        return prdToDt;
    }

    @JsonProperty("prdToDt")
    public void setPrdToDt(String prdToDt) {
        this.prdToDt = prdToDt;
    }

    public Rcrd withPrdToDt(String prdToDt) {
        this.prdToDt = prdToDt;
        return this;
    }

    @JsonProperty("taxAmtRate")
    public String getTaxAmtRate() {
        return taxAmtRate;
    }

    @JsonProperty("taxAmtRate")
    public void setTaxAmtRate(String taxAmtRate) {
        this.taxAmtRate = taxAmtRate;
    }

    public Rcrd withTaxAmtRate(String taxAmtRate) {
        this.taxAmtRate = taxAmtRate;
        return this;
    }

    @JsonProperty("taxAmtTaxblBaseAmt")
    public String getTaxAmtTaxblBaseAmt() {
        return taxAmtTaxblBaseAmt;
    }

    @JsonProperty("taxAmtTaxblBaseAmt")
    public void setTaxAmtTaxblBaseAmt(String taxAmtTaxblBaseAmt) {
        this.taxAmtTaxblBaseAmt = taxAmtTaxblBaseAmt;
    }

    public Rcrd withTaxAmtTaxblBaseAmt(String taxAmtTaxblBaseAmt) {
        this.taxAmtTaxblBaseAmt = taxAmtTaxblBaseAmt;
        return this;
    }

    @JsonProperty("taxAmtTaxblBaseAmtCcy")
    public String getTaxAmtTaxblBaseAmtCcy() {
        return taxAmtTaxblBaseAmtCcy;
    }

    @JsonProperty("taxAmtTaxblBaseAmtCcy")
    public void setTaxAmtTaxblBaseAmtCcy(String taxAmtTaxblBaseAmtCcy) {
        this.taxAmtTaxblBaseAmtCcy = taxAmtTaxblBaseAmtCcy;
    }

    public Rcrd withTaxAmtTaxblBaseAmtCcy(String taxAmtTaxblBaseAmtCcy) {
        this.taxAmtTaxblBaseAmtCcy = taxAmtTaxblBaseAmtCcy;
        return this;
    }

    @JsonProperty("taxAmtTtlAmt")
    public String getTaxAmtTtlAmt() {
        return taxAmtTtlAmt;
    }

    @JsonProperty("taxAmtTtlAmt")
    public void setTaxAmtTtlAmt(String taxAmtTtlAmt) {
        this.taxAmtTtlAmt = taxAmtTtlAmt;
    }

    public Rcrd withTaxAmtTtlAmt(String taxAmtTtlAmt) {
        this.taxAmtTtlAmt = taxAmtTtlAmt;
        return this;
    }

    @JsonProperty("taxAmtTtlAmtCcy")
    public String getTaxAmtTtlAmtCcy() {
        return taxAmtTtlAmtCcy;
    }

    @JsonProperty("taxAmtTtlAmtCcy")
    public void setTaxAmtTtlAmtCcy(String taxAmtTtlAmtCcy) {
        this.taxAmtTtlAmtCcy = taxAmtTtlAmtCcy;
    }

    public Rcrd withTaxAmtTtlAmtCcy(String taxAmtTtlAmtCcy) {
        this.taxAmtTtlAmtCcy = taxAmtTtlAmtCcy;
        return this;
    }

    @JsonProperty("addtlInf")
    public String getAddtlInf() {
        return addtlInf;
    }

    @JsonProperty("addtlInf")
    public void setAddtlInf(String addtlInf) {
        this.addtlInf = addtlInf;
    }

    public Rcrd withAddtlInf(String addtlInf) {
        this.addtlInf = addtlInf;
        return this;
    }

    @JsonProperty("taxAmtDtls")
    public List<TaxAmtDtl> getTaxAmtDtls() {
        return taxAmtDtls;
    }

    @JsonProperty("taxAmtDtls")
    public void setTaxAmtDtls(List<TaxAmtDtl> taxAmtDtls) {
        this.taxAmtDtls = taxAmtDtls;
    }

    public Rcrd withTaxAmtDtls(List<TaxAmtDtl> taxAmtDtls) {
        this.taxAmtDtls = taxAmtDtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Rcrd withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tp).append(ctgy).append(ctgyDtls).append(dbtrSts).append(certId).append(frmsCd).append(prdYr).append(prdTp).append(prdFrDt).append(prdToDt).append(taxAmtRate).append(taxAmtTaxblBaseAmt).append(taxAmtTaxblBaseAmtCcy).append(taxAmtTtlAmt).append(taxAmtTtlAmtCcy).append(addtlInf).append(taxAmtDtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Rcrd) == false) {
            return false;
        }
        Rcrd rhs = ((Rcrd) other);
        return new EqualsBuilder().append(tp, rhs.tp).append(ctgy, rhs.ctgy).append(ctgyDtls, rhs.ctgyDtls).append(dbtrSts, rhs.dbtrSts).append(certId, rhs.certId).append(frmsCd, rhs.frmsCd).append(prdYr, rhs.prdYr).append(prdTp, rhs.prdTp).append(prdFrDt, rhs.prdFrDt).append(prdToDt, rhs.prdToDt).append(taxAmtRate, rhs.taxAmtRate).append(taxAmtTaxblBaseAmt, rhs.taxAmtTaxblBaseAmt).append(taxAmtTaxblBaseAmtCcy, rhs.taxAmtTaxblBaseAmtCcy).append(taxAmtTtlAmt, rhs.taxAmtTtlAmt).append(taxAmtTtlAmtCcy, rhs.taxAmtTtlAmtCcy).append(addtlInf, rhs.addtlInf).append(taxAmtDtls, rhs.taxAmtDtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

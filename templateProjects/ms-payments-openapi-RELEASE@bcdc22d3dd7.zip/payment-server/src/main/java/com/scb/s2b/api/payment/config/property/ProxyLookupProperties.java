package com.scb.s2b.api.payment.config.property;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.Data;

@Data
public class ProxyLookupProperties {
    private List<TopicProperties> requestQueues;
    private List<String> responseQueues;

    public Map<String, String> getProxyTopicMap() {
        return requestQueues.stream().collect(Collectors.toMap(TopicProperties::getRegion, TopicProperties::getTemplate));
    }
}

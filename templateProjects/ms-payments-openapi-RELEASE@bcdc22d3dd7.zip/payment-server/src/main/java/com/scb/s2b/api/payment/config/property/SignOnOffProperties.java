package com.scb.s2b.api.payment.config.property;

import lombok.Data;

@Data
public class SignOnOffProperties {

    private Integer maxAttempts = 5;

    private String suspendQueueTemplate;

    private String suspendRouteIdTemplate;
}

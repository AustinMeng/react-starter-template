package com.scb.s2b.api.payment.api;

import static com.scb.s2b.api.payment.config.PaymentConstant.IDENTITY_TYPE_TH;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiIdentity;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.CcsPaymentInstruction;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.processor.request.CcsRequestProcessor;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.CcsPaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.PromptPayPaymentRequestValidator;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.inject.Singleton;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Singleton
public class PromptPayPaymentApiImpl extends ApiBase {

    private final OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;

    private final PromptPayPaymentRequestValidator promptPayValidator;

    private final RequestProcessor requestProcessor;

    private final CcsRequestProcessor ccsRequestProcessor;

    private final CcsPaymentService ccsPaymentService;

    @Autowired
    public PromptPayPaymentApiImpl(OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer,
            PromptPayPaymentRequestValidator promptPayValidator,
            @Qualifier("promptPayRequestProcessor") RequestProcessor requestProcessor,
            @Qualifier("ccsPromptPayRequestProcessor") CcsRequestProcessor ccsRequestProcessor,
            CcsPaymentService ccsPaymentService) {
        this.openApiPaymentInstructionTransformer = openApiPaymentInstructionTransformer;
        this.promptPayValidator = promptPayValidator;
        this.requestProcessor = requestProcessor;
        this.ccsRequestProcessor = ccsRequestProcessor;
        this.ccsPaymentService = ccsPaymentService;
    }

    public Response paymentInitiate(OpenApiPaymentInstruction body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);

        log.info("PromptPay Initiate requestId={}, groupId={}, clientReferenceId={}, paymentType={}", requestId,
                groupId, body.getInstruction().getReferenceId(), body.getInstruction().getPaymentType());

        promptPayValidator.validate(groupId, body);
        Map<String, String> headersMap = this.getHeaders(headers);

        PaymentInstruction paymentInstruction = openApiPaymentInstructionTransformer
                .toPaymentInstruction(body, false, headersMap);
        requestProcessor.process(paymentInstruction);

        CcsPaymentInstruction ccsPaymentInstruction = openApiPaymentInstructionTransformer
                .toCCSPaymentInstruction(body);

        List<PaymentInstruction> paymentInstructions = Collections.singletonList(paymentInstruction);
        ccsRequestProcessor.process(ccsPaymentInstruction, paymentInstructions);
        ccsPaymentService.ccsPaymentInitiate(groupId, ccsPaymentInstruction, paymentInstructions);
        promptPayValidator.cache(paymentInstruction);

        return Response.ok(openApiPaymentInstructionTransformer.toOpenApiPaymentId(paymentInstruction)).build();
    }

}

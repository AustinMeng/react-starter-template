package com.scb.s2b.api.payment.config;

import static com.scb.s2b.api.payment.config.PaymentConstant.HK;
import static com.scb.s2b.api.payment.config.PaymentConstant.PHILIPPINE;
import static com.scb.s2b.api.payment.config.PaymentConstant.SG;
import static com.scb.s2b.api.payment.config.PaymentConstant.SYSTEM;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.client.notification.components.NotificationClient;
import com.scb.s2b.api.instrumentation.service.InstrumentationService;
import com.scb.s2b.api.payment.camel.CommonStatusConsumerAdapter;
import com.scb.s2b.api.payment.camel.JmsConsumerAdapter;
import com.scb.s2b.api.payment.camel.JmsProducerAdapter;
import com.scb.s2b.api.payment.camel.KafkaConsumerAdapter;
import com.scb.s2b.api.payment.camel.KafkaProducerAdapter;
import com.scb.s2b.api.payment.camel.ZkConsumerAdapter;
import com.scb.s2b.api.payment.camel.ZkProducerAdapter;
import com.scb.s2b.api.payment.camel.notification.handler.SNMNotificationHandler;
import com.scb.s2b.api.payment.camel.notification.processor.SNMNotificationProcessor;
import com.scb.s2b.api.payment.config.property.KafkaProperties;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.PaymentTransaction;
import com.scb.s2b.api.payment.entity.refdata.StatusProperties;
import com.scb.s2b.api.payment.entity.scpay.beneficiary.response.BeneRes;
import com.scb.s2b.api.payment.entity.scpay.initiate.response.PaymentRes;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.entity.scpay.proxy.request.ProxyLookupReq;
import com.scb.s2b.api.payment.entity.scpay.proxy.request.header.Header;
import com.scb.s2b.api.payment.entity.scpay.proxy.response.ProxyLookupRes;
import com.scb.s2b.api.payment.instrumentation.PaymentInstrumentationService;
import com.scb.s2b.api.payment.instrumentation.PaymentInstrumentationTransformer;
import com.scb.s2b.api.payment.marshaller.CustomJsonMessageMarshaller;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.marshaller.LocalDateSerializer;
import com.scb.s2b.api.payment.notification.NotificationProducer;
import com.scb.s2b.api.payment.processor.request.CcsRequestProcessor;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.processor.request.step.*;
import com.scb.s2b.api.payment.processor.request.step.ccs.*;
import com.scb.s2b.api.payment.processor.request.step.in.ImpsBicProcessStep;
import com.scb.s2b.api.payment.processor.request.step.in.ImpsDebtorProcessStep;
import com.scb.s2b.api.payment.processor.request.step.validation.OnBehalfOfEnableValidationStep;
import com.scb.s2b.api.payment.repository.CCSTxnRepository;
import com.scb.s2b.api.payment.repository.ClassicDbRepository;
import com.scb.s2b.api.payment.repository.IdSequenceRepository;
import com.scb.s2b.api.payment.repository.MetaRepository;
import com.scb.s2b.api.payment.repository.PaymentMessageRepository;
import com.scb.s2b.api.payment.repository.PaymentTxnRepository;
import com.scb.s2b.api.payment.repository.impl.ClassicDbRepositoryImpl;
import com.scb.s2b.api.payment.repository.impl.IdSequenceRepositoryImpl;
import com.scb.s2b.api.payment.service.CCSService;
import com.scb.s2b.api.payment.service.CCSStatusService;
import com.scb.s2b.api.payment.service.CadmService;
import com.scb.s2b.api.payment.service.CcsPaymentService;
import com.scb.s2b.api.payment.service.LimitService;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.service.PayeePaymentService;
import com.scb.s2b.api.payment.service.PaymentResGroupFilterService;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.service.PaymentStatusService;
import com.scb.s2b.api.payment.service.ReferenceDataService;
import com.scb.s2b.api.payment.service.impl.CCSServiceImpl;
import com.scb.s2b.api.payment.service.impl.CCSStatusServiceImpl;
import com.scb.s2b.api.payment.service.impl.CcsPaymentServiceImpl;
import com.scb.s2b.api.payment.service.impl.LimitServiceImpl;
import com.scb.s2b.api.payment.service.impl.PayeePaymentServiceImpl;
import com.scb.s2b.api.payment.service.impl.PaymentResGroupFilterServiceImpl;
import com.scb.s2b.api.payment.service.impl.PaymentServiceImpl;
import com.scb.s2b.api.payment.service.impl.PaymentStatusServiceImpl;
import com.scb.s2b.api.payment.service.impl.ReferenceDataServiceImpl;
import com.scb.s2b.api.payment.transformer.BanstaReportTransformer;
import com.scb.s2b.api.payment.transformer.BeneficiaryEnquiryTransformer;
import com.scb.s2b.api.payment.transformer.CCSTransactionTransformer;
import com.scb.s2b.api.payment.transformer.KafkaMessageTransformer;
import com.scb.s2b.api.payment.transformer.OpenApiBulkPaymentInstructionTransformer;
import com.scb.s2b.api.payment.transformer.OpenApiPayeeInstructionTransformer;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.transformer.PaymentTransactionStatusTransformer;
import com.scb.s2b.api.payment.transformer.PaymentTransactionTransformer;
import com.scb.s2b.api.payment.transformer.ProxyLookupReqHeaderTransformer;
import com.scb.s2b.api.payment.transformer.ProxyLookupReqTransformerForHK;
import com.scb.s2b.api.payment.transformer.ProxyLookupReqTransformerForPH;
import com.scb.s2b.api.payment.transformer.ProxyLookupReqTransformerForSG;
import com.scb.s2b.api.payment.transformer.ProxyLookupTransformer;
import com.scb.s2b.api.payment.util.CCSFileNameManager;
import com.scb.s2b.api.payment.util.IdGenerator;
import com.scb.s2b.api.payment.util.IdManager;
import com.scb.s2b.api.payment.util.PaymentIdManager;
import com.scb.s2b.api.payment.validation.*;
import com.scb.s2b.api.payment.validation.limit.LimitStore;
import com.scb.s2b.api.payment.validation.limit.MetaLimitStore;
import java.math.BigDecimal;
import java.util.Map;
import java.util.function.Function;
import javax.validation.Validator;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

@SuppressWarnings("unused")
public class PaymentConfig {

    @Value("${payment.maxAmount}")
    private BigDecimal maxAmount;

    @Value("${payment.retryInterval}")
    private long retryInterval;

    @Value("${payment.maxRetry}")
    private int maxRetry;

    @Value("${payment.paynow.centralBic}")
    private String payNowCentralBic;

    @Value("${payment.paynow.paynowPHBic}")
    private String paynowPHBic;

    @Value("${payment.idBlockSize:1000}")
    private Long idBlockSize;

    @Value("${notification.client.kafka.endpoints.paymentStatus}")
    private String notificationClientEndpoint;

    @Value("${payee.baseUrl}")
    private String payeeBaseUrl;

    @Bean
    public PaymentAmountValidator paymentAmountValidator(LimitService limitService) {
        return new PaymentAmountValidator(limitService, maxAmount);
    }

    @Bean
    public NapasPaymentAmountValidator napasPaymentAmountValidator(LimitService limitService) {
        return new NapasPaymentAmountValidator(limitService);
    }

    @Bean
    public SGPaymentAmountValidator sgPaymentAmountValidator(LimitService limitService) {
        return new SGPaymentAmountValidator(limitService, maxAmount);
    }

    @Bean
    public FastPaymentRequestValidator fastPaymentRequestValidator(CacheManager cacheManager,
            SGPaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new FastPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public NapasPaymentRequestValidator napasPaymentRequestValidator(CacheManager cacheManager,
            NapasPaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new NapasPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public PayrollRequestValidator payrollRequestValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new PayrollRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public ImpsPaymentRequestValidator impsPaymentRequestValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new ImpsPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public ImpsProxyPaymentRequestValidator impsProxyPaymentRequestValidator(CacheManager cacheManager,
                                                                   PaymentAmountValidator paymentAmountValidator,
                                                                   ReferenceDataService referenceDataService,
                                                                   PaymentTxnRepository paymentTxnRepository) {
        return new ImpsProxyPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean("paynowRequestValidator")
    public PaynowRequestValidator paynowRequestValidator(CacheManager cacheManager,
            SGPaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new PaynowRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public CrossborderPaymentRequestValidator crossborderPaymentValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new CrossborderPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public NonFastPaymentRequestValidator nonFastPaymentValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new NonFastPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public Psd2PaymentRequestValidator psd2PaymentRequestValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository,
            CadmService cadmService) {
        return new Psd2PaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository, cadmService);
    }

    @Bean
    public BulkPaymentRequestValidator bulkPaymentRequestValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator, ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository, Validator validator) {
        return new BulkPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public InstaPayBankTransferPaymentValidator instaPayBankTransferPaymentValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new InstaPayBankTransferPaymentValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean(name = "instaPayProxyPaymentValidator")
    public InstaPayProxyPaymentValidator instaPayProxyPaymentValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new InstaPayProxyPaymentValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public FpsPaymentValidator fpsPaymentValidator(CacheManager cacheManager,
        PaymentAmountValidator paymentAmountValidator,
        ReferenceDataService referenceDataService,
        PaymentTxnRepository paymentTxnRepository) {
            return new FpsPaymentValidator(cacheManager, paymentAmountValidator, referenceDataService,
                    paymentTxnRepository);
    }

    @Bean
    public FpsProxyPaymentValidator fpsProxyPaymentValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository,
            CadmService cadmService) {
        return new FpsProxyPaymentValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository, cadmService);
    }

    @Bean
    public PromptPayPaymentRequestValidator promptPayPaymentRequestValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new PromptPayPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }

    @Bean
    public PromptPayProxyPaymentRequestValidator promptPayProxyPaymentRequestValidator(CacheManager cacheManager,
            PaymentAmountValidator paymentAmountValidator,
            ReferenceDataService referenceDataService,
            PaymentTxnRepository paymentTxnRepository) {
        return new PromptPayProxyPaymentRequestValidator(cacheManager, paymentAmountValidator, referenceDataService,
                paymentTxnRepository);
    }


    @Bean
    @Primary
    public JsonMessageMarshaller jsonMessageMarshaller() {
        return new JsonMessageMarshaller();
    }

    @Bean(name = "ccsJsonMessageMarshaller")
    public JsonMessageMarshaller ccsJsonMessageMarshaller() {
        return new CustomJsonMessageMarshaller(new LocalDateSerializer());
    }

    @Bean
    public CCSFileNameManager fileNameManager(PaymentIdManager paymentIdManager) {
        return new CCSFileNameManager(paymentIdManager);
    }

    @Bean
    public CCSTransactionTransformer ccsTransactionTransformer() {
        return new CCSTransactionTransformer();
    }

    @Bean
    public PaymentService paymentService(ScpayProperties scpayProperties,
            PaymentTxnRepository paymentTxnRepository,
            PaymentMessageRepository paymentMessageRepository,
            PaymentStatusService paymentStatusService,
            KafkaProducerAdapter kafkaProducer,
            JmsProducerAdapter jmsProducer,
            JsonMessageMarshaller messageMarshaller,
            PaymentTransactionTransformer paymentTransactionTransformer,
            PaymentTransactionStatusTransformer paymentTransactionStatusTransformer,
            BeneficiaryEnquiryTransformer beneficiaryEnquiryTransformer,
            ProxyLookupTransformer proxyLookupTransformer,
            PaymentInstrumentationService instrumentationService) {
        return new PaymentServiceImpl(scpayProperties, paymentTxnRepository,
                paymentMessageRepository, paymentStatusService, kafkaProducer,
                jmsProducer, messageMarshaller, paymentTransactionTransformer,
                paymentTransactionStatusTransformer, beneficiaryEnquiryTransformer, proxyLookupTransformer,
                instrumentationService);
    }

    @Bean
    public CCSService ccsService(PaymentService paymentService,
            CCSTransactionTransformer ccsTransactionTransformer,
            CCSTxnRepository ccsTxnRepository,
            CCSFileNameManager ccsFileNameManager) {
        return new CCSServiceImpl(paymentService, ccsTransactionTransformer, ccsTxnRepository, ccsFileNameManager);
    }

    @Bean
    public CcsPaymentService ccsPaymentService(
            PaymentTransactionTransformer paymentTransactionTransformer,
            @Qualifier("ccsJsonMessageMarshaller") JsonMessageMarshaller messageMarshaller,
            PaymentMessageRepository paymentMessageRepository,
            KafkaProducerAdapter kafkaProducer,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            CCSService ccsService,
            IdGenerator idGenerator, CCSTransactionTransformer ccsTransactionTransformer,
            PaymentInstrumentationService instrumentationService) {
        return new CcsPaymentServiceImpl(paymentTransactionTransformer,
                messageMarshaller,
                paymentMessageRepository,
                kafkaProducer,
                kafkaProperties.getEndpoints().get("ccsAgentExport"), ccsService, idGenerator,
                ccsTransactionTransformer, instrumentationService);
    }

    @Bean
    public ZkConsumerAdapter zkConsumerAdapter(
            Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap) {
        return new ZkConsumerAdapter(eventCodeHandlerMap);
    }

    @Bean
    public ZkProducerAdapter zkProducerAdapter(@Value("${zookeeper.brokers}") String zkBrokers,
            ScpayProperties scpayProperties, ProducerTemplate producerTemplate) {
        return new ZkProducerAdapter(
                zkBrokers, scpayProperties, producerTemplate);
    }

    @Bean
    public KafkaConsumerAdapter kafkaConsumerAdapter(PaymentService paymentService,
            PaymentStatusService paymentStatusService,
            JsonMessageMarshaller messageMarshaller,
            ProducerTemplate producer,
            MaintenanceService maintenanceService,
            ScpayProperties scpayProperties, IdGenerator idGenerator,
            CCSStatusService ccsStatusService,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            ReferenceDataService referenceDataService) {
        return new KafkaConsumerAdapter(retryInterval, maxRetry,
                kafkaProperties.getEndpoints().get("paymentInitiateRetry"),
                kafkaProperties.getEndpoints().get("paymentInitiate"),
                paymentService, paymentStatusService, messageMarshaller, producer,
                maintenanceService,
                scpayProperties.getNotification(), idGenerator,
                ccsStatusService, referenceDataService);
    }

    @Bean
    public KafkaProducerAdapter kafkaProducerAdapter(ProducerTemplate producerTemplate,
            KafkaMessageTransformer messageTransformer,
            JsonMessageMarshaller messageMarshaller,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties) {
        return new KafkaProducerAdapter(kafkaProperties.getEndpoints().get("paymentInitiate"),
                kafkaProperties.getEndpoints().get("ccsAgentImport"),
                producerTemplate, messageMarshaller);
    }

    @Bean
    public JmsProducerAdapter jmsProducerAdapter(ProducerTemplate producerTemplate) {
        return new JmsProducerAdapter(producerTemplate);
    }

    @Bean
    public JmsConsumerAdapter jmsConsumerAdapter(PaymentStatusService paymentStatusService,
            JsonMessageMarshaller messageMarshaller,
            SNMNotificationProcessor notificationProcessor,
            IdGenerator idGenerator) {
        return new JmsConsumerAdapter(paymentStatusService, messageMarshaller, notificationProcessor, idGenerator);
    }

    @Bean
    public PaymentTransactionStatusTransformer transactionStatusTransformer(
            JsonMessageMarshaller jsonMessageMarshaller, IdGenerator idGenerator) {
        return new PaymentTransactionStatusTransformer(jsonMessageMarshaller, idGenerator);
    }

    @Bean
    @ConfigurationProperties("payment.status")
    public StatusProperties statusProperties() {
        return new StatusProperties();
    }
    @Primary
    @Bean
    public OpenApiPaymentInstructionTransformer paymentIntructionTransformer(CadmService cadmService) {
        return new OpenApiPaymentInstructionTransformer(cadmService);
    }

    @Bean
    public PaymentTransactionTransformer paymentTransactionTransformer(JsonMessageMarshaller jsonMessageMarshaller,
            IdGenerator idGenerator) {
        return new PaymentTransactionTransformer(jsonMessageMarshaller, idGenerator);
    }

    @Bean
    public Function<PaymentTransaction, Header> proxyLookupReqHeaderTransformer() {
        return new ProxyLookupReqHeaderTransformer();
    }

    @Bean
    public Function<PaymentTransaction, ProxyLookupReq> proxyLookupReqTransformerForSG(
            @Qualifier("proxyLookupReqHeaderTransformer") Function<PaymentTransaction, Header> headerTransformer
    ) {
        return new ProxyLookupReqTransformerForSG(
                payNowCentralBic,
                headerTransformer
        );
    }

    @Bean
    public Function<PaymentTransaction, ProxyLookupReq> proxyLookupReqTransformerForPH(
            @Qualifier("proxyLookupReqHeaderTransformer") Function<PaymentTransaction, Header> headerTransformer
    ) {
        return new ProxyLookupReqTransformerForPH(paynowPHBic, headerTransformer);
    }

    @Bean
    public Function<PaymentTransaction, ProxyLookupReq> proxyLookupReqTransformerForHK(
            @Qualifier("proxyLookupReqHeaderTransformer") Function<PaymentTransaction, Header> headerTransformer
    ) {
        return new ProxyLookupReqTransformerForHK(headerTransformer);
    }

    @Bean
    public ProxyLookupTransformer proxyLookupTransformer(
            @Qualifier("proxyLookupReqTransformerForSG") Function<PaymentTransaction, ProxyLookupReq> reqTransformerForSG,
            @Qualifier("proxyLookupReqTransformerForPH") Function<PaymentTransaction, ProxyLookupReq> reqTransformerForPH,
            @Qualifier("proxyLookupReqTransformerForHK") Function<PaymentTransaction, ProxyLookupReq> reqTransformerForHK,
            ReferenceDataService referenceDataService
    ) {
        return new ProxyLookupTransformer(
                ImmutableMap.of(
                        SG, reqTransformerForSG,
                        HK, reqTransformerForHK,
                        PHILIPPINE, reqTransformerForPH
                ),
                referenceDataService);
    }

    @Bean
    public BeneficiaryEnquiryTransformer beneficiaryEnquiryTransformer(IdGenerator idGenerator) {
        return new BeneficiaryEnquiryTransformer(idGenerator);
    }

    @Bean
    public KafkaMessageTransformer kafkaMessageTransformer(JsonMessageMarshaller messageMarshaller) {
        return new KafkaMessageTransformer(messageMarshaller);
    }

    @Bean
    public BanstaReportTransformer banstaReportTransformer() {
        return new BanstaReportTransformer();
    }

    @Bean
    public OpenApiBulkPaymentInstructionTransformer openApiBulkPaymentInstructionTransformer(CadmService cadmService) {
        return new OpenApiBulkPaymentInstructionTransformer(cadmService);
    }

    @Bean
    public PaymentStatusService paymentStatusService(PaymentTxnRepository paymentTxnRepository,
            PaymentMessageRepository paymentMessageRepository,
            KafkaProducerAdapter kafkaProducer,
            JsonMessageMarshaller jsonMessageMarshaller,
            PaymentTransactionTransformer paymentTransactionTransformer,
            PaymentTransactionStatusTransformer paymentTransactionStatusTransformer,
            NotificationProducer notificationProducer,
            PaymentInstrumentationService instrumentationService,
            ProxyLookupTransformer proxyLookupTransformer) {
        return new PaymentStatusServiceImpl(paymentTxnRepository, paymentMessageRepository,
                kafkaProducer, jsonMessageMarshaller, paymentTransactionTransformer,
                paymentTransactionStatusTransformer, notificationProducer, instrumentationService, proxyLookupTransformer);
    }

    @Bean
    public PaymentResGroupFilterService paymentResGroupFilterService(StatusProperties statusProperties) {
        return new PaymentResGroupFilterServiceImpl(statusProperties);
    }

    @Bean
    public CommonStatusConsumerAdapter statusConsumerAdapter(
            ProducerTemplate producer,
            JmsConsumerAdapter consumerAdapter,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            JsonMessageMarshaller messageMarshaller) {
        return new CommonStatusConsumerAdapter<PaymentRes>(retryInterval, maxRetry,
                kafkaProperties.getEndpoints().get("paymentStatusRetry"),
                producer,
                messageMarshaller::marshallToJsonByteArray,
                (paymentRes, retry) -> consumerAdapter.consumeScpayPaymentStatus(paymentRes),
                paymentRes ->{});
    }

    @Bean
    public CommonStatusConsumerAdapter proxyResConsumerAdapter(
            ProducerTemplate producer,
            JmsConsumerAdapter consumerAdapter,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            JsonMessageMarshaller messageMarshaller) {
        return new CommonStatusConsumerAdapter<ProxyLookupRes>(retryInterval, maxRetry,
                kafkaProperties.getEndpoints().get("paymentProxyResRetry"),
                producer,
                messageMarshaller::marshallToJsonByteArray,
                (proxyLookupRes, retry) -> consumerAdapter.consumeProxylookupResponse(proxyLookupRes),
                proxyLookupRes ->{});
    }

    @Bean
    public CommonStatusConsumerAdapter beneResConsumerAdapter(
            ProducerTemplate producer,
            JmsConsumerAdapter consumerAdapter,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            JsonMessageMarshaller messageMarshaller) {
        return new CommonStatusConsumerAdapter<BeneRes>(retryInterval, maxRetry,
                kafkaProperties.getEndpoints().get("paymentBeneResRetry"),
                producer,
                messageMarshaller::marshallToJsonByteArray,
                (beneRes, retry) -> consumerAdapter.consumeBeneResponse(beneRes),
                beneRes ->{});
    }

    @Bean
    public CCSStatusService ccsStatusService(PaymentTxnRepository paymentTxnRepository,
            CCSTxnRepository ccsTxnRepository,
            PaymentStatusService paymentStatusService,
            PaymentTransactionTransformer paymentTransactionTransformer,
            PaymentTransactionStatusTransformer paymentTransactionStatusTransformer,
            BanstaReportTransformer banstaReportTransformer) {
        return new CCSStatusServiceImpl(paymentTxnRepository, ccsTxnRepository, paymentStatusService,
                paymentTransactionTransformer, paymentTransactionStatusTransformer, banstaReportTransformer);
    }

    @Bean
    public IdSequenceRepository idSequenceRepository(@Qualifier("apibankingJdbcTemplate") JdbcTemplate jdbcTemplate) {
        return new IdSequenceRepositoryImpl(jdbcTemplate);
    }

    @Bean
    public IdManager idManager(IdSequenceRepository idSequenceRepository) {
        return new PaymentIdManager(idSequenceRepository, p -> idBlockSize);
    }

    @Bean
    public ReferenceDataService referenceDataService(MetaRepository metaRepository) {
        return new ReferenceDataServiceImpl(metaRepository);
    }

    @Bean(name = "fastRequestProcessor")
    public RequestProcessor fastRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            ScpayProperties scpayProperties,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_FAST_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_FAST_PROPERTIES)),
                new TargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new BeneficiaryEnquiryFlagProcessStep(scpayProperties.getBeneficiaryEnquiry().isEnabled()),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "napasRequestProcessor")
    public RequestProcessor napasRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            ScpayProperties scpayProperties,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_NAPAS_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_NAPAS_PROPERTIES)),
                new TargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new BeneficiaryEnquiryFlagProcessStep(scpayProperties.getBeneficiaryEnquiry().isEnabled()),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "instaPayPaymentRequestProcessor")
    public RequestProcessor instaPayPaymentRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            ScpayProperties scpayProperties,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_INSTAPAY_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_INSTAPAY_PROPERTIES)),
                new TargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new BeneficiaryEnquiryFlagProcessStep(scpayProperties.getBeneficiaryEnquiry().isEnabled()),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "fpsRequestProcessor")
    public RequestProcessor fpsRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            ScpayProperties scpayProperties,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_FPS_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_FPS_PROPERTIES)),
                new TargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new BeneficiaryEnquiryFlagProcessStep(scpayProperties.getBeneficiaryEnquiry().isEnabled()),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "impsRequestProcessor")
    public RequestProcessor impsRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_INIMPS_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_INIMPS_PROPERTIES)),
                new TargetSystemProcessStep(),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new ImpsBicProcessStep(),
                new ImpsDebtorProcessStep(),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "impsProxyRequestProcessor")
    public RequestProcessor impsProxyRequestProcessor(ReferenceDataService referenceDataService,
                                                 ClassicDbRepository classicDbRepository,
                                                 IdGenerator idGenerator,
                                                 CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_INIMPS_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_INIMPS_PROPERTIES)),
                new TargetSystemProcessStep(),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new ImpsBicProcessStep(),
                new ImpsDebtorProcessStep(),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "paynowRequestProcessor")
    public RequestProcessor paynowRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new ProxyEnquiryFlagProcessStep(),
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_PAYNOW_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_PAYNOW_PROPERTIES)),
                new TargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "instaPayProxyRequestProcessor")
    public RequestProcessor instaPayProxyRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new ProxyEnquiryFlagProcessStep(),
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_INSTAPAY_PROXY_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_INSTAPAY_PROXY_PROPERTIES)),
                new TargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "fpsProxyRequestProcessor")
    public RequestProcessor fpsProxyRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new ProxyEnquiryFlagProcessStep(),
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_FPS_PROXY_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_FPS_PROXY_PROPERTIES)),
                new TargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "crossborderRequestProcessor")
    public RequestProcessor crossborderRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_CROSSBORDER_PROPERTIES)),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator),
                new CcsTargetSystemProcessStep()
        ));
    }

    @Bean(name = "ccsRequestProcessor")
    public CcsRequestProcessor ccsRequestProcessor(ReferenceDataService referenceDataService) {
        return new CcsRequestProcessor(ImmutableList.of(new CcsMandatoryFieldsProcessorStep(),
                new CcsImdLookupProcessStep(referenceDataService),new CcsBicProcessStep()));
    }

    @Bean(name = "mwpCcsRequestProcessor")
    public CcsRequestProcessor mwpCcsRequestProcessor(ReferenceDataService referenceDataService) {
        return new CcsRequestProcessor(ImmutableList.of(new CcsMandatoryFieldsProcessorStep()));
    }

    @Bean(name = "mwpRequestProcessor")
    public RequestProcessor mwpRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            ScpayProperties scpayProperties) {
        return new RequestProcessor(ImmutableList.of(
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_MWP_PROPERTIES)),
                new CcsTargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new BeneficiaryEnquiryFlagProcessStep(scpayProperties.getBeneficiaryEnquiry().isEnabled()),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "psd2RequestProcessor")
    public RequestProcessor psd2RequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            ScpayProperties scpayProperties) {
        return new RequestProcessor(ImmutableList.of(
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_PSD2_PROPERTIES)),
                new TargetSystemProcessStep(),
                new CcsTargetSystemProcessStep(),
                new BicLookupProcessStep(referenceDataService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new BeneficiaryEnquiryFlagProcessStep(scpayProperties.getBeneficiaryEnquiry().isEnabled()),
                new PaymentIdProcessStep(idGenerator)
        ));
    }

    @Bean(name = "nonfastRequestProcessor")
    public RequestProcessor nonfastRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_PROPERTIES)),
                new BicLookupProcessNonFastStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator),
                new CcsTargetSystemProcessStep()
        ));
    }

    @Bean(name = "bulkRequestProcessor")
    public RequestProcessor bulkRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_BULK_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_BULK_PROPERTIES)),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator),
                new CcsTargetSystemProcessStep()
        ));
    }

    @Bean(name = "payrollRequestProcessor")
    public RequestProcessor payrollRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_PAYROLL_PROPERTIES)),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator),
                new CcsTargetSystemProcessStep()
        ));
    }

    @Bean(name = "promptPayRequestProcessor")
    public RequestProcessor promptPayRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_PROMPTPAY_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_PROMPTPAY_PROPERTIES)),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator),
                new CcsTargetSystemProcessStep()
        ));
    }

    @Bean(name = "ccsPromptPayRequestProcessor")
    public CcsRequestProcessor ccsPromptPayRequestProcessor() {
        return new CcsRequestProcessor(ImmutableList.of(new CcsMandatoryFieldsProcessorStep(), new CcsPromptPayProcessStep()));
    }

    @Bean(name = "promptPayProxyRequestProcessor")
    public RequestProcessor promptPayProxyRequestProcessor(ReferenceDataService referenceDataService,
            ClassicDbRepository classicDbRepository,
            IdGenerator idGenerator,
            CadmService cadmService) {
        return new RequestProcessor(ImmutableList.of(
                new ProxyEnquiryFlagProcessStep(),
                new PaymentTypeProcessStep(() -> referenceDataService
                        .getPaymentProperties(SYSTEM, ReferenceDataService.META_PAYMENT_PROMPTPAY_PROPERTIES)),
                new DefaultAttributesProcessStep(groupId -> referenceDataService
                        .getPaymentProperties(groupId, ReferenceDataService.META_PAYMENT_PROMPTPAY_PROXY_PROPERTIES)),
                new BicLookupProcessStep(referenceDataService),
                new OnBehalfOfEnableValidationStep(cadmService),
                new DebtorProcessStep(classicDbRepository),
                new CustomerIdProcessStep(classicDbRepository),
                new RequiredExecutionDateProcessStep(),
                new PaymentIdProcessStep(idGenerator),
                new CcsTargetSystemProcessStep()
        ));
    }

    @Bean
    public ClassicDbRepository classicDbRepository(@Qualifier("classicJdbcTemplate") JdbcTemplate jdbcTemplate) {
        return new ClassicDbRepositoryImpl(jdbcTemplate);
    }

    @Bean
    public IdGenerator uuidGenerator(IdManager idManager) {
        return new IdGenerator(idManager, paynowPHBic);
    }

    @Bean
    public LimitStore limitStore(ReferenceDataService referenceDataService) {
        return new MetaLimitStore(referenceDataService);
    }

    @Bean
    public LimitService limitService(LimitStore limitStore) {
        return new LimitServiceImpl(limitStore);
    }

    @Bean
    public NotificationProducer notificationProducer(NotificationClient notificationClient,
            PaymentTransactionStatusTransformer paymentTransactionStatusTransformer) {
        return new NotificationProducer(notificationClient, notificationClientEndpoint,
                paymentTransactionStatusTransformer);
    }

    @Bean
    public PaymentInstrumentationService collectionInstrumentationService(
            InstrumentationService instrumentationService,
            PaymentInstrumentationTransformer paymentInstrumentationTransformer,
            JsonMessageMarshaller messageMarshaller) {
        return new PaymentInstrumentationService(instrumentationService, paymentInstrumentationTransformer,
                messageMarshaller);
    }

    @Bean
    public PaymentInstrumentationTransformer collectionInstrumentationTransformer() {
        return new PaymentInstrumentationTransformer();
    }

    @Bean
    @Profile("!test")
    public PayeePaymentService payeePaymentService(RestTemplate restTemplate,
            ReferenceDataService referenceDataService) {
        return new PayeePaymentServiceImpl(payeeBaseUrl, restTemplate, referenceDataService);
    }

    @Bean
    public OpenApiPayeeInstructionTransformer openApiPayeeInstructionTransformer() {
        return new OpenApiPayeeInstructionTransformer();
    }
}


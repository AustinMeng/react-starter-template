package com.scb.s2b.api.payment.entity.refdata;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class SuspendableCountriesTypes {
    private Set<String> countries;
}

# Payment

## Components
![Components Diagram](./doc/images/components.png)

## Use cases
### Fast payment via SCPay
![Fast payment via SCPay](./doc/images/scpay_fast_payment_initiate.png)

### Proxy payment via SCPay
![Proxy payment via SCPay](./doc/images/scpay_proxy_payment_initiate.png)

### Payment via CCS
![Payment via CCS](./doc/images/ccs_payment_initiate.png)

## Swagger UI

```
http://host:port/index.html
```

## Run PaymentApiApp in Intellij
### Add program arguments
```
--spring.config.location=classpath:/config/dev/application.yml --spring.hazelcast.config=classpath:config/dev/hc.yml
```
package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class EnumInfo {

    private final String name;
    private final String definition;

    public String name() {
        return name;
    }

    public String definition() {
        return definition;
    }

    @Override
    public String toString() {
        return name + " (" + definition + ")";
    }
}


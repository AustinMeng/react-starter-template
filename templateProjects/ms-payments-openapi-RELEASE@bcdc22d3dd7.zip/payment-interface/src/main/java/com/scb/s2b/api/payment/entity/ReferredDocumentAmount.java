package com.scb.s2b.api.payment.entity;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class ReferredDocumentAmount {

    @Builder.Default
    private DenominatedAmount duePayableAmount = DenominatedAmount.ZERO;

    @Builder.Default
    private DenominatedAmount discountAppliedAmount = DenominatedAmount.ZERO;

    @Builder.Default
    private DenominatedAmount creditNoteAmount = DenominatedAmount.ZERO;

    @Builder.Default
    private DenominatedAmount taxAmount = DenominatedAmount.ZERO;

    @Builder.Default
    private DenominatedAmount adjustmentAmount = DenominatedAmount.ZERO;

    @Builder.Default
    private DenominatedAmount remittedAmount = DenominatedAmount.ZERO;

}

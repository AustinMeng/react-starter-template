package com.scb.s2b.api.payment.entity;

import com.scb.s2b.api.payment.entity.AccountIdentifier.IdentifierType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import nl.garvelink.iban.IBAN;
import org.apache.commons.lang3.StringUtils;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class AccountHeader implements ExternalCodes {

    private String identifier;

    private String iban;

    private CashAccountType type;

    @Builder.Default
    private CurrencyCode currencyCode = new CurrencyCode();

    private String name;

    private String s2bCustomerId;

    private IdentifierType identifierType;

    public AccountHeader(String identifier, String iban, CashAccountType type, String name,
            String s2bCustomerId, CurrencyCode currencyCode, IdentifierType identifierType) {
        this.identifier = identifier;
        this.iban = StringUtils.isNotBlank(iban) ? IBAN.parse(iban).toPlainString() : null;
        this.type = type;
        this.name = name;
        this.s2bCustomerId = s2bCustomerId;
        this.currencyCode = currencyCode;
        this.identifierType = identifierType;
    }

    public boolean hasIBAN() {
        return StringUtils.isNotBlank(iban);
    }

    public String getCommonId() {
        return this.identifier != null ? this.identifier : this.iban;
    }

    public AccountId toAccountId() {
        return new AccountId(identifier, currencyCode, null);
    }

}



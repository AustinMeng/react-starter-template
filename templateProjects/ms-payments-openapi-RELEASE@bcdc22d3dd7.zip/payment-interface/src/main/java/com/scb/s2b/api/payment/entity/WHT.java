package com.scb.s2b.api.payment.entity;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class WHT {

    private String type;

    private String description;

    private BigDecimal grossAmount;

    private BigDecimal amount;

}

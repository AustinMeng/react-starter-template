package com.scb.s2b.api.payment.entity;

import java.util.ArrayList;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class ReferredDocumentInformation implements ExternalCodes {

    private String proprietaryCode;

    @Builder.Default
    private DocumentType documentType = DocumentType.CINV;

    private String number;

    private LocalDate relatedDate;

    @Builder.Default
    private List<LineDetail> lineDetails = new ArrayList<>();

}

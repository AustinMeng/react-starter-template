package com.scb.s2b.api.payment.entity;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class Meta {

    private String messageId;

    @Builder.Default
    private Instant timestamp = Instant.now();

    @Builder.Default
    private PartyIdentifier initiatingParty = new PartyIdentifier();

    private String initiatingPartyMessageId;

    private String authenticationToken;

    @Builder.Default
    private MetaTags tags = new MetaTags();

    @Builder.Default
    private TppConsentDetails tppConsentDetails = new TppConsentDetails();

}
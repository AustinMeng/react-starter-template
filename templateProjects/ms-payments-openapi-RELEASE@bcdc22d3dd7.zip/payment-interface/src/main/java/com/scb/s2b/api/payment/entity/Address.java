package com.scb.s2b.api.payment.entity;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class Address implements Serializable {

    public enum AddressType {ADDR, PBOX, HOME, BIZZ, MLTO, DLVY}

    @Builder.Default
    private AddressType addressType = AddressType.ADDR;

    private String department;

    private String subDepartment;

    private String streetName;

    private String buildingNumber;

    private String townName;

    private String postCode;

    private String countrySubDivision;

    @Builder.Default
    private Country country = new Country();

    private List<String> addressLines;

}

package com.scb.s2b.api.payment.entity;

import static org.apache.commons.lang3.StringUtils.EMPTY;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class PaymentType implements ExternalCodes {

    private String code;

    @Builder.Default
    private InstructionPriority instructionPriority = InstructionPriority.NORM;

    private ServiceLevel serviceLevel;

    private LocalInstrumentType localInstrument;

    private String proprietaryLocalInstrument;

    private CategoryPurposeCode categoryPurpose;

    public boolean hasProprietaryLocalInstrument() {
        return StringUtils.isNotBlank(proprietaryLocalInstrument);
    }

    public String categoryPurposeCode() {
        return categoryPurpose == CategoryPurposeCode.OTHR ? EMPTY
                : categoryPurpose.getInfo().name();
    }
}

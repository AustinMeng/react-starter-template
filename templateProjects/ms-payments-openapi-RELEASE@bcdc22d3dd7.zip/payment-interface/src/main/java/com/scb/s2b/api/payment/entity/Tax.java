package com.scb.s2b.api.payment.entity;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class Tax {

    @Builder.Default
    private TaxParty creditor = new TaxParty();

    @Builder.Default
    private TaxParty debtor = new TaxParty();

    private String administrationZone;

    private String referenceNumber;

    private String method;

    @Builder.Default
    private DenominatedAmount totalTaxableBaseAmount = DenominatedAmount.ZERO;

    @Builder.Default
    private DenominatedAmount totalTaxAmount = DenominatedAmount.ZERO;

    private LocalDate date;

    private String sequenceNumber;

}

package com.scb.s2b.api.payment.entity;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class
PayeeInstruction {
    private String groupId;
    private String clientReferenceId;
    private String nickName;
    private String messageId;
    
    @Builder.Default
    private Instant timestamp = Instant.now();
}

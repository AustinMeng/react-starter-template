package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Getter
public class AccountId {

    private String accountId;

    private CurrencyCode currencyCode = new CurrencyCode();

    private String bankCode;

}

package com.scb.s2b.api.payment.entity;


import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class Garnishment {

    private String type;

    @Builder.Default
    private PartyIdentifier garnishee = new PartyIdentifier();

    @Builder.Default
    private PartyIdentifier garnishmentAdministrator = new PartyIdentifier();

    private String referenceNumber;

    private LocalDate dateTime;

    @Builder.Default
    private DenominatedAmount remittedAmount = DenominatedAmount.ZERO;

    private boolean familyMedicalInsurance;

    private boolean employeeTerminated;

}

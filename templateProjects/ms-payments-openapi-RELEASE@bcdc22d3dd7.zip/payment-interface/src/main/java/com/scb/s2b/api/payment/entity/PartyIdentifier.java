package com.scb.s2b.api.payment.entity;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class PartyIdentifier implements Serializable {

    private String groupId;

    private String leId;

    private String name;

    private String displayName;

    @Builder.Default
    private Address postalAddress = new Address();

    private String id;

    @Builder.Default
    private Country countryOfResidence = new Country();

    @Builder.Default
    private Contact contactDetails = new Contact();

    @Builder.Default
    private PartyIdentity partyIdentity = new PartyIdentity();

    private String stsId;

    private String referenceId;

    private String jointBeneficiaryName;

    private String jointBeneficiaryIdentity;

    private String jointBeneficiaryIdentityType;

    private String type;

}

package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class TaxParty {

    private String taxIdentification;

    private String registrationIdentification;

    private String taxType;

    private String authorizationName;

    private String authorizationTitle;

}

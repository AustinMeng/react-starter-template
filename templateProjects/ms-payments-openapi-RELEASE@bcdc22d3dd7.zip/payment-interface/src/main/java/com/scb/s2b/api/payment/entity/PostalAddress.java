package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class PostalAddress {

    private String line_1;
    private String line_2;
    private String line_3;
    private String line_4;
    private String city;
    private String postcode;
    private String country;
}

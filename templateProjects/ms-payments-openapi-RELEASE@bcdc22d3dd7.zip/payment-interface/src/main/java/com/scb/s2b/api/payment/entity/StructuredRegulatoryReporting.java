package com.scb.s2b.api.payment.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class StructuredRegulatoryReporting {

    private String type;

    private LocalDate dateTime;

    @Builder.Default
    private Country country = new Country();

    private String cd;

    @Builder.Default
    private DenominatedAmount amount = DenominatedAmount.ZERO;

    @Builder.Default
    private List<String> info = new ArrayList<>();

}

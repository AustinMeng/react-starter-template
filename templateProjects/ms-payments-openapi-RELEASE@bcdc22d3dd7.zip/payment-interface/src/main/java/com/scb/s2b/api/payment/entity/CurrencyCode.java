package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class CurrencyCode implements Serializable {

    public static final CurrencyCode ALL = new CurrencyCode("ALL");

    private String isoCode;

    public static CurrencyCode of(String currencyCode) {
        return new CurrencyCode(currencyCode);
    }

}

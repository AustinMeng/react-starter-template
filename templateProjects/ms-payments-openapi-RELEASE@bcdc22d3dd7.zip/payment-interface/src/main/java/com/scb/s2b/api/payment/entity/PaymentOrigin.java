package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class PaymentOrigin {

    private Country country = new Country();

    private String scheme;

}

package com.scb.s2b.api.payment.entity;


import com.scb.s2b.api.openapi.payment.v2.model.OpenApiInstructions;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class BranchAndInstituteHeader implements ExternalCodes {

    public enum Type {
        CH("CH"),
        AC("AC"),
        SW("SW"),
        CP("CP"),
        FW("FW"),
        SC("SC"),
        TX("TX");

        private final String type;
        private final static Map<String, Type> types = Stream.of(values())
                .collect(Collectors.toMap(Type::getType, t -> t));

        Type(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        public static Type fromType(String type) {
            return types.get(type);
        }
    }

    private String bicfi;

    private String clearingSystemIdentification;

    @Builder.Default
    private ClearingSystemIdentificationType clearingSystemIdentificationType = ClearingSystemIdentificationType.GBDSC;

    private String name;

    @Builder.Default
    private Address postalAddress = new Address();

    private String routingCode;

    private String s2bCustomerId;

    private String branchIdentifier;

    private String branchName;

    private String subBranchCode;

    private Type type;

    @Builder.Default
    private Address branchAddress = new Address();

    @Builder.Default
    private List<OpenApiInstructions> instructions = new ArrayList<>();

}

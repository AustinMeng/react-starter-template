package com.scb.s2b.api.payment.entity;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@Builder
public class OnBehalfOf {

    private boolean provided;

    private String name;

    @Builder.Default
    private Address postalAddress = new Address();

    @Builder.Default
    private AccountHeader account = new AccountHeader();

    private String oboType;

    private String partyIdentifierCode;

    private String partyIdentifierValue;

    private String partyIdentifierCountry;

    private String partyIdentifierIssuer;

    private String partyIdentifierRegisteringAuthority;

    private String partyIdentifierIssuingAuthority;

    private List<OboAddressCode> oboAddressCodes;

    private String oboAddressLineIssuer;

    private String oboAddressLineIssuerLL;

}

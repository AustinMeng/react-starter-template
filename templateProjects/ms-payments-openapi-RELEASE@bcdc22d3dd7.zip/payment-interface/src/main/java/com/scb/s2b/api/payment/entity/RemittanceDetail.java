package com.scb.s2b.api.payment.entity;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@Builder
public class RemittanceDetail {

    private String unstructured;

    @Builder.Default
    private StructuredRemittance structured = new StructuredRemittance();

    private List<String> multiUnstructured;

}

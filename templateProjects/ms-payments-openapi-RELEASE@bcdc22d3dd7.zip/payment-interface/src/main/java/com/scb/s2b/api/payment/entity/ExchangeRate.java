package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class ExchangeRate {

    public enum ExchangeRateType {
        NONE("Z"),
        SPOT("S"),
        SALE("A"),
        AGRD("A");

        private final String s2bCode;

        ExchangeRateType(String s2bCode) {
            this.s2bCode = s2bCode;
        }

        public String getS2bCode() {
            return s2bCode;
        }
    }

    public static final ExchangeRate ZERO = new ExchangeRate(new CurrencyCode("USD"), BigDecimal.ZERO, ExchangeRateType.NONE, "");

    private CurrencyCode unitCcy;

    private BigDecimal exchangeRate;

    private ExchangeRateType rateType;

    private String contractId;

}

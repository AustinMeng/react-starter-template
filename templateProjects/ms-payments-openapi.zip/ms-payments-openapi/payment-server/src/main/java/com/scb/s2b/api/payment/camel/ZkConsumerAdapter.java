package com.scb.s2b.api.payment.camel;

import com.scb.s2b.api.payment.camel.notification.handler.SNMNotificationHandler;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode.*;

@Slf4j
public class ZkConsumerAdapter {

    private final Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap;

    @Autowired
    public ZkConsumerAdapter(Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap) {
        this.eventCodeHandlerMap = eventCodeHandlerMap;
    }

    public void watchSignOnOffNotificationEvent(String messageId) {
        log.info("Receiving notification event for messageId={}.", messageId);
        eventCodeHandlerMap.get(SCPAY_SIGN_OFF).handleEvent(messageId);
        log.info("Handling notification event messageId={} done.", messageId);
    }

    public void watchBankDefaultBroadcastNotificationEvent(String messageId) {
        log.info("Receiving notification event for messageId={}.", messageId);
        eventCodeHandlerMap.get(BANK_DEFAULT_BROADCAST).handleEvent(messageId);
        log.info("Handling notification event messageId={} done.", messageId);
    }

    public void watchBankStatusBroadcastNotificationEvent(String messageId) {
        log.info("Receiving notification event for messageId={}.", messageId);
        eventCodeHandlerMap.get(BANK_STATUS_BROADCAST).handleEvent(messageId);
        log.info("Handling notification event messageId={} done.", messageId);
    }

    public void watchSystemStatusBroadcastNotificationEvent(String messageId) {
        log.info("Receiving notification event for messageId={}.", messageId);
        eventCodeHandlerMap.get(SYSTEM_STATUS_BROADCASE).handleEvent(messageId);
        log.info("Handling notification event messageId={} done.", messageId);
    }

    public void watchBankStatusBroadcastForPHNotificationEvent(String messageId) {
        log.info("Receiving notification event for messageId={}.", messageId);
        eventCodeHandlerMap.get(BANK_STATUS_BROADCAST_PH).handleEvent(messageId);
        log.info("Handling notification event messageId={} done.", messageId);
    }
}

package com.scb.s2b.api.payment.api.exceptionmapper;


import com.google.common.collect.Maps;
import java.util.Map;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

public class PaymentNotFoundExceptionMapper implements ExceptionMapper<NotFoundException> {
    @Override
    public Response toResponse(NotFoundException e) {
        Map<String, String> result = Maps.newHashMap();
        result.put("errorMessage", e.getMessage());
        return Response.status(Response.Status.NOT_FOUND).entity(result).build();
    }
}

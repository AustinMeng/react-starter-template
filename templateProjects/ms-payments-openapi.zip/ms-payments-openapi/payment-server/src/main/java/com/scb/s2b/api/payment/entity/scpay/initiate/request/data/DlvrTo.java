
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tp",
    "cntrPickupLctn",
    "nm",
    "pstlAdr"
})
public class DlvrTo {

    @JsonProperty("tp")
    private String tp;
    @JsonProperty("cntrPickupLctn")
    private String cntrPickupLctn;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tp")
    public String getTp() {
        return tp;
    }

    @JsonProperty("tp")
    public void setTp(String tp) {
        this.tp = tp;
    }

    public DlvrTo withTp(String tp) {
        this.tp = tp;
        return this;
    }

    @JsonProperty("cntrPickupLctn")
    public String getCntrPickupLctn() {
        return cntrPickupLctn;
    }

    @JsonProperty("cntrPickupLctn")
    public void setCntrPickupLctn(String cntrPickupLctn) {
        this.cntrPickupLctn = cntrPickupLctn;
    }

    public DlvrTo withCntrPickupLctn(String cntrPickupLctn) {
        this.cntrPickupLctn = cntrPickupLctn;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public DlvrTo withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public DlvrTo withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DlvrTo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tp).append(cntrPickupLctn).append(nm).append(pstlAdr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DlvrTo) == false) {
            return false;
        }
        DlvrTo rhs = ((DlvrTo) other);
        return new EqualsBuilder().append(tp, rhs.tp).append(cntrPickupLctn, rhs.cntrPickupLctn).append(nm, rhs.nm).append(pstlAdr, rhs.pstlAdr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

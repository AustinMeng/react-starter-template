
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "chrgBr",
    "chrgAcctCcy",
    "chrgAcctId",
    "wvrFlg",
    "xchgRate",
    "chrgQuoteId",
    "fxdChrgAmt",
    "fxdChrgAmtCcy",
    "varblChrgAmt",
    "varblChrgAmtCcy",
    "retailMrkUpChrgAmt",
    "retailMrkUpChrgAmtCcy",
    "chrgClmInd",
    "DROMOSChrgCd",
    "chrgsClctdInd",
    "chrgsClctdStsCd",
    "chrgsClctdStsDesc",
    "chrgsPstdInd",
    "scbChrgsInf",
    "agtChrgsInf"
})
public class ChrgsInf {

    @JsonProperty("chrgBr")
    private String chrgBr;
    @JsonProperty("chrgAcctCcy")
    private String chrgAcctCcy;
    @JsonProperty("chrgAcctId")
    private String chrgAcctId;
    @JsonProperty("wvrFlg")
    private String wvrFlg;
    @JsonProperty("xchgRate")
    private String xchgRate;
    @JsonProperty("chrgQuoteId")
    private String chrgQuoteId;
    @JsonProperty("fxdChrgAmt")
    private String fxdChrgAmt;
    @JsonProperty("fxdChrgAmtCcy")
    private String fxdChrgAmtCcy;
    @JsonProperty("varblChrgAmt")
    private String varblChrgAmt;
    @JsonProperty("varblChrgAmtCcy")
    private String varblChrgAmtCcy;
    @JsonProperty("retailMrkUpChrgAmt")
    private String retailMrkUpChrgAmt;
    @JsonProperty("retailMrkUpChrgAmtCcy")
    private String retailMrkUpChrgAmtCcy;
    @JsonProperty("chrgClmInd")
    private String chrgClmInd;
    @JsonProperty("DROMOSChrgCd")
    private String dROMOSChrgCd;
    @JsonProperty("chrgsClctdInd")
    private String chrgsClctdInd;
    @JsonProperty("chrgsClctdStsCd")
    private String chrgsClctdStsCd;
    @JsonProperty("chrgsClctdStsDesc")
    private String chrgsClctdStsDesc;
    @JsonProperty("chrgsPstdInd")
    private String chrgsPstdInd;
    @JsonProperty("scbChrgsInf")
    private List<ScbChrgsInf> scbChrgsInf = null;
    @JsonProperty("agtChrgsInf")
    private List<AgtChrgsInf> agtChrgsInf = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("chrgBr")
    public String getChrgBr() {
        return chrgBr;
    }

    @JsonProperty("chrgBr")
    public void setChrgBr(String chrgBr) {
        this.chrgBr = chrgBr;
    }

    public ChrgsInf withChrgBr(String chrgBr) {
        this.chrgBr = chrgBr;
        return this;
    }

    @JsonProperty("chrgAcctCcy")
    public String getChrgAcctCcy() {
        return chrgAcctCcy;
    }

    @JsonProperty("chrgAcctCcy")
    public void setChrgAcctCcy(String chrgAcctCcy) {
        this.chrgAcctCcy = chrgAcctCcy;
    }

    public ChrgsInf withChrgAcctCcy(String chrgAcctCcy) {
        this.chrgAcctCcy = chrgAcctCcy;
        return this;
    }

    @JsonProperty("chrgAcctId")
    public String getChrgAcctId() {
        return chrgAcctId;
    }

    @JsonProperty("chrgAcctId")
    public void setChrgAcctId(String chrgAcctId) {
        this.chrgAcctId = chrgAcctId;
    }

    public ChrgsInf withChrgAcctId(String chrgAcctId) {
        this.chrgAcctId = chrgAcctId;
        return this;
    }

    @JsonProperty("wvrFlg")
    public String getWvrFlg() {
        return wvrFlg;
    }

    @JsonProperty("wvrFlg")
    public void setWvrFlg(String wvrFlg) {
        this.wvrFlg = wvrFlg;
    }

    public ChrgsInf withWvrFlg(String wvrFlg) {
        this.wvrFlg = wvrFlg;
        return this;
    }

    @JsonProperty("xchgRate")
    public String getXchgRate() {
        return xchgRate;
    }

    @JsonProperty("xchgRate")
    public void setXchgRate(String xchgRate) {
        this.xchgRate = xchgRate;
    }

    public ChrgsInf withXchgRate(String xchgRate) {
        this.xchgRate = xchgRate;
        return this;
    }

    @JsonProperty("chrgQuoteId")
    public String getChrgQuoteId() {
        return chrgQuoteId;
    }

    @JsonProperty("chrgQuoteId")
    public void setChrgQuoteId(String chrgQuoteId) {
        this.chrgQuoteId = chrgQuoteId;
    }

    public ChrgsInf withChrgQuoteId(String chrgQuoteId) {
        this.chrgQuoteId = chrgQuoteId;
        return this;
    }

    @JsonProperty("fxdChrgAmt")
    public String getFxdChrgAmt() {
        return fxdChrgAmt;
    }

    @JsonProperty("fxdChrgAmt")
    public void setFxdChrgAmt(String fxdChrgAmt) {
        this.fxdChrgAmt = fxdChrgAmt;
    }

    public ChrgsInf withFxdChrgAmt(String fxdChrgAmt) {
        this.fxdChrgAmt = fxdChrgAmt;
        return this;
    }

    @JsonProperty("fxdChrgAmtCcy")
    public String getFxdChrgAmtCcy() {
        return fxdChrgAmtCcy;
    }

    @JsonProperty("fxdChrgAmtCcy")
    public void setFxdChrgAmtCcy(String fxdChrgAmtCcy) {
        this.fxdChrgAmtCcy = fxdChrgAmtCcy;
    }

    public ChrgsInf withFxdChrgAmtCcy(String fxdChrgAmtCcy) {
        this.fxdChrgAmtCcy = fxdChrgAmtCcy;
        return this;
    }

    @JsonProperty("varblChrgAmt")
    public String getVarblChrgAmt() {
        return varblChrgAmt;
    }

    @JsonProperty("varblChrgAmt")
    public void setVarblChrgAmt(String varblChrgAmt) {
        this.varblChrgAmt = varblChrgAmt;
    }

    public ChrgsInf withVarblChrgAmt(String varblChrgAmt) {
        this.varblChrgAmt = varblChrgAmt;
        return this;
    }

    @JsonProperty("varblChrgAmtCcy")
    public String getVarblChrgAmtCcy() {
        return varblChrgAmtCcy;
    }

    @JsonProperty("varblChrgAmtCcy")
    public void setVarblChrgAmtCcy(String varblChrgAmtCcy) {
        this.varblChrgAmtCcy = varblChrgAmtCcy;
    }

    public ChrgsInf withVarblChrgAmtCcy(String varblChrgAmtCcy) {
        this.varblChrgAmtCcy = varblChrgAmtCcy;
        return this;
    }

    @JsonProperty("retailMrkUpChrgAmt")
    public String getRetailMrkUpChrgAmt() {
        return retailMrkUpChrgAmt;
    }

    @JsonProperty("retailMrkUpChrgAmt")
    public void setRetailMrkUpChrgAmt(String retailMrkUpChrgAmt) {
        this.retailMrkUpChrgAmt = retailMrkUpChrgAmt;
    }

    public ChrgsInf withRetailMrkUpChrgAmt(String retailMrkUpChrgAmt) {
        this.retailMrkUpChrgAmt = retailMrkUpChrgAmt;
        return this;
    }

    @JsonProperty("retailMrkUpChrgAmtCcy")
    public String getRetailMrkUpChrgAmtCcy() {
        return retailMrkUpChrgAmtCcy;
    }

    @JsonProperty("retailMrkUpChrgAmtCcy")
    public void setRetailMrkUpChrgAmtCcy(String retailMrkUpChrgAmtCcy) {
        this.retailMrkUpChrgAmtCcy = retailMrkUpChrgAmtCcy;
    }

    public ChrgsInf withRetailMrkUpChrgAmtCcy(String retailMrkUpChrgAmtCcy) {
        this.retailMrkUpChrgAmtCcy = retailMrkUpChrgAmtCcy;
        return this;
    }

    @JsonProperty("chrgClmInd")
    public String getChrgClmInd() {
        return chrgClmInd;
    }

    @JsonProperty("chrgClmInd")
    public void setChrgClmInd(String chrgClmInd) {
        this.chrgClmInd = chrgClmInd;
    }

    public ChrgsInf withChrgClmInd(String chrgClmInd) {
        this.chrgClmInd = chrgClmInd;
        return this;
    }

    @JsonProperty("DROMOSChrgCd")
    public String getDROMOSChrgCd() {
        return dROMOSChrgCd;
    }

    @JsonProperty("DROMOSChrgCd")
    public void setDROMOSChrgCd(String dROMOSChrgCd) {
        this.dROMOSChrgCd = dROMOSChrgCd;
    }

    public ChrgsInf withDROMOSChrgCd(String dROMOSChrgCd) {
        this.dROMOSChrgCd = dROMOSChrgCd;
        return this;
    }

    @JsonProperty("chrgsClctdInd")
    public String getChrgsClctdInd() {
        return chrgsClctdInd;
    }

    @JsonProperty("chrgsClctdInd")
    public void setChrgsClctdInd(String chrgsClctdInd) {
        this.chrgsClctdInd = chrgsClctdInd;
    }

    public ChrgsInf withChrgsClctdInd(String chrgsClctdInd) {
        this.chrgsClctdInd = chrgsClctdInd;
        return this;
    }

    @JsonProperty("chrgsClctdStsCd")
    public String getChrgsClctdStsCd() {
        return chrgsClctdStsCd;
    }

    @JsonProperty("chrgsClctdStsCd")
    public void setChrgsClctdStsCd(String chrgsClctdStsCd) {
        this.chrgsClctdStsCd = chrgsClctdStsCd;
    }

    public ChrgsInf withChrgsClctdStsCd(String chrgsClctdStsCd) {
        this.chrgsClctdStsCd = chrgsClctdStsCd;
        return this;
    }

    @JsonProperty("chrgsClctdStsDesc")
    public String getChrgsClctdStsDesc() {
        return chrgsClctdStsDesc;
    }

    @JsonProperty("chrgsClctdStsDesc")
    public void setChrgsClctdStsDesc(String chrgsClctdStsDesc) {
        this.chrgsClctdStsDesc = chrgsClctdStsDesc;
    }

    public ChrgsInf withChrgsClctdStsDesc(String chrgsClctdStsDesc) {
        this.chrgsClctdStsDesc = chrgsClctdStsDesc;
        return this;
    }

    @JsonProperty("chrgsPstdInd")
    public String getChrgsPstdInd() {
        return chrgsPstdInd;
    }

    @JsonProperty("chrgsPstdInd")
    public void setChrgsPstdInd(String chrgsPstdInd) {
        this.chrgsPstdInd = chrgsPstdInd;
    }

    public ChrgsInf withChrgsPstdInd(String chrgsPstdInd) {
        this.chrgsPstdInd = chrgsPstdInd;
        return this;
    }

    @JsonProperty("scbChrgsInf")
    public List<ScbChrgsInf> getScbChrgsInf() {
        return scbChrgsInf;
    }

    @JsonProperty("scbChrgsInf")
    public void setScbChrgsInf(List<ScbChrgsInf> scbChrgsInf) {
        this.scbChrgsInf = scbChrgsInf;
    }

    public ChrgsInf withScbChrgsInf(List<ScbChrgsInf> scbChrgsInf) {
        this.scbChrgsInf = scbChrgsInf;
        return this;
    }

    @JsonProperty("agtChrgsInf")
    public List<AgtChrgsInf> getAgtChrgsInf() {
        return agtChrgsInf;
    }

    @JsonProperty("agtChrgsInf")
    public void setAgtChrgsInf(List<AgtChrgsInf> agtChrgsInf) {
        this.agtChrgsInf = agtChrgsInf;
    }

    public ChrgsInf withAgtChrgsInf(List<AgtChrgsInf> agtChrgsInf) {
        this.agtChrgsInf = agtChrgsInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ChrgsInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(chrgBr).append(chrgAcctCcy).append(chrgAcctId).append(wvrFlg).append(xchgRate).append(chrgQuoteId).append(fxdChrgAmt).append(fxdChrgAmtCcy).append(varblChrgAmt).append(varblChrgAmtCcy).append(retailMrkUpChrgAmt).append(retailMrkUpChrgAmtCcy).append(chrgClmInd).append(dROMOSChrgCd).append(chrgsClctdInd).append(chrgsClctdStsCd).append(chrgsClctdStsDesc).append(chrgsPstdInd).append(scbChrgsInf).append(agtChrgsInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChrgsInf) == false) {
            return false;
        }
        ChrgsInf rhs = ((ChrgsInf) other);
        return new EqualsBuilder().append(chrgBr, rhs.chrgBr).append(chrgAcctCcy, rhs.chrgAcctCcy).append(chrgAcctId, rhs.chrgAcctId).append(wvrFlg, rhs.wvrFlg).append(xchgRate, rhs.xchgRate).append(chrgQuoteId, rhs.chrgQuoteId).append(fxdChrgAmt, rhs.fxdChrgAmt).append(fxdChrgAmtCcy, rhs.fxdChrgAmtCcy).append(varblChrgAmt, rhs.varblChrgAmt).append(varblChrgAmtCcy, rhs.varblChrgAmtCcy).append(retailMrkUpChrgAmt, rhs.retailMrkUpChrgAmt).append(retailMrkUpChrgAmtCcy, rhs.retailMrkUpChrgAmtCcy).append(chrgClmInd, rhs.chrgClmInd).append(dROMOSChrgCd, rhs.dROMOSChrgCd).append(chrgsClctdInd, rhs.chrgsClctdInd).append(chrgsClctdStsCd, rhs.chrgsClctdStsCd).append(chrgsClctdStsDesc, rhs.chrgsClctdStsDesc).append(chrgsPstdInd, rhs.chrgsPstdInd).append(scbChrgsInf, rhs.scbChrgsInf).append(agtChrgsInf, rhs.agtChrgsInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

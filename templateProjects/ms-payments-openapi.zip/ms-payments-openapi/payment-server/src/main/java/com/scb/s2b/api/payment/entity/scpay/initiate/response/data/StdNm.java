
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "rltnshpNb",
    "lang",
    "nm",
    "prmryInd"
})
public class StdNm {

    @JsonProperty("rltnshpNb")
    private String rltnshpNb;
    @JsonProperty("lang")
    private String lang;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("prmryInd")
    private String prmryInd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("rltnshpNb")
    public String getRltnshpNb() {
        return rltnshpNb;
    }

    @JsonProperty("rltnshpNb")
    public void setRltnshpNb(String rltnshpNb) {
        this.rltnshpNb = rltnshpNb;
    }

    public StdNm withRltnshpNb(String rltnshpNb) {
        this.rltnshpNb = rltnshpNb;
        return this;
    }

    @JsonProperty("lang")
    public String getLang() {
        return lang;
    }

    @JsonProperty("lang")
    public void setLang(String lang) {
        this.lang = lang;
    }

    public StdNm withLang(String lang) {
        this.lang = lang;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public StdNm withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("prmryInd")
    public String getPrmryInd() {
        return prmryInd;
    }

    @JsonProperty("prmryInd")
    public void setPrmryInd(String prmryInd) {
        this.prmryInd = prmryInd;
    }

    public StdNm withPrmryInd(String prmryInd) {
        this.prmryInd = prmryInd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public StdNm withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(rltnshpNb).append(lang).append(nm).append(prmryInd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StdNm) == false) {
            return false;
        }
        StdNm rhs = ((StdNm) other);
        return new EqualsBuilder().append(rltnshpNb, rhs.rltnshpNb).append(lang, rhs.lang).append(nm, rhs.nm).append(prmryInd, rhs.prmryInd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

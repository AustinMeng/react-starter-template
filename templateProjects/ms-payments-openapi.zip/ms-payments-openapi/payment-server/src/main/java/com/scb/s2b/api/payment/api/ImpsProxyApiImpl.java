package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.ImpsProxyPaymentRequestValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.inject.Singleton;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.util.Map;

@Component
@Singleton
public class ImpsProxyApiImpl extends ApiBase {

    private final ImpsProxyPaymentRequestValidator paymentRequestValidator;

    private final RequestProcessor impsRequestProcessor;

    private final OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;

    private final PaymentService paymentService;

    private static final Logger logger = LoggerFactory.getLogger(ImpsProxyApiImpl.class);

    @Autowired
    public ImpsProxyApiImpl(ImpsProxyPaymentRequestValidator paymentRequestValidator,
                            @Qualifier("impsProxyRequestProcessor") RequestProcessor impsRequestProcessor,
                            OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer,
                            PaymentService paymentService) {
        this.paymentRequestValidator = paymentRequestValidator;
        this.impsRequestProcessor = impsRequestProcessor;
        this.openApiPaymentInstructionTransformer = openApiPaymentInstructionTransformer;
        this.paymentService = paymentService;
    }

    public Response paymentInitiate(String preVerified, OpenApiPaymentInstruction body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);
        logger.info("PaymentInitiate requestId={}, groupId={}, clientReferenceId={}", requestId, groupId,
                body.getInstruction().getReferenceId());

        paymentRequestValidator.validate(groupId, body);
        Map<String, String> headersMap = this.getHeaders(headers);

        boolean isPreVerified = "true".equalsIgnoreCase(preVerified);
        PaymentInstruction paymentInstruction = openApiPaymentInstructionTransformer
                .toPaymentInstruction(body, isPreVerified, headersMap);

        impsRequestProcessor.process(paymentInstruction);
        paymentService.initiate(paymentInstruction);
        paymentRequestValidator.cache(paymentInstruction);

        OpenApiPaymentId openApiPaymentId = openApiPaymentInstructionTransformer.toOpenApiPaymentId(paymentInstruction);

        return Response.ok(openApiPaymentId).build();
    }
}


package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "fileTp",
    "prcgEngine",
    "prcgMd"
})
public class SplmtryData {

    @JsonProperty("fileTp")
    private String fileTp;
    @JsonProperty("prcgEngine")
    private String prcgEngine;
    @JsonProperty("prcgMd")
    private String prcgMd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("fileTp")
    public String getFileTp() {
        return fileTp;
    }

    @JsonProperty("fileTp")
    public void setFileTp(String fileTp) {
        this.fileTp = fileTp;
    }

    public SplmtryData withFileTp(String fileTp) {
        this.fileTp = fileTp;
        return this;
    }

    @JsonProperty("prcgEngine")
    public String getPrcgEngine() {
        return prcgEngine;
    }

    @JsonProperty("prcgEngine")
    public void setPrcgEngine(String prcgEngine) {
        this.prcgEngine = prcgEngine;
    }

    public SplmtryData withPrcgEngine(String prcgEngine) {
        this.prcgEngine = prcgEngine;
        return this;
    }

    @JsonProperty("prcgMd")
    public String getPrcgMd() {
        return prcgMd;
    }

    @JsonProperty("prcgMd")
    public void setPrcgMd(String prcgMd) {
        this.prcgMd = prcgMd;
    }

    public SplmtryData withPrcgMd(String prcgMd) {
        this.prcgMd = prcgMd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SplmtryData withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(fileTp).append(prcgEngine).append(prcgMd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SplmtryData) == false) {
            return false;
        }
        SplmtryData rhs = ((SplmtryData) other);
        return new EqualsBuilder().append(fileTp, rhs.fileTp).append(prcgEngine, rhs.prcgEngine).append(prcgMd, rhs.prcgMd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

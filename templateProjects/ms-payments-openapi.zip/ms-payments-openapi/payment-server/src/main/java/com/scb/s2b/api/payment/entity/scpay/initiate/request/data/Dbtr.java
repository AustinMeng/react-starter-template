
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "nm",
    "nmLclLang",
    "pstlAdrLclLang",
    "brnchCd",
    "brnchNm",
    "ctryOfRes",
    "ntlty",
    "frmtInd",
    "sgmt",
    "orgId",
    "prvtId",
    "pstlAdr",
    "ctctDtls"
})
public class Dbtr {

    @JsonProperty("nm")
    private String nm;
    @JsonProperty("nmLclLang")
    private String nmLclLang;
    @JsonProperty("pstlAdrLclLang")
    private String pstlAdrLclLang;
    @JsonProperty("brnchCd")
    private String brnchCd;
    @JsonProperty("brnchNm")
    private String brnchNm;
    @JsonProperty("ctryOfRes")
    private String ctryOfRes;
    @JsonProperty("ntlty")
    private String ntlty;
    @JsonProperty("frmtInd")
    private String frmtInd;
    @JsonProperty("sgmt")
    private String sgmt;
    @JsonProperty("orgId")
    private OrgId orgId;
    @JsonProperty("prvtId")
    private PrvtId prvtId;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonProperty("ctctDtls")
    private CtctDtls ctctDtls;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public Dbtr withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("nmLclLang")
    public String getNmLclLang() {
        return nmLclLang;
    }

    @JsonProperty("nmLclLang")
    public void setNmLclLang(String nmLclLang) {
        this.nmLclLang = nmLclLang;
    }

    public Dbtr withNmLclLang(String nmLclLang) {
        this.nmLclLang = nmLclLang;
        return this;
    }

    @JsonProperty("pstlAdrLclLang")
    public String getPstlAdrLclLang() {
        return pstlAdrLclLang;
    }

    @JsonProperty("pstlAdrLclLang")
    public void setPstlAdrLclLang(String pstlAdrLclLang) {
        this.pstlAdrLclLang = pstlAdrLclLang;
    }

    public Dbtr withPstlAdrLclLang(String pstlAdrLclLang) {
        this.pstlAdrLclLang = pstlAdrLclLang;
        return this;
    }

    @JsonProperty("brnchCd")
    public String getBrnchCd() {
        return brnchCd;
    }

    @JsonProperty("brnchCd")
    public void setBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
    }

    public Dbtr withBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
        return this;
    }

    @JsonProperty("brnchNm")
    public String getBrnchNm() {
        return brnchNm;
    }

    @JsonProperty("brnchNm")
    public void setBrnchNm(String brnchNm) {
        this.brnchNm = brnchNm;
    }

    public Dbtr withBrnchNm(String brnchNm) {
        this.brnchNm = brnchNm;
        return this;
    }

    @JsonProperty("ctryOfRes")
    public String getCtryOfRes() {
        return ctryOfRes;
    }

    @JsonProperty("ctryOfRes")
    public void setCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
    }

    public Dbtr withCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
        return this;
    }

    @JsonProperty("ntlty")
    public String getNtlty() {
        return ntlty;
    }

    @JsonProperty("ntlty")
    public void setNtlty(String ntlty) {
        this.ntlty = ntlty;
    }

    public Dbtr withNtlty(String ntlty) {
        this.ntlty = ntlty;
        return this;
    }

    @JsonProperty("frmtInd")
    public String getFrmtInd() {
        return frmtInd;
    }

    @JsonProperty("frmtInd")
    public void setFrmtInd(String frmtInd) {
        this.frmtInd = frmtInd;
    }

    public Dbtr withFrmtInd(String frmtInd) {
        this.frmtInd = frmtInd;
        return this;
    }

    @JsonProperty("sgmt")
    public String getSgmt() {
        return sgmt;
    }

    @JsonProperty("sgmt")
    public void setSgmt(String sgmt) {
        this.sgmt = sgmt;
    }

    public Dbtr withSgmt(String sgmt) {
        this.sgmt = sgmt;
        return this;
    }

    @JsonProperty("orgId")
    public OrgId getOrgId() {
        return orgId;
    }

    @JsonProperty("orgId")
    public void setOrgId(OrgId orgId) {
        this.orgId = orgId;
    }

    public Dbtr withOrgId(OrgId orgId) {
        this.orgId = orgId;
        return this;
    }

    @JsonProperty("prvtId")
    public PrvtId getPrvtId() {
        return prvtId;
    }

    @JsonProperty("prvtId")
    public void setPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
    }

    public Dbtr withPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public Dbtr withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @JsonProperty("ctctDtls")
    public CtctDtls getCtctDtls() {
        return ctctDtls;
    }

    @JsonProperty("ctctDtls")
    public void setCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
    }

    public Dbtr withCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Dbtr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(nm).append(nmLclLang).append(pstlAdrLclLang).append(brnchCd).append(brnchNm).append(ctryOfRes).append(ntlty).append(frmtInd).append(sgmt).append(orgId).append(prvtId).append(pstlAdr).append(ctctDtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Dbtr) == false) {
            return false;
        }
        Dbtr rhs = ((Dbtr) other);
        return new EqualsBuilder().append(nm, rhs.nm).append(nmLclLang, rhs.nmLclLang).append(pstlAdrLclLang, rhs.pstlAdrLclLang).append(brnchCd, rhs.brnchCd).append(brnchNm, rhs.brnchNm).append(ctryOfRes, rhs.ctryOfRes).append(ntlty, rhs.ntlty).append(frmtInd, rhs.frmtInd).append(sgmt, rhs.sgmt).append(orgId, rhs.orgId).append(prvtId, rhs.prvtId).append(pstlAdr, rhs.pstlAdr).append(ctctDtls, rhs.ctctDtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

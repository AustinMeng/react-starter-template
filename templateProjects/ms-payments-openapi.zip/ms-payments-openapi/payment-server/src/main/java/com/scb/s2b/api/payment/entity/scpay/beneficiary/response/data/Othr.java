
package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "idSchmeNmCd",
    "idSchmeNmPrtry",
    "idIssr"
})
public class Othr {

    @JsonProperty("id")
    private String id;
    @JsonProperty("idSchmeNmCd")
    private String idSchmeNmCd;
    @JsonProperty("idSchmeNmPrtry")
    private String idSchmeNmPrtry;
    @JsonProperty("idIssr")
    private String idIssr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Othr withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("idSchmeNmCd")
    public String getIdSchmeNmCd() {
        return idSchmeNmCd;
    }

    @JsonProperty("idSchmeNmCd")
    public void setIdSchmeNmCd(String idSchmeNmCd) {
        this.idSchmeNmCd = idSchmeNmCd;
    }

    public Othr withIdSchmeNmCd(String idSchmeNmCd) {
        this.idSchmeNmCd = idSchmeNmCd;
        return this;
    }

    @JsonProperty("idSchmeNmPrtry")
    public String getIdSchmeNmPrtry() {
        return idSchmeNmPrtry;
    }

    @JsonProperty("idSchmeNmPrtry")
    public void setIdSchmeNmPrtry(String idSchmeNmPrtry) {
        this.idSchmeNmPrtry = idSchmeNmPrtry;
    }

    public Othr withIdSchmeNmPrtry(String idSchmeNmPrtry) {
        this.idSchmeNmPrtry = idSchmeNmPrtry;
        return this;
    }

    @JsonProperty("idIssr")
    public String getIdIssr() {
        return idIssr;
    }

    @JsonProperty("idIssr")
    public void setIdIssr(String idIssr) {
        this.idIssr = idIssr;
    }

    public Othr withIdIssr(String idIssr) {
        this.idIssr = idIssr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Othr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(id).append(idSchmeNmCd).append(idSchmeNmPrtry).append(idIssr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Othr) == false) {
            return false;
        }
        Othr rhs = ((Othr) other);
        return new EqualsBuilder().append(id, rhs.id).append(idSchmeNmCd, rhs.idSchmeNmCd).append(idSchmeNmPrtry, rhs.idSchmeNmPrtry).append(idIssr, rhs.idIssr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

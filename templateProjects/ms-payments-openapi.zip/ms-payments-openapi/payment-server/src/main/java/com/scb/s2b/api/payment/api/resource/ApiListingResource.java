package com.scb.s2b.api.payment.api.resource;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.core.util.Json;
import io.swagger.v3.core.util.Yaml;
import io.swagger.v3.jaxrs2.integration.JaxrsOpenApiContextBuilder;
import io.swagger.v3.jaxrs2.integration.ServletConfigContextUtils;
import io.swagger.v3.jaxrs2.integration.resources.BaseOpenApiResource;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.integration.OpenApiConfigurationException;
import io.swagger.v3.oas.integration.api.OpenApiContext;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Paths;
import javax.servlet.ServletConfig;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import org.apache.commons.lang3.StringUtils;

@Path("/swagger.{type:json|yaml}")
public class ApiListingResource extends BaseOpenApiResource {

    private static final String BASE_CONTEXT = "/openapi/";

    @Context
    ServletConfig config;

    @GET
    @Produces({"application/json", "application/yaml"})
    @Operation(
            summary = "The swagger definition in JSON",
            hidden = true
    )
    public Response getListing(@Context Application app, @Context ServletConfig sc, @Context HttpHeaders headers,
            @Context UriInfo uriInfo, @PathParam("type") String type) {
        return this.getOpenApi(headers, sc, app, uriInfo, type);
    }

    @Override
    public Response getOpenApi(HttpHeaders headers, ServletConfig config, Application app, UriInfo uriInfo,
            String type)  {
        try {
            String ctxId = ServletConfigContextUtils.getContextIdFromServletConfig(config);

            OpenApiContext ctx = new JaxrsOpenApiContextBuilder()
                    .servletConfig(config)
                    .application(app)
                    .configLocation("swagger-configuration.yaml")
                    .ctxId(ctxId)
                    .buildContext(true);
            OpenAPI oas = ctx.read();

            Paths updatedPath = new Paths();
            oas.getPaths().forEach((key, value) -> {
                String updatedKey = key.replace(BASE_CONTEXT, "/");
                updatedPath.addPathItem(updatedKey, value);
            });
            oas.setPaths(updatedPath);

            return StringUtils.isNotBlank(type) && type.trim().equalsIgnoreCase("yaml") ?
                    Response.status(Response.Status.OK)
                            .entity(Yaml.mapper().writeValueAsString(oas))
                            .type("application/yaml")
                            .build() :
                    Response.status(Response.Status.OK)
                            .entity(Json.mapper().writeValueAsString(oas))
                            .type(MediaType.APPLICATION_JSON_TYPE)
                            .build();
        } catch (OpenApiConfigurationException | JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}

package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instgChanl",
    "instgSubChanl",
    "instdChanl",
    "instdSubChanl",
    "prePrcr",
    "imprtRef",
    "authrsrDtls",
    "authrsrTknId",
    "authrsrSgntr",
    "txRcvdDtTm",
    "clntFileNm",
    "prxyLookupNtwkTp"
})
public class Chanl {

    @JsonProperty("instgChanl")
    private String instgChanl;
    @JsonProperty("instgSubChanl")
    private String instgSubChanl;
    @JsonProperty("instdChanl")
    private String instdChanl;
    @JsonProperty("instdSubChanl")
    private String instdSubChanl;
    @JsonProperty("prePrcr")
    private String prePrcr;
    @JsonProperty("imprtRef")
    private String imprtRef;
    @JsonProperty("authrsrDtls")
    private List<String> authrsrDtls = null;
    @JsonProperty("authrsrTknId")
    private List<String> authrsrTknId = null;
    @JsonProperty("authrsrSgntr")
    private List<String> authrsrSgntr = null;
    @JsonProperty("txRcvdDtTm")
    private String txRcvdDtTm;
    @JsonProperty("clntFileNm")
    private String clntFileNm;
    @JsonProperty("prxyLookupNtwkTp")
    private String prxyLookupNtwkTp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instgChanl")
    public String getInstgChanl() {
        return instgChanl;
    }

    @JsonProperty("instgChanl")
    public void setInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
    }

    public Chanl withInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
        return this;
    }

    @JsonProperty("instgSubChanl")
    public String getInstgSubChanl() {
        return instgSubChanl;
    }

    @JsonProperty("instgSubChanl")
    public void setInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
    }

    public Chanl withInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
        return this;
    }

    @JsonProperty("instdChanl")
    public String getInstdChanl() {
        return instdChanl;
    }

    @JsonProperty("instdChanl")
    public void setInstdChanl(String instdChanl) {
        this.instdChanl = instdChanl;
    }

    public Chanl withInstdChanl(String instdChanl) {
        this.instdChanl = instdChanl;
        return this;
    }

    @JsonProperty("instdSubChanl")
    public String getInstdSubChanl() {
        return instdSubChanl;
    }

    @JsonProperty("instdSubChanl")
    public void setInstdSubChanl(String instdSubChanl) {
        this.instdSubChanl = instdSubChanl;
    }

    public Chanl withInstdSubChanl(String instdSubChanl) {
        this.instdSubChanl = instdSubChanl;
        return this;
    }

    @JsonProperty("prePrcr")
    public String getPrePrcr() {
        return prePrcr;
    }

    @JsonProperty("prePrcr")
    public void setPrePrcr(String prePrcr) {
        this.prePrcr = prePrcr;
    }

    public Chanl withPrePrcr(String prePrcr) {
        this.prePrcr = prePrcr;
        return this;
    }

    @JsonProperty("imprtRef")
    public String getImprtRef() {
        return imprtRef;
    }

    @JsonProperty("imprtRef")
    public void setImprtRef(String imprtRef) {
        this.imprtRef = imprtRef;
    }

    public Chanl withImprtRef(String imprtRef) {
        this.imprtRef = imprtRef;
        return this;
    }

    @JsonProperty("authrsrDtls")
    public List<String> getAuthrsrDtls() {
        return authrsrDtls;
    }

    @JsonProperty("authrsrDtls")
    public void setAuthrsrDtls(List<String> authrsrDtls) {
        this.authrsrDtls = authrsrDtls;
    }

    public Chanl withAuthrsrDtls(List<String> authrsrDtls) {
        this.authrsrDtls = authrsrDtls;
        return this;
    }

    @JsonProperty("authrsrTknId")
    public List<String> getAuthrsrTknId() {
        return authrsrTknId;
    }

    @JsonProperty("authrsrTknId")
    public void setAuthrsrTknId(List<String> authrsrTknId) {
        this.authrsrTknId = authrsrTknId;
    }

    public Chanl withAuthrsrTknId(List<String> authrsrTknId) {
        this.authrsrTknId = authrsrTknId;
        return this;
    }

    @JsonProperty("authrsrSgntr")
    public List<String> getAuthrsrSgntr() {
        return authrsrSgntr;
    }

    @JsonProperty("authrsrSgntr")
    public void setAuthrsrSgntr(List<String> authrsrSgntr) {
        this.authrsrSgntr = authrsrSgntr;
    }

    public Chanl withAuthrsrSgntr(List<String> authrsrSgntr) {
        this.authrsrSgntr = authrsrSgntr;
        return this;
    }

    @JsonProperty("txRcvdDtTm")
    public String getTxRcvdDtTm() {
        return txRcvdDtTm;
    }

    @JsonProperty("txRcvdDtTm")
    public void setTxRcvdDtTm(String txRcvdDtTm) {
        this.txRcvdDtTm = txRcvdDtTm;
    }

    public Chanl withTxRcvdDtTm(String txRcvdDtTm) {
        this.txRcvdDtTm = txRcvdDtTm;
        return this;
    }

    @JsonProperty("clntFileNm")
    public String getClntFileNm() {
        return clntFileNm;
    }

    @JsonProperty("clntFileNm")
    public void setClntFileNm(String clntFileNm) {
        this.clntFileNm = clntFileNm;
    }

    public Chanl withClntFileNm(String clntFileNm) {
        this.clntFileNm = clntFileNm;
        return this;
    }

    @JsonProperty("prxyLookupNtwkTp")
    public String getPrxyLookupNtwkTp() {
        return prxyLookupNtwkTp;
    }

    @JsonProperty("prxyLookupNtwkTp")
    public void setPrxyLookupNtwkTp(String prxyLookupNtwkTp) {
        this.prxyLookupNtwkTp = prxyLookupNtwkTp;
    }

    public Chanl withPrxyLookupNtwkTp(String prxyLookupNtwkTp) {
        this.prxyLookupNtwkTp = prxyLookupNtwkTp;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Chanl withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instgChanl).append(instgSubChanl).append(instdChanl).append(instdSubChanl).append(prePrcr).append(imprtRef).append(authrsrDtls).append(authrsrTknId).append(authrsrSgntr).append(txRcvdDtTm).append(clntFileNm).append(prxyLookupNtwkTp).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Chanl) == false) {
            return false;
        }
        Chanl rhs = ((Chanl) other);
        return new EqualsBuilder().append(instgChanl, rhs.instgChanl).append(instgSubChanl, rhs.instgSubChanl).append(instdChanl, rhs.instdChanl).append(instdSubChanl, rhs.instdSubChanl).append(prePrcr, rhs.prePrcr).append(imprtRef, rhs.imprtRef).append(authrsrDtls, rhs.authrsrDtls).append(authrsrTknId, rhs.authrsrTknId).append(authrsrSgntr, rhs.authrsrSgntr).append(txRcvdDtTm, rhs.txRcvdDtTm).append(clntFileNm, rhs.clntFileNm).append(prxyLookupNtwkTp, rhs.prxyLookupNtwkTp).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

package com.scb.s2b.api.payment.camel.controller;


import org.apache.camel.builder.RouteBuilder;

public interface CamelController {

    void resumeRoute(String routeId, int maxAttempts) throws Exception;

    void addOrSuspendRoute(String routeId, int maxAttempts, RouteBuilder builder) throws Exception ;

    void addOrResumeRoute(String routeId, int maxAttempts, RouteBuilder builder) throws Exception ;
}

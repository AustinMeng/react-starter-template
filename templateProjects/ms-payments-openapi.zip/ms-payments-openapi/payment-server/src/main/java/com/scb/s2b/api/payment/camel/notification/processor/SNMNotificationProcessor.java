package com.scb.s2b.api.payment.camel.notification.processor;


import com.scb.s2b.api.payment.entity.scpay.notification.Notification;

public interface SNMNotificationProcessor {
    void processingNotification(Notification notification);

    void persistNotificationMessage(String message, String entityType, String messageId);
}

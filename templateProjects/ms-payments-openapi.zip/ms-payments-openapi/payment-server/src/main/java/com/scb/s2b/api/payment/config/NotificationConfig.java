package com.scb.s2b.api.payment.config;

import com.scb.s2b.api.payment.camel.JmsProducerAdapter;
import com.scb.s2b.api.payment.camel.ZkProducerAdapter;
import com.scb.s2b.api.payment.camel.controller.CamelController;
import com.scb.s2b.api.payment.camel.notification.SNMNotificationScheduler;
import com.scb.s2b.api.payment.camel.notification.handler.*;
import com.scb.s2b.api.payment.camel.notification.processor.SNMNotificationProcessor;
import com.scb.s2b.api.payment.camel.notification.processor.SNMNotificationProcessorImpl;
import com.scb.s2b.api.payment.config.property.CamelControllerProperties;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.repository.PaymentMessageRepository;
import com.scb.s2b.api.payment.repository.RuntimePropertyRepository;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.service.ReferenceDataService;
import com.scb.s2b.api.payment.service.impl.MaintenanceServiceImpl;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import com.scb.s2b.api.payment.util.IdGenerator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

@SuppressWarnings("unused")
@EnableScheduling
public class NotificationConfig {

    @Bean
    public CamelControllerProperties notificationControllerProperties() {
        return new CamelControllerProperties();
    }

    @Bean
    @Qualifier("scPaySignOnOff")
    public SNMNotificationHandler scPaySignOnOffHandler(CamelController camelController,
            MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer,
            ScpayProperties scpayProperties,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        return new SCPaySignOnOffHandler(
                maintenanceService,
                zkProducer,
                scpayProperties,
                camelController,
                exceptionProcessor,
                messageMarshaller);
    }

    @Bean
    @Qualifier("scBankDefaultBroadcast")
    public SNMNotificationHandler scBankDefaultBroadcastHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        return new BankDefaultBroadcastHandler(maintenanceService,
                zkProducer,
                scpayProperties,
                camelController,
                exceptionProcessor,
                messageMarshaller);
    }

    @Bean
    @Qualifier("scBankStatusBroadcast")
    public SNMNotificationHandler scBankStatusBroadcastHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        return new BankStatusBroadcastHandler(maintenanceService,
                zkProducer,
                scpayProperties,
                camelController,
                exceptionProcessor,
                messageMarshaller);
    }

    @Bean
    @Qualifier("scSystemStatusBroadcast")
    public SNMNotificationHandler scSystemStatusBroadcastHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        return new SystemStatusBroadcastHandler(maintenanceService,
                zkProducer,
                scpayProperties,
                camelController,
                exceptionProcessor,
                messageMarshaller);
    }

    @Bean
    @Qualifier("scBankStatusBroadcastForPHHandler")
    public SNMNotificationHandler scBankStatusBroadcastForPHHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        return new BankStatusBroadcastForPHHandler(maintenanceService,
                zkProducer,
                scpayProperties,
                camelController,
                exceptionProcessor,
                messageMarshaller);
    }

    @Bean
    public Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap(List<SNMNotificationHandler> handlers) {
        return handlers.stream().collect(HashMap::new,
                (BiConsumer<Map<EventCode, SNMNotificationHandler>, SNMNotificationHandler>) (map, handler) ->
                        handler.getCode().forEach(code -> map.put(code, handler)),
                Map::putAll);
    }

    @Bean
    public SNMNotificationProcessor notificationService(JmsProducerAdapter jmsProducer,
            Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap,
            PaymentMessageRepository paymentMessageRepository, JsonMessageMarshaller messageMarshaller,
            ScpayProperties scpayProperties, IdGenerator idGenerator) {
        return new SNMNotificationProcessorImpl(jmsProducer, eventCodeHandlerMap,
                paymentMessageRepository, messageMarshaller, scpayProperties.getNotification(), idGenerator);
    }

    @Bean
    public MaintenanceService maintenanceService(JsonMessageMarshaller jsonMessageMarshaller,
            RuntimePropertyRepository runtimePropertyRepository,
            ReferenceDataService referenceDataService,
            ScpayProperties scpayProperties, CamelController camelController) {
        return new MaintenanceServiceImpl(jsonMessageMarshaller, runtimePropertyRepository, referenceDataService
        );
    }

    @Bean
    public SNMNotificationScheduler snmNotificationScheduler(Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap,
            ScpayProperties scpayProperties) {
        return new SNMNotificationScheduler(eventCodeHandlerMap, scpayProperties);
    }
}

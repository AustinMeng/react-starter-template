
package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ustrd",
    "ustrdLclLang"
})
public class RmtInf {

    @JsonProperty("ustrd")
    private List<String> ustrd;
    @JsonProperty("ustrdLclLang")
    private String ustrdLclLang;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ustrd")
    public List<String> getUstrd() {
        return ustrd;
    }

    @JsonProperty("ustrd")
    public void setUstrd(List<String> ustrd) {
        this.ustrd = ustrd;
    }

    public RmtInf withUstrd(List<String> ustrd) {
        this.ustrd = ustrd;
        return this;
    }

    @JsonProperty("ustrdLclLang")
    public String getUstrdLclLang() {
        return ustrdLclLang;
    }

    @JsonProperty("ustrdLclLang")
    public void setUstrdLclLang(String ustrdLclLang) {
        this.ustrdLclLang = ustrdLclLang;
    }

    public RmtInf withUstrdLclLang(String ustrdLclLang) {
        this.ustrdLclLang = ustrdLclLang;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RmtInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(ustrd).append(ustrdLclLang).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RmtInf) == false) {
            return false;
        }
        RmtInf rhs = ((RmtInf) other);
        return new EqualsBuilder().append(ustrd, rhs.ustrd).append(ustrdLclLang, rhs.ustrdLclLang).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

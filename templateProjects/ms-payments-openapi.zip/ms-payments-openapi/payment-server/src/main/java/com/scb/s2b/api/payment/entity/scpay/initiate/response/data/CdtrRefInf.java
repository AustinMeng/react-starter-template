
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tpCd",
    "tpPrtry",
    "tpIssr",
    "ref"
})
public class CdtrRefInf {

    @JsonProperty("tpCd")
    private String tpCd;
    @JsonProperty("tpPrtry")
    private String tpPrtry;
    @JsonProperty("tpIssr")
    private String tpIssr;
    @JsonProperty("ref")
    private String ref;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tpCd")
    public String getTpCd() {
        return tpCd;
    }

    @JsonProperty("tpCd")
    public void setTpCd(String tpCd) {
        this.tpCd = tpCd;
    }

    public CdtrRefInf withTpCd(String tpCd) {
        this.tpCd = tpCd;
        return this;
    }

    @JsonProperty("tpPrtry")
    public String getTpPrtry() {
        return tpPrtry;
    }

    @JsonProperty("tpPrtry")
    public void setTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
    }

    public CdtrRefInf withTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
        return this;
    }

    @JsonProperty("tpIssr")
    public String getTpIssr() {
        return tpIssr;
    }

    @JsonProperty("tpIssr")
    public void setTpIssr(String tpIssr) {
        this.tpIssr = tpIssr;
    }

    public CdtrRefInf withTpIssr(String tpIssr) {
        this.tpIssr = tpIssr;
        return this;
    }

    @JsonProperty("ref")
    public String getRef() {
        return ref;
    }

    @JsonProperty("ref")
    public void setRef(String ref) {
        this.ref = ref;
    }

    public CdtrRefInf withRef(String ref) {
        this.ref = ref;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CdtrRefInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tpCd).append(tpPrtry).append(tpIssr).append(ref).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CdtrRefInf) == false) {
            return false;
        }
        CdtrRefInf rhs = ((CdtrRefInf) other);
        return new EqualsBuilder().append(tpCd, rhs.tpCd).append(tpPrtry, rhs.tpPrtry).append(tpIssr, rhs.tpIssr).append(ref, rhs.ref).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

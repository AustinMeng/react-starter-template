package com.scb.s2b.api.payment.entity.payee.response;

import lombok.Getter;

@Getter
public class PayeeDtl {
    private String groupId;
    private PayeeRes payee;
}
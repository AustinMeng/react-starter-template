
package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instgChanl",
    "instgSubChanl",
    "instdChanl",
    "instdSubChanl"
})
public class Chanl {

    @JsonProperty("instgChanl")
    private String instgChanl;
    @JsonProperty("instgSubChanl")
    private String instgSubChanl;
    @JsonProperty("instdChanl")
    private String instdChanl;
    @JsonProperty("instdSubChanl")
    private String instdSubChanl;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instgChanl")
    public String getInstgChanl() {
        return instgChanl;
    }

    @JsonProperty("instgChanl")
    public void setInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
    }

    public Chanl withInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
        return this;
    }

    @JsonProperty("instgSubChanl")
    public String getInstgSubChanl() {
        return instgSubChanl;
    }

    @JsonProperty("instgSubChanl")
    public void setInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
    }

    public Chanl withInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
        return this;
    }

    @JsonProperty("instdChanl")
    public String getInstdChanl() {
        return instdChanl;
    }

    @JsonProperty("instdChanl")
    public void setInstdChanl(String instdChanl) {
        this.instdChanl = instdChanl;
    }

    public Chanl withInstdChanl(String instdChanl) {
        this.instdChanl = instdChanl;
        return this;
    }

    @JsonProperty("instdSubChanl")
    public String getInstdSubChanl() {
        return instdSubChanl;
    }

    @JsonProperty("instdSubChanl")
    public void setInstdSubChanl(String instdSubChanl) {
        this.instdSubChanl = instdSubChanl;
    }

    public Chanl withInstdSubChanl(String instdSubChanl) {
        this.instdSubChanl = instdSubChanl;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Chanl withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instgChanl).append(instgSubChanl).append(instdChanl).append(instdSubChanl).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Chanl) == false) {
            return false;
        }
        Chanl rhs = ((Chanl) other);
        return new EqualsBuilder().append(instgChanl, rhs.instgChanl).append(instgSubChanl, rhs.instgSubChanl).append(instdChanl, rhs.instdChanl).append(instdSubChanl, rhs.instdSubChanl).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

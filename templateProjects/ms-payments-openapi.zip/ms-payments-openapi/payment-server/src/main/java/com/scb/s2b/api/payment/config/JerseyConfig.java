package com.scb.s2b.api.payment.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.scb.channels.foundation.commons.jersey.filter.AESEncryptionAndHashingFilter;
import com.scb.channels.foundation.commons.jersey.filter.AxwayContentTypeCompensatorFilter;
import com.scb.channels.foundation.commons.uaas.UaasClient;
import com.scb.s2b.api.payment.api.exceptionmapper.JsonMappingExceptionMapper;
import com.scb.s2b.api.payment.api.exceptionmapper.JsonParseExceptionMapper;
import com.scb.s2b.api.payment.api.exceptionmapper.HttpClientExceptionMapper;
import com.scb.s2b.api.payment.api.exceptionmapper.PaymentNotFoundExceptionMapper;
import com.scb.s2b.api.payment.api.exceptionmapper.PaymentValidationExceptionMapper;
import com.scb.s2b.api.payment.api.exceptionmapper.RootExceptionMapper;
import com.scb.s2b.api.payment.api.filter.CorrelationFilter;
import com.scb.s2b.api.payment.api.filter.LoggingFilter;
import com.scb.s2b.api.payment.api.provider.JacksonObjectMapperProvider;
import com.scb.s2b.api.payment.api.v2.PaymentsApiFacade;
import com.scb.s2b.api.payment.api.resource.ApiListingResource;
import com.scb.s2b.api.payment.service.CadmService;
import io.swagger.v3.jaxrs2.SwaggerSerializers;
import io.swagger.v3.jaxrs2.integration.resources.AcceptHeaderOpenApiResource;
import javax.annotation.PostConstruct;
import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@ApplicationPath(JerseyConfig.ROOT_CONTEXT)
public class JerseyConfig extends ResourceConfig {

    public static final String ROOT_CONTEXT = "openapi";
    private volatile boolean isSwaggerInitialized = false;

    public JerseyConfig() {
        register(JacksonObjectMapperProvider.class);
        register(JacksonJaxbJsonProvider.class);
        register(JacksonFeature.class);
        register(CorrelationFilter.class);
        register(LoggingFilter.class);
        register(AxwayContentTypeCompensatorFilter.class);
        register(AESEncryptionAndHashingFilter.class);
        register(JsonParseExceptionMapper.class);
        register(JsonMappingExceptionMapper.class);
        register(PaymentValidationExceptionMapper.class);
        register(PaymentNotFoundExceptionMapper.class);
        register(RootExceptionMapper.class);
        register(PaymentsApiFacade.class);
        register(HttpClientExceptionMapper.class);
    }

    @PostConstruct
    public void init() {
        if(!isSwaggerInitialized) {
            this.configureSwagger();
            isSwaggerInitialized = true;
        }
    }

    private void configureSwagger() {
        register(ApiListingResource.class);
        register(AcceptHeaderOpenApiResource.class);
        register(SwaggerSerializers.class);
    }

    @SuppressWarnings("unused")
    @Bean
    @Profile("!test")
    public AESEncryptionAndHashingFilter aesFilter(CadmService cadmService,
            UaasClient uaasClient) {
        ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule())
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS, false);
        return new AESEncryptionAndHashingFilter(objectMapper,
                g -> cadmService.getGroupById(g).getApiservice().getPublicKey(),
                b -> uaasClient.sign(b, "SHA1withRSA"));
    }
}

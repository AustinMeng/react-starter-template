
package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "adrTp",
    "dept",
    "subDept",
    "strtNm",
    "bldgNb",
    "adrLine",
    "twnNm",
    "twnLctnNm",
    "ctrySubDvsn",
    "ctry",
    "pstCd",
    "pstBx",
    "flr",
    "room",
    "dstrctNm",
    "bldgNm"
})
public class PstlAdr {

    @JsonProperty("adrTp")
    private String adrTp;
    @JsonProperty("dept")
    private String dept;
    @JsonProperty("subDept")
    private String subDept;
    @JsonProperty("strtNm")
    private String strtNm;
    @JsonProperty("bldgNb")
    private String bldgNb;
    @JsonProperty("adrLine")
    private List<String> adrLine;
    @JsonProperty("twnNm")
    private String twnNm;
    @JsonProperty("twnLctnNm")
    private String twnLctnNm;
    @JsonProperty("ctrySubDvsn")
    private String ctrySubDvsn;
    @JsonProperty("ctry")
    private String ctry;
    @JsonProperty("pstCd")
    private String pstCd;
    @JsonProperty("pstBx")
    private String pstBx;
    @JsonProperty("flr")
    private String flr;
    @JsonProperty("room")
    private String room;
    @JsonProperty("dstrctNm")
    private String dstrctNm;
    @JsonProperty("bldgNm")
    private String bldgNm;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("adrTp")
    public String getAdrTp() {
        return adrTp;
    }

    @JsonProperty("adrTp")
    public void setAdrTp(String adrTp) {
        this.adrTp = adrTp;
    }

    public PstlAdr withAdrTp(String adrTp) {
        this.adrTp = adrTp;
        return this;
    }

    @JsonProperty("dept")
    public String getDept() {
        return dept;
    }

    @JsonProperty("dept")
    public void setDept(String dept) {
        this.dept = dept;
    }

    public PstlAdr withDept(String dept) {
        this.dept = dept;
        return this;
    }

    @JsonProperty("subDept")
    public String getSubDept() {
        return subDept;
    }

    @JsonProperty("subDept")
    public void setSubDept(String subDept) {
        this.subDept = subDept;
    }

    public PstlAdr withSubDept(String subDept) {
        this.subDept = subDept;
        return this;
    }

    @JsonProperty("strtNm")
    public String getStrtNm() {
        return strtNm;
    }

    @JsonProperty("strtNm")
    public void setStrtNm(String strtNm) {
        this.strtNm = strtNm;
    }

    public PstlAdr withStrtNm(String strtNm) {
        this.strtNm = strtNm;
        return this;
    }

    @JsonProperty("bldgNb")
    public String getBldgNb() {
        return bldgNb;
    }

    @JsonProperty("bldgNb")
    public void setBldgNb(String bldgNb) {
        this.bldgNb = bldgNb;
    }

    public PstlAdr withBldgNb(String bldgNb) {
        this.bldgNb = bldgNb;
        return this;
    }

    @JsonProperty("adrLine")
    public List<String> getAdrLine() {
        return adrLine;
    }

    @JsonProperty("adrLine")
    public void setAdrLine(List<String> adrLine) {
        this.adrLine = adrLine;
    }

    public PstlAdr withAdrLine(List<String> adrLine) {
        this.adrLine = adrLine;
        return this;
    }

    @JsonProperty("twnNm")
    public String getTwnNm() {
        return twnNm;
    }

    @JsonProperty("twnNm")
    public void setTwnNm(String twnNm) {
        this.twnNm = twnNm;
    }

    public PstlAdr withTwnNm(String twnNm) {
        this.twnNm = twnNm;
        return this;
    }

    @JsonProperty("twnLctnNm")
    public String getTwnLctnNm() {
        return twnLctnNm;
    }

    @JsonProperty("twnLctnNm")
    public void setTwnLctnNm(String twnLctnNm) {
        this.twnLctnNm = twnLctnNm;
    }

    public PstlAdr withTwnLctnNm(String twnLctnNm) {
        this.twnLctnNm = twnLctnNm;
        return this;
    }

    @JsonProperty("ctrySubDvsn")
    public String getCtrySubDvsn() {
        return ctrySubDvsn;
    }

    @JsonProperty("ctrySubDvsn")
    public void setCtrySubDvsn(String ctrySubDvsn) {
        this.ctrySubDvsn = ctrySubDvsn;
    }

    public PstlAdr withCtrySubDvsn(String ctrySubDvsn) {
        this.ctrySubDvsn = ctrySubDvsn;
        return this;
    }

    @JsonProperty("ctry")
    public String getCtry() {
        return ctry;
    }

    @JsonProperty("ctry")
    public void setCtry(String ctry) {
        this.ctry = ctry;
    }

    public PstlAdr withCtry(String ctry) {
        this.ctry = ctry;
        return this;
    }

    @JsonProperty("pstCd")
    public String getPstCd() {
        return pstCd;
    }

    @JsonProperty("pstCd")
    public void setPstCd(String pstCd) {
        this.pstCd = pstCd;
    }

    public PstlAdr withPstCd(String pstCd) {
        this.pstCd = pstCd;
        return this;
    }

    @JsonProperty("pstBx")
    public String getPstBx() {
        return pstBx;
    }

    @JsonProperty("pstBx")
    public void setPstBx(String pstBx) {
        this.pstBx = pstBx;
    }

    public PstlAdr withPstBx(String pstBx) {
        this.pstBx = pstBx;
        return this;
    }

    @JsonProperty("flr")
    public String getFlr() {
        return flr;
    }

    @JsonProperty("flr")
    public void setFlr(String flr) {
        this.flr = flr;
    }

    public PstlAdr withFlr(String flr) {
        this.flr = flr;
        return this;
    }

    @JsonProperty("room")
    public String getRoom() {
        return room;
    }

    @JsonProperty("room")
    public void setRoom(String room) {
        this.room = room;
    }

    public PstlAdr withRoom(String room) {
        this.room = room;
        return this;
    }

    @JsonProperty("dstrctNm")
    public String getDstrctNm() {
        return dstrctNm;
    }

    @JsonProperty("dstrctNm")
    public void setDstrctNm(String dstrctNm) {
        this.dstrctNm = dstrctNm;
    }

    public PstlAdr withDstrctNm(String dstrctNm) {
        this.dstrctNm = dstrctNm;
        return this;
    }

    @JsonProperty("bldgNm")
    public String getBldgNm() {
        return bldgNm;
    }

    @JsonProperty("bldgNm")
    public void setBldgNm(String bldgNm) {
        this.bldgNm = bldgNm;
    }

    public PstlAdr withBldgNm(String bldgNm) {
        this.bldgNm = bldgNm;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PstlAdr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(adrTp).append(dept).append(subDept).append(strtNm).append(bldgNb).append(adrLine).append(twnNm).append(twnLctnNm).append(ctrySubDvsn).append(ctry).append(pstCd).append(pstBx).append(flr).append(room).append(dstrctNm).append(bldgNm).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PstlAdr) == false) {
            return false;
        }
        PstlAdr rhs = ((PstlAdr) other);
        return new EqualsBuilder().append(adrTp, rhs.adrTp).append(dept, rhs.dept).append(subDept, rhs.subDept).append(strtNm, rhs.strtNm).append(bldgNb, rhs.bldgNb).append(adrLine, rhs.adrLine).append(twnNm, rhs.twnNm).append(twnLctnNm, rhs.twnLctnNm).append(ctrySubDvsn, rhs.ctrySubDvsn).append(ctry, rhs.ctry).append(pstCd, rhs.pstCd).append(pstBx, rhs.pstBx).append(flr, rhs.flr).append(room, rhs.room).append(dstrctNm, rhs.dstrctNm).append(bldgNm, rhs.bldgNm).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

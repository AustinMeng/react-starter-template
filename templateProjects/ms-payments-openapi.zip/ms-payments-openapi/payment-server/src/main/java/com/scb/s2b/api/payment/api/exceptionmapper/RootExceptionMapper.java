package com.scb.s2b.api.payment.api.exceptionmapper;

import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.payment.validation.ValidationErrorCode;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import org.apache.commons.lang3.StringUtils;
import org.postgresql.util.PSQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RootExceptionMapper implements ExceptionMapper<Throwable> {

    private static final Logger logger = LoggerFactory.getLogger(RootExceptionMapper.class);

    @Override
    public Response toResponse(Throwable throwable) {
        logger.error(throwable.getMessage(), throwable);

        if (throwable instanceof WebApplicationException) {
            return ((WebApplicationException) throwable).getResponse();
        } else if (Throwables.getRootCause(throwable) instanceof PSQLException) {
            PSQLException pe = (PSQLException) Throwables.getRootCause(throwable);
            if (StringUtils.equals(pe.getSQLState(), "23505")) {
                return Response.status(Response.Status.BAD_REQUEST)
                        .entity(ValidationErrorCode.AER_1113.getFullMessage(null))
                        .build();
            }
        }

        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(
            ImmutableMap.of(
                "errorMessage", "Internal Server Error",
                "errorCode", "AER-1999"
            )
        ).build();
    }
}

package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPayeeInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.entity.PayeeInstruction;
import com.scb.s2b.api.payment.entity.payee.response.PayeeDtl;
import com.scb.s2b.api.payment.service.PayeePaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPayeeInstructionTransformer;
import java.util.UUID;
import javax.inject.Singleton;
import javax.validation.Valid;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Singleton
public class PayeesPaymentApiImpl extends ApiBase {

    private final OpenApiPayeeInstructionTransformer openApiPayeeInstructionTransformer;

    private final PayeePaymentService payeePaymentService;

    @Autowired
    public PayeesPaymentApiImpl(OpenApiPayeeInstructionTransformer openApiPayeeInstructionTransformer,
            PayeePaymentService payeePaymentService) {
        this.openApiPayeeInstructionTransformer = openApiPayeeInstructionTransformer;
        this.payeePaymentService = payeePaymentService;
    }

    public Response payeesPaymentInitiate(String preVerified, @Valid OpenApiPayeeInstruction body,
            HttpHeaders headers) {
        String messageId = UUID.randomUUID().toString();
        String groupId = this.validateGroupId(headers);

        log.info("payeesPaymentInitiate messageId={}, groupId={}, clientReferenceId={}, nickName={}",
                messageId, groupId, body.getInstruction().getReferenceId(),
                body.getInstruction().getCreditor().getNickName());

        PayeeInstruction payeeInstruction = openApiPayeeInstructionTransformer
                .toPayeeInstruction(groupId, messageId, body);
        PayeeDtl payeeDtl = payeePaymentService.payeeLookup(groupId, messageId, payeeInstruction);

        OpenApiPaymentInstruction openApiPaymentInstruction = openApiPayeeInstructionTransformer
                .toOpenApiPaymentInstruction(payeeDtl, body);

        OpenApiPaymentId openApiPaymentId = payeePaymentService
                .route(messageId, body.getHeader().getCountryCode(), body.getInstruction().getPaymentType(), preVerified,
                        openApiPaymentInstruction, headers);
        return Response.ok(openApiPaymentId).build();
    }

}


package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "IBAN",
    "id",
    "idSchmeNmCd",
    "idSchmeNmPrtry",
    "idIssr",
    "tpCd",
    "tpPrtry",
    "ccy",
    "nm",
    "prxyTpCd",
    "prxyTpPrtry",
    "prxyId"
})
public class PrvsInstgAgtAcct {

    @JsonProperty("IBAN")
    private String iBAN;
    @JsonProperty("id")
    private String id;
    @JsonProperty("idSchmeNmCd")
    private String idSchmeNmCd;
    @JsonProperty("idSchmeNmPrtry")
    private String idSchmeNmPrtry;
    @JsonProperty("idIssr")
    private String idIssr;
    @JsonProperty("tpCd")
    private String tpCd;
    @JsonProperty("tpPrtry")
    private String tpPrtry;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("prxyTpCd")
    private String prxyTpCd;
    @JsonProperty("prxyTpPrtry")
    private String prxyTpPrtry;
    @JsonProperty("prxyId")
    private String prxyId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("IBAN")
    public String getIBAN() {
        return iBAN;
    }

    @JsonProperty("IBAN")
    public void setIBAN(String iBAN) {
        this.iBAN = iBAN;
    }

    public PrvsInstgAgtAcct withIBAN(String iBAN) {
        this.iBAN = iBAN;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public PrvsInstgAgtAcct withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("idSchmeNmCd")
    public String getIdSchmeNmCd() {
        return idSchmeNmCd;
    }

    @JsonProperty("idSchmeNmCd")
    public void setIdSchmeNmCd(String idSchmeNmCd) {
        this.idSchmeNmCd = idSchmeNmCd;
    }

    public PrvsInstgAgtAcct withIdSchmeNmCd(String idSchmeNmCd) {
        this.idSchmeNmCd = idSchmeNmCd;
        return this;
    }

    @JsonProperty("idSchmeNmPrtry")
    public String getIdSchmeNmPrtry() {
        return idSchmeNmPrtry;
    }

    @JsonProperty("idSchmeNmPrtry")
    public void setIdSchmeNmPrtry(String idSchmeNmPrtry) {
        this.idSchmeNmPrtry = idSchmeNmPrtry;
    }

    public PrvsInstgAgtAcct withIdSchmeNmPrtry(String idSchmeNmPrtry) {
        this.idSchmeNmPrtry = idSchmeNmPrtry;
        return this;
    }

    @JsonProperty("idIssr")
    public String getIdIssr() {
        return idIssr;
    }

    @JsonProperty("idIssr")
    public void setIdIssr(String idIssr) {
        this.idIssr = idIssr;
    }

    public PrvsInstgAgtAcct withIdIssr(String idIssr) {
        this.idIssr = idIssr;
        return this;
    }

    @JsonProperty("tpCd")
    public String getTpCd() {
        return tpCd;
    }

    @JsonProperty("tpCd")
    public void setTpCd(String tpCd) {
        this.tpCd = tpCd;
    }

    public PrvsInstgAgtAcct withTpCd(String tpCd) {
        this.tpCd = tpCd;
        return this;
    }

    @JsonProperty("tpPrtry")
    public String getTpPrtry() {
        return tpPrtry;
    }

    @JsonProperty("tpPrtry")
    public void setTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
    }

    public PrvsInstgAgtAcct withTpPrtry(String tpPrtry) {
        this.tpPrtry = tpPrtry;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public PrvsInstgAgtAcct withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public PrvsInstgAgtAcct withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("prxyTpCd")
    public String getPrxyTpCd() {
        return prxyTpCd;
    }

    @JsonProperty("prxyTpCd")
    public void setPrxyTpCd(String prxyTpCd) {
        this.prxyTpCd = prxyTpCd;
    }

    public PrvsInstgAgtAcct withPrxyTpCd(String prxyTpCd) {
        this.prxyTpCd = prxyTpCd;
        return this;
    }

    @JsonProperty("prxyTpPrtry")
    public String getPrxyTpPrtry() {
        return prxyTpPrtry;
    }

    @JsonProperty("prxyTpPrtry")
    public void setPrxyTpPrtry(String prxyTpPrtry) {
        this.prxyTpPrtry = prxyTpPrtry;
    }

    public PrvsInstgAgtAcct withPrxyTpPrtry(String prxyTpPrtry) {
        this.prxyTpPrtry = prxyTpPrtry;
        return this;
    }

    @JsonProperty("prxyId")
    public String getPrxyId() {
        return prxyId;
    }

    @JsonProperty("prxyId")
    public void setPrxyId(String prxyId) {
        this.prxyId = prxyId;
    }

    public PrvsInstgAgtAcct withPrxyId(String prxyId) {
        this.prxyId = prxyId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PrvsInstgAgtAcct withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(iBAN).append(id).append(idSchmeNmCd).append(idSchmeNmPrtry).append(idIssr).append(tpCd).append(tpPrtry).append(ccy).append(nm).append(prxyTpCd).append(prxyTpPrtry).append(prxyId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PrvsInstgAgtAcct) == false) {
            return false;
        }
        PrvsInstgAgtAcct rhs = ((PrvsInstgAgtAcct) other);
        return new EqualsBuilder().append(iBAN, rhs.iBAN).append(id, rhs.id).append(idSchmeNmCd, rhs.idSchmeNmCd).append(idSchmeNmPrtry, rhs.idSchmeNmPrtry).append(idIssr, rhs.idIssr).append(tpCd, rhs.tpCd).append(tpPrtry, rhs.tpPrtry).append(ccy, rhs.ccy).append(nm, rhs.nm).append(prxyTpCd, rhs.prxyTpCd).append(prxyTpPrtry, rhs.prxyTpPrtry).append(prxyId, rhs.prxyId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

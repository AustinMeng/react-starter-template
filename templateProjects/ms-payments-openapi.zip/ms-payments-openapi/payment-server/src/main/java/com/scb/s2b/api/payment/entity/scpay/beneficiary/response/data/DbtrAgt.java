
package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BICFI",
    "clrSysIdCd",
    "clrSysIdPrtry",
    "clrSysMmbId",
    "LEI",
    "nm",
    "brnchCd",
    "pstlAdr"
})
public class DbtrAgt {

    @JsonProperty("BICFI")
    private String bICFI;
    @JsonProperty("clrSysIdCd")
    private String clrSysIdCd;
    @JsonProperty("clrSysIdPrtry")
    private String clrSysIdPrtry;
    @JsonProperty("clrSysMmbId")
    private String clrSysMmbId;
    @JsonProperty("LEI")
    private String lEI;
    @JsonProperty("nm")
    private String nm;
    @JsonProperty("brnchCd")
    private String brnchCd;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("BICFI")
    public String getBICFI() {
        return bICFI;
    }

    @JsonProperty("BICFI")
    public void setBICFI(String bICFI) {
        this.bICFI = bICFI;
    }

    public DbtrAgt withBICFI(String bICFI) {
        this.bICFI = bICFI;
        return this;
    }

    @JsonProperty("clrSysIdCd")
    public String getClrSysIdCd() {
        return clrSysIdCd;
    }

    @JsonProperty("clrSysIdCd")
    public void setClrSysIdCd(String clrSysIdCd) {
        this.clrSysIdCd = clrSysIdCd;
    }

    public DbtrAgt withClrSysIdCd(String clrSysIdCd) {
        this.clrSysIdCd = clrSysIdCd;
        return this;
    }

    @JsonProperty("clrSysIdPrtry")
    public String getClrSysIdPrtry() {
        return clrSysIdPrtry;
    }

    @JsonProperty("clrSysIdPrtry")
    public void setClrSysIdPrtry(String clrSysIdPrtry) {
        this.clrSysIdPrtry = clrSysIdPrtry;
    }

    public DbtrAgt withClrSysIdPrtry(String clrSysIdPrtry) {
        this.clrSysIdPrtry = clrSysIdPrtry;
        return this;
    }

    @JsonProperty("clrSysMmbId")
    public String getClrSysMmbId() {
        return clrSysMmbId;
    }

    @JsonProperty("clrSysMmbId")
    public void setClrSysMmbId(String clrSysMmbId) {
        this.clrSysMmbId = clrSysMmbId;
    }

    public DbtrAgt withClrSysMmbId(String clrSysMmbId) {
        this.clrSysMmbId = clrSysMmbId;
        return this;
    }

    @JsonProperty("LEI")
    public String getLEI() {
        return lEI;
    }

    @JsonProperty("LEI")
    public void setLEI(String lEI) {
        this.lEI = lEI;
    }

    public DbtrAgt withLEI(String lEI) {
        this.lEI = lEI;
        return this;
    }

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public DbtrAgt withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("brnchCd")
    public String getBrnchCd() {
        return brnchCd;
    }

    @JsonProperty("brnchCd")
    public void setBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
    }

    public DbtrAgt withBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public DbtrAgt withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DbtrAgt withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(bICFI).append(clrSysIdCd).append(clrSysIdPrtry).append(clrSysMmbId).append(lEI).append(nm).append(brnchCd).append(pstlAdr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DbtrAgt) == false) {
            return false;
        }
        DbtrAgt rhs = ((DbtrAgt) other);
        return new EqualsBuilder().append(bICFI, rhs.bICFI).append(clrSysIdCd, rhs.clrSysIdCd).append(clrSysIdPrtry, rhs.clrSysIdPrtry).append(clrSysMmbId, rhs.clrSysMmbId).append(lEI, rhs.lEI).append(nm, rhs.nm).append(brnchCd, rhs.brnchCd).append(pstlAdr, rhs.pstlAdr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

package com.scb.s2b.api.payment.api.filter;

import org.apache.commons.lang3.StringUtils;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.ext.Provider;
import java.util.UUID;

import static com.scb.s2b.api.payment.config.PaymentConstant.CORRELATION_ID_HEADER;

@Provider
@PreMatching
public class CorrelationFilter implements ContainerRequestFilter {

    static final String CORRELATION_ID = "X-Request-ID";

    @Override
    public void filter(ContainerRequestContext containerRequestContext) {
        String correlationId = containerRequestContext.getHeaderString(CORRELATION_ID);

        if (StringUtils.isBlank(correlationId)) {
            correlationId = UUID.randomUUID().toString();
        }

        containerRequestContext.getHeaders().putSingle(CORRELATION_ID_HEADER, correlationId);
    }
}

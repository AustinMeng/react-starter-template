package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.payment.processor.request.CcsRequestProcessor;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.CcsPaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiBulkPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.PayrollRequestValidator;
import javax.inject.Singleton;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Singleton
public class PayrollApiImpl extends BulkPaymentApiBase {

    @Autowired
    public PayrollApiImpl(PayrollRequestValidator payrollRequestValidator,
            @Qualifier("payrollRequestProcessor") RequestProcessor requestProcessor,
            @Qualifier("ccsRequestProcessor") CcsRequestProcessor ccsRequestProcessor,
            OpenApiBulkPaymentInstructionTransformer openApiPayrollInstructionTransformer,
            CcsPaymentService ccsPaymentService) {
        super(openApiPayrollInstructionTransformer, payrollRequestValidator, requestProcessor, ccsRequestProcessor,
                ccsPaymentService);
    }
}

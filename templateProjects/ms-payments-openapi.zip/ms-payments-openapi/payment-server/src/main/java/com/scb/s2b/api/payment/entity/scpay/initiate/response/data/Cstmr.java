
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "s2bGrpId",
    "stsCustId",
    "qlCustId",
    "prty",
    "srcOfFnd",
    "lstdCpnyCd",
    "sciLeId",
    "sgmntCd",
    "sciSgmntCd",
    "sciSubSgmntCd",
    "mstrNb",
    "subProfileId",
    "bookgLctnId",
    "SNASGldnSrc",
    "SNASDataFr",
    "SNASLookupReqrd",
    "memo",
    "xtndedCutOffInd",
    "stdNm",
    "stdAdr",
    "stdNmAdr",
    "SNASLookupSts"
})
public class Cstmr {

    @JsonProperty("s2bGrpId")
    private String s2bGrpId;
    @JsonProperty("stsCustId")
    private String stsCustId;
    @JsonProperty("qlCustId")
    private String qlCustId;
    @JsonProperty("prty")
    private String prty;
    @JsonProperty("srcOfFnd")
    private String srcOfFnd;
    @JsonProperty("lstdCpnyCd")
    private String lstdCpnyCd;
    @JsonProperty("sciLeId")
    private String sciLeId;
    @JsonProperty("sgmntCd")
    private String sgmntCd;
    @JsonProperty("sciSgmntCd")
    private String sciSgmntCd;
    @JsonProperty("sciSubSgmntCd")
    private String sciSubSgmntCd;
    @JsonProperty("mstrNb")
    private String mstrNb;
    @JsonProperty("subProfileId")
    private String subProfileId;
    @JsonProperty("bookgLctnId")
    private String bookgLctnId;
    @JsonProperty("SNASGldnSrc")
    private String sNASGldnSrc;
    @JsonProperty("SNASDataFr")
    private String sNASDataFr;
    @JsonProperty("SNASLookupReqrd")
    private String sNASLookupReqrd;
    @JsonProperty("memo")
    private String memo;
    @JsonProperty("xtndedCutOffInd")
    private String xtndedCutOffInd;
    @JsonProperty("stdNm")
    private List<StdNm> stdNm = null;
    @JsonProperty("stdAdr")
    private StdAdr stdAdr;
    @JsonProperty("stdNmAdr")
    private List<StdNmAdr> stdNmAdr = null;
    @JsonProperty("SNASLookupSts")
    private List<SNASLookupSt> sNASLookupSts = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("s2bGrpId")
    public String getS2bGrpId() {
        return s2bGrpId;
    }

    @JsonProperty("s2bGrpId")
    public void setS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
    }

    public Cstmr withS2bGrpId(String s2bGrpId) {
        this.s2bGrpId = s2bGrpId;
        return this;
    }

    @JsonProperty("stsCustId")
    public String getStsCustId() {
        return stsCustId;
    }

    @JsonProperty("stsCustId")
    public void setStsCustId(String stsCustId) {
        this.stsCustId = stsCustId;
    }

    public Cstmr withStsCustId(String stsCustId) {
        this.stsCustId = stsCustId;
        return this;
    }

    @JsonProperty("qlCustId")
    public String getQlCustId() {
        return qlCustId;
    }

    @JsonProperty("qlCustId")
    public void setQlCustId(String qlCustId) {
        this.qlCustId = qlCustId;
    }

    public Cstmr withQlCustId(String qlCustId) {
        this.qlCustId = qlCustId;
        return this;
    }

    @JsonProperty("prty")
    public String getPrty() {
        return prty;
    }

    @JsonProperty("prty")
    public void setPrty(String prty) {
        this.prty = prty;
    }

    public Cstmr withPrty(String prty) {
        this.prty = prty;
        return this;
    }

    @JsonProperty("srcOfFnd")
    public String getSrcOfFnd() {
        return srcOfFnd;
    }

    @JsonProperty("srcOfFnd")
    public void setSrcOfFnd(String srcOfFnd) {
        this.srcOfFnd = srcOfFnd;
    }

    public Cstmr withSrcOfFnd(String srcOfFnd) {
        this.srcOfFnd = srcOfFnd;
        return this;
    }

    @JsonProperty("lstdCpnyCd")
    public String getLstdCpnyCd() {
        return lstdCpnyCd;
    }

    @JsonProperty("lstdCpnyCd")
    public void setLstdCpnyCd(String lstdCpnyCd) {
        this.lstdCpnyCd = lstdCpnyCd;
    }

    public Cstmr withLstdCpnyCd(String lstdCpnyCd) {
        this.lstdCpnyCd = lstdCpnyCd;
        return this;
    }

    @JsonProperty("sciLeId")
    public String getSciLeId() {
        return sciLeId;
    }

    @JsonProperty("sciLeId")
    public void setSciLeId(String sciLeId) {
        this.sciLeId = sciLeId;
    }

    public Cstmr withSciLeId(String sciLeId) {
        this.sciLeId = sciLeId;
        return this;
    }

    @JsonProperty("sgmntCd")
    public String getSgmntCd() {
        return sgmntCd;
    }

    @JsonProperty("sgmntCd")
    public void setSgmntCd(String sgmntCd) {
        this.sgmntCd = sgmntCd;
    }

    public Cstmr withSgmntCd(String sgmntCd) {
        this.sgmntCd = sgmntCd;
        return this;
    }

    @JsonProperty("sciSgmntCd")
    public String getSciSgmntCd() {
        return sciSgmntCd;
    }

    @JsonProperty("sciSgmntCd")
    public void setSciSgmntCd(String sciSgmntCd) {
        this.sciSgmntCd = sciSgmntCd;
    }

    public Cstmr withSciSgmntCd(String sciSgmntCd) {
        this.sciSgmntCd = sciSgmntCd;
        return this;
    }

    @JsonProperty("sciSubSgmntCd")
    public String getSciSubSgmntCd() {
        return sciSubSgmntCd;
    }

    @JsonProperty("sciSubSgmntCd")
    public void setSciSubSgmntCd(String sciSubSgmntCd) {
        this.sciSubSgmntCd = sciSubSgmntCd;
    }

    public Cstmr withSciSubSgmntCd(String sciSubSgmntCd) {
        this.sciSubSgmntCd = sciSubSgmntCd;
        return this;
    }

    @JsonProperty("mstrNb")
    public String getMstrNb() {
        return mstrNb;
    }

    @JsonProperty("mstrNb")
    public void setMstrNb(String mstrNb) {
        this.mstrNb = mstrNb;
    }

    public Cstmr withMstrNb(String mstrNb) {
        this.mstrNb = mstrNb;
        return this;
    }

    @JsonProperty("subProfileId")
    public String getSubProfileId() {
        return subProfileId;
    }

    @JsonProperty("subProfileId")
    public void setSubProfileId(String subProfileId) {
        this.subProfileId = subProfileId;
    }

    public Cstmr withSubProfileId(String subProfileId) {
        this.subProfileId = subProfileId;
        return this;
    }

    @JsonProperty("bookgLctnId")
    public String getBookgLctnId() {
        return bookgLctnId;
    }

    @JsonProperty("bookgLctnId")
    public void setBookgLctnId(String bookgLctnId) {
        this.bookgLctnId = bookgLctnId;
    }

    public Cstmr withBookgLctnId(String bookgLctnId) {
        this.bookgLctnId = bookgLctnId;
        return this;
    }

    @JsonProperty("SNASGldnSrc")
    public String getSNASGldnSrc() {
        return sNASGldnSrc;
    }

    @JsonProperty("SNASGldnSrc")
    public void setSNASGldnSrc(String sNASGldnSrc) {
        this.sNASGldnSrc = sNASGldnSrc;
    }

    public Cstmr withSNASGldnSrc(String sNASGldnSrc) {
        this.sNASGldnSrc = sNASGldnSrc;
        return this;
    }

    @JsonProperty("SNASDataFr")
    public String getSNASDataFr() {
        return sNASDataFr;
    }

    @JsonProperty("SNASDataFr")
    public void setSNASDataFr(String sNASDataFr) {
        this.sNASDataFr = sNASDataFr;
    }

    public Cstmr withSNASDataFr(String sNASDataFr) {
        this.sNASDataFr = sNASDataFr;
        return this;
    }

    @JsonProperty("SNASLookupReqrd")
    public String getSNASLookupReqrd() {
        return sNASLookupReqrd;
    }

    @JsonProperty("SNASLookupReqrd")
    public void setSNASLookupReqrd(String sNASLookupReqrd) {
        this.sNASLookupReqrd = sNASLookupReqrd;
    }

    public Cstmr withSNASLookupReqrd(String sNASLookupReqrd) {
        this.sNASLookupReqrd = sNASLookupReqrd;
        return this;
    }

    @JsonProperty("memo")
    public String getMemo() {
        return memo;
    }

    @JsonProperty("memo")
    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Cstmr withMemo(String memo) {
        this.memo = memo;
        return this;
    }

    @JsonProperty("xtndedCutOffInd")
    public String getXtndedCutOffInd() {
        return xtndedCutOffInd;
    }

    @JsonProperty("xtndedCutOffInd")
    public void setXtndedCutOffInd(String xtndedCutOffInd) {
        this.xtndedCutOffInd = xtndedCutOffInd;
    }

    public Cstmr withXtndedCutOffInd(String xtndedCutOffInd) {
        this.xtndedCutOffInd = xtndedCutOffInd;
        return this;
    }

    @JsonProperty("stdNm")
    public List<StdNm> getStdNm() {
        return stdNm;
    }

    @JsonProperty("stdNm")
    public void setStdNm(List<StdNm> stdNm) {
        this.stdNm = stdNm;
    }

    public Cstmr withStdNm(List<StdNm> stdNm) {
        this.stdNm = stdNm;
        return this;
    }

    @JsonProperty("stdAdr")
    public StdAdr getStdAdr() {
        return stdAdr;
    }

    @JsonProperty("stdAdr")
    public void setStdAdr(StdAdr stdAdr) {
        this.stdAdr = stdAdr;
    }

    public Cstmr withStdAdr(StdAdr stdAdr) {
        this.stdAdr = stdAdr;
        return this;
    }

    @JsonProperty("stdNmAdr")
    public List<StdNmAdr> getStdNmAdr() {
        return stdNmAdr;
    }

    @JsonProperty("stdNmAdr")
    public void setStdNmAdr(List<StdNmAdr> stdNmAdr) {
        this.stdNmAdr = stdNmAdr;
    }

    public Cstmr withStdNmAdr(List<StdNmAdr> stdNmAdr) {
        this.stdNmAdr = stdNmAdr;
        return this;
    }

    @JsonProperty("SNASLookupSts")
    public List<SNASLookupSt> getSNASLookupSts() {
        return sNASLookupSts;
    }

    @JsonProperty("SNASLookupSts")
    public void setSNASLookupSts(List<SNASLookupSt> sNASLookupSts) {
        this.sNASLookupSts = sNASLookupSts;
    }

    public Cstmr withSNASLookupSts(List<SNASLookupSt> sNASLookupSts) {
        this.sNASLookupSts = sNASLookupSts;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Cstmr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(s2bGrpId).append(stsCustId).append(qlCustId).append(prty).append(srcOfFnd).append(lstdCpnyCd).append(sciLeId).append(sgmntCd).append(sciSgmntCd).append(sciSubSgmntCd).append(mstrNb).append(subProfileId).append(bookgLctnId).append(sNASGldnSrc).append(sNASDataFr).append(sNASLookupReqrd).append(memo).append(xtndedCutOffInd).append(stdNm).append(stdAdr).append(stdNmAdr).append(sNASLookupSts).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Cstmr) == false) {
            return false;
        }
        Cstmr rhs = ((Cstmr) other);
        return new EqualsBuilder().append(s2bGrpId, rhs.s2bGrpId).append(stsCustId, rhs.stsCustId).append(qlCustId, rhs.qlCustId).append(prty, rhs.prty).append(srcOfFnd, rhs.srcOfFnd).append(lstdCpnyCd, rhs.lstdCpnyCd).append(sciLeId, rhs.sciLeId).append(sgmntCd, rhs.sgmntCd).append(sciSgmntCd, rhs.sciSgmntCd).append(sciSubSgmntCd, rhs.sciSubSgmntCd).append(mstrNb, rhs.mstrNb).append(subProfileId, rhs.subProfileId).append(bookgLctnId, rhs.bookgLctnId).append(sNASGldnSrc, rhs.sNASGldnSrc).append(sNASDataFr, rhs.sNASDataFr).append(sNASLookupReqrd, rhs.sNASLookupReqrd).append(memo, rhs.memo).append(xtndedCutOffInd, rhs.xtndedCutOffInd).append(stdNm, rhs.stdNm).append(stdAdr, rhs.stdAdr).append(stdNmAdr, rhs.stdNmAdr).append(sNASLookupSts, rhs.sNASLookupSts).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

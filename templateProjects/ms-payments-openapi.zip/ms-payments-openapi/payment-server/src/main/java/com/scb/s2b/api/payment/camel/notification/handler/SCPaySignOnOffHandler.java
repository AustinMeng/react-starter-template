package com.scb.s2b.api.payment.camel.notification.handler;

import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_ID;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_SCP;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.SUCCESS_STATUS;

import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.scb.s2b.api.payment.camel.ZkProducerAdapter;
import com.scb.s2b.api.payment.camel.controller.CamelController;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.notification.data.NotificationData.SignStatusType;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.util.Strings;

@Slf4j
public class SCPaySignOnOffHandler extends AbstractSNMNotificationHandler implements SNMNotificationHandler {

    private final MaintenanceService maintenanceService;

    private final ZkProducerAdapter zkProducer;

    private final ScpayProperties scpayProperties;

    private final CamelController camelController;

    private volatile String prevSignOnOffNotificationMsgId;

    private final Set<String> localSuspendedCountries = new HashSet<>();

    private final Set<String> localRevokedCountries = new HashSet<>();

    private final ReentrantLock lock = new ReentrantLock();

    public SCPaySignOnOffHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        super(exceptionProcessor, messageMarshaller);
        this.maintenanceService = maintenanceService;
        this.zkProducer = zkProducer;
        this.scpayProperties = scpayProperties;
        this.camelController = camelController;
    }

    @PostConstruct
    public void initiateSCPaySignOnOffHandler() {
        if (scpayProperties.getNotification().isEnabled()) {
            // register notification node on zk
            log.info("Notification is enabled, just initiate sc pay sign on off handler.");
            handleEvent(null);
            log.info("Initiating initiate sc pay sign on off handler has done.");
        }
    }

    @Override
    public List<EventCode> getCode() {
        return Arrays.asList(EventCode.SCPAY_SIGN_ON, EventCode.SCPAY_SIGN_OFF);
    }

    @Override
    public void handleNotification(Notification notification) {
        String messageId = notification.getHeader().getMessageId();
        log.info("start to handler snm notification messageId={}", messageId);

        NotificationHeader notificationHeader = notification.getHeader();
        try {
            String countryCode = Optional.ofNullable(notificationHeader.getCountryCode())
                    .map(StringUtils::strip)
                    .map(Strings::toUpperCase)
                    .orElse(StringUtils.EMPTY);
            Set<String> supportedCountries = maintenanceService.getSCPaySuspendSupportedCountries();
            if (supportedCountries == null || !supportedCountries.contains(countryCode)) {
                log.error("The country code {} is not allowed to sign on.", countryCode);
                throw new Exception(String.format("The country code %s is not allowed to sign on/off.", countryCode));
            }

            SignStatusType signOnType = notification.getData().getSignOn();
            if (signOnType == null) {
                log.error("/data/sgnOn is empty");
                throw new RuntimeException("/data/sgnOn is empty");
            }

            log.info("SignStatusType is {}", signOnType);
            maintenanceService.refreshSuspendedCountries();
            boolean needPublish = false;
            if (signOnType == SignStatusType.SIGN_ON) {
                // revoke Stop Payments for the Participant Bank BIC
                log.info("Need to revoke Stop Payments for the country code {}", countryCode);
                if (!maintenanceService.suspendedCountriesExists() ||
                        !maintenanceService.getRevokedCountries().contains(countryCode)) {
                    needPublish = true;
                }
                maintenanceService.removeCountry(countryCode, messageId);
            } else {
                // Stop Payments for the Participant Bank BIC
                log.info("Need to stop Payments for the country code {}", countryCode);
                if (!maintenanceService.suspendedCountriesExists() ||
                        !maintenanceService.getSuspendedCountries().contains(countryCode)) {
                    needPublish = true;
                }
                maintenanceService.addCountry(countryCode, messageId);
            }
            notification.getHeader().setResponseStatus(SUCCESS_STATUS);
            notification.getHeader().setDestination(CHANNEL_SCP);
            notification.getHeader().setProcessingDate(LocalDateTime.now());
            notification.getHeader().setChannelId(CHANNEL_ID);
            if (needPublish) {
                log.info("publish sign onOff notification with messageId={}.", messageId);
                zkProducer.publishSignOnOffNotification(messageId);
            }
        } catch (Exception e) {
            log.error("Failed to handle SCPay sign on/off notification {}",
                    notification.getHeader().getTransactionReference(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void handleEvent(String messageId) {
        if (StringUtils.isNotEmpty(messageId) && StringUtils.equals(messageId, prevSignOnOffNotificationMsgId)) {
            log.info("messageId={} has not been updated, skip refreshing sign on off route.", messageId);
            return;
        }
        log.info("Refreshing SCPaySignOnOff route for messageId={}.", messageId);
        refreshRouteStatus(false);
        log.info("Updating prevSignOnOffNotificationMsgId={}", messageId);
        prevSignOnOffNotificationMsgId = messageId;
    }

    @Override
    public void refreshRouteStatus(boolean daemon) {
        log.info("Starting to refresh sc pay sign on off route status for daemon={}", daemon);
        maintenanceService.refreshSuspendedCountries();
        boolean isLockAcquired;

        if (!daemon) {
            lock.lock();
        } else {
            isLockAcquired = lock.tryLock();

            if (!isLockAcquired) {
                log.info("Daemon task failed to acquire the lock for SCPay sign on off route status, try on the next round.");
                return;
            }
        }

        try {
            if (daemon) {
                localSuspendedCountries.clear();
                localRevokedCountries.clear();
            }
            Set<String> suspendedCountries = maintenanceService.getSuspendedCountries();
            SetView<String> diffSuspendedCountries = Sets.difference(suspendedCountries, localSuspendedCountries);
            if (diffSuspendedCountries.size() > 0) {
                log.info("{} changed country codes found for updating suspended route status", diffSuspendedCountries.size());
            }
            diffSuspendedCountries.forEach(countryCode -> {
                String endpoint = String.format(scpayProperties.getNotification().getSignOnOff().getSuspendQueueTemplate(),
                        countryCode);
                String routeId = String.format(scpayProperties.getNotification().getSignOnOff().getSuspendRouteIdTemplate(),
                        countryCode);
                int maxAttempts = scpayProperties.getNotification().getSignOnOff().getMaxAttempts();
                try {
                    log.info("add or suspend route for endpoint={}, routeId={}, countryCode={}", endpoint, routeId, countryCode);
                    camelController.addOrSuspendRoute(routeId, maxAttempts, this.suspendedRouteBuilder(endpoint, routeId));
                    localSuspendedCountries.add(countryCode);
                    localRevokedCountries.remove(countryCode);
                } catch (Exception e) {
                    log.error("Failed to suspend endpoint={}", endpoint, e);
                }
            });
            Set<String> revokedCountries = maintenanceService.getRevokedCountries();
            SetView<String> diffRevokedCountries = Sets.difference(revokedCountries, localRevokedCountries);
            if (diffRevokedCountries.size() > 0) {
                log.info("{} country codes found for updating revoked route status", diffRevokedCountries.size());
            }
            diffRevokedCountries.forEach(countryCode -> {
                String endpoint = String.format(scpayProperties.getNotification().getSignOnOff().getSuspendQueueTemplate(),
                        countryCode);
                String routeId = String.format(scpayProperties.getNotification().getSignOnOff().getSuspendRouteIdTemplate(),
                        countryCode);
                int maxAttempts = scpayProperties.getNotification().getSignOnOff().getMaxAttempts();
                try {
                    log.info("revoke route for endpoint={}, routeId={}, countryCode={}", endpoint, routeId, countryCode);
                    camelController.addOrResumeRoute(routeId, maxAttempts, this.revokedRouteBuilder(endpoint, routeId));
                    localRevokedCountries.add(countryCode);
                    localSuspendedCountries.remove(countryCode);
                } catch (Exception e) {
                    log.error("Failed to revoke endpoint={}", endpoint, e);
                }
            });
        } finally {
            lock.unlock();
        }
    }
}

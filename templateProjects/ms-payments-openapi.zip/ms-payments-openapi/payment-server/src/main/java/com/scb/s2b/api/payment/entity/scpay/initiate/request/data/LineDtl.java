
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "desc",
    "duePyblAmt",
    "duePyblAmtCcy",
    "cdtNoteAmt",
    "cdtNoteAmtCcy",
    "rmtdAmt",
    "rmtdAmtCcy",
    "dscntApldAmt",
    "taxAmt",
    "adjstmntAmtAndRsn"
})
public class LineDtl {

    @JsonProperty("id")
    private List<Id> id = null;
    @JsonProperty("desc")
    private String desc;
    @JsonProperty("duePyblAmt")
    private String duePyblAmt;
    @JsonProperty("duePyblAmtCcy")
    private String duePyblAmtCcy;
    @JsonProperty("cdtNoteAmt")
    private String cdtNoteAmt;
    @JsonProperty("cdtNoteAmtCcy")
    private String cdtNoteAmtCcy;
    @JsonProperty("rmtdAmt")
    private String rmtdAmt;
    @JsonProperty("rmtdAmtCcy")
    private String rmtdAmtCcy;
    @JsonProperty("dscntApldAmt")
    private List<DscntApldAmt> dscntApldAmt = null;
    @JsonProperty("taxAmt")
    private List<TaxAmt> taxAmt = null;
    @JsonProperty("adjstmntAmtAndRsn")
    private List<AdjstmntAmtAndRsn> adjstmntAmtAndRsn = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("id")
    public List<Id> getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(List<Id> id) {
        this.id = id;
    }

    public LineDtl withId(List<Id> id) {
        this.id = id;
        return this;
    }

    @JsonProperty("desc")
    public String getDesc() {
        return desc;
    }

    @JsonProperty("desc")
    public void setDesc(String desc) {
        this.desc = desc;
    }

    public LineDtl withDesc(String desc) {
        this.desc = desc;
        return this;
    }

    @JsonProperty("duePyblAmt")
    public String getDuePyblAmt() {
        return duePyblAmt;
    }

    @JsonProperty("duePyblAmt")
    public void setDuePyblAmt(String duePyblAmt) {
        this.duePyblAmt = duePyblAmt;
    }

    public LineDtl withDuePyblAmt(String duePyblAmt) {
        this.duePyblAmt = duePyblAmt;
        return this;
    }

    @JsonProperty("duePyblAmtCcy")
    public String getDuePyblAmtCcy() {
        return duePyblAmtCcy;
    }

    @JsonProperty("duePyblAmtCcy")
    public void setDuePyblAmtCcy(String duePyblAmtCcy) {
        this.duePyblAmtCcy = duePyblAmtCcy;
    }

    public LineDtl withDuePyblAmtCcy(String duePyblAmtCcy) {
        this.duePyblAmtCcy = duePyblAmtCcy;
        return this;
    }

    @JsonProperty("cdtNoteAmt")
    public String getCdtNoteAmt() {
        return cdtNoteAmt;
    }

    @JsonProperty("cdtNoteAmt")
    public void setCdtNoteAmt(String cdtNoteAmt) {
        this.cdtNoteAmt = cdtNoteAmt;
    }

    public LineDtl withCdtNoteAmt(String cdtNoteAmt) {
        this.cdtNoteAmt = cdtNoteAmt;
        return this;
    }

    @JsonProperty("cdtNoteAmtCcy")
    public String getCdtNoteAmtCcy() {
        return cdtNoteAmtCcy;
    }

    @JsonProperty("cdtNoteAmtCcy")
    public void setCdtNoteAmtCcy(String cdtNoteAmtCcy) {
        this.cdtNoteAmtCcy = cdtNoteAmtCcy;
    }

    public LineDtl withCdtNoteAmtCcy(String cdtNoteAmtCcy) {
        this.cdtNoteAmtCcy = cdtNoteAmtCcy;
        return this;
    }

    @JsonProperty("rmtdAmt")
    public String getRmtdAmt() {
        return rmtdAmt;
    }

    @JsonProperty("rmtdAmt")
    public void setRmtdAmt(String rmtdAmt) {
        this.rmtdAmt = rmtdAmt;
    }

    public LineDtl withRmtdAmt(String rmtdAmt) {
        this.rmtdAmt = rmtdAmt;
        return this;
    }

    @JsonProperty("rmtdAmtCcy")
    public String getRmtdAmtCcy() {
        return rmtdAmtCcy;
    }

    @JsonProperty("rmtdAmtCcy")
    public void setRmtdAmtCcy(String rmtdAmtCcy) {
        this.rmtdAmtCcy = rmtdAmtCcy;
    }

    public LineDtl withRmtdAmtCcy(String rmtdAmtCcy) {
        this.rmtdAmtCcy = rmtdAmtCcy;
        return this;
    }

    @JsonProperty("dscntApldAmt")
    public List<DscntApldAmt> getDscntApldAmt() {
        return dscntApldAmt;
    }

    @JsonProperty("dscntApldAmt")
    public void setDscntApldAmt(List<DscntApldAmt> dscntApldAmt) {
        this.dscntApldAmt = dscntApldAmt;
    }

    public LineDtl withDscntApldAmt(List<DscntApldAmt> dscntApldAmt) {
        this.dscntApldAmt = dscntApldAmt;
        return this;
    }

    @JsonProperty("taxAmt")
    public List<TaxAmt> getTaxAmt() {
        return taxAmt;
    }

    @JsonProperty("taxAmt")
    public void setTaxAmt(List<TaxAmt> taxAmt) {
        this.taxAmt = taxAmt;
    }

    public LineDtl withTaxAmt(List<TaxAmt> taxAmt) {
        this.taxAmt = taxAmt;
        return this;
    }

    @JsonProperty("adjstmntAmtAndRsn")
    public List<AdjstmntAmtAndRsn> getAdjstmntAmtAndRsn() {
        return adjstmntAmtAndRsn;
    }

    @JsonProperty("adjstmntAmtAndRsn")
    public void setAdjstmntAmtAndRsn(List<AdjstmntAmtAndRsn> adjstmntAmtAndRsn) {
        this.adjstmntAmtAndRsn = adjstmntAmtAndRsn;
    }

    public LineDtl withAdjstmntAmtAndRsn(List<AdjstmntAmtAndRsn> adjstmntAmtAndRsn) {
        this.adjstmntAmtAndRsn = adjstmntAmtAndRsn;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public LineDtl withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(id).append(desc).append(duePyblAmt).append(duePyblAmtCcy).append(cdtNoteAmt).append(cdtNoteAmtCcy).append(rmtdAmt).append(rmtdAmtCcy).append(dscntApldAmt).append(taxAmt).append(adjstmntAmtAndRsn).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LineDtl) == false) {
            return false;
        }
        LineDtl rhs = ((LineDtl) other);
        return new EqualsBuilder().append(id, rhs.id).append(desc, rhs.desc).append(duePyblAmt, rhs.duePyblAmt).append(duePyblAmtCcy, rhs.duePyblAmtCcy).append(cdtNoteAmt, rhs.cdtNoteAmt).append(cdtNoteAmtCcy, rhs.cdtNoteAmtCcy).append(rmtdAmt, rhs.rmtdAmt).append(rmtdAmtCcy, rhs.rmtdAmtCcy).append(dscntApldAmt, rhs.dscntApldAmt).append(taxAmt, rhs.taxAmt).append(adjstmntAmtAndRsn, rhs.adjstmntAmtAndRsn).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

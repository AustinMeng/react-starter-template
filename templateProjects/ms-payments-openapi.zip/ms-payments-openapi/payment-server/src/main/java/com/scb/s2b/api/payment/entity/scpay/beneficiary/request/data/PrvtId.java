
package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "birthDt",
    "prvcOfBirth",
    "cityOfBirth",
    "ctryOfBirth",
    "othr"
})
public class PrvtId {

    @JsonProperty("birthDt")
    private String birthDt;
    @JsonProperty("prvcOfBirth")
    private String prvcOfBirth;
    @JsonProperty("cityOfBirth")
    private String cityOfBirth;
    @JsonProperty("ctryOfBirth")
    private String ctryOfBirth;
    @JsonProperty("othr")
    private List<Othr> othr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("birthDt")
    public String getBirthDt() {
        return birthDt;
    }

    @JsonProperty("birthDt")
    public void setBirthDt(String birthDt) {
        this.birthDt = birthDt;
    }

    public PrvtId withBirthDt(String birthDt) {
        this.birthDt = birthDt;
        return this;
    }

    @JsonProperty("prvcOfBirth")
    public String getPrvcOfBirth() {
        return prvcOfBirth;
    }

    @JsonProperty("prvcOfBirth")
    public void setPrvcOfBirth(String prvcOfBirth) {
        this.prvcOfBirth = prvcOfBirth;
    }

    public PrvtId withPrvcOfBirth(String prvcOfBirth) {
        this.prvcOfBirth = prvcOfBirth;
        return this;
    }

    @JsonProperty("cityOfBirth")
    public String getCityOfBirth() {
        return cityOfBirth;
    }

    @JsonProperty("cityOfBirth")
    public void setCityOfBirth(String cityOfBirth) {
        this.cityOfBirth = cityOfBirth;
    }

    public PrvtId withCityOfBirth(String cityOfBirth) {
        this.cityOfBirth = cityOfBirth;
        return this;
    }

    @JsonProperty("ctryOfBirth")
    public String getCtryOfBirth() {
        return ctryOfBirth;
    }

    @JsonProperty("ctryOfBirth")
    public void setCtryOfBirth(String ctryOfBirth) {
        this.ctryOfBirth = ctryOfBirth;
    }

    public PrvtId withCtryOfBirth(String ctryOfBirth) {
        this.ctryOfBirth = ctryOfBirth;
        return this;
    }

    @JsonProperty("othr")
    public List<Othr> getOthr() {
        return othr;
    }

    @JsonProperty("othr")
    public void setOthr(List<Othr> othr) {
        this.othr = othr;
    }

    public PrvtId withOthr(List<Othr> othr) {
        this.othr = othr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PrvtId withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(birthDt).append(prvcOfBirth).append(cityOfBirth).append(ctryOfBirth).append(othr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PrvtId) == false) {
            return false;
        }
        PrvtId rhs = ((PrvtId) other);
        return new EqualsBuilder().append(birthDt, rhs.birthDt).append(prvcOfBirth, rhs.prvcOfBirth).append(cityOfBirth, rhs.cityOfBirth).append(ctryOfBirth, rhs.ctryOfBirth).append(othr, rhs.othr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

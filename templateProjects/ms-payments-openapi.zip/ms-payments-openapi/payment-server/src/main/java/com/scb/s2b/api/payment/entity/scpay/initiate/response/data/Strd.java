
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "addtlRmtInf",
    "rfrdDocInf",
    "rfrdDocAmt",
    "cdtrRefInf",
    "invcr",
    "invcee",
    "taxRmt",
    "grnshmtRmt"
})
public class Strd {

    @JsonProperty("addtlRmtInf")
    private List<String> addtlRmtInf = null;
    @JsonProperty("rfrdDocInf")
    private List<RfrdDocInf> rfrdDocInf = null;
    @JsonProperty("rfrdDocAmt")
    private RfrdDocAmt rfrdDocAmt;
    @JsonProperty("cdtrRefInf")
    private CdtrRefInf cdtrRefInf;
    @JsonProperty("invcr")
    private Invcr invcr;
    @JsonProperty("invcee")
    private Invcee invcee;
    @JsonProperty("taxRmt")
    private TaxRmt taxRmt;
    @JsonProperty("grnshmtRmt")
    private GrnshmtRmt grnshmtRmt;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("addtlRmtInf")
    public List<String> getAddtlRmtInf() {
        return addtlRmtInf;
    }

    @JsonProperty("addtlRmtInf")
    public void setAddtlRmtInf(List<String> addtlRmtInf) {
        this.addtlRmtInf = addtlRmtInf;
    }

    public Strd withAddtlRmtInf(List<String> addtlRmtInf) {
        this.addtlRmtInf = addtlRmtInf;
        return this;
    }

    @JsonProperty("rfrdDocInf")
    public List<RfrdDocInf> getRfrdDocInf() {
        return rfrdDocInf;
    }

    @JsonProperty("rfrdDocInf")
    public void setRfrdDocInf(List<RfrdDocInf> rfrdDocInf) {
        this.rfrdDocInf = rfrdDocInf;
    }

    public Strd withRfrdDocInf(List<RfrdDocInf> rfrdDocInf) {
        this.rfrdDocInf = rfrdDocInf;
        return this;
    }

    @JsonProperty("rfrdDocAmt")
    public RfrdDocAmt getRfrdDocAmt() {
        return rfrdDocAmt;
    }

    @JsonProperty("rfrdDocAmt")
    public void setRfrdDocAmt(RfrdDocAmt rfrdDocAmt) {
        this.rfrdDocAmt = rfrdDocAmt;
    }

    public Strd withRfrdDocAmt(RfrdDocAmt rfrdDocAmt) {
        this.rfrdDocAmt = rfrdDocAmt;
        return this;
    }

    @JsonProperty("cdtrRefInf")
    public CdtrRefInf getCdtrRefInf() {
        return cdtrRefInf;
    }

    @JsonProperty("cdtrRefInf")
    public void setCdtrRefInf(CdtrRefInf cdtrRefInf) {
        this.cdtrRefInf = cdtrRefInf;
    }

    public Strd withCdtrRefInf(CdtrRefInf cdtrRefInf) {
        this.cdtrRefInf = cdtrRefInf;
        return this;
    }

    @JsonProperty("invcr")
    public Invcr getInvcr() {
        return invcr;
    }

    @JsonProperty("invcr")
    public void setInvcr(Invcr invcr) {
        this.invcr = invcr;
    }

    public Strd withInvcr(Invcr invcr) {
        this.invcr = invcr;
        return this;
    }

    @JsonProperty("invcee")
    public Invcee getInvcee() {
        return invcee;
    }

    @JsonProperty("invcee")
    public void setInvcee(Invcee invcee) {
        this.invcee = invcee;
    }

    public Strd withInvcee(Invcee invcee) {
        this.invcee = invcee;
        return this;
    }

    @JsonProperty("taxRmt")
    public TaxRmt getTaxRmt() {
        return taxRmt;
    }

    @JsonProperty("taxRmt")
    public void setTaxRmt(TaxRmt taxRmt) {
        this.taxRmt = taxRmt;
    }

    public Strd withTaxRmt(TaxRmt taxRmt) {
        this.taxRmt = taxRmt;
        return this;
    }

    @JsonProperty("grnshmtRmt")
    public GrnshmtRmt getGrnshmtRmt() {
        return grnshmtRmt;
    }

    @JsonProperty("grnshmtRmt")
    public void setGrnshmtRmt(GrnshmtRmt grnshmtRmt) {
        this.grnshmtRmt = grnshmtRmt;
    }

    public Strd withGrnshmtRmt(GrnshmtRmt grnshmtRmt) {
        this.grnshmtRmt = grnshmtRmt;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Strd withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(addtlRmtInf).append(rfrdDocInf).append(rfrdDocAmt).append(cdtrRefInf).append(invcr).append(invcee).append(taxRmt).append(grnshmtRmt).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Strd) == false) {
            return false;
        }
        Strd rhs = ((Strd) other);
        return new EqualsBuilder().append(addtlRmtInf, rhs.addtlRmtInf).append(rfrdDocInf, rhs.rfrdDocInf).append(rfrdDocAmt, rhs.rfrdDocAmt).append(cdtrRefInf, rhs.cdtrRefInf).append(invcr, rhs.invcr).append(invcee, rhs.invcee).append(taxRmt, rhs.taxRmt).append(grnshmtRmt, rhs.grnshmtRmt).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

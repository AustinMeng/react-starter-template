
package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "txCtry",
    "sts",
    "chanl",
    "pmtTpInf",
    "pmtId",
    "amt",
    "sttlmDtTmInf",
    "dbtr",
    "dbtrAcct",
    "dbtrAgt",
    "dbtrAgtAcct",
    "cdtrAgt",
    "cdtrAgtAcct",
    "cdtr",
    "cdtrAcct",
    "cstmr",
    "rmtInf"
})
public class Datum {

    @JsonProperty("txCtry")
    private String txCtry;
    @JsonProperty("sts")
    private Sts sts;
    @JsonProperty("chanl")
    private Chanl chanl;
    @JsonProperty("pmtTpInf")
    private PmtTpInf pmtTpInf;
    @JsonProperty("pmtId")
    private PmtId pmtId;
    @JsonProperty("amt")
    private Amt amt;
    @JsonProperty("sttlmDtTmInf")
    private SttlmDtTmInf sttlmDtTmInf;
    @JsonProperty("dbtr")
    private Dbtr dbtr;
    @JsonProperty("dbtrAcct")
    private DbtrAcct dbtrAcct;
    @JsonProperty("dbtrAgt")
    private DbtrAgt dbtrAgt;
    @JsonProperty("dbtrAgtAcct")
    private DbtrAgtAcct dbtrAgtAcct;
    @JsonProperty("cdtrAgt")
    private CdtrAgt cdtrAgt;
    @JsonProperty("cdtrAgtAcct")
    private CdtrAgtAcct cdtrAgtAcct;
    @JsonProperty("cdtr")
    private Cdtr cdtr;
    @JsonProperty("cdtrAcct")
    private CdtrAcct cdtrAcct;
    @JsonProperty("cstmr")
    private Cstmr cstmr;
    @JsonProperty("rmtInf")
    private RmtInf rmtInf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("txCtry")
    public String getTxCtry() {
        return txCtry;
    }

    @JsonProperty("txCtry")
    public void setTxCtry(String txCtry) {
        this.txCtry = txCtry;
    }

    public Datum withTxCtry(String txCtry) {
        this.txCtry = txCtry;
        return this;
    }

    @JsonProperty("sts")
    public Sts getSts() {
        return sts;
    }

    @JsonProperty("sts")
    public void setSts(Sts sts) {
        this.sts = sts;
    }

    public Datum withSts(Sts sts) {
        this.sts = sts;
        return this;
    }

    @JsonProperty("chanl")
    public Chanl getChanl() {
        return chanl;
    }

    @JsonProperty("chanl")
    public void setChanl(Chanl chanl) {
        this.chanl = chanl;
    }

    public Datum withChanl(Chanl chanl) {
        this.chanl = chanl;
        return this;
    }

    @JsonProperty("pmtTpInf")
    public PmtTpInf getPmtTpInf() {
        return pmtTpInf;
    }

    @JsonProperty("pmtTpInf")
    public void setPmtTpInf(PmtTpInf pmtTpInf) {
        this.pmtTpInf = pmtTpInf;
    }

    public Datum withPmtTpInf(PmtTpInf pmtTpInf) {
        this.pmtTpInf = pmtTpInf;
        return this;
    }

    @JsonProperty("pmtId")
    public PmtId getPmtId() {
        return pmtId;
    }

    @JsonProperty("pmtId")
    public void setPmtId(PmtId pmtId) {
        this.pmtId = pmtId;
    }

    public Datum withPmtId(PmtId pmtId) {
        this.pmtId = pmtId;
        return this;
    }

    @JsonProperty("amt")
    public Amt getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(Amt amt) {
        this.amt = amt;
    }

    public Datum withAmt(Amt amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("sttlmDtTmInf")
    public SttlmDtTmInf getSttlmDtTmInf() {
        return sttlmDtTmInf;
    }

    @JsonProperty("sttlmDtTmInf")
    public void setSttlmDtTmInf(SttlmDtTmInf sttlmDtTmInf) {
        this.sttlmDtTmInf = sttlmDtTmInf;
    }

    public Datum withSttlmDtTmInf(SttlmDtTmInf sttlmDtTmInf) {
        this.sttlmDtTmInf = sttlmDtTmInf;
        return this;
    }

    @JsonProperty("dbtr")
    public Dbtr getDbtr() {
        return dbtr;
    }

    @JsonProperty("dbtr")
    public void setDbtr(Dbtr dbtr) {
        this.dbtr = dbtr;
    }

    public Datum withDbtr(Dbtr dbtr) {
        this.dbtr = dbtr;
        return this;
    }

    @JsonProperty("dbtrAcct")
    public DbtrAcct getDbtrAcct() {
        return dbtrAcct;
    }

    @JsonProperty("dbtrAcct")
    public void setDbtrAcct(DbtrAcct dbtrAcct) {
        this.dbtrAcct = dbtrAcct;
    }

    public Datum withDbtrAcct(DbtrAcct dbtrAcct) {
        this.dbtrAcct = dbtrAcct;
        return this;
    }

    @JsonProperty("dbtrAgt")
    public DbtrAgt getDbtrAgt() {
        return dbtrAgt;
    }

    @JsonProperty("dbtrAgt")
    public void setDbtrAgt(DbtrAgt dbtrAgt) {
        this.dbtrAgt = dbtrAgt;
    }

    public Datum withDbtrAgt(DbtrAgt dbtrAgt) {
        this.dbtrAgt = dbtrAgt;
        return this;
    }

    @JsonProperty("dbtrAgtAcct")
    public DbtrAgtAcct getDbtrAgtAcct() {
        return dbtrAgtAcct;
    }

    @JsonProperty("dbtrAgtAcct")
    public void setDbtrAgtAcct(DbtrAgtAcct dbtrAgtAcct) {
        this.dbtrAgtAcct = dbtrAgtAcct;
    }

    public Datum withDbtrAgtAcct(DbtrAgtAcct dbtrAgtAcct) {
        this.dbtrAgtAcct = dbtrAgtAcct;
        return this;
    }

    @JsonProperty("cdtrAgt")
    public CdtrAgt getCdtrAgt() {
        return cdtrAgt;
    }

    @JsonProperty("cdtrAgt")
    public void setCdtrAgt(CdtrAgt cdtrAgt) {
        this.cdtrAgt = cdtrAgt;
    }

    public Datum withCdtrAgt(CdtrAgt cdtrAgt) {
        this.cdtrAgt = cdtrAgt;
        return this;
    }

    @JsonProperty("cdtrAgtAcct")
    public CdtrAgtAcct getCdtrAgtAcct() {
        return cdtrAgtAcct;
    }

    @JsonProperty("cdtrAgtAcct")
    public void setCdtrAgtAcct(CdtrAgtAcct cdtrAgtAcct) {
        this.cdtrAgtAcct = cdtrAgtAcct;
    }

    public Datum withCdtrAgtAcct(CdtrAgtAcct cdtrAgtAcct) {
        this.cdtrAgtAcct = cdtrAgtAcct;
        return this;
    }

    @JsonProperty("cdtr")
    public Cdtr getCdtr() {
        return cdtr;
    }

    @JsonProperty("cdtr")
    public void setCdtr(Cdtr cdtr) {
        this.cdtr = cdtr;
    }

    public Datum withCdtr(Cdtr cdtr) {
        this.cdtr = cdtr;
        return this;
    }

    @JsonProperty("cdtrAcct")
    public CdtrAcct getCdtrAcct() {
        return cdtrAcct;
    }

    @JsonProperty("cdtrAcct")
    public void setCdtrAcct(CdtrAcct cdtrAcct) {
        this.cdtrAcct = cdtrAcct;
    }

    public Datum withCdtrAcct(CdtrAcct cdtrAcct) {
        this.cdtrAcct = cdtrAcct;
        return this;
    }

    @JsonProperty("cstmr")
    public Cstmr getCstmr() {
        return cstmr;
    }

    @JsonProperty("cstmr")
    public void setCstmr(Cstmr cstmr) {
        this.cstmr = cstmr;
    }

    public Datum withCstmr(Cstmr cstmr) {
        this.cstmr = cstmr;
        return this;
    }

    @JsonProperty("rmtInf")
    public RmtInf getRmtInf() {
        return rmtInf;
    }

    @JsonProperty("rmtInf")
    public void setRmtInf(RmtInf rmtInf) {
        this.rmtInf = rmtInf;
    }

    public Datum withRmtInf(RmtInf rmtInf) {
        this.rmtInf = rmtInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Datum withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(txCtry).append(sts).append(chanl).append(pmtTpInf).append(pmtId).append(amt).append(sttlmDtTmInf).append(dbtr).append(dbtrAcct).append(dbtrAgt).append(dbtrAgtAcct).append(cdtrAgt).append(cdtrAgtAcct).append(cdtr).append(cdtrAcct).append(cstmr).append(rmtInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Datum) == false) {
            return false;
        }
        Datum rhs = ((Datum) other);
        return new EqualsBuilder().append(txCtry, rhs.txCtry).append(sts, rhs.sts).append(chanl, rhs.chanl).append(pmtTpInf, rhs.pmtTpInf).append(pmtId, rhs.pmtId).append(amt, rhs.amt).append(sttlmDtTmInf, rhs.sttlmDtTmInf).append(dbtr, rhs.dbtr).append(dbtrAcct, rhs.dbtrAcct).append(dbtrAgt, rhs.dbtrAgt).append(dbtrAgtAcct, rhs.dbtrAgtAcct).append(cdtrAgt, rhs.cdtrAgt).append(cdtrAgtAcct, rhs.cdtrAgtAcct).append(cdtr, rhs.cdtr).append(cdtrAcct, rhs.cdtrAcct).append(cstmr, rhs.cstmr).append(rmtInf, rhs.rmtInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

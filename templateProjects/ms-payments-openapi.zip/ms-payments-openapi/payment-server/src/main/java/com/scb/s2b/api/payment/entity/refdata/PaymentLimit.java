package com.scb.s2b.api.payment.entity.refdata;

import com.scb.s2b.api.payment.entity.DenominatedAmount;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class PaymentLimit implements Serializable {
    private LimitType type;
    private DenominatedAmount value;

    public enum LimitType {GROUP, CURRENCY;
        @Override
        public String toString() {
            return this.name().toLowerCase();
        }
    }
}

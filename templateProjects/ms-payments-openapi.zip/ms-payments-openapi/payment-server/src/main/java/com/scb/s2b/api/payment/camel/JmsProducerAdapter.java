package com.scb.s2b.api.payment.camel;

import com.google.common.collect.ImmutableMap;
import java.util.Map;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JmsProducerAdapter {

    private final ProducerTemplate producer;

    private static final String QUEUE_PREFIX = ".*:(topic|queue):";
    private static final String HEADER_TOPIC = "topic";
    private static final String HEADER_CORRELATION_ID = "correlationId";
    private static final String HEADER_CONVERSATION_ID = "conversationId";
    private static final String HEADER_SOLACE_ISXML = "JMS_Solace_isXML";

    private static final Logger logger = LoggerFactory.getLogger(JmsProducerAdapter.class);

    public JmsProducerAdapter(ProducerTemplate producer) {
        this.producer = producer;
    }

    public void publishPaymentRequest(String endpoint, String msgId, String message) {
        logger.info("Sending message {} to {}", msgId, endpoint);
        producer.sendBodyAndHeaders(endpoint, message, this.getJmsHeaders(endpoint, msgId));
    }

    public void publishNMNotificationMessage(String queue, String msgId, String message) {
        logger.info("Sending NM notification message {} to {}", msgId, queue);
        producer.sendBodyAndHeaders(queue, message, this.getJmsHeaders(queue, msgId));
    }

    String getQueueFromEndpoint(String endpoint) {
        return StringUtils.removePattern(endpoint, QUEUE_PREFIX);
    }

    Map<String, Object> getJmsHeaders(String endpoint, String msgId) {
        return ImmutableMap.of(
                HEADER_TOPIC, this.getQueueFromEndpoint(endpoint),
                HEADER_CORRELATION_ID, msgId,
                HEADER_CONVERSATION_ID, msgId,
                HEADER_SOLACE_ISXML, false
        );
    }
}

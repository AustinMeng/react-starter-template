package com.scb.s2b.api.payment.entity.payee.response;

import java.util.List;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class PayeeRes {
    private String nickName;
    private String payeeStatus;
    private String name;
    private PostalAddress postalAddress;
    private Contact contact;
    private List<Identity> identity = null;
    private String jointPayeeName;
    private String jointPayeeIdentity;
    private String jointPayeeIdentityType;
    private PayeeExtension payeeExtension;
    private PayeeInfoExtension payeeInfoExtension;
    private PayeeAgent payeeAgent;
    private List<PayeeAccount> account = null;
    private IntermediaryAgent intermediaryAgent;
}

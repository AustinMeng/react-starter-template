
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "txCtry",
    "txCityCd",
    "dbtRefNb",
    "dbtLegSucssInd",
    "tellerId",
    "chanlCutOffInd",
    "instrForDbtrAgt",
    "lgnBrnchCd",
    "prcgBrnchCd",
    "formTp",
    "instgAgtXtndedCutOffInd",
    "sts",
    "usrActnInf",
    "chanl",
    "sttlmInf",
    "pmtTpInf",
    "fwdgAgt",
    "instgAgt",
    "instdAgt",
    "pmtId",
    "amt",
    "sttlmDtTmInf",
    "xchgRateInf",
    "chrgsInf",
    "prvsInstgAgt1",
    "prvsInstgAgt1Acct",
    "prvsInstgAgt2",
    "prvsInstgAgt2Acct",
    "prvsInstgAgt3",
    "prvsInstgAgt3Acct",
    "intrmyAgt1",
    "intrmyAgt1Acct",
    "intrmyAgt2",
    "intrmyAgt2Acct",
    "intrmyAgt3",
    "intrmyAgt3Acct",
    "ultmtDbtr",
    "initgPty",
    "dbtr",
    "dbtrAcct",
    "dbtrAgt",
    "dbtrAgtAcct",
    "reqdDbtAcctInf",
    "cdtrAgt",
    "cdtrAgtAcct",
    "cdtr",
    "cdtrAcct",
    "ultmtCdtr",
    "instrForCdtrAgt",
    "instrForNxtAgt",
    "purp",
    "rgltryRptg",
    "tax",
    "cstmr",
    "rltdRmtInf",
    "rmtInf",
    "chqInstr",
    "billAndMrchntTxInf",
    "epfAndPnsnTxInf",
    "statutoryAndTaxTxInf",
    "rgltryDocVrfctnInf",
    "invcDtls",
    "splmtryData",
    "txSttlmInf"
})
public class Data {

    @JsonProperty("txCtry")
    private String txCtry;
    @JsonProperty("txCityCd")
    private String txCityCd;
    @JsonProperty("dbtRefNb")
    private String dbtRefNb;
    @JsonProperty("dbtLegSucssInd")
    private String dbtLegSucssInd;
    @JsonProperty("tellerId")
    private String tellerId;
    @JsonProperty("chanlCutOffInd")
    private String chanlCutOffInd;
    @JsonProperty("instrForDbtrAgt")
    private String instrForDbtrAgt;
    @JsonProperty("lgnBrnchCd")
    private String lgnBrnchCd;
    @JsonProperty("prcgBrnchCd")
    private String prcgBrnchCd;
    @JsonProperty("formTp")
    private String formTp;
    @JsonProperty("instgAgtXtndedCutOffInd")
    private String instgAgtXtndedCutOffInd;
    @JsonProperty("sts")
    private Sts sts;
    @JsonProperty("usrActnInf")
    private UsrActnInf usrActnInf;
    @JsonProperty("chanl")
    private Chanl chanl;
    @JsonProperty("sttlmInf")
    private SttlmInf sttlmInf;
    @JsonProperty("pmtTpInf")
    private PmtTpInf pmtTpInf;
    @JsonProperty("fwdgAgt")
    private FwdgAgt fwdgAgt;
    @JsonProperty("instgAgt")
    private InstgAgt instgAgt;
    @JsonProperty("instdAgt")
    private InstdAgt instdAgt;
    @JsonProperty("pmtId")
    private PmtId pmtId;
    @JsonProperty("amt")
    private Amt amt;
    @JsonProperty("sttlmDtTmInf")
    private SttlmDtTmInf sttlmDtTmInf;
    @JsonProperty("xchgRateInf")
    private XchgRateInf xchgRateInf;
    @JsonProperty("chrgsInf")
    private ChrgsInf chrgsInf;
    @JsonProperty("prvsInstgAgt1")
    private PrvsInstgAgt prvsInstgAgt1;
    @JsonProperty("prvsInstgAgt1Acct")
    private PrvsInstgAgtAcct prvsInstgAgt1Acct;
    @JsonProperty("prvsInstgAgt2")
    private PrvsInstgAgt prvsInstgAgt2;
    @JsonProperty("prvsInstgAgt2Acct")
    private PrvsInstgAgtAcct prvsInstgAgt2Acct;
    @JsonProperty("prvsInstgAgt3")
    private PrvsInstgAgt prvsInstgAgt3;
    @JsonProperty("prvsInstgAgt3Acct")
    private PrvsInstgAgtAcct prvsInstgAgt3Acct;
    @JsonProperty("intrmyAgt1")
    private IntrmyAgt intrmyAgt1;
    @JsonProperty("intrmyAgt1Acct")
    private IntrmyAgtAcct intrmyAgt1Acct;
    @JsonProperty("intrmyAgt2")
    private IntrmyAgt intrmyAgt2;
    @JsonProperty("intrmyAgt2Acct")
    private IntrmyAgtAcct intrmyAgt2Acct;
    @JsonProperty("intrmyAgt3")
    private IntrmyAgt intrmyAgt3;
    @JsonProperty("intrmyAgt3Acct")
    private IntrmyAgtAcct intrmyAgt3Acct;
    @JsonProperty("ultmtDbtr")
    private UltmtDbtr ultmtDbtr;
    @JsonProperty("initgPty")
    private InitgPty initgPty;
    @JsonProperty("dbtr")
    private Dbtr dbtr;
    @JsonProperty("dbtrAcct")
    private DbtrAcct dbtrAcct;
    @JsonProperty("dbtrAgt")
    private DbtrAgt dbtrAgt;
    @JsonProperty("dbtrAgtAcct")
    private DbtrAgtAcct dbtrAgtAcct;
    @JsonProperty("reqdDbtAcctInf")
    private ReqdDbtAcctInf reqdDbtAcctInf;
    @JsonProperty("cdtrAgt")
    private CdtrAgt cdtrAgt;
    @JsonProperty("cdtrAgtAcct")
    private CdtrAgtAcct cdtrAgtAcct;
    @JsonProperty("cdtr")
    private Cdtr cdtr;
    @JsonProperty("cdtrAcct")
    private CdtrAcct cdtrAcct;
    @JsonProperty("ultmtCdtr")
    private UltmtCdtr ultmtCdtr;
    @JsonProperty("instrForCdtrAgt")
    private List<InstrForCdtrAgt> instrForCdtrAgt = null;
    @JsonProperty("instrForNxtAgt")
    private List<InstrForNxtAgt> instrForNxtAgt = null;
    @JsonProperty("purp")
    private Purp purp;
    @JsonProperty("rgltryRptg")
    private List<RgltryRptg> rgltryRptg = null;
    @JsonProperty("tax")
    private Tax tax;
    @JsonProperty("cstmr")
    private Cstmr cstmr;
    @JsonProperty("rltdRmtInf")
    private RltdRmtInf rltdRmtInf;
    @JsonProperty("rmtInf")
    private RmtInf rmtInf;
    @JsonProperty("chqInstr")
    private ChqInstr chqInstr;
    @JsonProperty("billAndMrchntTxInf")
    private BillAndMrchntTxInf billAndMrchntTxInf;
    @JsonProperty("epfAndPnsnTxInf")
    private EpfAndPnsnTxInf epfAndPnsnTxInf;
    @JsonProperty("statutoryAndTaxTxInf")
    private StatutoryAndTaxTxInf statutoryAndTaxTxInf;
    @JsonProperty("rgltryDocVrfctnInf")
    private RgltryDocVrfctnInf rgltryDocVrfctnInf;
    @JsonProperty("invcDtls")
    private InvcDtls invcDtls;
    @JsonProperty("splmtryData")
    private SplmtryData splmtryData;
    @JsonProperty("txSttlmInf")
    private TxSttlmInf txSttlmInf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("txCtry")
    public String getTxCtry() {
        return txCtry;
    }

    @JsonProperty("txCtry")
    public void setTxCtry(String txCtry) {
        this.txCtry = txCtry;
    }

    public Data withTxCtry(String txCtry) {
        this.txCtry = txCtry;
        return this;
    }

    @JsonProperty("txCityCd")
    public String getTxCityCd() {
        return txCityCd;
    }

    @JsonProperty("txCityCd")
    public void setTxCityCd(String txCityCd) {
        this.txCityCd = txCityCd;
    }

    public Data withTxCityCd(String txCityCd) {
        this.txCityCd = txCityCd;
        return this;
    }

    @JsonProperty("dbtRefNb")
    public String getDbtRefNb() {
        return dbtRefNb;
    }

    @JsonProperty("dbtRefNb")
    public void setDbtRefNb(String dbtRefNb) {
        this.dbtRefNb = dbtRefNb;
    }

    public Data withDbtRefNb(String dbtRefNb) {
        this.dbtRefNb = dbtRefNb;
        return this;
    }

    @JsonProperty("dbtLegSucssInd")
    public String getDbtLegSucssInd() {
        return dbtLegSucssInd;
    }

    @JsonProperty("dbtLegSucssInd")
    public void setDbtLegSucssInd(String dbtLegSucssInd) {
        this.dbtLegSucssInd = dbtLegSucssInd;
    }

    public Data withDbtLegSucssInd(String dbtLegSucssInd) {
        this.dbtLegSucssInd = dbtLegSucssInd;
        return this;
    }

    @JsonProperty("tellerId")
    public String getTellerId() {
        return tellerId;
    }

    @JsonProperty("tellerId")
    public void setTellerId(String tellerId) {
        this.tellerId = tellerId;
    }

    public Data withTellerId(String tellerId) {
        this.tellerId = tellerId;
        return this;
    }

    @JsonProperty("chanlCutOffInd")
    public String getChanlCutOffInd() {
        return chanlCutOffInd;
    }

    @JsonProperty("chanlCutOffInd")
    public void setChanlCutOffInd(String chanlCutOffInd) {
        this.chanlCutOffInd = chanlCutOffInd;
    }

    public Data withChanlCutOffInd(String chanlCutOffInd) {
        this.chanlCutOffInd = chanlCutOffInd;
        return this;
    }

    @JsonProperty("instrForDbtrAgt")
    public String getInstrForDbtrAgt() {
        return instrForDbtrAgt;
    }

    @JsonProperty("instrForDbtrAgt")
    public void setInstrForDbtrAgt(String instrForDbtrAgt) {
        this.instrForDbtrAgt = instrForDbtrAgt;
    }

    public Data withInstrForDbtrAgt(String instrForDbtrAgt) {
        this.instrForDbtrAgt = instrForDbtrAgt;
        return this;
    }

    @JsonProperty("lgnBrnchCd")
    public String getLgnBrnchCd() {
        return lgnBrnchCd;
    }

    @JsonProperty("lgnBrnchCd")
    public void setLgnBrnchCd(String lgnBrnchCd) {
        this.lgnBrnchCd = lgnBrnchCd;
    }

    public Data withLgnBrnchCd(String lgnBrnchCd) {
        this.lgnBrnchCd = lgnBrnchCd;
        return this;
    }

    @JsonProperty("prcgBrnchCd")
    public String getPrcgBrnchCd() {
        return prcgBrnchCd;
    }

    @JsonProperty("prcgBrnchCd")
    public void setPrcgBrnchCd(String prcgBrnchCd) {
        this.prcgBrnchCd = prcgBrnchCd;
    }

    public Data withPrcgBrnchCd(String prcgBrnchCd) {
        this.prcgBrnchCd = prcgBrnchCd;
        return this;
    }

    @JsonProperty("formTp")
    public String getFormTp() {
        return formTp;
    }

    @JsonProperty("formTp")
    public void setFormTp(String formTp) {
        this.formTp = formTp;
    }

    public Data withFormTp(String formTp) {
        this.formTp = formTp;
        return this;
    }

    @JsonProperty("instgAgtXtndedCutOffInd")
    public String getInstgAgtXtndedCutOffInd() {
        return instgAgtXtndedCutOffInd;
    }

    @JsonProperty("instgAgtXtndedCutOffInd")
    public void setInstgAgtXtndedCutOffInd(String instgAgtXtndedCutOffInd) {
        this.instgAgtXtndedCutOffInd = instgAgtXtndedCutOffInd;
    }

    public Data withInstgAgtXtndedCutOffInd(String instgAgtXtndedCutOffInd) {
        this.instgAgtXtndedCutOffInd = instgAgtXtndedCutOffInd;
        return this;
    }

    @JsonProperty("sts")
    public Sts getSts() {
        return sts;
    }

    @JsonProperty("sts")
    public void setSts(Sts sts) {
        this.sts = sts;
    }

    public Data withSts(Sts sts) {
        this.sts = sts;
        return this;
    }

    @JsonProperty("usrActnInf")
    public UsrActnInf getUsrActnInf() {
        return usrActnInf;
    }

    @JsonProperty("usrActnInf")
    public void setUsrActnInf(UsrActnInf usrActnInf) {
        this.usrActnInf = usrActnInf;
    }

    public Data withUsrActnInf(UsrActnInf usrActnInf) {
        this.usrActnInf = usrActnInf;
        return this;
    }

    @JsonProperty("chanl")
    public Chanl getChanl() {
        return chanl;
    }

    @JsonProperty("chanl")
    public void setChanl(Chanl chanl) {
        this.chanl = chanl;
    }

    public Data withChanl(Chanl chanl) {
        this.chanl = chanl;
        return this;
    }

    @JsonProperty("sttlmInf")
    public SttlmInf getSttlmInf() {
        return sttlmInf;
    }

    @JsonProperty("sttlmInf")
    public void setSttlmInf(SttlmInf sttlmInf) {
        this.sttlmInf = sttlmInf;
    }

    public Data withSttlmInf(SttlmInf sttlmInf) {
        this.sttlmInf = sttlmInf;
        return this;
    }

    @JsonProperty("pmtTpInf")
    public PmtTpInf getPmtTpInf() {
        return pmtTpInf;
    }

    @JsonProperty("pmtTpInf")
    public void setPmtTpInf(PmtTpInf pmtTpInf) {
        this.pmtTpInf = pmtTpInf;
    }

    public Data withPmtTpInf(PmtTpInf pmtTpInf) {
        this.pmtTpInf = pmtTpInf;
        return this;
    }

    @JsonProperty("fwdgAgt")
    public FwdgAgt getFwdgAgt() {
        return fwdgAgt;
    }

    @JsonProperty("fwdgAgt")
    public void setFwdgAgt(FwdgAgt fwdgAgt) {
        this.fwdgAgt = fwdgAgt;
    }

    public Data withFwdgAgt(FwdgAgt fwdgAgt) {
        this.fwdgAgt = fwdgAgt;
        return this;
    }

    @JsonProperty("instgAgt")
    public InstgAgt getInstgAgt() {
        return instgAgt;
    }

    @JsonProperty("instgAgt")
    public void setInstgAgt(InstgAgt instgAgt) {
        this.instgAgt = instgAgt;
    }

    public Data withInstgAgt(InstgAgt instgAgt) {
        this.instgAgt = instgAgt;
        return this;
    }

    @JsonProperty("instdAgt")
    public InstdAgt getInstdAgt() {
        return instdAgt;
    }

    @JsonProperty("instdAgt")
    public void setInstdAgt(InstdAgt instdAgt) {
        this.instdAgt = instdAgt;
    }

    public Data withInstdAgt(InstdAgt instdAgt) {
        this.instdAgt = instdAgt;
        return this;
    }

    @JsonProperty("pmtId")
    public PmtId getPmtId() {
        return pmtId;
    }

    @JsonProperty("pmtId")
    public void setPmtId(PmtId pmtId) {
        this.pmtId = pmtId;
    }

    public Data withPmtId(PmtId pmtId) {
        this.pmtId = pmtId;
        return this;
    }

    @JsonProperty("amt")
    public Amt getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(Amt amt) {
        this.amt = amt;
    }

    public Data withAmt(Amt amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("sttlmDtTmInf")
    public SttlmDtTmInf getSttlmDtTmInf() {
        return sttlmDtTmInf;
    }

    @JsonProperty("sttlmDtTmInf")
    public void setSttlmDtTmInf(SttlmDtTmInf sttlmDtTmInf) {
        this.sttlmDtTmInf = sttlmDtTmInf;
    }

    public Data withSttlmDtTmInf(SttlmDtTmInf sttlmDtTmInf) {
        this.sttlmDtTmInf = sttlmDtTmInf;
        return this;
    }

    @JsonProperty("xchgRateInf")
    public XchgRateInf getXchgRateInf() {
        return xchgRateInf;
    }

    @JsonProperty("xchgRateInf")
    public void setXchgRateInf(XchgRateInf xchgRateInf) {
        this.xchgRateInf = xchgRateInf;
    }

    public Data withXchgRateInf(XchgRateInf xchgRateInf) {
        this.xchgRateInf = xchgRateInf;
        return this;
    }

    @JsonProperty("chrgsInf")
    public ChrgsInf getChrgsInf() {
        return chrgsInf;
    }

    @JsonProperty("chrgsInf")
    public void setChrgsInf(ChrgsInf chrgsInf) {
        this.chrgsInf = chrgsInf;
    }

    public Data withChrgsInf(ChrgsInf chrgsInf) {
        this.chrgsInf = chrgsInf;
        return this;
    }

    @JsonProperty("prvsInstgAgt1")
    public PrvsInstgAgt getPrvsInstgAgt1() {
        return prvsInstgAgt1;
    }

    @JsonProperty("prvsInstgAgt1")
    public void setPrvsInstgAgt1(PrvsInstgAgt prvsInstgAgt1) {
        this.prvsInstgAgt1 = prvsInstgAgt1;
    }

    public Data withPrvsInstgAgt1(PrvsInstgAgt prvsInstgAgt1) {
        this.prvsInstgAgt1 = prvsInstgAgt1;
        return this;
    }

    @JsonProperty("prvsInstgAgt1Acct")
    public PrvsInstgAgtAcct getPrvsInstgAgt1Acct() {
        return prvsInstgAgt1Acct;
    }

    @JsonProperty("prvsInstgAgt1Acct")
    public void setPrvsInstgAgt1Acct(PrvsInstgAgtAcct prvsInstgAgt1Acct) {
        this.prvsInstgAgt1Acct = prvsInstgAgt1Acct;
    }

    public Data withPrvsInstgAgt1Acct(PrvsInstgAgtAcct prvsInstgAgt1Acct) {
        this.prvsInstgAgt1Acct = prvsInstgAgt1Acct;
        return this;
    }

    @JsonProperty("prvsInstgAgt2")
    public PrvsInstgAgt getPrvsInstgAgt2() {
        return prvsInstgAgt2;
    }

    @JsonProperty("prvsInstgAgt2")
    public void setPrvsInstgAgt2(PrvsInstgAgt prvsInstgAgt2) {
        this.prvsInstgAgt2 = prvsInstgAgt2;
    }

    public Data withPrvsInstgAgt2(PrvsInstgAgt prvsInstgAgt2) {
        this.prvsInstgAgt2 = prvsInstgAgt2;
        return this;
    }

    @JsonProperty("prvsInstgAgt2Acct")
    public PrvsInstgAgtAcct getPrvsInstgAgt2Acct() {
        return prvsInstgAgt2Acct;
    }

    @JsonProperty("prvsInstgAgt2Acct")
    public void setPrvsInstgAgt2Acct(PrvsInstgAgtAcct prvsInstgAgt2Acct) {
        this.prvsInstgAgt2Acct = prvsInstgAgt2Acct;
    }

    public Data withPrvsInstgAgt2Acct(PrvsInstgAgtAcct prvsInstgAgt2Acct) {
        this.prvsInstgAgt2Acct = prvsInstgAgt2Acct;
        return this;
    }

    @JsonProperty("prvsInstgAgt3")
    public PrvsInstgAgt getPrvsInstgAgt3() {
        return prvsInstgAgt3;
    }

    @JsonProperty("prvsInstgAgt3")
    public void setPrvsInstgAgt3(PrvsInstgAgt prvsInstgAgt3) {
        this.prvsInstgAgt3 = prvsInstgAgt3;
    }

    public Data withPrvsInstgAgt3(PrvsInstgAgt prvsInstgAgt3) {
        this.prvsInstgAgt3 = prvsInstgAgt3;
        return this;
    }

    @JsonProperty("prvsInstgAgt3Acct")
    public PrvsInstgAgtAcct getPrvsInstgAgt3Acct() {
        return prvsInstgAgt3Acct;
    }

    @JsonProperty("prvsInstgAgt3Acct")
    public void setPrvsInstgAgt3Acct(PrvsInstgAgtAcct prvsInstgAgt3Acct) {
        this.prvsInstgAgt3Acct = prvsInstgAgt3Acct;
    }

    public Data withPrvsInstgAgt3Acct(PrvsInstgAgtAcct prvsInstgAgt3Acct) {
        this.prvsInstgAgt3Acct = prvsInstgAgt3Acct;
        return this;
    }

    @JsonProperty("intrmyAgt1")
    public IntrmyAgt getIntrmyAgt1() {
        return intrmyAgt1;
    }

    @JsonProperty("intrmyAgt1")
    public void setIntrmyAgt1(IntrmyAgt intrmyAgt1) {
        this.intrmyAgt1 = intrmyAgt1;
    }

    public Data withIntrmyAgt1(IntrmyAgt intrmyAgt1) {
        this.intrmyAgt1 = intrmyAgt1;
        return this;
    }

    @JsonProperty("intrmyAgt1Acct")
    public IntrmyAgtAcct getIntrmyAgt1Acct() {
        return intrmyAgt1Acct;
    }

    @JsonProperty("intrmyAgt1Acct")
    public void setIntrmyAgt1Acct(IntrmyAgtAcct intrmyAgt1Acct) {
        this.intrmyAgt1Acct = intrmyAgt1Acct;
    }

    public Data withIntrmyAgt1Acct(IntrmyAgtAcct intrmyAgt1Acct) {
        this.intrmyAgt1Acct = intrmyAgt1Acct;
        return this;
    }

    @JsonProperty("intrmyAgt2")
    public IntrmyAgt getIntrmyAgt2() {
        return intrmyAgt2;
    }

    @JsonProperty("intrmyAgt2")
    public void setIntrmyAgt2(IntrmyAgt intrmyAgt2) {
        this.intrmyAgt2 = intrmyAgt2;
    }

    public Data withIntrmyAgt2(IntrmyAgt intrmyAgt2) {
        this.intrmyAgt2 = intrmyAgt2;
        return this;
    }

    @JsonProperty("intrmyAgt2Acct")
    public IntrmyAgtAcct getIntrmyAgt2Acct() {
        return intrmyAgt2Acct;
    }

    @JsonProperty("intrmyAgt2Acct")
    public void setIntrmyAgt2Acct(IntrmyAgtAcct intrmyAgt2Acct) {
        this.intrmyAgt2Acct = intrmyAgt2Acct;
    }

    public Data withIntrmyAgt2Acct(IntrmyAgtAcct intrmyAgt2Acct) {
        this.intrmyAgt2Acct = intrmyAgt2Acct;
        return this;
    }

    @JsonProperty("intrmyAgt3")
    public IntrmyAgt getIntrmyAgt3() {
        return intrmyAgt3;
    }

    @JsonProperty("intrmyAgt3")
    public void setIntrmyAgt3(IntrmyAgt intrmyAgt3) {
        this.intrmyAgt3 = intrmyAgt3;
    }

    public Data withIntrmyAgt3(IntrmyAgt intrmyAgt3) {
        this.intrmyAgt3 = intrmyAgt3;
        return this;
    }

    @JsonProperty("intrmyAgt3Acct")
    public IntrmyAgtAcct getIntrmyAgt3Acct() {
        return intrmyAgt3Acct;
    }

    @JsonProperty("intrmyAgt3Acct")
    public void setIntrmyAgt3Acct(IntrmyAgtAcct intrmyAgt3Acct) {
        this.intrmyAgt3Acct = intrmyAgt3Acct;
    }

    public Data withIntrmyAgt3Acct(IntrmyAgtAcct intrmyAgt3Acct) {
        this.intrmyAgt3Acct = intrmyAgt3Acct;
        return this;
    }

    @JsonProperty("ultmtDbtr")
    public UltmtDbtr getUltmtDbtr() {
        return ultmtDbtr;
    }

    @JsonProperty("ultmtDbtr")
    public void setUltmtDbtr(UltmtDbtr ultmtDbtr) {
        this.ultmtDbtr = ultmtDbtr;
    }

    public Data withUltmtDbtr(UltmtDbtr ultmtDbtr) {
        this.ultmtDbtr = ultmtDbtr;
        return this;
    }

    @JsonProperty("initgPty")
    public InitgPty getInitgPty() {
        return initgPty;
    }

    @JsonProperty("initgPty")
    public void setInitgPty(InitgPty initgPty) {
        this.initgPty = initgPty;
    }

    public Data withInitgPty(InitgPty initgPty) {
        this.initgPty = initgPty;
        return this;
    }

    @JsonProperty("dbtr")
    public Dbtr getDbtr() {
        return dbtr;
    }

    @JsonProperty("dbtr")
    public void setDbtr(Dbtr dbtr) {
        this.dbtr = dbtr;
    }

    public Data withDbtr(Dbtr dbtr) {
        this.dbtr = dbtr;
        return this;
    }

    @JsonProperty("dbtrAcct")
    public DbtrAcct getDbtrAcct() {
        return dbtrAcct;
    }

    @JsonProperty("dbtrAcct")
    public void setDbtrAcct(DbtrAcct dbtrAcct) {
        this.dbtrAcct = dbtrAcct;
    }

    public Data withDbtrAcct(DbtrAcct dbtrAcct) {
        this.dbtrAcct = dbtrAcct;
        return this;
    }

    @JsonProperty("dbtrAgt")
    public DbtrAgt getDbtrAgt() {
        return dbtrAgt;
    }

    @JsonProperty("dbtrAgt")
    public void setDbtrAgt(DbtrAgt dbtrAgt) {
        this.dbtrAgt = dbtrAgt;
    }

    public Data withDbtrAgt(DbtrAgt dbtrAgt) {
        this.dbtrAgt = dbtrAgt;
        return this;
    }

    @JsonProperty("dbtrAgtAcct")
    public DbtrAgtAcct getDbtrAgtAcct() {
        return dbtrAgtAcct;
    }

    @JsonProperty("dbtrAgtAcct")
    public void setDbtrAgtAcct(DbtrAgtAcct dbtrAgtAcct) {
        this.dbtrAgtAcct = dbtrAgtAcct;
    }

    public Data withDbtrAgtAcct(DbtrAgtAcct dbtrAgtAcct) {
        this.dbtrAgtAcct = dbtrAgtAcct;
        return this;
    }

    @JsonProperty("reqdDbtAcctInf")
    public ReqdDbtAcctInf getReqdDbtAcctInf() {
        return reqdDbtAcctInf;
    }

    @JsonProperty("reqdDbtAcctInf")
    public void setReqdDbtAcctInf(ReqdDbtAcctInf reqdDbtAcctInf) {
        this.reqdDbtAcctInf = reqdDbtAcctInf;
    }

    public Data withReqdDbtAcctInf(ReqdDbtAcctInf reqdDbtAcctInf) {
        this.reqdDbtAcctInf = reqdDbtAcctInf;
        return this;
    }

    @JsonProperty("cdtrAgt")
    public CdtrAgt getCdtrAgt() {
        return cdtrAgt;
    }

    @JsonProperty("cdtrAgt")
    public void setCdtrAgt(CdtrAgt cdtrAgt) {
        this.cdtrAgt = cdtrAgt;
    }

    public Data withCdtrAgt(CdtrAgt cdtrAgt) {
        this.cdtrAgt = cdtrAgt;
        return this;
    }

    @JsonProperty("cdtrAgtAcct")
    public CdtrAgtAcct getCdtrAgtAcct() {
        return cdtrAgtAcct;
    }

    @JsonProperty("cdtrAgtAcct")
    public void setCdtrAgtAcct(CdtrAgtAcct cdtrAgtAcct) {
        this.cdtrAgtAcct = cdtrAgtAcct;
    }

    public Data withCdtrAgtAcct(CdtrAgtAcct cdtrAgtAcct) {
        this.cdtrAgtAcct = cdtrAgtAcct;
        return this;
    }

    @JsonProperty("cdtr")
    public Cdtr getCdtr() {
        return cdtr;
    }

    @JsonProperty("cdtr")
    public void setCdtr(Cdtr cdtr) {
        this.cdtr = cdtr;
    }

    public Data withCdtr(Cdtr cdtr) {
        this.cdtr = cdtr;
        return this;
    }

    @JsonProperty("cdtrAcct")
    public CdtrAcct getCdtrAcct() {
        return cdtrAcct;
    }

    @JsonProperty("cdtrAcct")
    public void setCdtrAcct(CdtrAcct cdtrAcct) {
        this.cdtrAcct = cdtrAcct;
    }

    public Data withCdtrAcct(CdtrAcct cdtrAcct) {
        this.cdtrAcct = cdtrAcct;
        return this;
    }

    @JsonProperty("ultmtCdtr")
    public UltmtCdtr getUltmtCdtr() {
        return ultmtCdtr;
    }

    @JsonProperty("ultmtCdtr")
    public void setUltmtCdtr(UltmtCdtr ultmtCdtr) {
        this.ultmtCdtr = ultmtCdtr;
    }

    public Data withUltmtCdtr(UltmtCdtr ultmtCdtr) {
        this.ultmtCdtr = ultmtCdtr;
        return this;
    }

    @JsonProperty("instrForCdtrAgt")
    public List<InstrForCdtrAgt> getInstrForCdtrAgt() {
        return instrForCdtrAgt;
    }

    @JsonProperty("instrForCdtrAgt")
    public void setInstrForCdtrAgt(List<InstrForCdtrAgt> instrForCdtrAgt) {
        this.instrForCdtrAgt = instrForCdtrAgt;
    }

    public Data withInstrForCdtrAgt(List<InstrForCdtrAgt> instrForCdtrAgt) {
        this.instrForCdtrAgt = instrForCdtrAgt;
        return this;
    }

    @JsonProperty("instrForNxtAgt")
    public List<InstrForNxtAgt> getInstrForNxtAgt() {
        return instrForNxtAgt;
    }

    @JsonProperty("instrForNxtAgt")
    public void setInstrForNxtAgt(List<InstrForNxtAgt> instrForNxtAgt) {
        this.instrForNxtAgt = instrForNxtAgt;
    }

    public Data withInstrForNxtAgt(List<InstrForNxtAgt> instrForNxtAgt) {
        this.instrForNxtAgt = instrForNxtAgt;
        return this;
    }

    @JsonProperty("purp")
    public Purp getPurp() {
        return purp;
    }

    @JsonProperty("purp")
    public void setPurp(Purp purp) {
        this.purp = purp;
    }

    public Data withPurp(Purp purp) {
        this.purp = purp;
        return this;
    }

    @JsonProperty("rgltryRptg")
    public List<RgltryRptg> getRgltryRptg() {
        return rgltryRptg;
    }

    @JsonProperty("rgltryRptg")
    public void setRgltryRptg(List<RgltryRptg> rgltryRptg) {
        this.rgltryRptg = rgltryRptg;
    }

    public Data withRgltryRptg(List<RgltryRptg> rgltryRptg) {
        this.rgltryRptg = rgltryRptg;
        return this;
    }

    @JsonProperty("tax")
    public Tax getTax() {
        return tax;
    }

    @JsonProperty("tax")
    public void setTax(Tax tax) {
        this.tax = tax;
    }

    public Data withTax(Tax tax) {
        this.tax = tax;
        return this;
    }

    @JsonProperty("cstmr")
    public Cstmr getCstmr() {
        return cstmr;
    }

    @JsonProperty("cstmr")
    public void setCstmr(Cstmr cstmr) {
        this.cstmr = cstmr;
    }

    public Data withCstmr(Cstmr cstmr) {
        this.cstmr = cstmr;
        return this;
    }

    @JsonProperty("rltdRmtInf")
    public RltdRmtInf getRltdRmtInf() {
        return rltdRmtInf;
    }

    @JsonProperty("rltdRmtInf")
    public void setRltdRmtInf(RltdRmtInf rltdRmtInf) {
        this.rltdRmtInf = rltdRmtInf;
    }

    public Data withRltdRmtInf(RltdRmtInf rltdRmtInf) {
        this.rltdRmtInf = rltdRmtInf;
        return this;
    }

    @JsonProperty("rmtInf")
    public RmtInf getRmtInf() {
        return rmtInf;
    }

    @JsonProperty("rmtInf")
    public void setRmtInf(RmtInf rmtInf) {
        this.rmtInf = rmtInf;
    }

    public Data withRmtInf(RmtInf rmtInf) {
        this.rmtInf = rmtInf;
        return this;
    }

    @JsonProperty("chqInstr")
    public ChqInstr getChqInstr() {
        return chqInstr;
    }

    @JsonProperty("chqInstr")
    public void setChqInstr(ChqInstr chqInstr) {
        this.chqInstr = chqInstr;
    }

    public Data withChqInstr(ChqInstr chqInstr) {
        this.chqInstr = chqInstr;
        return this;
    }

    @JsonProperty("billAndMrchntTxInf")
    public BillAndMrchntTxInf getBillAndMrchntTxInf() {
        return billAndMrchntTxInf;
    }

    @JsonProperty("billAndMrchntTxInf")
    public void setBillAndMrchntTxInf(BillAndMrchntTxInf billAndMrchntTxInf) {
        this.billAndMrchntTxInf = billAndMrchntTxInf;
    }

    public Data withBillAndMrchntTxInf(BillAndMrchntTxInf billAndMrchntTxInf) {
        this.billAndMrchntTxInf = billAndMrchntTxInf;
        return this;
    }

    @JsonProperty("epfAndPnsnTxInf")
    public EpfAndPnsnTxInf getEpfAndPnsnTxInf() {
        return epfAndPnsnTxInf;
    }

    @JsonProperty("epfAndPnsnTxInf")
    public void setEpfAndPnsnTxInf(EpfAndPnsnTxInf epfAndPnsnTxInf) {
        this.epfAndPnsnTxInf = epfAndPnsnTxInf;
    }

    public Data withEpfAndPnsnTxInf(EpfAndPnsnTxInf epfAndPnsnTxInf) {
        this.epfAndPnsnTxInf = epfAndPnsnTxInf;
        return this;
    }

    @JsonProperty("statutoryAndTaxTxInf")
    public StatutoryAndTaxTxInf getStatutoryAndTaxTxInf() {
        return statutoryAndTaxTxInf;
    }

    @JsonProperty("statutoryAndTaxTxInf")
    public void setStatutoryAndTaxTxInf(StatutoryAndTaxTxInf statutoryAndTaxTxInf) {
        this.statutoryAndTaxTxInf = statutoryAndTaxTxInf;
    }

    public Data withStatutoryAndTaxTxInf(StatutoryAndTaxTxInf statutoryAndTaxTxInf) {
        this.statutoryAndTaxTxInf = statutoryAndTaxTxInf;
        return this;
    }

    @JsonProperty("rgltryDocVrfctnInf")
    public RgltryDocVrfctnInf getRgltryDocVrfctnInf() {
        return rgltryDocVrfctnInf;
    }

    @JsonProperty("rgltryDocVrfctnInf")
    public void setRgltryDocVrfctnInf(RgltryDocVrfctnInf rgltryDocVrfctnInf) {
        this.rgltryDocVrfctnInf = rgltryDocVrfctnInf;
    }

    public Data withRgltryDocVrfctnInf(RgltryDocVrfctnInf rgltryDocVrfctnInf) {
        this.rgltryDocVrfctnInf = rgltryDocVrfctnInf;
        return this;
    }

    @JsonProperty("invcDtls")
    public InvcDtls getInvcDtls() {
        return invcDtls;
    }

    @JsonProperty("invcDtls")
    public void setInvcDtls(InvcDtls invcDtls) {
        this.invcDtls = invcDtls;
    }

    public Data withInvcDtls(InvcDtls invcDtls) {
        this.invcDtls = invcDtls;
        return this;
    }

    @JsonProperty("splmtryData")
    public SplmtryData getSplmtryData() {
        return splmtryData;
    }

    @JsonProperty("splmtryData")
    public void setSplmtryData(SplmtryData splmtryData) {
        this.splmtryData = splmtryData;
    }

    public Data withSplmtryData(SplmtryData splmtryData) {
        this.splmtryData = splmtryData;
        return this;
    }

    @JsonProperty("txSttlmInf")
    public TxSttlmInf getTxSttlmInf() {
        return txSttlmInf;
    }

    @JsonProperty("txSttlmInf")
    public void setTxSttlmInf(TxSttlmInf txSttlmInf) {
        this.txSttlmInf = txSttlmInf;
    }

    public Data withTxSttlmInf(TxSttlmInf txSttlmInf) {
        this.txSttlmInf = txSttlmInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Data withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(txCtry).append(txCityCd).append(dbtRefNb).append(dbtLegSucssInd).append(tellerId).append(chanlCutOffInd).append(instrForDbtrAgt).append(lgnBrnchCd).append(prcgBrnchCd).append(formTp).append(instgAgtXtndedCutOffInd).append(sts).append(usrActnInf).append(chanl).append(sttlmInf).append(pmtTpInf).append(fwdgAgt).append(instgAgt).append(instdAgt).append(pmtId).append(amt).append(sttlmDtTmInf).append(xchgRateInf).append(chrgsInf).append(prvsInstgAgt1).append(prvsInstgAgt1Acct).append(prvsInstgAgt2).append(prvsInstgAgt2Acct).append(prvsInstgAgt3).append(prvsInstgAgt3Acct).append(intrmyAgt1).append(intrmyAgt1Acct).append(intrmyAgt2).append(intrmyAgt2Acct).append(intrmyAgt3).append(intrmyAgt3Acct).append(ultmtDbtr).append(initgPty).append(dbtr).append(dbtrAcct).append(dbtrAgt).append(dbtrAgtAcct).append(reqdDbtAcctInf).append(cdtrAgt).append(cdtrAgtAcct).append(cdtr).append(cdtrAcct).append(ultmtCdtr).append(instrForCdtrAgt).append(instrForNxtAgt).append(purp).append(rgltryRptg).append(tax).append(cstmr).append(rltdRmtInf).append(rmtInf).append(chqInstr).append(billAndMrchntTxInf).append(epfAndPnsnTxInf).append(statutoryAndTaxTxInf).append(rgltryDocVrfctnInf).append(invcDtls).append(splmtryData).append(txSttlmInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Data) == false) {
            return false;
        }
        Data rhs = ((Data) other);
        return new EqualsBuilder().append(txCtry, rhs.txCtry).append(txCityCd, rhs.txCityCd).append(dbtRefNb, rhs.dbtRefNb).append(dbtLegSucssInd, rhs.dbtLegSucssInd).append(tellerId, rhs.tellerId).append(chanlCutOffInd, rhs.chanlCutOffInd).append(instrForDbtrAgt, rhs.instrForDbtrAgt).append(lgnBrnchCd, rhs.lgnBrnchCd).append(prcgBrnchCd, rhs.prcgBrnchCd).append(formTp, rhs.formTp).append(instgAgtXtndedCutOffInd, rhs.instgAgtXtndedCutOffInd).append(sts, rhs.sts).append(usrActnInf, rhs.usrActnInf).append(chanl, rhs.chanl).append(sttlmInf, rhs.sttlmInf).append(pmtTpInf, rhs.pmtTpInf).append(fwdgAgt, rhs.fwdgAgt).append(instgAgt, rhs.instgAgt).append(instdAgt, rhs.instdAgt).append(pmtId, rhs.pmtId).append(amt, rhs.amt).append(sttlmDtTmInf, rhs.sttlmDtTmInf).append(xchgRateInf, rhs.xchgRateInf).append(chrgsInf, rhs.chrgsInf).append(prvsInstgAgt1, rhs.prvsInstgAgt1).append(prvsInstgAgt1Acct, rhs.prvsInstgAgt1Acct).append(prvsInstgAgt2, rhs.prvsInstgAgt2).append(prvsInstgAgt2Acct, rhs.prvsInstgAgt2Acct).append(prvsInstgAgt3, rhs.prvsInstgAgt3).append(prvsInstgAgt3Acct, rhs.prvsInstgAgt3Acct).append(intrmyAgt1, rhs.intrmyAgt1).append(intrmyAgt1Acct, rhs.intrmyAgt1Acct).append(intrmyAgt2, rhs.intrmyAgt2).append(intrmyAgt2Acct, rhs.intrmyAgt2Acct).append(intrmyAgt3, rhs.intrmyAgt3).append(intrmyAgt3Acct, rhs.intrmyAgt3Acct).append(ultmtDbtr, rhs.ultmtDbtr).append(initgPty, rhs.initgPty).append(dbtr, rhs.dbtr).append(dbtrAcct, rhs.dbtrAcct).append(dbtrAgt, rhs.dbtrAgt).append(dbtrAgtAcct, rhs.dbtrAgtAcct).append(reqdDbtAcctInf, rhs.reqdDbtAcctInf).append(cdtrAgt, rhs.cdtrAgt).append(cdtrAgtAcct, rhs.cdtrAgtAcct).append(cdtr, rhs.cdtr).append(cdtrAcct, rhs.cdtrAcct).append(ultmtCdtr, rhs.ultmtCdtr).append(instrForCdtrAgt, rhs.instrForCdtrAgt).append(instrForNxtAgt, rhs.instrForNxtAgt).append(purp, rhs.purp).append(rgltryRptg, rhs.rgltryRptg).append(tax, rhs.tax).append(cstmr, rhs.cstmr).append(rltdRmtInf, rhs.rltdRmtInf).append(rmtInf, rhs.rmtInf).append(chqInstr, rhs.chqInstr).append(billAndMrchntTxInf, rhs.billAndMrchntTxInf).append(epfAndPnsnTxInf, rhs.epfAndPnsnTxInf).append(statutoryAndTaxTxInf, rhs.statutoryAndTaxTxInf).append(rgltryDocVrfctnInf, rhs.rgltryDocVrfctnInf).append(invcDtls, rhs.invcDtls).append(splmtryData, rhs.splmtryData).append(txSttlmInf, rhs.txSttlmInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}


package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instgChanlRef",
    "cstmrRef",
    "endToEndId",
    "UETR",
    "clrSysRef"
})
public class PmtId {

    @JsonProperty("instgChanlRef")
    private String instgChanlRef;
    @JsonProperty("cstmrRef")
    private String cstmrRef;
    @JsonProperty("endToEndId")
    private String endToEndId;
    @JsonProperty("UETR")
    private String uETR;
    @JsonProperty("clrSysRef")
    private String clrSysRef;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instgChanlRef")
    public String getInstgChanlRef() {
        return instgChanlRef;
    }

    @JsonProperty("instgChanlRef")
    public void setInstgChanlRef(String instgChanlRef) {
        this.instgChanlRef = instgChanlRef;
    }

    public PmtId withInstgChanlRef(String instgChanlRef) {
        this.instgChanlRef = instgChanlRef;
        return this;
    }

    @JsonProperty("cstmrRef")
    public String getCstmrRef() {
        return cstmrRef;
    }

    @JsonProperty("cstmrRef")
    public void setCstmrRef(String cstmrRef) {
        this.cstmrRef = cstmrRef;
    }

    public PmtId withCstmrRef(String cstmrRef) {
        this.cstmrRef = cstmrRef;
        return this;
    }

    @JsonProperty("endToEndId")
    public String getEndToEndId() {
        return endToEndId;
    }

    @JsonProperty("endToEndId")
    public void setEndToEndId(String endToEndId) {
        this.endToEndId = endToEndId;
    }

    public PmtId withEndToEndId(String endToEndId) {
        this.endToEndId = endToEndId;
        return this;
    }

    @JsonProperty("UETR")
    public String getUETR() {
        return uETR;
    }

    @JsonProperty("UETR")
    public void setUETR(String uETR) {
        this.uETR = uETR;
    }

    public PmtId withUETR(String uETR) {
        this.uETR = uETR;
        return this;
    }

    @JsonProperty("clrSysRef")
    public String getClrSysRef() {
        return clrSysRef;
    }

    @JsonProperty("clrSysRef")
    public void setClrSysRef(String clrSysRef) {
        this.clrSysRef = clrSysRef;
    }

    public PmtId withClrSysRef(String clrSysRef) {
        this.clrSysRef = clrSysRef;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PmtId withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instgChanlRef).append(cstmrRef).append(endToEndId).append(uETR).append(clrSysRef).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PmtId) == false) {
            return false;
        }
        PmtId rhs = ((PmtId) other);
        return new EqualsBuilder().append(instgChanlRef, rhs.instgChanlRef).append(cstmrRef, rhs.cstmrRef).append(endToEndId, rhs.endToEndId).append(uETR, rhs.uETR).append(clrSysRef, rhs.clrSysRef).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

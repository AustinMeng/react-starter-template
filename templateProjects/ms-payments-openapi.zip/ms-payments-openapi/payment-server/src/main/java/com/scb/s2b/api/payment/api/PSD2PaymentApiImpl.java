package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.CcsPaymentInstruction;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.processor.request.CcsRequestProcessor;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.CcsPaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.Psd2PaymentRequestValidator;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.inject.Singleton;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component
@Singleton
public class PSD2PaymentApiImpl extends ApiBase {

    private final CcsPaymentService ccsPaymentService;

    private final RequestProcessor requestProcessor;

    private final CcsRequestProcessor ccsRequestProcessor;

    private final Psd2PaymentRequestValidator psd2PaymentRequestValidator;

    private final OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;

    private static final Logger logger = LoggerFactory.getLogger(PSD2PaymentApiImpl.class);

    @Autowired
    public PSD2PaymentApiImpl(CcsPaymentService ccsPaymentService,
                              @Qualifier("psd2RequestProcessor") RequestProcessor requestProcessor,
                              @Qualifier("ccsRequestProcessor") CcsRequestProcessor ccsRequestProcessor,
                              Psd2PaymentRequestValidator psd2PaymentRequestValidator,
                              OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer) {
        this.ccsPaymentService = ccsPaymentService;
        this.requestProcessor = requestProcessor;
        this.ccsRequestProcessor = ccsRequestProcessor;
        this.psd2PaymentRequestValidator = psd2PaymentRequestValidator;
        this.openApiPaymentInstructionTransformer = openApiPaymentInstructionTransformer;
    }

    @SuppressWarnings("unused")
    public Response psd2FasterpaymentInitiate(String preVerified, OpenApiPaymentInstruction body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);

        logger.info("PaymentInitiate requestId={}, groupId={}, clientReferenceId={}", requestId, groupId,
                body.getInstruction().getReferenceId());
        psd2PaymentRequestValidator.validate(groupId, body);
        Map<String, String> headersMap = this.getHeaders(headers);

        PaymentInstruction paymentInstruction = openApiPaymentInstructionTransformer
                .toPaymentInstruction(body, false, headersMap);
        requestProcessor.process(paymentInstruction);

        CcsPaymentInstruction ccsPaymentInstruction = openApiPaymentInstructionTransformer.toCCSPaymentInstruction(body);
        List<PaymentInstruction> paymentInstructions = Collections.singletonList(paymentInstruction);
        ccsRequestProcessor.process(ccsPaymentInstruction, paymentInstructions);
        paymentInstruction.getPaymentType().setCode(body.getInstruction().getPaymentType());
        ccsPaymentService.ccsPaymentInitiate(groupId, ccsPaymentInstruction, paymentInstructions);
        psd2PaymentRequestValidator.cache(paymentInstruction);

        OpenApiPaymentId openApiPaymentId = openApiPaymentInstructionTransformer.toOpenApiPaymentId(paymentInstruction);
        return Response.ok(openApiPaymentId).build();
    }
}


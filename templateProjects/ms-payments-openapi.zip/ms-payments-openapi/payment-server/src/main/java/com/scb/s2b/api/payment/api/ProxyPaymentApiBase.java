package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.PaynowRequestValidator;
import javax.validation.Valid;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public abstract class ProxyPaymentApiBase extends ApiBase {

    private final PaymentService paymentService;
    private final PaynowRequestValidator paymentRequestValidator;
    private final RequestProcessor requestProcessor;
    private final OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;


    public Response paynowInitiate(OpenApiPaymentInstruction body, HttpHeaders headers) {
        return proxyInitiate(body, false, headers);
    }

    public Response paynowInitiateProxyValidation(@Valid OpenApiPaymentInstruction body, HttpHeaders headers) {
        return proxyInitiate(body, true, headers);
    }


    private Response proxyInitiate(OpenApiPaymentInstruction body, boolean validateName, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);

        log.info("PaynowInitiate requestId={}, groupId={}, clientReferenceId={}", requestId, groupId,
                body.getInstruction().getReferenceId());

        if (validateName) {
            paymentRequestValidator.validateWithProxyName(groupId, body);
        } else {
            paymentRequestValidator.validate(groupId, body);
        }

        PaymentInstruction paymentInstruction = openApiPaymentInstructionTransformer
                .toPaymentInstruction(body, false, this.getHeaders(headers));
        paymentInstruction.setCreditorNameValidRequired(validateName);

        requestProcessor.process(paymentInstruction);
        paymentService.initiate(paymentInstruction);
        paymentRequestValidator.cache(paymentInstruction);
        OpenApiPaymentId openApiPaymentId = openApiPaymentInstructionTransformer.toOpenApiPaymentId(paymentInstruction);
        return Response.ok(openApiPaymentId).build();
    }
}

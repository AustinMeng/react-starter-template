package com.scb.s2b.api.payment.config;

import com.scb.channels.foundation.commons.camel.SolaceComponentFactory;
import com.scb.channels.foundation.commons.camel.configuration.SolaceProperties;
import com.scb.channels.foundation.commons.camel.configuration.VpnProperties;
import com.scb.channels.foundation.notificationengine.KafkaStruct;
import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.payment.camel.CommonStatusConsumerAdapter;
import com.scb.s2b.api.payment.camel.controller.CamelController;
import com.scb.s2b.api.payment.camel.controller.CamelControllerImpl;
import com.scb.s2b.api.payment.config.property.CamelControllerProperties;
import com.scb.s2b.api.payment.config.property.KafkaProperties;
import com.scb.s2b.api.payment.config.property.KafkaSecurityProperties;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.PaymentTransaction;
import com.scb.s2b.api.payment.entity.scpay.beneficiary.response.BeneRes;
import com.scb.s2b.api.payment.entity.scpay.initiate.response.PaymentRes;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.proxy.response.ProxyLookupRes;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.PaymentResGroupFilterService;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import com.scb.s2b.api.payment.util.KafkaOffsetCommitProcessor;
import com.scb.s2b.api.payment.util.LoggingUtility;
import com.scb.s2b.api.payment.validation.DBPersistenceException;
import com.scb.s2b.api.payment.validation.NoSuchInstructionException;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.Predicate;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.activemq.ActiveMQComponent;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.kafka.KafkaComponent;
import org.apache.camel.component.kafka.KafkaConfiguration;
import org.apache.camel.spring.boot.CamelContextConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

@Slf4j
@SuppressWarnings("unused")
public class CamelConfig {

    @Value("${zookeeper.brokers}")
    private String zookeeperBrokers;

    @Bean(name = "kafkaProperties")
    @ConfigurationProperties("kafka")
    public KafkaProperties kafkaProperties() {
        return new KafkaProperties();
    }

    @Profile("!test")
    @Bean(name = "kafka-component")
    public KafkaComponent kafkaComponent(@Qualifier("kafkaProperties") KafkaProperties kafkaProperties) {
        return this.buildKafkaComponent(kafkaProperties);
    }

    @Bean
    @ConfigurationProperties("kafka-ssl")
    public KafkaSecurityProperties kafkaSSLProperties() {
        return new KafkaSecurityProperties();
    }

    @Bean
    @ConfigurationProperties("scpay")
    public ScpayProperties scpayProperties() {
        return new ScpayProperties();
    }

    @Bean
    @ConfigurationProperties("solace")
    public SolaceProperties solaceProperties() {
        return new SolaceProperties();
    }

    @Profile("!test")
    @Bean
    CamelContextConfiguration scpayContextConfiguration(SolaceProperties solaceProperties) {
        return new CamelContextConfiguration() {
            @Override
            public void beforeApplicationStart(CamelContext camelContext) {
                solaceProperties.getVpn().forEach(vpnProps -> {
                            if(StringUtils.equalsIgnoreCase(vpnProps.getType(), VpnProperties.SOLACE)) {
                                camelContext.addComponent(vpnProps.getPrefix(), SolaceComponentFactory.create(solaceProperties, vpnProps));
                            } else if (StringUtils.equalsIgnoreCase(vpnProps.getType(), VpnProperties.ACTIVE_MQ)) {
                                camelContext.addComponent(vpnProps.getPrefix(), ActiveMQComponent.activeMQComponent(vpnProps.getUrl()));
                            } else {
                                log.error("Invalid type: {}", vpnProps.getType());
                            }
                        }
                );
            }

            @Override
            public void afterApplicationStart(CamelContext camelContext) {
            }
        };
    }

    @Bean
    RouteBuilder routeBuilder(ScpayProperties scpayProperties,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
			ApplicationContext context,
			JsonMessageMarshaller marshaller ,
			CamelAsynchExceptionProcessor exceptionProcessor,
            KafkaOffsetCommitProcessor kafkaOffsetCommitProcessor,
            ProducerTemplate producerTemplate,
            PaymentResGroupFilterService resGroupFilterService
    ) {
        return new RouteBuilder() {
            @Override
            public void configure() {
				JacksonDataFormat paymentTransactionFormatter= new JacksonDataFormat(PaymentTransaction.class);
				paymentTransactionFormatter.setObjectMapper(marshaller.getObjectMapper());

                JacksonDataFormat ccsAgentOutboundFormatter= new JacksonDataFormat(CCSAgentOutboundIns.class);
                ccsAgentOutboundFormatter.setObjectMapper(marshaller.getObjectMapper());

                onException(Throwable.class).maximumRedeliveries(0);
                from(kafkaProperties.getEndpoints().get("paymentInitiate")).routeId("paymentInitiate")
                        .doTry()
                        .bean(KafkaStruct.class, "deserialise")
                        .setBody(simple("${body.messageWrapper.content}"))
                        .unmarshal(paymentTransactionFormatter).convertBodyTo(PaymentTransaction.class)
                        .bean(LoggingUtility.class, "asynchLogVars")
                        .bean("kafkaConsumerAdapter", "dispatchPaymentTransaction(${body}, ${headers})")
                        .process(kafkaOffsetCommitProcessor)
                        .log("paymentInitiate topic offset ${headers.kafka.OFFSET} committed")
                        .doCatch(Exception.class)
                        .log("Failed to process paymentTransaction")
                        .process(exceptionProcessor).end();

                from(kafkaProperties.getEndpoints().get("ccsAgentExport")).routeId("ccsAgentExport")
                        .doTry()
                        .unmarshal(ccsAgentOutboundFormatter).convertBodyTo(CCSAgentOutboundIns.class)
                        .bean(LoggingUtility.class, "asynchLogVars")
                        .bean("kafkaConsumerAdapter", "consumeCCSPaymentTransaction")
                        .process(kafkaOffsetCommitProcessor)
                        .log("ccsAgentExport topic offset ${headers.kafka.OFFSET} committed")
                        .doCatch(Exception.class)
                        .log("Failed to process ccsAgentExport offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor).end();

                from(kafkaProperties.getEndpoints().get("ccsBanstaReport")).routeId("ccsBanstaReport")
                        .doTry()
                        .unmarshal(ccsAgentOutboundFormatter)
                        .convertBodyTo(CCSAgentOutboundIns.class)
                        .bean(LoggingUtility.class, "asynchLogVars")
                        .bean("kafkaConsumerAdapter", "consumeBanstaReport")
                        .process(kafkaOffsetCommitProcessor)
                        .log("ccsBanstaReport topic offset ${headers.kafka.OFFSET} committed")
                        .doCatch(Exception.class)
                        .log("Failed to process ccsBanstaReport offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor).end();

                from(kafkaProperties.getEndpoints().get("ccsPaymentResp")).routeId("ccsPaymentResp")
                        .doTry()
                        .unmarshal(ccsAgentOutboundFormatter)
                        .convertBodyTo(CCSAgentOutboundIns.class)
                        .bean(LoggingUtility.class, "asynchLogVars")
                        .bean("kafkaConsumerAdapter", "consumeCcsPaymentResponse")
                        .process(kafkaOffsetCommitProcessor)
                        .log("ccsPaymentResp topic offset ${headers.kafka.OFFSET} committed")
                        .doCatch(Exception.class)
                        .log("Failed to process ccsPaymentResp offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor).end();

                from(kafkaProperties.getEndpoints().get("paymentInitiateRetry")).routeId("paymentInitiateRetry")
                        .delay().method("kafkaConsumerAdapter", "calculateDelay(${headers})")
                        .doTry()
                        .bean(KafkaStruct.class,"deserialise")
                        .setBody(simple("${body.messageWrapper.content}"))
                        .unmarshal(paymentTransactionFormatter)
                        .convertBodyTo(PaymentTransaction.class)
                        .bean(LoggingUtility.class, "asynchLogVars")
                        .bean("kafkaConsumerAdapter", "consumePaymentTransactionRetry(${body}, ${headers})")
                        .process(kafkaOffsetCommitProcessor)
                        .log("paymentInitiateRetry topic offset ${headers.kafka.OFFSET} committed")
                        .doCatch(Exception.class)
                        .log("Failed to process paymentInitiateRetry offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor).end();

                JacksonDataFormat paymentResDataFormat = new JacksonDataFormat(marshaller.getObjectMapper(), PaymentRes.class);
                scpayProperties.getStatusQueues().forEach(
                        paymentStatusQueue -> from(paymentStatusQueue).routeId(paymentStatusQueue)
                                .doTry()
                                .unmarshal(paymentResDataFormat)
                                .convertBodyTo(PaymentRes.class)
                                .bean("jmsConsumerAdapter", "consumeScpayPaymentStatus")
                                .doCatch(NoSuchInstructionException.class, DBPersistenceException.class)
                                .choice()
                                .when(bodyPredicate(resGroupFilterService.PaymentStatusResFilter(), PaymentRes.class))
                                .marshal(paymentResDataFormat)
                                .to(kafkaProperties.getEndpoints().get("paymentStatusRetry"))
                                .otherwise()
                                .log("message with grpId=${body.data.cstmr.s2bGrpId} and UETR=${body.data.pmtId.uETR} is discarded")
                                .end()
                );

                JacksonDataFormat proxyResDataFormat = new JacksonDataFormat(marshaller.getObjectMapper(), ProxyLookupRes.class);
                scpayProperties.getProxyLookup().getResponseQueues().forEach(
                        responseQueue -> from(responseQueue).routeId(responseQueue)
                                .doTry()
                                .unmarshal(proxyResDataFormat)
                                .convertBodyTo(ProxyLookupRes.class)
                                .bean("jmsConsumerAdapter", "consumeProxylookupResponse")
                                .doCatch(NoSuchInstructionException.class, DBPersistenceException.class)
                                .marshal(proxyResDataFormat)
                                .to(kafkaProperties.getEndpoints().get("paymentProxyResRetry"))
                                .doCatch(Exception.class)
                                .process(exceptionProcessor)
                                .end()
                );

                JacksonDataFormat BeneResDataFormat = new JacksonDataFormat(marshaller.getObjectMapper(), BeneRes.class);
                if(scpayProperties.getBeneficiaryEnquiry().isEnabled()) {
                    from(scpayProperties.getBeneficiaryEnquiry().getResponseQueue()).routeId("beneResponse")
                            .doTry()
                            .unmarshal(BeneResDataFormat)
                            .convertBodyTo(BeneRes.class)
                            .bean("jmsConsumerAdapter", "consumeBeneResponse")
                            .doCatch(NoSuchInstructionException.class, DBPersistenceException.class)
                            .marshal(BeneResDataFormat)
                            .to(kafkaProperties.getEndpoints().get("paymentBeneResRetry"))
                            .doCatch(Exception.class)
                            .process(exceptionProcessor)
                            .end();
                }

                if (scpayProperties.getNotification().isEnabled()) {
                    scpayProperties.getNotification().getNotificationReqQueues()
                            .forEach(notificationReqQueue -> from(notificationReqQueue).routeId(notificationReqQueue)
                                    .doTry()
                                    .unmarshal(new JacksonDataFormat(marshaller.getObjectMapper(), Notification.class))
                                    .convertBodyTo(Notification.class)
                                    .bean("jmsConsumerAdapter", "receiveNotification")
                                    .doCatch(Exception.class)
                                    .process(exceptionProcessor)
                                    .end()
                            );

                    from(String.format(scpayProperties.getNotification().getSignOnOff().getNotificationTemplate(),
                            zookeeperBrokers))
                            .routeId("snm-notfy-signOnOff-zk-route")
                            .doTry()
                            .convertBodyTo(String.class, StandardCharsets.UTF_8.toString())
                            .bean("zkConsumerAdapter", "watchSignOnOffNotificationEvent")
                            .doCatch(Exception.class)
                            .process(exceptionProcessor)
                            .end();

                    from(String.format(scpayProperties.getNotification().getBankStatusBroadcast()
                                    .getNotificationTemplate(),
                            zookeeperBrokers))
                            .routeId("snm-notfy-bankStatus-zk-route")
                            .doTry()
                            .convertBodyTo(String.class, StandardCharsets.UTF_8.toString())
                            .bean("zkConsumerAdapter", "watchBankStatusBroadcastNotificationEvent")
                            .doCatch(Exception.class)
                            .process(exceptionProcessor)
                            .end();

                    from(String.format(scpayProperties.getNotification().getBankDefaultBroadcast()
                                    .getNotificationTemplate(),
                            zookeeperBrokers))
                            .routeId("snm-notfy-bankDefault-zk-route")
                            .doTry()
                            .convertBodyTo(String.class, StandardCharsets.UTF_8.toString())
                            .bean("zkConsumerAdapter", "watchBankDefaultBroadcastNotificationEvent")
                            .doCatch(Exception.class)
                            .process(exceptionProcessor)
                            .end();

                    from(String.format(scpayProperties.getNotification().getSystemStatusBroadcast()
                                    .getNotificationTemplate(),
                            zookeeperBrokers))
                            .routeId("snm-notfy-systemStatus-zk-route")
                            .doTry()
                            .convertBodyTo(String.class, StandardCharsets.UTF_8.toString())
                            .bean("zkConsumerAdapter", "watchSystemStatusBroadcastNotificationEvent")
                            .doCatch(Exception.class)
                            .process(exceptionProcessor)
                            .end();
                    from(String.format(scpayProperties.getNotification().getBankStatusBroadcastPH()
                                    .getNotificationTemplate(),
                            zookeeperBrokers))
                            .routeId("snm-notfy-systemStatus-for-ph-zk-route")
                            .doTry()
                            .convertBodyTo(String.class, StandardCharsets.UTF_8.toString())
                            .bean("zkConsumerAdapter", "watchBankStatusBroadcastForPHNotificationEvent")
                            .doCatch(Exception.class)
                            .process(exceptionProcessor)
                            .end();
                }
            }
        };
    }

    @Bean
    public RouteBuilder StatusRetryRoute(@Qualifier("statusConsumerAdapter") CommonStatusConsumerAdapter retryAdapter,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            JsonMessageMarshaller marshaller,
            CamelAsynchExceptionProcessor exceptionProcessor,
            KafkaOffsetCommitProcessor kafkaOffsetCommitProcessor) {
        return buildStatusRetryRoute(kafkaProperties.getEndpoints().get("paymentStatusRetry"), PaymentRes.class,
                marshaller, retryAdapter, exceptionProcessor, kafkaOffsetCommitProcessor);
    }

    @Bean
    public RouteBuilder ProxyResRetryRoute(@Qualifier("proxyResConsumerAdapter") CommonStatusConsumerAdapter retryAdapter,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            JsonMessageMarshaller marshaller,
            CamelAsynchExceptionProcessor exceptionProcessor,
            KafkaOffsetCommitProcessor kafkaOffsetCommitProcessor) {
        return buildStatusRetryRoute(kafkaProperties.getEndpoints().get("paymentProxyResRetry"), ProxyLookupRes.class,
                marshaller, retryAdapter, exceptionProcessor, kafkaOffsetCommitProcessor);
    }

    @Bean
    public RouteBuilder BeneResRetryRoute(@Qualifier("beneResConsumerAdapter") CommonStatusConsumerAdapter retryAdapter,
            @Qualifier("kafkaProperties") KafkaProperties kafkaProperties,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller marshaller,
            KafkaOffsetCommitProcessor kafkaOffsetCommitProcessor) {
        return buildStatusRetryRoute(kafkaProperties.getEndpoints().get("paymentBeneResRetry"), BeneRes.class,
                marshaller, retryAdapter, exceptionProcessor, kafkaOffsetCommitProcessor);
    }

    @Bean
    public CamelController camelController(CamelContext camelContext,
            CamelControllerProperties camelControllerProperties) {
        return new CamelControllerImpl(camelContext, camelControllerProperties);
    }

    private KafkaComponent buildKafkaComponent(KafkaProperties properties) {
        KafkaComponent kafka = new KafkaComponent();

        KafkaConfiguration configuration = new KafkaConfiguration();
        configuration.setKeySerializer("org.apache.kafka.common.serialization.IntegerSerializer");
        configuration.setValueSerializer("org.apache.kafka.common.serialization.ByteArraySerializer");
        configuration.setKeyDeserializer("org.apache.kafka.common.serialization.IntegerDeserializer");
        configuration.setValueDeserializer("org.apache.kafka.common.serialization.ByteArrayDeserializer");
        configuration.setAutoCommitEnable(false);
        configuration.setAllowManualCommit(true);
        configuration.setBrokers(properties.getBrokers());

        KafkaSecurityProperties kafkaSecurityProperties = properties.getSecurityInfo();
        if (kafkaSecurityProperties != null) {
            log.info("connection Kafka {} using SSL", properties.getBrokers());
            log.info("SSL parameters: {}", kafkaSecurityProperties);

            configuration.setSecurityProtocol(kafkaSecurityProperties.getSecurityProtocol());
            configuration.setSslKeystoreLocation(kafkaSecurityProperties.getKeystore());
            configuration.setSslKeystorePassword(kafkaSecurityProperties.getKeystorePassword());
            configuration.setSslTruststoreLocation(kafkaSecurityProperties.getTruststore());
            configuration.setSslTruststorePassword(kafkaSecurityProperties.getTruststorePassword());
            configuration.setSslKeyPassword(kafkaSecurityProperties.getKeyPassword());
            configuration.setSslEndpointAlgorithm(kafkaSecurityProperties.getEndpointAlgorithm());
        }

        kafka.setConfiguration(configuration);
        return kafka;
    }

    private RouteBuilder buildStatusRetryRoute(String retryEndpoint, Class<?> clazz, JsonMessageMarshaller marshaller,
            CommonStatusConsumerAdapter retryAdapter, CamelAsynchExceptionProcessor exceptionProcessor,
            KafkaOffsetCommitProcessor kafkaOffsetCommitProcessor) {
        return new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                if (StringUtils.isNotBlank(retryEndpoint)) {
                    onException(Throwable.class).maximumRedeliveries(0);
                    JacksonDataFormat jsonDataFormat = new JacksonDataFormat(marshaller.getObjectMapper(), clazz);
                    from(retryEndpoint)
                            .delay().method(retryAdapter, "calculateDelay(${headers})")
                            .doTry()
                            .unmarshal(jsonDataFormat)
                            .convertBodyTo(clazz)
                            .bean(LoggingUtility.class, "asynchLogVars")
                            .bean(retryAdapter, "consumeWithRetry(${body}, ${headers})")
                            .process(kafkaOffsetCommitProcessor)
                            .log(retryEndpoint +  " topic offset ${headers.kafka.OFFSET} committed")
                            .doCatch(Exception.class)
                            .log("Failed to process " + retryEndpoint + " offset ${headers.kafka.OFFSET}")
                            .process(exceptionProcessor)
                            .end();
                }
            }
        };
    }

    private<T> Predicate bodyPredicate(java.util.function.Predicate<T> predicate, Class<T> clazz) {
        return exchange -> predicate.test(exchange.getIn().getBody(clazz));
    }
}

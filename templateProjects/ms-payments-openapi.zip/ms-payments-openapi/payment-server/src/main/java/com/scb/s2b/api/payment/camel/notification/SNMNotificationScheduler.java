package com.scb.s2b.api.payment.camel.notification;

import com.scb.s2b.api.payment.camel.notification.handler.SNMNotificationHandler;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
public class SNMNotificationScheduler {

    private final Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap;

    private final ScpayProperties scpayProperties;

    private static final String SCHEDULER_INITIAL_DELAY = "${scpay.notification.scheudler.initialDelay}";

    private final static String SCHEDULER_FIXED_RATE = "${scpay.notification.scheudler.fixedRate}";

    public SNMNotificationScheduler(Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap,
            ScpayProperties scpayProperties) {
        this.eventCodeHandlerMap = eventCodeHandlerMap;
        this.scpayProperties = scpayProperties;
    }

    @Scheduled(initialDelayString = SCHEDULER_INITIAL_DELAY, fixedRateString = SCHEDULER_FIXED_RATE)
    public void synchronizeSNMNotificationRouteStatus() {
        if (!scpayProperties.getNotification().isEnabled()) {
            return;
        }

        for (Map.Entry<EventCode, SNMNotificationHandler> handlerEntry: eventCodeHandlerMap.entrySet()) {
            try {
                log.debug("Starting to synchronize {} status", handlerEntry.getKey().name());
                handlerEntry.getValue().refreshRouteStatus(true);
                log.debug("Synchronizing {} status finished", handlerEntry.getKey().name());
            } catch (Exception e) {
                log.error("Failed to synchronize {} status due to {}", handlerEntry.getKey().name(), e);
            }
        }
    }
}

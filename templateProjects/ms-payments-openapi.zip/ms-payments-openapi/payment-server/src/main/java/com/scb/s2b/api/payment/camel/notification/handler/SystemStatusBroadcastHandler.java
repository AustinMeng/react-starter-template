package com.scb.s2b.api.payment.camel.notification.handler;

import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_ID;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.CHANNEL_SCP;
import static com.scb.s2b.api.payment.entity.scpay.notification.NotificationConstants.SUCCESS_STATUS;
import static com.scb.s2b.api.payment.service.impl.MaintenanceServiceImpl.MAINTENANCE_SYSTEM_STATUS_BROADCAST_CACHE;

import com.scb.s2b.api.payment.camel.ZkProducerAdapter;
import com.scb.s2b.api.payment.camel.controller.CamelController;
import com.scb.s2b.api.payment.config.property.ScpayProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.notification.data.NotificationData.ServiceStatusType;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.util.CamelAsynchExceptionProcessor;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
public class SystemStatusBroadcastHandler extends AbstractSNMNotificationHandler implements SNMNotificationHandler {

    private final MaintenanceService maintenanceService;

    private final ZkProducerAdapter zkProducer;

    private final ScpayProperties scpayProperties;

    private final CamelController camelController;

    private volatile String prevSystemStatusBroadcastNotificationMsgId;

    private volatile Boolean localG3SuspendEnabled;

    private final ReentrantLock lock = new ReentrantLock();

    public SystemStatusBroadcastHandler(MaintenanceService maintenanceService,
            ZkProducerAdapter zkProducer, ScpayProperties scpayProperties,
            CamelController camelController,
            CamelAsynchExceptionProcessor exceptionProcessor,
            JsonMessageMarshaller messageMarshaller) {
        super(exceptionProcessor, messageMarshaller);
        this.maintenanceService = maintenanceService;
        this.zkProducer = zkProducer;
        this.scpayProperties = scpayProperties;
        this.camelController = camelController;
    }

    @PostConstruct
    public void initiateSystemStatusBroadcastHandler() {
        if (scpayProperties.getNotification().isEnabled()) {
            // register notification node on zk
            log.info("Notification is enabled, just initiate system status broadcast handler.");
            handleEvent(null);
            log.info("Initiating system status broadcast handler has done.");
        }
    }

    @Override
    public List<EventCode> getCode() {
        return Collections.singletonList(EventCode.SYSTEM_STATUS_BROADCASE);
    }

    @Override
    @Transactional(transactionManager = "transactionManager")
    public void handleNotification(Notification notification) {
        String messageId = notification.getHeader().getMessageId();
        log.info("start to handler snm notification messageId={}", notification.getHeader().getMessageId());

        try {
            ServiceStatusType newServiceStatus = notification.getData().getNewServiceStatus();
            if (newServiceStatus == null) {
                log.error("/data/newSvsSts is empty");
                throw new RuntimeException("/data/newSvsSts is empty");
            }

            String bicCode = notification.getData().getBankSWIFTBIC();
            if (bicCode == null) {
                log.error("/data/bkSwiftBic is empty");
                throw new RuntimeException("/data/bkSwiftBic is empty");
            }

            log.info("new service status is {} and bicCode is {}", newServiceStatus, bicCode);
            boolean needPublish = false;
            maintenanceService.refreshSystemStatusBroadcastG3SuspendStatus();
            if (newServiceStatus == ServiceStatusType.NORMAL) {
                log.info("Current service status is normal.");
                if (!maintenanceService.systemStatusBroadcastG3SuspendExists() || maintenanceService
                        .getSystemStatusBroadcastG3SuspendStatus()) {
                    // revoke Stop Payments for the Participant Bank BIC
                    log.info(
                            "System status broadcast is enabled, and revoking Stop Payments for the bic code {}, need to publish notification",
                            bicCode);
                    needPublish = true;
                }
                maintenanceService.disableSystemStatusBroadcastG3Suspend(messageId);
            } else {
                log.info("Current service status is suspended.");
                // Stop Payments for the Participant Bank BIC
                if (!maintenanceService.systemStatusBroadcastG3SuspendExists() || !maintenanceService
                        .getSystemStatusBroadcastG3SuspendStatus()) {
                    log.info(
                            "System status broadcast is disabled, and stopping Payments for the bic code {}, need to publish notification",
                            bicCode);
                    needPublish = true;
                }
                maintenanceService.enableSystemStatusBroadcastG3Suspend(messageId);
            }
            notification.getHeader().setResponseStatus(SUCCESS_STATUS);
            notification.getHeader().setChannelId(CHANNEL_ID);
            notification.getHeader().setDestination(CHANNEL_SCP);
            notification.getHeader().setProcessingDate(LocalDateTime.now());
            if (needPublish) {
                log.info("publish system status broadcast notification with messageId={}.", messageId);
                zkProducer.publishSystemStatusBroadcastNotification(messageId);
            }
        } catch (Exception e) {
            log.error("Failed to handle bank status broadcast notification {}",
                    notification.getHeader().getTransactionReference(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    @CacheEvict(value = MAINTENANCE_SYSTEM_STATUS_BROADCAST_CACHE, allEntries = true)
    public void handleEvent(String messageId) {
        if (StringUtils.isNotEmpty(messageId) && StringUtils
                .equals(messageId, prevSystemStatusBroadcastNotificationMsgId)) {
            log.info("messageId={} has not been updated, skip refreshing system status broadcast route.", messageId);
            return;
        }
        log.info("Refreshing SystemStatusBroadcast route for messageId={}", messageId);
        refreshRouteStatus(false);
        log.info("Updating prevSystemStatusBroadcastNotificationMsgId={}", messageId);
        prevSystemStatusBroadcastNotificationMsgId = messageId;
    }

    @Override
    public void refreshRouteStatus(boolean daemon) {
        log.info("Starting to refresh system status broadcast route status for daemon={}", daemon);

        boolean isLockAcquired;

        if (!daemon) {
            lock.lock();
        } else {
            isLockAcquired = lock.tryLock();

            if (!isLockAcquired) {
                log.info("Daemon task failed to acquire the lock for refreshing system status broadcast route status, try on the next round.");
                return;
            }
        }

        try {
            String endpoint = scpayProperties.getNotification().getSystemStatusBroadcast().getSuspendQueueTemplate();
            String routeId = scpayProperties.getNotification().getSystemStatusBroadcast().getSuspendRouteIdTemplate();
            int maxAttempts = scpayProperties.getNotification().getSystemStatusBroadcast().getMaxAttempts();
            try {
                boolean g3SuspendEnabled = maintenanceService.getSystemStatusBroadcastG3SuspendStatus();
                maintenanceService.refreshSystemStatusBroadcastG3SuspendStatus();
                if (!maintenanceService.systemStatusBroadcastG3SuspendExists() || (localG3SuspendEnabled != null && localG3SuspendEnabled.equals(g3SuspendEnabled))) {
                    log.debug("No change for system broadcast status G3 status, skip updating route status.");
                    return;
                } else {
                    localG3SuspendEnabled = g3SuspendEnabled;
                }
                log.info("add or suspend route for endpoint={}, routeId={}", endpoint, routeId);
                if (g3SuspendEnabled) {
                    camelController.addOrSuspendRoute(routeId, maxAttempts, this.suspendedRouteBuilder(endpoint, routeId));
                } else {
                    camelController.addOrResumeRoute(routeId, maxAttempts, this.revokedRouteBuilder(endpoint, routeId));
                }
            } catch (Exception e) {
                log.error("Failed to refresh endpoint={}, routeId={}", endpoint, routeId, e);
            }
        } finally {
            lock.unlock();
        }
    }
}

package com.scb.s2b.api.payment.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class CcsPaymentInstruction {

    public static final String JSON_PROPERTY_HEADER = "header";
    @JsonProperty(JSON_PROPERTY_HEADER)
    private CcsPaymentInstructionHeader header;

    public static final String JSON_PROPERTY_INSTRUCTIONS = "instructions";
    @JsonProperty(JSON_PROPERTY_INSTRUCTIONS)
    @Builder.Default
    private List<CcsPaymentInstructionInstruction> instructions = new ArrayList<>();
}


package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instgChanlRef",
    "instgBtchRef",
    "instgBtchPmtSeq",
    "pmtBtchRef",
    "instgOrgnlBtchRef",
    "endToEndId",
    "instrId",
    "txId",
    "UETR",
    "clrBtchRef",
    "outgngClrRef",
    "clrSysRef",
    "adrReqId",
    "prxyLookupClrRef",
    "bizMsgIdr",
    "prxyRegnId"
})
public class PmtId {

    @JsonProperty("instgChanlRef")
    private String instgChanlRef;
    @JsonProperty("instgBtchRef")
    private String instgBtchRef;
    @JsonProperty("instgBtchPmtSeq")
    private String instgBtchPmtSeq;
    @JsonProperty("pmtBtchRef")
    private String pmtBtchRef;
    @JsonProperty("instgOrgnlBtchRef")
    private String instgOrgnlBtchRef;
    @JsonProperty("endToEndId")
    private String endToEndId;
    @JsonProperty("instrId")
    private String instrId;
    @JsonProperty("txId")
    private String txId;
    @JsonProperty("UETR")
    private String uETR;
    @JsonProperty("clrBtchRef")
    private String clrBtchRef;
    @JsonProperty("outgngClrRef")
    private String outgngClrRef;
    @JsonProperty("clrSysRef")
    private String clrSysRef;
    @JsonProperty("adrReqId")
    private String adrReqId;
    @JsonProperty("prxyLookupClrRef")
    private String prxyLookupClrRef;
    @JsonProperty("bizMsgIdr")
    private String bizMsgIdr;
    @JsonProperty("prxyRegnId")
    private String prxyRegnId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instgChanlRef")
    public String getInstgChanlRef() {
        return instgChanlRef;
    }

    @JsonProperty("instgChanlRef")
    public void setInstgChanlRef(String instgChanlRef) {
        this.instgChanlRef = instgChanlRef;
    }

    public PmtId withInstgChanlRef(String instgChanlRef) {
        this.instgChanlRef = instgChanlRef;
        return this;
    }

    @JsonProperty("instgBtchRef")
    public String getInstgBtchRef() {
        return instgBtchRef;
    }

    @JsonProperty("instgBtchRef")
    public void setInstgBtchRef(String instgBtchRef) {
        this.instgBtchRef = instgBtchRef;
    }

    public PmtId withInstgBtchRef(String instgBtchRef) {
        this.instgBtchRef = instgBtchRef;
        return this;
    }

    @JsonProperty("instgBtchPmtSeq")
    public String getInstgBtchPmtSeq() {
        return instgBtchPmtSeq;
    }

    @JsonProperty("instgBtchPmtSeq")
    public void setInstgBtchPmtSeq(String instgBtchPmtSeq) {
        this.instgBtchPmtSeq = instgBtchPmtSeq;
    }

    public PmtId withInstgBtchPmtSeq(String instgBtchPmtSeq) {
        this.instgBtchPmtSeq = instgBtchPmtSeq;
        return this;
    }

    @JsonProperty("pmtBtchRef")
    public String getPmtBtchRef() {
        return pmtBtchRef;
    }

    @JsonProperty("pmtBtchRef")
    public void setPmtBtchRef(String pmtBtchRef) {
        this.pmtBtchRef = pmtBtchRef;
    }

    public PmtId withPmtBtchRef(String pmtBtchRef) {
        this.pmtBtchRef = pmtBtchRef;
        return this;
    }

    @JsonProperty("instgOrgnlBtchRef")
    public String getInstgOrgnlBtchRef() {
        return instgOrgnlBtchRef;
    }

    @JsonProperty("instgOrgnlBtchRef")
    public void setInstgOrgnlBtchRef(String instgOrgnlBtchRef) {
        this.instgOrgnlBtchRef = instgOrgnlBtchRef;
    }

    public PmtId withInstgOrgnlBtchRef(String instgOrgnlBtchRef) {
        this.instgOrgnlBtchRef = instgOrgnlBtchRef;
        return this;
    }

    @JsonProperty("endToEndId")
    public String getEndToEndId() {
        return endToEndId;
    }

    @JsonProperty("endToEndId")
    public void setEndToEndId(String endToEndId) {
        this.endToEndId = endToEndId;
    }

    public PmtId withEndToEndId(String endToEndId) {
        this.endToEndId = endToEndId;
        return this;
    }

    @JsonProperty("instrId")
    public String getInstrId() {
        return instrId;
    }

    @JsonProperty("instrId")
    public void setInstrId(String instrId) {
        this.instrId = instrId;
    }

    public PmtId withInstrId(String instrId) {
        this.instrId = instrId;
        return this;
    }

    @JsonProperty("txId")
    public String getTxId() {
        return txId;
    }

    @JsonProperty("txId")
    public void setTxId(String txId) {
        this.txId = txId;
    }

    public PmtId withTxId(String txId) {
        this.txId = txId;
        return this;
    }

    @JsonProperty("UETR")
    public String getUETR() {
        return uETR;
    }

    @JsonProperty("UETR")
    public void setUETR(String uETR) {
        this.uETR = uETR;
    }

    public PmtId withUETR(String uETR) {
        this.uETR = uETR;
        return this;
    }

    @JsonProperty("clrBtchRef")
    public String getClrBtchRef() {
        return clrBtchRef;
    }

    @JsonProperty("clrBtchRef")
    public void setClrBtchRef(String clrBtchRef) {
        this.clrBtchRef = clrBtchRef;
    }

    public PmtId withClrBtchRef(String clrBtchRef) {
        this.clrBtchRef = clrBtchRef;
        return this;
    }

    @JsonProperty("outgngClrRef")
    public String getOutgngClrRef() {
        return outgngClrRef;
    }

    @JsonProperty("outgngClrRef")
    public void setOutgngClrRef(String outgngClrRef) {
        this.outgngClrRef = outgngClrRef;
    }

    public PmtId withOutgngClrRef(String outgngClrRef) {
        this.outgngClrRef = outgngClrRef;
        return this;
    }

    @JsonProperty("clrSysRef")
    public String getClrSysRef() {
        return clrSysRef;
    }

    @JsonProperty("clrSysRef")
    public void setClrSysRef(String clrSysRef) {
        this.clrSysRef = clrSysRef;
    }

    public PmtId withClrSysRef(String clrSysRef) {
        this.clrSysRef = clrSysRef;
        return this;
    }

    @JsonProperty("adrReqId")
    public String getAdrReqId() {
        return adrReqId;
    }

    @JsonProperty("adrReqId")
    public void setAdrReqId(String adrReqId) {
        this.adrReqId = adrReqId;
    }

    public PmtId withAdrReqId(String adrReqId) {
        this.adrReqId = adrReqId;
        return this;
    }

    @JsonProperty("prxyLookupClrRef")
    public String getPrxyLookupClrRef() {
        return prxyLookupClrRef;
    }

    @JsonProperty("prxyLookupClrRef")
    public void setPrxyLookupClrRef(String prxyLookupClrRef) {
        this.prxyLookupClrRef = prxyLookupClrRef;
    }

    public PmtId withPrxyLookupClrRef(String prxyLookupClrRef) {
        this.prxyLookupClrRef = prxyLookupClrRef;
        return this;
    }

    @JsonProperty("bizMsgIdr")
    public String getBizMsgIdr() {
        return bizMsgIdr;
    }

    @JsonProperty("bizMsgIdr")
    public void setBizMsgIdr(String bizMsgIdr) {
        this.bizMsgIdr = bizMsgIdr;
    }

    public PmtId withBizMsgIdr(String bizMsgIdr) {
        this.bizMsgIdr = bizMsgIdr;
        return this;
    }

    @JsonProperty("prxyRegnId")
    public String getPrxyRegnId() {
        return prxyRegnId;
    }

    @JsonProperty("prxyRegnId")
    public void setPrxyRegnId(String prxyRegnId) {
        this.prxyRegnId = prxyRegnId;
    }

    public PmtId withPrxyRegnId(String prxyRegnId) {
        this.prxyRegnId = prxyRegnId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PmtId withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instgChanlRef).append(instgBtchRef).append(instgBtchPmtSeq).append(pmtBtchRef).append(instgOrgnlBtchRef).append(endToEndId).append(instrId).append(txId).append(uETR).append(clrBtchRef).append(outgngClrRef).append(clrSysRef).append(adrReqId).append(prxyLookupClrRef).append(bizMsgIdr).append(prxyRegnId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PmtId) == false) {
            return false;
        }
        PmtId rhs = ((PmtId) other);
        return new EqualsBuilder().append(instgChanlRef, rhs.instgChanlRef).append(instgBtchRef, rhs.instgBtchRef).append(instgBtchPmtSeq, rhs.instgBtchPmtSeq).append(pmtBtchRef, rhs.pmtBtchRef).append(instgOrgnlBtchRef, rhs.instgOrgnlBtchRef).append(endToEndId, rhs.endToEndId).append(instrId, rhs.instrId).append(txId, rhs.txId).append(uETR, rhs.uETR).append(clrBtchRef, rhs.clrBtchRef).append(outgngClrRef, rhs.outgngClrRef).append(clrSysRef, rhs.clrSysRef).append(adrReqId, rhs.adrReqId).append(prxyLookupClrRef, rhs.prxyLookupClrRef).append(bizMsgIdr, rhs.bizMsgIdr).append(prxyRegnId, rhs.prxyRegnId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

package com.scb.s2b.api.payment.entity.payee.response;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiIdentity;
import lombok.Getter;

@Getter
public class Identity extends OpenApiIdentity {
}

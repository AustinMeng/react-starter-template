package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import javax.inject.Singleton;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Singleton
@RequiredArgsConstructor
public class PaymentRetrieveApiImpl extends ApiBase{
    private final OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;
    private final PaymentService paymentService;

    public Response paymentRetrieve(String referenceId, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        log.info("PaymentRetrieve requestId={}, groupId={}, clientReferenceId={}",
                headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER), groupId, referenceId);

        OpenApiPaymentInstruction paymentInstruction = paymentService.getPayment(groupId, referenceId)
                .map(openApiPaymentInstructionTransformer::toOpenApiPaymentInstruction)
                .orElseThrow(NotFoundException::new);

        return Response.ok().entity(paymentInstruction).build();
    }
}



package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sttlmPrty",
    "reqdExctnDt",
    "dtPrtyInd",
    "sttlmDt",
    "intrBkSttlmDt",
    "dbtValDt",
    "cdtValDt",
    "sttlmTmIndctnDbtDtTm",
    "sttlmTmIndctnCbtDtTm",
    "sttlmTmReqCLSTm",
    "sttlmTmReqTillTm",
    "sttlmTmReqFrTm",
    "sttlmTmReqRjctTm",
    "accptncDtTm"
})
public class SttlmDtTmInf {

    @JsonProperty("sttlmPrty")
    private String sttlmPrty;
    @JsonProperty("reqdExctnDt")
    private String reqdExctnDt;
    @JsonProperty("dtPrtyInd")
    private String dtPrtyInd;
    @JsonProperty("sttlmDt")
    private String sttlmDt;
    @JsonProperty("intrBkSttlmDt")
    private String intrBkSttlmDt;
    @JsonProperty("dbtValDt")
    private String dbtValDt;
    @JsonProperty("cdtValDt")
    private String cdtValDt;
    @JsonProperty("sttlmTmIndctnDbtDtTm")
    private String sttlmTmIndctnDbtDtTm;
    @JsonProperty("sttlmTmIndctnCbtDtTm")
    private String sttlmTmIndctnCbtDtTm;
    @JsonProperty("sttlmTmReqCLSTm")
    private String sttlmTmReqCLSTm;
    @JsonProperty("sttlmTmReqTillTm")
    private String sttlmTmReqTillTm;
    @JsonProperty("sttlmTmReqFrTm")
    private String sttlmTmReqFrTm;
    @JsonProperty("sttlmTmReqRjctTm")
    private String sttlmTmReqRjctTm;
    @JsonProperty("accptncDtTm")
    private String accptncDtTm;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("sttlmPrty")
    public String getSttlmPrty() {
        return sttlmPrty;
    }

    @JsonProperty("sttlmPrty")
    public void setSttlmPrty(String sttlmPrty) {
        this.sttlmPrty = sttlmPrty;
    }

    public SttlmDtTmInf withSttlmPrty(String sttlmPrty) {
        this.sttlmPrty = sttlmPrty;
        return this;
    }

    @JsonProperty("reqdExctnDt")
    public String getReqdExctnDt() {
        return reqdExctnDt;
    }

    @JsonProperty("reqdExctnDt")
    public void setReqdExctnDt(String reqdExctnDt) {
        this.reqdExctnDt = reqdExctnDt;
    }

    public SttlmDtTmInf withReqdExctnDt(String reqdExctnDt) {
        this.reqdExctnDt = reqdExctnDt;
        return this;
    }

    @JsonProperty("dtPrtyInd")
    public String getDtPrtyInd() {
        return dtPrtyInd;
    }

    @JsonProperty("dtPrtyInd")
    public void setDtPrtyInd(String dtPrtyInd) {
        this.dtPrtyInd = dtPrtyInd;
    }

    public SttlmDtTmInf withDtPrtyInd(String dtPrtyInd) {
        this.dtPrtyInd = dtPrtyInd;
        return this;
    }

    @JsonProperty("sttlmDt")
    public String getSttlmDt() {
        return sttlmDt;
    }

    @JsonProperty("sttlmDt")
    public void setSttlmDt(String sttlmDt) {
        this.sttlmDt = sttlmDt;
    }

    public SttlmDtTmInf withSttlmDt(String sttlmDt) {
        this.sttlmDt = sttlmDt;
        return this;
    }

    @JsonProperty("intrBkSttlmDt")
    public String getIntrBkSttlmDt() {
        return intrBkSttlmDt;
    }

    @JsonProperty("intrBkSttlmDt")
    public void setIntrBkSttlmDt(String intrBkSttlmDt) {
        this.intrBkSttlmDt = intrBkSttlmDt;
    }

    public SttlmDtTmInf withIntrBkSttlmDt(String intrBkSttlmDt) {
        this.intrBkSttlmDt = intrBkSttlmDt;
        return this;
    }

    @JsonProperty("dbtValDt")
    public String getDbtValDt() {
        return dbtValDt;
    }

    @JsonProperty("dbtValDt")
    public void setDbtValDt(String dbtValDt) {
        this.dbtValDt = dbtValDt;
    }

    public SttlmDtTmInf withDbtValDt(String dbtValDt) {
        this.dbtValDt = dbtValDt;
        return this;
    }

    @JsonProperty("cdtValDt")
    public String getCdtValDt() {
        return cdtValDt;
    }

    @JsonProperty("cdtValDt")
    public void setCdtValDt(String cdtValDt) {
        this.cdtValDt = cdtValDt;
    }

    public SttlmDtTmInf withCdtValDt(String cdtValDt) {
        this.cdtValDt = cdtValDt;
        return this;
    }

    @JsonProperty("sttlmTmIndctnDbtDtTm")
    public String getSttlmTmIndctnDbtDtTm() {
        return sttlmTmIndctnDbtDtTm;
    }

    @JsonProperty("sttlmTmIndctnDbtDtTm")
    public void setSttlmTmIndctnDbtDtTm(String sttlmTmIndctnDbtDtTm) {
        this.sttlmTmIndctnDbtDtTm = sttlmTmIndctnDbtDtTm;
    }

    public SttlmDtTmInf withSttlmTmIndctnDbtDtTm(String sttlmTmIndctnDbtDtTm) {
        this.sttlmTmIndctnDbtDtTm = sttlmTmIndctnDbtDtTm;
        return this;
    }

    @JsonProperty("sttlmTmIndctnCbtDtTm")
    public String getSttlmTmIndctnCbtDtTm() {
        return sttlmTmIndctnCbtDtTm;
    }

    @JsonProperty("sttlmTmIndctnCbtDtTm")
    public void setSttlmTmIndctnCbtDtTm(String sttlmTmIndctnCbtDtTm) {
        this.sttlmTmIndctnCbtDtTm = sttlmTmIndctnCbtDtTm;
    }

    public SttlmDtTmInf withSttlmTmIndctnCbtDtTm(String sttlmTmIndctnCbtDtTm) {
        this.sttlmTmIndctnCbtDtTm = sttlmTmIndctnCbtDtTm;
        return this;
    }

    @JsonProperty("sttlmTmReqCLSTm")
    public String getSttlmTmReqCLSTm() {
        return sttlmTmReqCLSTm;
    }

    @JsonProperty("sttlmTmReqCLSTm")
    public void setSttlmTmReqCLSTm(String sttlmTmReqCLSTm) {
        this.sttlmTmReqCLSTm = sttlmTmReqCLSTm;
    }

    public SttlmDtTmInf withSttlmTmReqCLSTm(String sttlmTmReqCLSTm) {
        this.sttlmTmReqCLSTm = sttlmTmReqCLSTm;
        return this;
    }

    @JsonProperty("sttlmTmReqTillTm")
    public String getSttlmTmReqTillTm() {
        return sttlmTmReqTillTm;
    }

    @JsonProperty("sttlmTmReqTillTm")
    public void setSttlmTmReqTillTm(String sttlmTmReqTillTm) {
        this.sttlmTmReqTillTm = sttlmTmReqTillTm;
    }

    public SttlmDtTmInf withSttlmTmReqTillTm(String sttlmTmReqTillTm) {
        this.sttlmTmReqTillTm = sttlmTmReqTillTm;
        return this;
    }

    @JsonProperty("sttlmTmReqFrTm")
    public String getSttlmTmReqFrTm() {
        return sttlmTmReqFrTm;
    }

    @JsonProperty("sttlmTmReqFrTm")
    public void setSttlmTmReqFrTm(String sttlmTmReqFrTm) {
        this.sttlmTmReqFrTm = sttlmTmReqFrTm;
    }

    public SttlmDtTmInf withSttlmTmReqFrTm(String sttlmTmReqFrTm) {
        this.sttlmTmReqFrTm = sttlmTmReqFrTm;
        return this;
    }

    @JsonProperty("sttlmTmReqRjctTm")
    public String getSttlmTmReqRjctTm() {
        return sttlmTmReqRjctTm;
    }

    @JsonProperty("sttlmTmReqRjctTm")
    public void setSttlmTmReqRjctTm(String sttlmTmReqRjctTm) {
        this.sttlmTmReqRjctTm = sttlmTmReqRjctTm;
    }

    public SttlmDtTmInf withSttlmTmReqRjctTm(String sttlmTmReqRjctTm) {
        this.sttlmTmReqRjctTm = sttlmTmReqRjctTm;
        return this;
    }

    @JsonProperty("accptncDtTm")
    public String getAccptncDtTm() {
        return accptncDtTm;
    }

    @JsonProperty("accptncDtTm")
    public void setAccptncDtTm(String accptncDtTm) {
        this.accptncDtTm = accptncDtTm;
    }

    public SttlmDtTmInf withAccptncDtTm(String accptncDtTm) {
        this.accptncDtTm = accptncDtTm;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SttlmDtTmInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sttlmPrty).append(reqdExctnDt).append(dtPrtyInd).append(sttlmDt).append(intrBkSttlmDt).append(dbtValDt).append(cdtValDt).append(sttlmTmIndctnDbtDtTm).append(sttlmTmIndctnCbtDtTm).append(sttlmTmReqCLSTm).append(sttlmTmReqTillTm).append(sttlmTmReqFrTm).append(sttlmTmReqRjctTm).append(accptncDtTm).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SttlmDtTmInf) == false) {
            return false;
        }
        SttlmDtTmInf rhs = ((SttlmDtTmInf) other);
        return new EqualsBuilder().append(sttlmPrty, rhs.sttlmPrty).append(reqdExctnDt, rhs.reqdExctnDt).append(dtPrtyInd, rhs.dtPrtyInd).append(sttlmDt, rhs.sttlmDt).append(intrBkSttlmDt, rhs.intrBkSttlmDt).append(dbtValDt, rhs.dbtValDt).append(cdtValDt, rhs.cdtValDt).append(sttlmTmIndctnDbtDtTm, rhs.sttlmTmIndctnDbtDtTm).append(sttlmTmIndctnCbtDtTm, rhs.sttlmTmIndctnCbtDtTm).append(sttlmTmReqCLSTm, rhs.sttlmTmReqCLSTm).append(sttlmTmReqTillTm, rhs.sttlmTmReqTillTm).append(sttlmTmReqFrTm, rhs.sttlmTmReqFrTm).append(sttlmTmReqRjctTm, rhs.sttlmTmReqRjctTm).append(accptncDtTm, rhs.accptncDtTm).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

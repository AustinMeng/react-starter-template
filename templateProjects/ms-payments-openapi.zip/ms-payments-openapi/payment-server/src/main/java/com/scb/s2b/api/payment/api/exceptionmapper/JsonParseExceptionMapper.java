package com.scb.s2b.api.payment.api.exceptionmapper;

import static com.scb.s2b.api.payment.validation.ValidationErrorCode.AER_1005;

import com.fasterxml.jackson.core.JsonParseException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

public class JsonParseExceptionMapper implements ExceptionMapper<JsonParseException> {

    @Override
    public Response toResponse(JsonParseException e) {
        return Response.status(Response.Status.BAD_REQUEST)
                .entity(AER_1005.getFullMessage(e.getMessage()))
                .build();
    }
}

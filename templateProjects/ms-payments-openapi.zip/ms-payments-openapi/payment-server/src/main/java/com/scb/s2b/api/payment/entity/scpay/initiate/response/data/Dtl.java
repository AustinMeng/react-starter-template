
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tp",
    "dt",
    "ctry",
    "cd",
    "amt",
    "ccy",
    "inf"
})
public class Dtl {

    @JsonProperty("tp")
    private String tp;
    @JsonProperty("dt")
    private String dt;
    @JsonProperty("ctry")
    private String ctry;
    @JsonProperty("cd")
    private String cd;
    @JsonProperty("amt")
    private String amt;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("inf")
    private List<String> inf = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tp")
    public String getTp() {
        return tp;
    }

    @JsonProperty("tp")
    public void setTp(String tp) {
        this.tp = tp;
    }

    public Dtl withTp(String tp) {
        this.tp = tp;
        return this;
    }

    @JsonProperty("dt")
    public String getDt() {
        return dt;
    }

    @JsonProperty("dt")
    public void setDt(String dt) {
        this.dt = dt;
    }

    public Dtl withDt(String dt) {
        this.dt = dt;
        return this;
    }

    @JsonProperty("ctry")
    public String getCtry() {
        return ctry;
    }

    @JsonProperty("ctry")
    public void setCtry(String ctry) {
        this.ctry = ctry;
    }

    public Dtl withCtry(String ctry) {
        this.ctry = ctry;
        return this;
    }

    @JsonProperty("cd")
    public String getCd() {
        return cd;
    }

    @JsonProperty("cd")
    public void setCd(String cd) {
        this.cd = cd;
    }

    public Dtl withCd(String cd) {
        this.cd = cd;
        return this;
    }

    @JsonProperty("amt")
    public String getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(String amt) {
        this.amt = amt;
    }

    public Dtl withAmt(String amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public Dtl withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("inf")
    public List<String> getInf() {
        return inf;
    }

    @JsonProperty("inf")
    public void setInf(List<String> inf) {
        this.inf = inf;
    }

    public Dtl withInf(List<String> inf) {
        this.inf = inf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Dtl withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tp).append(dt).append(ctry).append(cd).append(amt).append(ccy).append(inf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Dtl) == false) {
            return false;
        }
        Dtl rhs = ((Dtl) other);
        return new EqualsBuilder().append(tp, rhs.tp).append(dt, rhs.dt).append(ctry, rhs.ctry).append(cd, rhs.cd).append(amt, rhs.amt).append(ccy, rhs.ccy).append(inf, rhs.inf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}


package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "clrRefNb",
    "clrRealTmNtfctnInd",
    "POSNtryMtd",
    "POSCondCd",
    "POSId",
    "POSTermnlData",
    "txOrgCtryCd",
    "cardNb",
    "cardXpryDt",
    "mrchntTp",
    "buyrNm",
    "makrNm",
    "bnfcryId",
    "bnfcryRefNb1",
    "bnfcryRefNb2",
    "bllrCd",
    "bllrCdNm",
    "bllrNm",
    "txXpryDtTm",
    "taxTknTp",
    "lookupRef",
    "bllrRef",
    "utltySvcTp",
    "cstmrAcctNb"
})
public class BillAndMrchntTxInf {

    @JsonProperty("clrRefNb")
    private String clrRefNb;
    @JsonProperty("clrRealTmNtfctnInd")
    private String clrRealTmNtfctnInd;
    @JsonProperty("POSNtryMtd")
    private String pOSNtryMtd;
    @JsonProperty("POSCondCd")
    private String pOSCondCd;
    @JsonProperty("POSId")
    private String pOSId;
    @JsonProperty("POSTermnlData")
    private String pOSTermnlData;
    @JsonProperty("txOrgCtryCd")
    private String txOrgCtryCd;
    @JsonProperty("cardNb")
    private String cardNb;
    @JsonProperty("cardXpryDt")
    private String cardXpryDt;
    @JsonProperty("mrchntTp")
    private String mrchntTp;
    @JsonProperty("buyrNm")
    private String buyrNm;
    @JsonProperty("makrNm")
    private String makrNm;
    @JsonProperty("bnfcryId")
    private String bnfcryId;
    @JsonProperty("bnfcryRefNb1")
    private String bnfcryRefNb1;
    @JsonProperty("bnfcryRefNb2")
    private String bnfcryRefNb2;
    @JsonProperty("bllrCd")
    private String bllrCd;
    @JsonProperty("bllrCdNm")
    private String bllrCdNm;
    @JsonProperty("bllrNm")
    private String bllrNm;
    @JsonProperty("txXpryDtTm")
    private String txXpryDtTm;
    @JsonProperty("taxTknTp")
    private String taxTknTp;
    @JsonProperty("lookupRef")
    private String lookupRef;
    @JsonProperty("bllrRef")
    private String bllrRef;
    @JsonProperty("utltySvcTp")
    private String utltySvcTp;
    @JsonProperty("cstmrAcctNb")
    private String cstmrAcctNb;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("clrRefNb")
    public String getClrRefNb() {
        return clrRefNb;
    }

    @JsonProperty("clrRefNb")
    public void setClrRefNb(String clrRefNb) {
        this.clrRefNb = clrRefNb;
    }

    public BillAndMrchntTxInf withClrRefNb(String clrRefNb) {
        this.clrRefNb = clrRefNb;
        return this;
    }

    @JsonProperty("clrRealTmNtfctnInd")
    public String getClrRealTmNtfctnInd() {
        return clrRealTmNtfctnInd;
    }

    @JsonProperty("clrRealTmNtfctnInd")
    public void setClrRealTmNtfctnInd(String clrRealTmNtfctnInd) {
        this.clrRealTmNtfctnInd = clrRealTmNtfctnInd;
    }

    public BillAndMrchntTxInf withClrRealTmNtfctnInd(String clrRealTmNtfctnInd) {
        this.clrRealTmNtfctnInd = clrRealTmNtfctnInd;
        return this;
    }

    @JsonProperty("POSNtryMtd")
    public String getPOSNtryMtd() {
        return pOSNtryMtd;
    }

    @JsonProperty("POSNtryMtd")
    public void setPOSNtryMtd(String pOSNtryMtd) {
        this.pOSNtryMtd = pOSNtryMtd;
    }

    public BillAndMrchntTxInf withPOSNtryMtd(String pOSNtryMtd) {
        this.pOSNtryMtd = pOSNtryMtd;
        return this;
    }

    @JsonProperty("POSCondCd")
    public String getPOSCondCd() {
        return pOSCondCd;
    }

    @JsonProperty("POSCondCd")
    public void setPOSCondCd(String pOSCondCd) {
        this.pOSCondCd = pOSCondCd;
    }

    public BillAndMrchntTxInf withPOSCondCd(String pOSCondCd) {
        this.pOSCondCd = pOSCondCd;
        return this;
    }

    @JsonProperty("POSId")
    public String getPOSId() {
        return pOSId;
    }

    @JsonProperty("POSId")
    public void setPOSId(String pOSId) {
        this.pOSId = pOSId;
    }

    public BillAndMrchntTxInf withPOSId(String pOSId) {
        this.pOSId = pOSId;
        return this;
    }

    @JsonProperty("POSTermnlData")
    public String getPOSTermnlData() {
        return pOSTermnlData;
    }

    @JsonProperty("POSTermnlData")
    public void setPOSTermnlData(String pOSTermnlData) {
        this.pOSTermnlData = pOSTermnlData;
    }

    public BillAndMrchntTxInf withPOSTermnlData(String pOSTermnlData) {
        this.pOSTermnlData = pOSTermnlData;
        return this;
    }

    @JsonProperty("txOrgCtryCd")
    public String getTxOrgCtryCd() {
        return txOrgCtryCd;
    }

    @JsonProperty("txOrgCtryCd")
    public void setTxOrgCtryCd(String txOrgCtryCd) {
        this.txOrgCtryCd = txOrgCtryCd;
    }

    public BillAndMrchntTxInf withTxOrgCtryCd(String txOrgCtryCd) {
        this.txOrgCtryCd = txOrgCtryCd;
        return this;
    }

    @JsonProperty("cardNb")
    public String getCardNb() {
        return cardNb;
    }

    @JsonProperty("cardNb")
    public void setCardNb(String cardNb) {
        this.cardNb = cardNb;
    }

    public BillAndMrchntTxInf withCardNb(String cardNb) {
        this.cardNb = cardNb;
        return this;
    }

    @JsonProperty("cardXpryDt")
    public String getCardXpryDt() {
        return cardXpryDt;
    }

    @JsonProperty("cardXpryDt")
    public void setCardXpryDt(String cardXpryDt) {
        this.cardXpryDt = cardXpryDt;
    }

    public BillAndMrchntTxInf withCardXpryDt(String cardXpryDt) {
        this.cardXpryDt = cardXpryDt;
        return this;
    }

    @JsonProperty("mrchntTp")
    public String getMrchntTp() {
        return mrchntTp;
    }

    @JsonProperty("mrchntTp")
    public void setMrchntTp(String mrchntTp) {
        this.mrchntTp = mrchntTp;
    }

    public BillAndMrchntTxInf withMrchntTp(String mrchntTp) {
        this.mrchntTp = mrchntTp;
        return this;
    }

    @JsonProperty("buyrNm")
    public String getBuyrNm() {
        return buyrNm;
    }

    @JsonProperty("buyrNm")
    public void setBuyrNm(String buyrNm) {
        this.buyrNm = buyrNm;
    }

    public BillAndMrchntTxInf withBuyrNm(String buyrNm) {
        this.buyrNm = buyrNm;
        return this;
    }

    @JsonProperty("makrNm")
    public String getMakrNm() {
        return makrNm;
    }

    @JsonProperty("makrNm")
    public void setMakrNm(String makrNm) {
        this.makrNm = makrNm;
    }

    public BillAndMrchntTxInf withMakrNm(String makrNm) {
        this.makrNm = makrNm;
        return this;
    }

    @JsonProperty("bnfcryId")
    public String getBnfcryId() {
        return bnfcryId;
    }

    @JsonProperty("bnfcryId")
    public void setBnfcryId(String bnfcryId) {
        this.bnfcryId = bnfcryId;
    }

    public BillAndMrchntTxInf withBnfcryId(String bnfcryId) {
        this.bnfcryId = bnfcryId;
        return this;
    }

    @JsonProperty("bnfcryRefNb1")
    public String getBnfcryRefNb1() {
        return bnfcryRefNb1;
    }

    @JsonProperty("bnfcryRefNb1")
    public void setBnfcryRefNb1(String bnfcryRefNb1) {
        this.bnfcryRefNb1 = bnfcryRefNb1;
    }

    public BillAndMrchntTxInf withBnfcryRefNb1(String bnfcryRefNb1) {
        this.bnfcryRefNb1 = bnfcryRefNb1;
        return this;
    }

    @JsonProperty("bnfcryRefNb2")
    public String getBnfcryRefNb2() {
        return bnfcryRefNb2;
    }

    @JsonProperty("bnfcryRefNb2")
    public void setBnfcryRefNb2(String bnfcryRefNb2) {
        this.bnfcryRefNb2 = bnfcryRefNb2;
    }

    public BillAndMrchntTxInf withBnfcryRefNb2(String bnfcryRefNb2) {
        this.bnfcryRefNb2 = bnfcryRefNb2;
        return this;
    }

    @JsonProperty("bllrCd")
    public String getBllrCd() {
        return bllrCd;
    }

    @JsonProperty("bllrCd")
    public void setBllrCd(String bllrCd) {
        this.bllrCd = bllrCd;
    }

    public BillAndMrchntTxInf withBllrCd(String bllrCd) {
        this.bllrCd = bllrCd;
        return this;
    }

    @JsonProperty("bllrCdNm")
    public String getBllrCdNm() {
        return bllrCdNm;
    }

    @JsonProperty("bllrCdNm")
    public void setBllrCdNm(String bllrCdNm) {
        this.bllrCdNm = bllrCdNm;
    }

    public BillAndMrchntTxInf withBllrCdNm(String bllrCdNm) {
        this.bllrCdNm = bllrCdNm;
        return this;
    }

    @JsonProperty("bllrNm")
    public String getBllrNm() {
        return bllrNm;
    }

    @JsonProperty("bllrNm")
    public void setBllrNm(String bllrNm) {
        this.bllrNm = bllrNm;
    }

    public BillAndMrchntTxInf withBllrNm(String bllrNm) {
        this.bllrNm = bllrNm;
        return this;
    }

    @JsonProperty("txXpryDtTm")
    public String getTxXpryDtTm() {
        return txXpryDtTm;
    }

    @JsonProperty("txXpryDtTm")
    public void setTxXpryDtTm(String txXpryDtTm) {
        this.txXpryDtTm = txXpryDtTm;
    }

    public BillAndMrchntTxInf withTxXpryDtTm(String txXpryDtTm) {
        this.txXpryDtTm = txXpryDtTm;
        return this;
    }

    @JsonProperty("taxTknTp")
    public String getTaxTknTp() {
        return taxTknTp;
    }

    @JsonProperty("taxTknTp")
    public void setTaxTknTp(String taxTknTp) {
        this.taxTknTp = taxTknTp;
    }

    public BillAndMrchntTxInf withTaxTknTp(String taxTknTp) {
        this.taxTknTp = taxTknTp;
        return this;
    }

    @JsonProperty("lookupRef")
    public String getLookupRef() {
        return lookupRef;
    }

    @JsonProperty("lookupRef")
    public void setLookupRef(String lookupRef) {
        this.lookupRef = lookupRef;
    }

    public BillAndMrchntTxInf withLookupRef(String lookupRef) {
        this.lookupRef = lookupRef;
        return this;
    }

    @JsonProperty("bllrRef")
    public String getBllrRef() {
        return bllrRef;
    }

    @JsonProperty("bllrRef")
    public void setBllrRef(String bllrRef) {
        this.bllrRef = bllrRef;
    }

    public BillAndMrchntTxInf withBllrRef(String bllrRef) {
        this.bllrRef = bllrRef;
        return this;
    }

    @JsonProperty("utltySvcTp")
    public String getUtltySvcTp() {
        return utltySvcTp;
    }

    @JsonProperty("utltySvcTp")
    public void setUtltySvcTp(String utltySvcTp) {
        this.utltySvcTp = utltySvcTp;
    }

    public BillAndMrchntTxInf withUtltySvcTp(String utltySvcTp) {
        this.utltySvcTp = utltySvcTp;
        return this;
    }

    @JsonProperty("cstmrAcctNb")
    public String getCstmrAcctNb() {
        return cstmrAcctNb;
    }

    @JsonProperty("cstmrAcctNb")
    public void setCstmrAcctNb(String cstmrAcctNb) {
        this.cstmrAcctNb = cstmrAcctNb;
    }

    public BillAndMrchntTxInf withCstmrAcctNb(String cstmrAcctNb) {
        this.cstmrAcctNb = cstmrAcctNb;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BillAndMrchntTxInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(clrRefNb).append(clrRealTmNtfctnInd).append(pOSNtryMtd).append(pOSCondCd).append(pOSId).append(pOSTermnlData).append(txOrgCtryCd).append(cardNb).append(cardXpryDt).append(mrchntTp).append(buyrNm).append(makrNm).append(bnfcryId).append(bnfcryRefNb1).append(bnfcryRefNb2).append(bllrCd).append(bllrCdNm).append(bllrNm).append(txXpryDtTm).append(taxTknTp).append(lookupRef).append(bllrRef).append(utltySvcTp).append(cstmrAcctNb).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BillAndMrchntTxInf) == false) {
            return false;
        }
        BillAndMrchntTxInf rhs = ((BillAndMrchntTxInf) other);
        return new EqualsBuilder().append(clrRefNb, rhs.clrRefNb).append(clrRealTmNtfctnInd, rhs.clrRealTmNtfctnInd).append(pOSNtryMtd, rhs.pOSNtryMtd).append(pOSCondCd, rhs.pOSCondCd).append(pOSId, rhs.pOSId).append(pOSTermnlData, rhs.pOSTermnlData).append(txOrgCtryCd, rhs.txOrgCtryCd).append(cardNb, rhs.cardNb).append(cardXpryDt, rhs.cardXpryDt).append(mrchntTp, rhs.mrchntTp).append(buyrNm, rhs.buyrNm).append(makrNm, rhs.makrNm).append(bnfcryId, rhs.bnfcryId).append(bnfcryRefNb1, rhs.bnfcryRefNb1).append(bnfcryRefNb2, rhs.bnfcryRefNb2).append(bllrCd, rhs.bllrCd).append(bllrCdNm, rhs.bllrCdNm).append(bllrNm, rhs.bllrNm).append(txXpryDtTm, rhs.txXpryDtTm).append(taxTknTp, rhs.taxTknTp).append(lookupRef, rhs.lookupRef).append(bllrRef, rhs.bllrRef).append(utltySvcTp, rhs.utltySvcTp).append(cstmrAcctNb, rhs.cstmrAcctNb).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

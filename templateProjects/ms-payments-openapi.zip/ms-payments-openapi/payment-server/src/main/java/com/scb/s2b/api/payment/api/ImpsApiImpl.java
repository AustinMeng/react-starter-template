package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.entity.PaymentInstruction;
import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.ImpsPaymentRequestValidator;
import java.util.Map;
import javax.inject.Singleton;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Singleton
public class ImpsApiImpl extends ApiBase {

    private final ImpsPaymentRequestValidator paymentRequestValidator;

    private final RequestProcessor impsRequestProcessor;

    private final OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer;

    private final PaymentService paymentService;

    private static final Logger logger = LoggerFactory.getLogger(ImpsApiImpl.class);

    @Autowired
    public ImpsApiImpl(ImpsPaymentRequestValidator paymentRequestValidator,
            @Qualifier("impsRequestProcessor") RequestProcessor impsRequestProcessor,
            OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer,
            PaymentService paymentService) {
        this.paymentRequestValidator = paymentRequestValidator;
        this.impsRequestProcessor = impsRequestProcessor;
        this.openApiPaymentInstructionTransformer = openApiPaymentInstructionTransformer;
        this.paymentService = paymentService;
    }

    public Response paymentInitiate(String preVerified, OpenApiPaymentInstruction body, HttpHeaders headers) {
        String groupId = this.validateGroupId(headers);
        String requestId = headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);
        logger.info("PaymentInitiate requestId={}, groupId={}, clientReferenceId={}", requestId, groupId,
                body.getInstruction().getReferenceId());

        paymentRequestValidator.validate(groupId, body);
        Map<String, String> headersMap = this.getHeaders(headers);

        boolean isPreVerified = "true".equalsIgnoreCase(preVerified);
        PaymentInstruction paymentInstruction = openApiPaymentInstructionTransformer
                .toPaymentInstruction(body, isPreVerified, headersMap);

        impsRequestProcessor.process(paymentInstruction);
        paymentService.initiate(paymentInstruction);
        paymentRequestValidator.cache(paymentInstruction);

        OpenApiPaymentId openApiPaymentId = openApiPaymentInstructionTransformer.toOpenApiPaymentId(paymentInstruction);

        return Response.ok(openApiPaymentId).build();
    }
}

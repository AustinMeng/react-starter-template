
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "duePyblAmt",
    "duePyblAmtCcy",
    "cdNoteAmt",
    "cdNoteAmtCcy",
    "rmtdAmt",
    "rmtdAmtCcy",
    "dscntApldAmt",
    "taxAmt",
    "adjstmntAmtAndRsn"
})
public class RfrdDocAmt {

    @JsonProperty("duePyblAmt")
    private String duePyblAmt;
    @JsonProperty("duePyblAmtCcy")
    private String duePyblAmtCcy;
    @JsonProperty("cdNoteAmt")
    private String cdNoteAmt;
    @JsonProperty("cdNoteAmtCcy")
    private String cdNoteAmtCcy;
    @JsonProperty("rmtdAmt")
    private String rmtdAmt;
    @JsonProperty("rmtdAmtCcy")
    private String rmtdAmtCcy;
    @JsonProperty("dscntApldAmt")
    private List<DscntApldAmt> dscntApldAmt = null;
    @JsonProperty("taxAmt")
    private List<TaxAmt> taxAmt = null;
    @JsonProperty("adjstmntAmtAndRsn")
    private List<AdjstmntAmtAndRsn> adjstmntAmtAndRsn = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("duePyblAmt")
    public String getDuePyblAmt() {
        return duePyblAmt;
    }

    @JsonProperty("duePyblAmt")
    public void setDuePyblAmt(String duePyblAmt) {
        this.duePyblAmt = duePyblAmt;
    }

    public RfrdDocAmt withDuePyblAmt(String duePyblAmt) {
        this.duePyblAmt = duePyblAmt;
        return this;
    }

    @JsonProperty("duePyblAmtCcy")
    public String getDuePyblAmtCcy() {
        return duePyblAmtCcy;
    }

    @JsonProperty("duePyblAmtCcy")
    public void setDuePyblAmtCcy(String duePyblAmtCcy) {
        this.duePyblAmtCcy = duePyblAmtCcy;
    }

    public RfrdDocAmt withDuePyblAmtCcy(String duePyblAmtCcy) {
        this.duePyblAmtCcy = duePyblAmtCcy;
        return this;
    }

    @JsonProperty("cdNoteAmt")
    public String getCdNoteAmt() {
        return cdNoteAmt;
    }

    @JsonProperty("cdNoteAmt")
    public void setCdNoteAmt(String cdNoteAmt) {
        this.cdNoteAmt = cdNoteAmt;
    }

    public RfrdDocAmt withCdNoteAmt(String cdNoteAmt) {
        this.cdNoteAmt = cdNoteAmt;
        return this;
    }

    @JsonProperty("cdNoteAmtCcy")
    public String getCdNoteAmtCcy() {
        return cdNoteAmtCcy;
    }

    @JsonProperty("cdNoteAmtCcy")
    public void setCdNoteAmtCcy(String cdNoteAmtCcy) {
        this.cdNoteAmtCcy = cdNoteAmtCcy;
    }

    public RfrdDocAmt withCdNoteAmtCcy(String cdNoteAmtCcy) {
        this.cdNoteAmtCcy = cdNoteAmtCcy;
        return this;
    }

    @JsonProperty("rmtdAmt")
    public String getRmtdAmt() {
        return rmtdAmt;
    }

    @JsonProperty("rmtdAmt")
    public void setRmtdAmt(String rmtdAmt) {
        this.rmtdAmt = rmtdAmt;
    }

    public RfrdDocAmt withRmtdAmt(String rmtdAmt) {
        this.rmtdAmt = rmtdAmt;
        return this;
    }

    @JsonProperty("rmtdAmtCcy")
    public String getRmtdAmtCcy() {
        return rmtdAmtCcy;
    }

    @JsonProperty("rmtdAmtCcy")
    public void setRmtdAmtCcy(String rmtdAmtCcy) {
        this.rmtdAmtCcy = rmtdAmtCcy;
    }

    public RfrdDocAmt withRmtdAmtCcy(String rmtdAmtCcy) {
        this.rmtdAmtCcy = rmtdAmtCcy;
        return this;
    }

    @JsonProperty("dscntApldAmt")
    public List<DscntApldAmt> getDscntApldAmt() {
        return dscntApldAmt;
    }

    @JsonProperty("dscntApldAmt")
    public void setDscntApldAmt(List<DscntApldAmt> dscntApldAmt) {
        this.dscntApldAmt = dscntApldAmt;
    }

    public RfrdDocAmt withDscntApldAmt(List<DscntApldAmt> dscntApldAmt) {
        this.dscntApldAmt = dscntApldAmt;
        return this;
    }

    @JsonProperty("taxAmt")
    public List<TaxAmt> getTaxAmt() {
        return taxAmt;
    }

    @JsonProperty("taxAmt")
    public void setTaxAmt(List<TaxAmt> taxAmt) {
        this.taxAmt = taxAmt;
    }

    public RfrdDocAmt withTaxAmt(List<TaxAmt> taxAmt) {
        this.taxAmt = taxAmt;
        return this;
    }

    @JsonProperty("adjstmntAmtAndRsn")
    public List<AdjstmntAmtAndRsn> getAdjstmntAmtAndRsn() {
        return adjstmntAmtAndRsn;
    }

    @JsonProperty("adjstmntAmtAndRsn")
    public void setAdjstmntAmtAndRsn(List<AdjstmntAmtAndRsn> adjstmntAmtAndRsn) {
        this.adjstmntAmtAndRsn = adjstmntAmtAndRsn;
    }

    public RfrdDocAmt withAdjstmntAmtAndRsn(List<AdjstmntAmtAndRsn> adjstmntAmtAndRsn) {
        this.adjstmntAmtAndRsn = adjstmntAmtAndRsn;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RfrdDocAmt withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(duePyblAmt).append(duePyblAmtCcy).append(cdNoteAmt).append(cdNoteAmtCcy).append(rmtdAmt).append(rmtdAmtCcy).append(dscntApldAmt).append(taxAmt).append(adjstmntAmtAndRsn).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RfrdDocAmt) == false) {
            return false;
        }
        RfrdDocAmt rhs = ((RfrdDocAmt) other);
        return new EqualsBuilder().append(duePyblAmt, rhs.duePyblAmt).append(duePyblAmtCcy, rhs.duePyblAmtCcy).append(cdNoteAmt, rhs.cdNoteAmt).append(cdNoteAmtCcy, rhs.cdNoteAmtCcy).append(rmtdAmt, rhs.rmtdAmt).append(rmtdAmtCcy, rhs.rmtdAmtCcy).append(dscntApldAmt, rhs.dscntApldAmt).append(taxAmt, rhs.taxAmt).append(adjstmntAmtAndRsn, rhs.adjstmntAmtAndRsn).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

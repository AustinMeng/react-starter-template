package com.scb.s2b.api.payment.config.property;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
public class NotificationProperties {
    private boolean enabled = true;
    private NotificationProperty signOnOff;
    private NotificationProperty bankDefaultBroadcast;
    private NotificationProperty bankStatusBroadcast;
    private NotificationProperty systemStatusBroadcast;
    private NotificationProperty bankStatusBroadcastPH;

    private List<String> notificationReqQueues;
    private List<TopicProperties> notificationRespTopics;

    public Map<String, String> getNotificationRespTopicMap() {
        return notificationRespTopics.stream().collect(Collectors.toMap(TopicProperties::getRegion, TopicProperties::getTemplate));
    }

    @ToString
    @Setter
    @Getter
    public static class NotificationProperty {
        private Integer maxAttempts = 5;
        private String suspendQueueTemplate;
        private String suspendRouteIdTemplate;
        private String notificationTemplate;
    }
}

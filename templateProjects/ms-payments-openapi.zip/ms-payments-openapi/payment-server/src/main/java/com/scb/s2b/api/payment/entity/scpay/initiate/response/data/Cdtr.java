
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "nm",
    "mddlNm",
    "lastNm",
    "fullNm",
    "dpNm",
    "jntNm",
    "jntTp",
    "nmLclLang",
    "brnchCd",
    "subBrnchCd",
    "brnchNm",
    "ctryOfRes",
    "mlngAdrLclLang",
    "pstlAdrLclLang",
    "ntlty",
    "acctCtryNm",
    "ocptn",
    "sgmt",
    "tp",
    "resdncyStsCd",
    "jntId",
    "frmtInd",
    "bnfcryTmpltId",
    "orgId",
    "prvtId",
    "pstlAdr",
    "ctctDtls"
})
public class Cdtr {

    @JsonProperty("nm")
    private String nm;
    @JsonProperty("mddlNm")
    private String mddlNm;
    @JsonProperty("lastNm")
    private String lastNm;
    @JsonProperty("fullNm")
    private String fullNm;
    @JsonProperty("dpNm")
    private String dpNm;
    @JsonProperty("jntNm")
    private String jntNm;
    @JsonProperty("jntTp")
    private String jntTp;
    @JsonProperty("nmLclLang")
    private String nmLclLang;
    @JsonProperty("brnchCd")
    private String brnchCd;
    @JsonProperty("subBrnchCd")
    private String subBrnchCd;
    @JsonProperty("brnchNm")
    private String brnchNm;
    @JsonProperty("ctryOfRes")
    private String ctryOfRes;
    @JsonProperty("mlngAdrLclLang")
    private String mlngAdrLclLang;
    @JsonProperty("pstlAdrLclLang")
    private String pstlAdrLclLang;
    @JsonProperty("ntlty")
    private String ntlty;
    @JsonProperty("acctCtryNm")
    private String acctCtryNm;
    @JsonProperty("ocptn")
    private String ocptn;
    @JsonProperty("sgmt")
    private String sgmt;
    @JsonProperty("tp")
    private String tp;
    @JsonProperty("resdncyStsCd")
    private String resdncyStsCd;
    @JsonProperty("jntId")
    private String jntId;
    @JsonProperty("frmtInd")
    private String frmtInd;
    @JsonProperty("bnfcryTmpltId")
    private String bnfcryTmpltId;
    @JsonProperty("orgId")
    private OrgId orgId;
    @JsonProperty("prvtId")
    private PrvtId prvtId;
    @JsonProperty("pstlAdr")
    private PstlAdr pstlAdr;
    @JsonProperty("ctctDtls")
    private CtctDtls ctctDtls;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("nm")
    public String getNm() {
        return nm;
    }

    @JsonProperty("nm")
    public void setNm(String nm) {
        this.nm = nm;
    }

    public Cdtr withNm(String nm) {
        this.nm = nm;
        return this;
    }

    @JsonProperty("mddlNm")
    public String getMddlNm() {
        return mddlNm;
    }

    @JsonProperty("mddlNm")
    public void setMddlNm(String mddlNm) {
        this.mddlNm = mddlNm;
    }

    public Cdtr withMddlNm(String mddlNm) {
        this.mddlNm = mddlNm;
        return this;
    }

    @JsonProperty("lastNm")
    public String getLastNm() {
        return lastNm;
    }

    @JsonProperty("lastNm")
    public void setLastNm(String lastNm) {
        this.lastNm = lastNm;
    }

    public Cdtr withLastNm(String lastNm) {
        this.lastNm = lastNm;
        return this;
    }

    @JsonProperty("fullNm")
    public String getFullNm() {
        return fullNm;
    }

    @JsonProperty("fullNm")
    public void setFullNm(String fullNm) {
        this.fullNm = fullNm;
    }

    public Cdtr withFullNm(String fullNm) {
        this.fullNm = fullNm;
        return this;
    }

    @JsonProperty("dpNm")
    public String getDpNm() {
        return dpNm;
    }

    @JsonProperty("dpNm")
    public void setDpNm(String dpNm) {
        this.dpNm = dpNm;
    }

    public Cdtr withDpNm(String dpNm) {
        this.dpNm = dpNm;
        return this;
    }

    @JsonProperty("jntNm")
    public String getJntNm() {
        return jntNm;
    }

    @JsonProperty("jntNm")
    public void setJntNm(String jntNm) {
        this.jntNm = jntNm;
    }

    public Cdtr withJntNm(String jntNm) {
        this.jntNm = jntNm;
        return this;
    }

    @JsonProperty("jntTp")
    public String getJntTp() {
        return jntTp;
    }

    @JsonProperty("jntTp")
    public void setJntTp(String jntTp) {
        this.jntTp = jntTp;
    }

    public Cdtr withJntTp(String jntTp) {
        this.jntTp = jntTp;
        return this;
    }

    @JsonProperty("nmLclLang")
    public String getNmLclLang() {
        return nmLclLang;
    }

    @JsonProperty("nmLclLang")
    public void setNmLclLang(String nmLclLang) {
        this.nmLclLang = nmLclLang;
    }

    public Cdtr withNmLclLang(String nmLclLang) {
        this.nmLclLang = nmLclLang;
        return this;
    }

    @JsonProperty("brnchCd")
    public String getBrnchCd() {
        return brnchCd;
    }

    @JsonProperty("brnchCd")
    public void setBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
    }

    public Cdtr withBrnchCd(String brnchCd) {
        this.brnchCd = brnchCd;
        return this;
    }

    @JsonProperty("subBrnchCd")
    public String getSubBrnchCd() {
        return subBrnchCd;
    }

    @JsonProperty("subBrnchCd")
    public void setSubBrnchCd(String subBrnchCd) {
        this.subBrnchCd = subBrnchCd;
    }

    public Cdtr withSubBrnchCd(String subBrnchCd) {
        this.subBrnchCd = subBrnchCd;
        return this;
    }

    @JsonProperty("brnchNm")
    public String getBrnchNm() {
        return brnchNm;
    }

    @JsonProperty("brnchNm")
    public void setBrnchNm(String brnchNm) {
        this.brnchNm = brnchNm;
    }

    public Cdtr withBrnchNm(String brnchNm) {
        this.brnchNm = brnchNm;
        return this;
    }

    @JsonProperty("ctryOfRes")
    public String getCtryOfRes() {
        return ctryOfRes;
    }

    @JsonProperty("ctryOfRes")
    public void setCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
    }

    public Cdtr withCtryOfRes(String ctryOfRes) {
        this.ctryOfRes = ctryOfRes;
        return this;
    }

    @JsonProperty("mlngAdrLclLang")
    public String getMlngAdrLclLang() {
        return mlngAdrLclLang;
    }

    @JsonProperty("mlngAdrLclLang")
    public void setMlngAdrLclLang(String mlngAdrLclLang) {
        this.mlngAdrLclLang = mlngAdrLclLang;
    }

    public Cdtr withMlngAdrLclLang(String mlngAdrLclLang) {
        this.mlngAdrLclLang = mlngAdrLclLang;
        return this;
    }

    @JsonProperty("pstlAdrLclLang")
    public String getPstlAdrLclLang() {
        return pstlAdrLclLang;
    }

    @JsonProperty("pstlAdrLclLang")
    public void setPstlAdrLclLang(String pstlAdrLclLang) {
        this.pstlAdrLclLang = pstlAdrLclLang;
    }

    public Cdtr withPstlAdrLclLang(String pstlAdrLclLang) {
        this.pstlAdrLclLang = pstlAdrLclLang;
        return this;
    }

    @JsonProperty("ntlty")
    public String getNtlty() {
        return ntlty;
    }

    @JsonProperty("ntlty")
    public void setNtlty(String ntlty) {
        this.ntlty = ntlty;
    }

    public Cdtr withNtlty(String ntlty) {
        this.ntlty = ntlty;
        return this;
    }

    @JsonProperty("acctCtryNm")
    public String getAcctCtryNm() {
        return acctCtryNm;
    }

    @JsonProperty("acctCtryNm")
    public void setAcctCtryNm(String acctCtryNm) {
        this.acctCtryNm = acctCtryNm;
    }

    public Cdtr withAcctCtryNm(String acctCtryNm) {
        this.acctCtryNm = acctCtryNm;
        return this;
    }

    @JsonProperty("ocptn")
    public String getOcptn() {
        return ocptn;
    }

    @JsonProperty("ocptn")
    public void setOcptn(String ocptn) {
        this.ocptn = ocptn;
    }

    public Cdtr withOcptn(String ocptn) {
        this.ocptn = ocptn;
        return this;
    }

    @JsonProperty("sgmt")
    public String getSgmt() {
        return sgmt;
    }

    @JsonProperty("sgmt")
    public void setSgmt(String sgmt) {
        this.sgmt = sgmt;
    }

    public Cdtr withSgmt(String sgmt) {
        this.sgmt = sgmt;
        return this;
    }

    @JsonProperty("tp")
    public String getTp() {
        return tp;
    }

    @JsonProperty("tp")
    public void setTp(String tp) {
        this.tp = tp;
    }

    public Cdtr withTp(String tp) {
        this.tp = tp;
        return this;
    }

    @JsonProperty("resdncyStsCd")
    public String getResdncyStsCd() {
        return resdncyStsCd;
    }

    @JsonProperty("resdncyStsCd")
    public void setResdncyStsCd(String resdncyStsCd) {
        this.resdncyStsCd = resdncyStsCd;
    }

    public Cdtr withResdncyStsCd(String resdncyStsCd) {
        this.resdncyStsCd = resdncyStsCd;
        return this;
    }

    @JsonProperty("jntId")
    public String getJntId() {
        return jntId;
    }

    @JsonProperty("jntId")
    public void setJntId(String jntId) {
        this.jntId = jntId;
    }

    public Cdtr withJntId(String jntId) {
        this.jntId = jntId;
        return this;
    }

    @JsonProperty("frmtInd")
    public String getFrmtInd() {
        return frmtInd;
    }

    @JsonProperty("frmtInd")
    public void setFrmtInd(String frmtInd) {
        this.frmtInd = frmtInd;
    }

    public Cdtr withFrmtInd(String frmtInd) {
        this.frmtInd = frmtInd;
        return this;
    }

    @JsonProperty("bnfcryTmpltId")
    public String getBnfcryTmpltId() {
        return bnfcryTmpltId;
    }

    @JsonProperty("bnfcryTmpltId")
    public void setBnfcryTmpltId(String bnfcryTmpltId) {
        this.bnfcryTmpltId = bnfcryTmpltId;
    }

    public Cdtr withBnfcryTmpltId(String bnfcryTmpltId) {
        this.bnfcryTmpltId = bnfcryTmpltId;
        return this;
    }

    @JsonProperty("orgId")
    public OrgId getOrgId() {
        return orgId;
    }

    @JsonProperty("orgId")
    public void setOrgId(OrgId orgId) {
        this.orgId = orgId;
    }

    public Cdtr withOrgId(OrgId orgId) {
        this.orgId = orgId;
        return this;
    }

    @JsonProperty("prvtId")
    public PrvtId getPrvtId() {
        return prvtId;
    }

    @JsonProperty("prvtId")
    public void setPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
    }

    public Cdtr withPrvtId(PrvtId prvtId) {
        this.prvtId = prvtId;
        return this;
    }

    @JsonProperty("pstlAdr")
    public PstlAdr getPstlAdr() {
        return pstlAdr;
    }

    @JsonProperty("pstlAdr")
    public void setPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
    }

    public Cdtr withPstlAdr(PstlAdr pstlAdr) {
        this.pstlAdr = pstlAdr;
        return this;
    }

    @JsonProperty("ctctDtls")
    public CtctDtls getCtctDtls() {
        return ctctDtls;
    }

    @JsonProperty("ctctDtls")
    public void setCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
    }

    public Cdtr withCtctDtls(CtctDtls ctctDtls) {
        this.ctctDtls = ctctDtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Cdtr withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(nm).append(mddlNm).append(lastNm).append(fullNm).append(dpNm).append(jntNm).append(jntTp).append(nmLclLang).append(brnchCd).append(subBrnchCd).append(brnchNm).append(ctryOfRes).append(mlngAdrLclLang).append(pstlAdrLclLang).append(ntlty).append(acctCtryNm).append(ocptn).append(sgmt).append(tp).append(resdncyStsCd).append(jntId).append(frmtInd).append(bnfcryTmpltId).append(orgId).append(prvtId).append(pstlAdr).append(ctctDtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Cdtr) == false) {
            return false;
        }
        Cdtr rhs = ((Cdtr) other);
        return new EqualsBuilder().append(nm, rhs.nm).append(mddlNm, rhs.mddlNm).append(lastNm, rhs.lastNm).append(fullNm, rhs.fullNm).append(dpNm, rhs.dpNm).append(jntNm, rhs.jntNm).append(jntTp, rhs.jntTp).append(nmLclLang, rhs.nmLclLang).append(brnchCd, rhs.brnchCd).append(subBrnchCd, rhs.subBrnchCd).append(brnchNm, rhs.brnchNm).append(ctryOfRes, rhs.ctryOfRes).append(mlngAdrLclLang, rhs.mlngAdrLclLang).append(pstlAdrLclLang, rhs.pstlAdrLclLang).append(ntlty, rhs.ntlty).append(acctCtryNm, rhs.acctCtryNm).append(ocptn, rhs.ocptn).append(sgmt, rhs.sgmt).append(tp, rhs.tp).append(resdncyStsCd, rhs.resdncyStsCd).append(jntId, rhs.jntId).append(frmtInd, rhs.frmtInd).append(bnfcryTmpltId, rhs.bnfcryTmpltId).append(orgId, rhs.orgId).append(prvtId, rhs.prvtId).append(pstlAdr, rhs.pstlAdr).append(ctctDtls, rhs.ctctDtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

package com.scb.s2b.api.payment.config.property;

import lombok.Data;

@Data
public class TopicProperties {

    private String region;

    private String template;

}

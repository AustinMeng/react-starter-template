
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "phneNb",
    "mobNb",
    "faxNb",
    "emailAdr"
})
public class CtctDtls {

    @JsonProperty("phneNb")
    private String phneNb;
    @JsonProperty("mobNb")
    private String mobNb;
    @JsonProperty("faxNb")
    private String faxNb;
    @JsonProperty("emailAdr")
    private String emailAdr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("phneNb")
    public String getPhneNb() {
        return phneNb;
    }

    @JsonProperty("phneNb")
    public void setPhneNb(String phneNb) {
        this.phneNb = phneNb;
    }

    public CtctDtls withPhneNb(String phneNb) {
        this.phneNb = phneNb;
        return this;
    }

    @JsonProperty("mobNb")
    public String getMobNb() {
        return mobNb;
    }

    @JsonProperty("mobNb")
    public void setMobNb(String mobNb) {
        this.mobNb = mobNb;
    }

    public CtctDtls withMobNb(String mobNb) {
        this.mobNb = mobNb;
        return this;
    }

    @JsonProperty("faxNb")
    public String getFaxNb() {
        return faxNb;
    }

    @JsonProperty("faxNb")
    public void setFaxNb(String faxNb) {
        this.faxNb = faxNb;
    }

    public CtctDtls withFaxNb(String faxNb) {
        this.faxNb = faxNb;
        return this;
    }

    @JsonProperty("emailAdr")
    public String getEmailAdr() {
        return emailAdr;
    }

    @JsonProperty("emailAdr")
    public void setEmailAdr(String emailAdr) {
        this.emailAdr = emailAdr;
    }

    public CtctDtls withEmailAdr(String emailAdr) {
        this.emailAdr = emailAdr;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CtctDtls withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(phneNb).append(mobNb).append(faxNb).append(emailAdr).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CtctDtls) == false) {
            return false;
        }
        CtctDtls rhs = ((CtctDtls) other);
        return new EqualsBuilder().append(phneNb, rhs.phneNb).append(mobNb, rhs.mobNb).append(faxNb, rhs.faxNb).append(emailAdr, rhs.emailAdr).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

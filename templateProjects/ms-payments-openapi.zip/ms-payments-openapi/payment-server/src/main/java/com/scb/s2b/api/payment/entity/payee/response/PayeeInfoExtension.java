package com.scb.s2b.api.payment.entity.payee.response;

import java.util.List;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class PayeeInfoExtension {
    private String mwp;

    private String payeeType;

    private List<String> notesToPayee = null;
}

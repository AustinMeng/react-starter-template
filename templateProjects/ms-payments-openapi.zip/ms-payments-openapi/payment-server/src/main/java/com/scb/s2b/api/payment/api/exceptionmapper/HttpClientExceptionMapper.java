package com.scb.s2b.api.payment.api.exceptionmapper;

import com.scb.s2b.api.payment.validation.HttpClientException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HttpClientExceptionMapper implements ExceptionMapper<HttpClientException> {

    @Override
    public Response toResponse(HttpClientException ex) {
        return Response
                .status(Status.BAD_REQUEST)
                .entity(ex.getErrorCode().getFullMessage(ex.getMessage()))
                .build();
    }
}

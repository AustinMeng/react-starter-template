
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "epfCntrbtnMnth",
    "epfMmbWages",
    "mplyrRegnNb",
    "mplyrHeadOffcNb",
    "mplyrPFNb",
    "mplyrCntrbtnAmt",
    "mplyrCntrbtnAmtCcy",
    "mplyeeCntrbtnAmt",
    "mplyeeCntrbtnAmtCcy",
    "mplyeeNtlId",
    "mplyeeNtlIdTp",
    "mplyeeId",
    "mplyeeOdNtlId",
    "mplyeeOdNtlIdTp",
    "mplyeeSpouseCd",
    "mplymntDt",
    "mplymntSts",
    "mplyeeCP38CntrbtnAmt",
    "mplyeeCP38CntrbtnAmtCcy",
    "ttlCP38Amt",
    "ttlCP38AmtCcy",
    "nbOfCP38Txs",
    "epfSeqNb"
})
public class EpfAndPnsnTxInf {

    @JsonProperty("epfCntrbtnMnth")
    private String epfCntrbtnMnth;
    @JsonProperty("epfMmbWages")
    private String epfMmbWages;
    @JsonProperty("mplyrRegnNb")
    private String mplyrRegnNb;
    @JsonProperty("mplyrHeadOffcNb")
    private String mplyrHeadOffcNb;
    @JsonProperty("mplyrPFNb")
    private String mplyrPFNb;
    @JsonProperty("mplyrCntrbtnAmt")
    private String mplyrCntrbtnAmt;
    @JsonProperty("mplyrCntrbtnAmtCcy")
    private String mplyrCntrbtnAmtCcy;
    @JsonProperty("mplyeeCntrbtnAmt")
    private String mplyeeCntrbtnAmt;
    @JsonProperty("mplyeeCntrbtnAmtCcy")
    private String mplyeeCntrbtnAmtCcy;
    @JsonProperty("mplyeeNtlId")
    private String mplyeeNtlId;
    @JsonProperty("mplyeeNtlIdTp")
    private String mplyeeNtlIdTp;
    @JsonProperty("mplyeeId")
    private String mplyeeId;
    @JsonProperty("mplyeeOdNtlId")
    private String mplyeeOdNtlId;
    @JsonProperty("mplyeeOdNtlIdTp")
    private String mplyeeOdNtlIdTp;
    @JsonProperty("mplyeeSpouseCd")
    private String mplyeeSpouseCd;
    @JsonProperty("mplymntDt")
    private String mplymntDt;
    @JsonProperty("mplymntSts")
    private String mplymntSts;
    @JsonProperty("mplyeeCP38CntrbtnAmt")
    private String mplyeeCP38CntrbtnAmt;
    @JsonProperty("mplyeeCP38CntrbtnAmtCcy")
    private String mplyeeCP38CntrbtnAmtCcy;
    @JsonProperty("ttlCP38Amt")
    private String ttlCP38Amt;
    @JsonProperty("ttlCP38AmtCcy")
    private String ttlCP38AmtCcy;
    @JsonProperty("nbOfCP38Txs")
    private String nbOfCP38Txs;
    @JsonProperty("epfSeqNb")
    private String epfSeqNb;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("epfCntrbtnMnth")
    public String getEpfCntrbtnMnth() {
        return epfCntrbtnMnth;
    }

    @JsonProperty("epfCntrbtnMnth")
    public void setEpfCntrbtnMnth(String epfCntrbtnMnth) {
        this.epfCntrbtnMnth = epfCntrbtnMnth;
    }

    public EpfAndPnsnTxInf withEpfCntrbtnMnth(String epfCntrbtnMnth) {
        this.epfCntrbtnMnth = epfCntrbtnMnth;
        return this;
    }

    @JsonProperty("epfMmbWages")
    public String getEpfMmbWages() {
        return epfMmbWages;
    }

    @JsonProperty("epfMmbWages")
    public void setEpfMmbWages(String epfMmbWages) {
        this.epfMmbWages = epfMmbWages;
    }

    public EpfAndPnsnTxInf withEpfMmbWages(String epfMmbWages) {
        this.epfMmbWages = epfMmbWages;
        return this;
    }

    @JsonProperty("mplyrRegnNb")
    public String getMplyrRegnNb() {
        return mplyrRegnNb;
    }

    @JsonProperty("mplyrRegnNb")
    public void setMplyrRegnNb(String mplyrRegnNb) {
        this.mplyrRegnNb = mplyrRegnNb;
    }

    public EpfAndPnsnTxInf withMplyrRegnNb(String mplyrRegnNb) {
        this.mplyrRegnNb = mplyrRegnNb;
        return this;
    }

    @JsonProperty("mplyrHeadOffcNb")
    public String getMplyrHeadOffcNb() {
        return mplyrHeadOffcNb;
    }

    @JsonProperty("mplyrHeadOffcNb")
    public void setMplyrHeadOffcNb(String mplyrHeadOffcNb) {
        this.mplyrHeadOffcNb = mplyrHeadOffcNb;
    }

    public EpfAndPnsnTxInf withMplyrHeadOffcNb(String mplyrHeadOffcNb) {
        this.mplyrHeadOffcNb = mplyrHeadOffcNb;
        return this;
    }

    @JsonProperty("mplyrPFNb")
    public String getMplyrPFNb() {
        return mplyrPFNb;
    }

    @JsonProperty("mplyrPFNb")
    public void setMplyrPFNb(String mplyrPFNb) {
        this.mplyrPFNb = mplyrPFNb;
    }

    public EpfAndPnsnTxInf withMplyrPFNb(String mplyrPFNb) {
        this.mplyrPFNb = mplyrPFNb;
        return this;
    }

    @JsonProperty("mplyrCntrbtnAmt")
    public String getMplyrCntrbtnAmt() {
        return mplyrCntrbtnAmt;
    }

    @JsonProperty("mplyrCntrbtnAmt")
    public void setMplyrCntrbtnAmt(String mplyrCntrbtnAmt) {
        this.mplyrCntrbtnAmt = mplyrCntrbtnAmt;
    }

    public EpfAndPnsnTxInf withMplyrCntrbtnAmt(String mplyrCntrbtnAmt) {
        this.mplyrCntrbtnAmt = mplyrCntrbtnAmt;
        return this;
    }

    @JsonProperty("mplyrCntrbtnAmtCcy")
    public String getMplyrCntrbtnAmtCcy() {
        return mplyrCntrbtnAmtCcy;
    }

    @JsonProperty("mplyrCntrbtnAmtCcy")
    public void setMplyrCntrbtnAmtCcy(String mplyrCntrbtnAmtCcy) {
        this.mplyrCntrbtnAmtCcy = mplyrCntrbtnAmtCcy;
    }

    public EpfAndPnsnTxInf withMplyrCntrbtnAmtCcy(String mplyrCntrbtnAmtCcy) {
        this.mplyrCntrbtnAmtCcy = mplyrCntrbtnAmtCcy;
        return this;
    }

    @JsonProperty("mplyeeCntrbtnAmt")
    public String getMplyeeCntrbtnAmt() {
        return mplyeeCntrbtnAmt;
    }

    @JsonProperty("mplyeeCntrbtnAmt")
    public void setMplyeeCntrbtnAmt(String mplyeeCntrbtnAmt) {
        this.mplyeeCntrbtnAmt = mplyeeCntrbtnAmt;
    }

    public EpfAndPnsnTxInf withMplyeeCntrbtnAmt(String mplyeeCntrbtnAmt) {
        this.mplyeeCntrbtnAmt = mplyeeCntrbtnAmt;
        return this;
    }

    @JsonProperty("mplyeeCntrbtnAmtCcy")
    public String getMplyeeCntrbtnAmtCcy() {
        return mplyeeCntrbtnAmtCcy;
    }

    @JsonProperty("mplyeeCntrbtnAmtCcy")
    public void setMplyeeCntrbtnAmtCcy(String mplyeeCntrbtnAmtCcy) {
        this.mplyeeCntrbtnAmtCcy = mplyeeCntrbtnAmtCcy;
    }

    public EpfAndPnsnTxInf withMplyeeCntrbtnAmtCcy(String mplyeeCntrbtnAmtCcy) {
        this.mplyeeCntrbtnAmtCcy = mplyeeCntrbtnAmtCcy;
        return this;
    }

    @JsonProperty("mplyeeNtlId")
    public String getMplyeeNtlId() {
        return mplyeeNtlId;
    }

    @JsonProperty("mplyeeNtlId")
    public void setMplyeeNtlId(String mplyeeNtlId) {
        this.mplyeeNtlId = mplyeeNtlId;
    }

    public EpfAndPnsnTxInf withMplyeeNtlId(String mplyeeNtlId) {
        this.mplyeeNtlId = mplyeeNtlId;
        return this;
    }

    @JsonProperty("mplyeeNtlIdTp")
    public String getMplyeeNtlIdTp() {
        return mplyeeNtlIdTp;
    }

    @JsonProperty("mplyeeNtlIdTp")
    public void setMplyeeNtlIdTp(String mplyeeNtlIdTp) {
        this.mplyeeNtlIdTp = mplyeeNtlIdTp;
    }

    public EpfAndPnsnTxInf withMplyeeNtlIdTp(String mplyeeNtlIdTp) {
        this.mplyeeNtlIdTp = mplyeeNtlIdTp;
        return this;
    }

    @JsonProperty("mplyeeId")
    public String getMplyeeId() {
        return mplyeeId;
    }

    @JsonProperty("mplyeeId")
    public void setMplyeeId(String mplyeeId) {
        this.mplyeeId = mplyeeId;
    }

    public EpfAndPnsnTxInf withMplyeeId(String mplyeeId) {
        this.mplyeeId = mplyeeId;
        return this;
    }

    @JsonProperty("mplyeeOdNtlId")
    public String getMplyeeOdNtlId() {
        return mplyeeOdNtlId;
    }

    @JsonProperty("mplyeeOdNtlId")
    public void setMplyeeOdNtlId(String mplyeeOdNtlId) {
        this.mplyeeOdNtlId = mplyeeOdNtlId;
    }

    public EpfAndPnsnTxInf withMplyeeOdNtlId(String mplyeeOdNtlId) {
        this.mplyeeOdNtlId = mplyeeOdNtlId;
        return this;
    }

    @JsonProperty("mplyeeOdNtlIdTp")
    public String getMplyeeOdNtlIdTp() {
        return mplyeeOdNtlIdTp;
    }

    @JsonProperty("mplyeeOdNtlIdTp")
    public void setMplyeeOdNtlIdTp(String mplyeeOdNtlIdTp) {
        this.mplyeeOdNtlIdTp = mplyeeOdNtlIdTp;
    }

    public EpfAndPnsnTxInf withMplyeeOdNtlIdTp(String mplyeeOdNtlIdTp) {
        this.mplyeeOdNtlIdTp = mplyeeOdNtlIdTp;
        return this;
    }

    @JsonProperty("mplyeeSpouseCd")
    public String getMplyeeSpouseCd() {
        return mplyeeSpouseCd;
    }

    @JsonProperty("mplyeeSpouseCd")
    public void setMplyeeSpouseCd(String mplyeeSpouseCd) {
        this.mplyeeSpouseCd = mplyeeSpouseCd;
    }

    public EpfAndPnsnTxInf withMplyeeSpouseCd(String mplyeeSpouseCd) {
        this.mplyeeSpouseCd = mplyeeSpouseCd;
        return this;
    }

    @JsonProperty("mplymntDt")
    public String getMplymntDt() {
        return mplymntDt;
    }

    @JsonProperty("mplymntDt")
    public void setMplymntDt(String mplymntDt) {
        this.mplymntDt = mplymntDt;
    }

    public EpfAndPnsnTxInf withMplymntDt(String mplymntDt) {
        this.mplymntDt = mplymntDt;
        return this;
    }

    @JsonProperty("mplymntSts")
    public String getMplymntSts() {
        return mplymntSts;
    }

    @JsonProperty("mplymntSts")
    public void setMplymntSts(String mplymntSts) {
        this.mplymntSts = mplymntSts;
    }

    public EpfAndPnsnTxInf withMplymntSts(String mplymntSts) {
        this.mplymntSts = mplymntSts;
        return this;
    }

    @JsonProperty("mplyeeCP38CntrbtnAmt")
    public String getMplyeeCP38CntrbtnAmt() {
        return mplyeeCP38CntrbtnAmt;
    }

    @JsonProperty("mplyeeCP38CntrbtnAmt")
    public void setMplyeeCP38CntrbtnAmt(String mplyeeCP38CntrbtnAmt) {
        this.mplyeeCP38CntrbtnAmt = mplyeeCP38CntrbtnAmt;
    }

    public EpfAndPnsnTxInf withMplyeeCP38CntrbtnAmt(String mplyeeCP38CntrbtnAmt) {
        this.mplyeeCP38CntrbtnAmt = mplyeeCP38CntrbtnAmt;
        return this;
    }

    @JsonProperty("mplyeeCP38CntrbtnAmtCcy")
    public String getMplyeeCP38CntrbtnAmtCcy() {
        return mplyeeCP38CntrbtnAmtCcy;
    }

    @JsonProperty("mplyeeCP38CntrbtnAmtCcy")
    public void setMplyeeCP38CntrbtnAmtCcy(String mplyeeCP38CntrbtnAmtCcy) {
        this.mplyeeCP38CntrbtnAmtCcy = mplyeeCP38CntrbtnAmtCcy;
    }

    public EpfAndPnsnTxInf withMplyeeCP38CntrbtnAmtCcy(String mplyeeCP38CntrbtnAmtCcy) {
        this.mplyeeCP38CntrbtnAmtCcy = mplyeeCP38CntrbtnAmtCcy;
        return this;
    }

    @JsonProperty("ttlCP38Amt")
    public String getTtlCP38Amt() {
        return ttlCP38Amt;
    }

    @JsonProperty("ttlCP38Amt")
    public void setTtlCP38Amt(String ttlCP38Amt) {
        this.ttlCP38Amt = ttlCP38Amt;
    }

    public EpfAndPnsnTxInf withTtlCP38Amt(String ttlCP38Amt) {
        this.ttlCP38Amt = ttlCP38Amt;
        return this;
    }

    @JsonProperty("ttlCP38AmtCcy")
    public String getTtlCP38AmtCcy() {
        return ttlCP38AmtCcy;
    }

    @JsonProperty("ttlCP38AmtCcy")
    public void setTtlCP38AmtCcy(String ttlCP38AmtCcy) {
        this.ttlCP38AmtCcy = ttlCP38AmtCcy;
    }

    public EpfAndPnsnTxInf withTtlCP38AmtCcy(String ttlCP38AmtCcy) {
        this.ttlCP38AmtCcy = ttlCP38AmtCcy;
        return this;
    }

    @JsonProperty("nbOfCP38Txs")
    public String getNbOfCP38Txs() {
        return nbOfCP38Txs;
    }

    @JsonProperty("nbOfCP38Txs")
    public void setNbOfCP38Txs(String nbOfCP38Txs) {
        this.nbOfCP38Txs = nbOfCP38Txs;
    }

    public EpfAndPnsnTxInf withNbOfCP38Txs(String nbOfCP38Txs) {
        this.nbOfCP38Txs = nbOfCP38Txs;
        return this;
    }

    @JsonProperty("epfSeqNb")
    public String getEpfSeqNb() {
        return epfSeqNb;
    }

    @JsonProperty("epfSeqNb")
    public void setEpfSeqNb(String epfSeqNb) {
        this.epfSeqNb = epfSeqNb;
    }

    public EpfAndPnsnTxInf withEpfSeqNb(String epfSeqNb) {
        this.epfSeqNb = epfSeqNb;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EpfAndPnsnTxInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(epfCntrbtnMnth).append(epfMmbWages).append(mplyrRegnNb).append(mplyrHeadOffcNb).append(mplyrPFNb).append(mplyrCntrbtnAmt).append(mplyrCntrbtnAmtCcy).append(mplyeeCntrbtnAmt).append(mplyeeCntrbtnAmtCcy).append(mplyeeNtlId).append(mplyeeNtlIdTp).append(mplyeeId).append(mplyeeOdNtlId).append(mplyeeOdNtlIdTp).append(mplyeeSpouseCd).append(mplymntDt).append(mplymntSts).append(mplyeeCP38CntrbtnAmt).append(mplyeeCP38CntrbtnAmtCcy).append(ttlCP38Amt).append(ttlCP38AmtCcy).append(nbOfCP38Txs).append(epfSeqNb).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EpfAndPnsnTxInf) == false) {
            return false;
        }
        EpfAndPnsnTxInf rhs = ((EpfAndPnsnTxInf) other);
        return new EqualsBuilder().append(epfCntrbtnMnth, rhs.epfCntrbtnMnth).append(epfMmbWages, rhs.epfMmbWages).append(mplyrRegnNb, rhs.mplyrRegnNb).append(mplyrHeadOffcNb, rhs.mplyrHeadOffcNb).append(mplyrPFNb, rhs.mplyrPFNb).append(mplyrCntrbtnAmt, rhs.mplyrCntrbtnAmt).append(mplyrCntrbtnAmtCcy, rhs.mplyrCntrbtnAmtCcy).append(mplyeeCntrbtnAmt, rhs.mplyeeCntrbtnAmt).append(mplyeeCntrbtnAmtCcy, rhs.mplyeeCntrbtnAmtCcy).append(mplyeeNtlId, rhs.mplyeeNtlId).append(mplyeeNtlIdTp, rhs.mplyeeNtlIdTp).append(mplyeeId, rhs.mplyeeId).append(mplyeeOdNtlId, rhs.mplyeeOdNtlId).append(mplyeeOdNtlIdTp, rhs.mplyeeOdNtlIdTp).append(mplyeeSpouseCd, rhs.mplyeeSpouseCd).append(mplymntDt, rhs.mplymntDt).append(mplymntSts, rhs.mplymntSts).append(mplyeeCP38CntrbtnAmt, rhs.mplyeeCP38CntrbtnAmt).append(mplyeeCP38CntrbtnAmtCcy, rhs.mplyeeCP38CntrbtnAmtCcy).append(ttlCP38Amt, rhs.ttlCP38Amt).append(ttlCP38AmtCcy, rhs.ttlCP38AmtCcy).append(nbOfCP38Txs, rhs.nbOfCP38Txs).append(epfSeqNb, rhs.epfSeqNb).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

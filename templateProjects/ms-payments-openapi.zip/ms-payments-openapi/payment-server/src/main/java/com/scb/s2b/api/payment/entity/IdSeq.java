package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IdSeq {

    private String groupId;

    private String paymentType;

    private Long seqRange;

}

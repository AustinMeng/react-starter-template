package com.scb.s2b.api.payment.api;

import static com.scb.s2b.api.payment.validation.ValidationErrorCode.AER_1006;
import static com.scb.s2b.api.payment.validation.ValidationErrorCode.throwValidationException;

import com.scb.s2b.api.payment.config.PaymentConstant;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.HttpHeaders;
import org.apache.commons.lang3.StringUtils;

public abstract class ApiBase {

    public String validateGroupId(HttpHeaders headers) {
        String groupId = headers.getHeaderString(PaymentConstant.GROUP_ID_HEADER);
        if (StringUtils.isBlank(groupId)) {
            throwValidationException(AER_1006);
        }

        return groupId;
    }

    public Map<String, String> getHeaders(HttpHeaders headers) {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put(PaymentConstant.TPP_ID, headers.getHeaderString(PaymentConstant.TPP_ID));
        headerMap.put(PaymentConstant.TPP_GROUP_ID, headers.getHeaderString(PaymentConstant.TPP_GROUP_ID));
        headerMap.put(PaymentConstant.CONSENT_ID, headers.getHeaderString(PaymentConstant.CONSENT_ID));
        headerMap.put(PaymentConstant.GROUP_ID_HEADER, headers.getHeaderString(PaymentConstant.GROUP_ID_HEADER));
        headerMap.put(PaymentConstant.CORRELATION_ID_HEADER,
                headers.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER));

        return headerMap;
    }
}


package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.data;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instrPrty",
    "reqdPmtTp",
    "reqdSubPmtTp",
    "pmtTp",
    "subPmtTp",
    "pmtTpDrvdInd"
})
public class PmtTpInf {

    @JsonProperty("instrPrty")
    private String instrPrty;
    @JsonProperty("reqdPmtTp")
    private String reqdPmtTp;
    @JsonProperty("reqdSubPmtTp")
    private String reqdSubPmtTp;
    @JsonProperty("pmtTp")
    private String pmtTp;
    @JsonProperty("subPmtTp")
    private String subPmtTp;
    @JsonProperty("pmtTpDrvdInd")
    private String pmtTpDrvdInd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instrPrty")
    public String getInstrPrty() {
        return instrPrty;
    }

    @JsonProperty("instrPrty")
    public void setInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
    }

    public PmtTpInf withInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
        return this;
    }

    @JsonProperty("reqdPmtTp")
    public String getReqdPmtTp() {
        return reqdPmtTp;
    }

    @JsonProperty("reqdPmtTp")
    public void setReqdPmtTp(String reqdPmtTp) {
        this.reqdPmtTp = reqdPmtTp;
    }

    public PmtTpInf withReqdPmtTp(String reqdPmtTp) {
        this.reqdPmtTp = reqdPmtTp;
        return this;
    }

    @JsonProperty("reqdSubPmtTp")
    public String getReqdSubPmtTp() {
        return reqdSubPmtTp;
    }

    @JsonProperty("reqdSubPmtTp")
    public void setReqdSubPmtTp(String reqdSubPmtTp) {
        this.reqdSubPmtTp = reqdSubPmtTp;
    }

    public PmtTpInf withReqdSubPmtTp(String reqdSubPmtTp) {
        this.reqdSubPmtTp = reqdSubPmtTp;
        return this;
    }

    @JsonProperty("pmtTp")
    public String getPmtTp() {
        return pmtTp;
    }

    @JsonProperty("pmtTp")
    public void setPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
    }

    public PmtTpInf withPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
        return this;
    }

    @JsonProperty("subPmtTp")
    public String getSubPmtTp() {
        return subPmtTp;
    }

    @JsonProperty("subPmtTp")
    public void setSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
    }

    public PmtTpInf withSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
        return this;
    }

    @JsonProperty("pmtTpDrvdInd")
    public String getPmtTpDrvdInd() {
        return pmtTpDrvdInd;
    }

    @JsonProperty("pmtTpDrvdInd")
    public void setPmtTpDrvdInd(String pmtTpDrvdInd) {
        this.pmtTpDrvdInd = pmtTpDrvdInd;
    }

    public PmtTpInf withPmtTpDrvdInd(String pmtTpDrvdInd) {
        this.pmtTpDrvdInd = pmtTpDrvdInd;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PmtTpInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instrPrty).append(reqdPmtTp).append(reqdSubPmtTp).append(pmtTp).append(subPmtTp).append(pmtTpDrvdInd).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PmtTpInf) == false) {
            return false;
        }
        PmtTpInf rhs = ((PmtTpInf) other);
        return new EqualsBuilder().append(instrPrty, rhs.instrPrty).append(reqdPmtTp, rhs.reqdPmtTp).append(reqdSubPmtTp, rhs.reqdSubPmtTp).append(pmtTp, rhs.pmtTp).append(subPmtTp, rhs.subPmtTp).append(pmtTpDrvdInd, rhs.pmtTpDrvdInd).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

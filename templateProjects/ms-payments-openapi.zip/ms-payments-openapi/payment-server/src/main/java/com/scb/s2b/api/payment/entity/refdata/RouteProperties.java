package com.scb.s2b.api.payment.entity.refdata;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RouteProperties implements Serializable {

    public static final RouteProperties DEFAULT = new RouteProperties();

    private String defaultPath;
    private Set<RouteProperty> routes = new HashSet<>();
}

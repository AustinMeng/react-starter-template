package com.scb.s2b.api.payment.entity.refdata;

import java.io.Serializable;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class StatusProperties implements Serializable {
    private Integer maxRetry;
    private GroupFilterProperties groupFilter;
}

package com.scb.s2b.api.payment.entity;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstructionHeader;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Builder
@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
public class CcsPaymentInstructionHeader extends OpenApiPaymentInstructionHeader {

}

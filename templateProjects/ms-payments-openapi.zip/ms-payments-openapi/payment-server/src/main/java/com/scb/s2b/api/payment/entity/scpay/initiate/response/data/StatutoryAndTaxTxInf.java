
package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "taxOrgCd",
    "cdtrOrgCd",
    "taxNb",
    "taxCd",
    "taxRgnCd",
    "lookupRef",
    "lookupReqId",
    "pmtDesc",
    "pyerNm"
})
public class StatutoryAndTaxTxInf {

    @JsonProperty("taxOrgCd")
    private String taxOrgCd;
    @JsonProperty("cdtrOrgCd")
    private String cdtrOrgCd;
    @JsonProperty("taxNb")
    private String taxNb;
    @JsonProperty("taxCd")
    private String taxCd;
    @JsonProperty("taxRgnCd")
    private String taxRgnCd;
    @JsonProperty("lookupRef")
    private String lookupRef;
    @JsonProperty("lookupReqId")
    private String lookupReqId;
    @JsonProperty("pmtDesc")
    private String pmtDesc;
    @JsonProperty("pyerNm")
    private String pyerNm;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("taxOrgCd")
    public String getTaxOrgCd() {
        return taxOrgCd;
    }

    @JsonProperty("taxOrgCd")
    public void setTaxOrgCd(String taxOrgCd) {
        this.taxOrgCd = taxOrgCd;
    }

    public StatutoryAndTaxTxInf withTaxOrgCd(String taxOrgCd) {
        this.taxOrgCd = taxOrgCd;
        return this;
    }

    @JsonProperty("cdtrOrgCd")
    public String getCdtrOrgCd() {
        return cdtrOrgCd;
    }

    @JsonProperty("cdtrOrgCd")
    public void setCdtrOrgCd(String cdtrOrgCd) {
        this.cdtrOrgCd = cdtrOrgCd;
    }

    public StatutoryAndTaxTxInf withCdtrOrgCd(String cdtrOrgCd) {
        this.cdtrOrgCd = cdtrOrgCd;
        return this;
    }

    @JsonProperty("taxNb")
    public String getTaxNb() {
        return taxNb;
    }

    @JsonProperty("taxNb")
    public void setTaxNb(String taxNb) {
        this.taxNb = taxNb;
    }

    public StatutoryAndTaxTxInf withTaxNb(String taxNb) {
        this.taxNb = taxNb;
        return this;
    }

    @JsonProperty("taxCd")
    public String getTaxCd() {
        return taxCd;
    }

    @JsonProperty("taxCd")
    public void setTaxCd(String taxCd) {
        this.taxCd = taxCd;
    }

    public StatutoryAndTaxTxInf withTaxCd(String taxCd) {
        this.taxCd = taxCd;
        return this;
    }

    @JsonProperty("taxRgnCd")
    public String getTaxRgnCd() {
        return taxRgnCd;
    }

    @JsonProperty("taxRgnCd")
    public void setTaxRgnCd(String taxRgnCd) {
        this.taxRgnCd = taxRgnCd;
    }

    public StatutoryAndTaxTxInf withTaxRgnCd(String taxRgnCd) {
        this.taxRgnCd = taxRgnCd;
        return this;
    }

    @JsonProperty("lookupRef")
    public String getLookupRef() {
        return lookupRef;
    }

    @JsonProperty("lookupRef")
    public void setLookupRef(String lookupRef) {
        this.lookupRef = lookupRef;
    }

    public StatutoryAndTaxTxInf withLookupRef(String lookupRef) {
        this.lookupRef = lookupRef;
        return this;
    }

    @JsonProperty("lookupReqId")
    public String getLookupReqId() {
        return lookupReqId;
    }

    @JsonProperty("lookupReqId")
    public void setLookupReqId(String lookupReqId) {
        this.lookupReqId = lookupReqId;
    }

    public StatutoryAndTaxTxInf withLookupReqId(String lookupReqId) {
        this.lookupReqId = lookupReqId;
        return this;
    }

    @JsonProperty("pmtDesc")
    public String getPmtDesc() {
        return pmtDesc;
    }

    @JsonProperty("pmtDesc")
    public void setPmtDesc(String pmtDesc) {
        this.pmtDesc = pmtDesc;
    }

    public StatutoryAndTaxTxInf withPmtDesc(String pmtDesc) {
        this.pmtDesc = pmtDesc;
        return this;
    }

    @JsonProperty("pyerNm")
    public String getPyerNm() {
        return pyerNm;
    }

    @JsonProperty("pyerNm")
    public void setPyerNm(String pyerNm) {
        this.pyerNm = pyerNm;
    }

    public StatutoryAndTaxTxInf withPyerNm(String pyerNm) {
        this.pyerNm = pyerNm;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public StatutoryAndTaxTxInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(taxOrgCd).append(cdtrOrgCd).append(taxNb).append(taxCd).append(taxRgnCd).append(lookupRef).append(lookupReqId).append(pmtDesc).append(pyerNm).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StatutoryAndTaxTxInf) == false) {
            return false;
        }
        StatutoryAndTaxTxInf rhs = ((StatutoryAndTaxTxInf) other);
        return new EqualsBuilder().append(taxOrgCd, rhs.taxOrgCd).append(cdtrOrgCd, rhs.cdtrOrgCd).append(taxNb, rhs.taxNb).append(taxCd, rhs.taxCd).append(taxRgnCd, rhs.taxRgnCd).append(lookupRef, rhs.lookupRef).append(lookupReqId, rhs.lookupReqId).append(pmtDesc, rhs.pmtDesc).append(pyerNm, rhs.pyerNm).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

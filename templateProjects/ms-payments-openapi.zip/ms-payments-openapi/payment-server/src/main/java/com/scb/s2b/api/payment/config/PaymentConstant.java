package com.scb.s2b.api.payment.config;

public interface PaymentConstant {

    String SYSTEM = "SYSTEM";
    String SCHEME = "OPENAPI";
    String CHANNEL = "API";
    String CCS = "CCSAgent";
    String SCPAY = "SCPay";
    String TPP = "TPP";

    String INDIA = "IN";
    String PHILIPPINE = "PH";
    String HK = "HK";
    String SG = "SG";

    String PROXY_LOOKUP_META_COUNTRY_CODE = "country_code";

    String GROUP_ID_HEADER = "GroupId";
    String CORRELATION_ID_HEADER = "CorrelationId";
    String TPP_ID = "TppId";
    String TPP_GROUP_ID = "TppGroupId";
    String CONSENT_ID = "ConsentId";
    String PRE_VERIFIED = "PreVerified";

    String KAFKA_RETRY_HEADER = "Payment.Retry";
    String KAFKA_SUSPEND_TO_HEADER = "Payment.SuspendTo";

    String BENEFICIARY_PAYMENT_TYPE = "BENQ";
    String PROXY_LOOKUP_PAYMENT_TYPE = "PRXYQ";
    String PROXY_LOOKUP_SUCCESS = "ACTC";
    String PROXY_LOOKUP_SUCCESS_ACCT = "ACCT";
    String PAYMENT_TYPE_CODE_TT = "TT";
    String PAYMENT_TYPE_CODE_ACH = "ACH";
    String PAYMENT_TYPE_CODE_RTGS = "RTGS";

    String ENTITY_TYPE_SCPAY_PAY_REQ = "scpay-pmt-req";
    String ENTITY_TYPE_SCPAY_BENE_REQ = "scpay-bene-req";
    String ENTITY_TYPE_SCPAY_PRXY_REQ = "scpay-prxy-req";
    String ENTITY_TYPE_SCPAY_PAY_ACK = "scpay-pmt-ack";
    String ENTITY_TYPE_SCPAY_BENE_ACK = "scpay-bene-ack";
    String ENTITY_TYPE_SCPAY_PRXY_ACK = "scpay-prxy-ack";
    String ENTITY_TYPE_CCS_PAY_REQ = "ccs-pmt-req";
    String ENTITY_TYPE_CCS_PAY_ACK = "ccs-pmt-ack";
    String ENTITY_TYPE_NOTIFICATION_REQ = "notify-req";
    String ENTITY_TYPE_NOTIFICATION_ACK = "notify-ack";

    String CCS_RESPONSE_TYPE_DUP = "DUPL";
    String CCS_RESPONSE_TYPE_ACK = "ACK3";
    String CCS_RESPONSE_TYPE_REJ = "REJ3";

    String CCS_INBOUND_NOUN = "PAYMENTS";
    String CCS_INBOUND_FORMAT = "JSON-PAYMENTS";
    String CCS_CALLBACK_ENDPOINT_HEADER = "CCSCallbackEndpoint";

    String IDENTITY_TYPE_MMID = "MMID";
    String IDENTITY_TYPE_RETMSISDN = "RetMSISDN";
    String PAY_TO_ACCOUNT_IN = "PTAVI";
    String PAY_TO_PROXY_IN = "PTMVI";
    String PAY_TO_ACCOUNT = "PTA";

    String API_PENDING_STATUS = "0";
    String CCS_PENDING_STATUS = "2";
    String API_REJECTED_STATUS = "10";
    String PROXY_LOOKUP_REJECTED_STATUS = "11";
    String CCS_REJECTED_STATUS = "12";
    String BENE_SUCCESS_STATUS = "101";
    String BENE_FAILED_STATUS = "102";
    String BENE_RESEND_STATUS = "103";

    String PROXY_LOOKUP_HK_ID_ELIGIBLE_FLAG = "Y";
    String IDENTITY_TYPE_TH = "C";
}

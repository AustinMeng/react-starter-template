package com.scb.s2b.api.payment.camel;

import static com.scb.s2b.api.payment.config.PaymentConstant.ENTITY_TYPE_CCS_PAY_ACK;

import static com.scb.s2b.api.payment.util.AdapterUtil.getHeader;
import static com.scb.s2b.api.payment.util.AdapterUtil.isDupException;

import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.payment.config.PaymentConstant;
import com.scb.s2b.api.payment.config.property.NotificationProperties;
import com.scb.s2b.api.payment.entity.BranchAndInstituteHeader;
import com.scb.s2b.api.payment.entity.CcsResponse;
import com.scb.s2b.api.payment.entity.CreditTransferTransaction;
import com.scb.s2b.api.payment.entity.PaymentSystem;
import com.scb.s2b.api.payment.entity.PaymentTransaction;
import com.scb.s2b.api.payment.entity.refdata.CcsRespProperties;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.service.CCSStatusService;
import com.scb.s2b.api.payment.service.MaintenanceService;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.service.PaymentStatusService;
import com.scb.s2b.api.payment.service.ReferenceDataService;
import com.scb.s2b.api.payment.util.IdGenerator;
import com.scb.s2b.api.payment.util.KafkaUtil;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang.StringUtils;
import org.bouncycastle.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KafkaConsumerAdapter {

    private final long retryInterval;

    private final int maxRetry;

    private final String paymentInitiateRetryEndpoint;

    private final String paymentInitiateEndpoint;

    private final PaymentService paymentService;

    private final PaymentStatusService paymentStatusService;

    private final JsonMessageMarshaller jsonMessageMarshaller;

    private final ProducerTemplate producer;

    private final MaintenanceService maintenanceService;

    private final NotificationProperties notificationProperties;

    private final IdGenerator idGenerator;

    private final CCSStatusService ccsStatusService;

    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerAdapter.class);

    private final ReferenceDataService referenceDataService;

    public KafkaConsumerAdapter(long retryInterval, int maxRetry, String paymentInitiateRetryEndpoint,
            String paymentInitiateEndpoint, PaymentService paymentService,
            PaymentStatusService paymentStatusService,
            JsonMessageMarshaller jsonMessageMarshaller, ProducerTemplate producer,
            MaintenanceService maintenanceService,
            NotificationProperties notificationProperties, IdGenerator idGenerator,
            CCSStatusService ccsStatusService, ReferenceDataService referenceDataService) {
        this.retryInterval = retryInterval;
        this.maxRetry = maxRetry;
        this.paymentInitiateRetryEndpoint = paymentInitiateRetryEndpoint;
        this.paymentInitiateEndpoint = paymentInitiateEndpoint;
        this.paymentService = paymentService;
        this.paymentStatusService = paymentStatusService;
        this.jsonMessageMarshaller = jsonMessageMarshaller;
        this.producer = producer;
        this.maintenanceService = maintenanceService;
        this.notificationProperties = notificationProperties;
        this.idGenerator = idGenerator;
        this.ccsStatusService = ccsStatusService;
        this.referenceDataService = referenceDataService;
    }

    public void consumeSuspendedTransaction(PaymentTransaction paymentTransaction) {
        logger.info("Processing suspended payment transaction {}.", paymentTransaction.getClientReferenceId());
        this.publishPaymentTransactionToEndpoint(paymentInitiateEndpoint, paymentTransaction, null);
        logger.info("Processing suspended payment transaction {} done.", paymentTransaction.getClientReferenceId());
    }

    public void dispatchPaymentTransaction(PaymentTransaction paymentTransaction, Map<String, Object> headers) {
        int retry = getHeader(headers, PaymentConstant.KAFKA_RETRY_HEADER, Integer::parseInt, 0);
        logger.info("Dispatching payment transaction requestId={}, groupId={}, referenceId={} retry = {}",
                paymentTransaction.getRequestId(),
                paymentTransaction.getGroupId(),
                paymentTransaction.getClientReferenceId(),
                retry);
        this.publishPaymentTransaction(paymentTransaction, retry);
    }

    public void consumePaymentTransactionRetry(PaymentTransaction paymentTransaction, Map<String, Object> headers) {
        int retry = getHeader(headers, PaymentConstant.KAFKA_RETRY_HEADER, Integer::parseInt, 0);
        logger.info("Consuming PaymentTransactionRetry requestId={}, groupId={}, clientReferenceId={}, retry={}",
                paymentTransaction.getRequestId(),
                paymentTransaction.getGroupId(),
                paymentTransaction.getClientReferenceId(),
                retry);

        this.publishPaymentTransactionToEndpoint(paymentInitiateEndpoint, paymentTransaction, headers);

        logger.info("PaymentInitiateRetry committed requestId={}, groupId={}, clientReferenceId={}, retry={}",
                paymentTransaction.getRequestId(), paymentTransaction.getGroupId(),
                paymentTransaction.getClientReferenceId(), retry);
    }

    public Long calculateDelay(Map<String, Object> headers) {
        try {
            long now = System.currentTimeMillis();
            long suspendTo = getHeader(headers, PaymentConstant.KAFKA_SUSPEND_TO_HEADER, Long::parseLong, now);
            return suspendTo > now ? suspendTo - now : 0;
        } catch (NumberFormatException ex) {
            return retryInterval;
        }
    }

    String getSuspendQueueEndPoint(PaymentTransaction paymentTransaction) {
        // check countries
        Set<String> countries = maintenanceService.getSuspendedCountries();
        String country = Strings.toUpperCase(Optional.ofNullable(paymentTransaction.getCountryCode()).orElse(
                StringUtils.EMPTY));
        if (countries.contains(country)) {
            return maintenanceService
                    .getQueueEndPoint(notificationProperties.getSignOnOff().getSuspendQueueTemplate(), country);
        }

        // bicfis
        Set<String> bicfis = Stream.concat(
                Stream.of(paymentTransaction.getDebtorAgent().getBicfi()),
                paymentTransaction.getCreditTransferTransactions().stream()
                        .map(CreditTransferTransaction::getCreditorAgent)
                        .map(BranchAndInstituteHeader::getBicfi)
        )
                .collect(Collectors.toSet());

        // Bank status broadcast
        Set<String> bankStatusBroadcastBicCode = maintenanceService.getBankStatusBroadcastSuspendedBicCodes();

        // Bank status broadcast for ph 960
        Set<String> bankStatusBroadcastForPHBicCode = maintenanceService.getBankStatusBroadcastForPHSuspendedBicCodes();

        // Bank default broadcast
        Set<String> bankDefaultBroadcastBicCode = maintenanceService.getBankDefaultBroadcastSuspendedBicCodes();

        for (String bicfi : bicfis) {
            if (bankStatusBroadcastBicCode.contains(bicfi)) {
                String template = notificationProperties.getBankStatusBroadcast().getSuspendQueueTemplate();
                return maintenanceService.getQueueEndPoint(template, bicfi);
            }

            if (bankStatusBroadcastForPHBicCode.contains(bicfi)) {
                String template = notificationProperties.getBankStatusBroadcastPH().getSuspendQueueTemplate();
                return maintenanceService.getQueueEndPoint(template, bicfi);
            }

            if (bankDefaultBroadcastBicCode.contains(bicfi)) {
                String template = notificationProperties.getBankDefaultBroadcast().getSuspendQueueTemplate();
                return maintenanceService.getQueueEndPoint(template, bicfi);
            }
        }

        // System status broadcast
        if (maintenanceService.getSystemStatusBroadcastG3SuspendStatus() && maintenanceService
                .isG3Payment(paymentTransaction)) {
            String template = notificationProperties.getSystemStatusBroadcast().getSuspendQueueTemplate();
            return maintenanceService.getQueueEndPoint(template);
        }
        return null;
    }

    private void doSwitchToSuspendRoute(String endpoint, PaymentTransaction paymentTransaction) {
        String groupId = paymentTransaction.getGroupId();
        String messageId = paymentTransaction.getMessageId();
        String referenceId = paymentTransaction.getClientReferenceId();
        logger.info("Switching payment transaction groupId={}, messageId={}, referenceId={} to endpoint={}", groupId,
                messageId,
                referenceId, endpoint);
        this.publishPaymentTransactionToEndpoint(endpoint, paymentTransaction, null);
    }

    public void publishPaymentTransaction(PaymentTransaction paymentTransaction, int retry) {
        try {
            if (paymentTransaction.getPaymentSystem() == PaymentSystem.SCPAY) {
                String suspendQueueEndPoint = this.getSuspendQueueEndPoint(paymentTransaction);
                if (StringUtils.isNotBlank(suspendQueueEndPoint)) {
                    doSwitchToSuspendRoute(suspendQueueEndPoint, paymentTransaction);
                } else {
                    if (paymentTransaction.isBeneEnquiryRequired() && !paymentTransaction.isBeneEnquiryDone()) {
                        paymentTransaction.setBeneEnquiry(true);
                    } else if (paymentTransaction.isProxyEnquiryRequired() && !paymentTransaction.isProxyEnquiryDone()) {
                        paymentTransaction.setProxyEnquiry(true);
                    }
                    paymentService.publishPaymentTransactionToScpay(paymentTransaction, retry);
                }
            }
        } catch (Throwable ex) {
            logger.error(ex.getMessage(), ex);
            if (isDupException(ex)) {
                logger.warn("Ignore duplicated PaymentTransaction groupId={}, referenceId={}, retry={}",
                        paymentTransaction.getGroupId(), paymentTransaction.getClientReferenceId(), retry);
            } else {
                if (retry >= maxRetry) {
                    logger.info("Rejecting PaymentTransaction groupId={}, referenceId={}, retry={}",
                            paymentTransaction.getGroupId(), paymentTransaction.getClientReferenceId(), retry);

                    paymentService.rejectPaymentTransaction(paymentTransaction);
                } else {
                    this.retryPaymentTransaction(paymentTransaction, ++retry);
                }
            }
        }
    }

    public void consumeCCSPaymentTransaction(CCSAgentOutboundIns ccsAgentOutboundIns) {
        String messageId = idGenerator.messageId();
        logger.info("Consuming CCSAgentOutboundIns fileName={}, groupId={}, umi={}, messageId={}",
                ccsAgentOutboundIns.getFilename(),
                ccsAgentOutboundIns.getGroupId(),
                ccsAgentOutboundIns.getUmi(),
                messageId);

        try {
            if (ccsStatusService.checkPaymentByCCSFileName(ccsAgentOutboundIns.getFilename())) {
                paymentStatusService
                        .persistPaymentMessage(jsonMessageMarshaller.marshallToJsonString(ccsAgentOutboundIns),
                                ENTITY_TYPE_CCS_PAY_ACK, messageId);
                ccsStatusService.processCCSPaymentTransactionResponse(messageId, ccsAgentOutboundIns);
            } else {
                logger.info("No Payment found for ccs payment transaction umi={}, fileName={}",
                        ccsAgentOutboundIns.getUmi(),
                        ccsAgentOutboundIns.getFilename());
            }
        } catch (Throwable ex) {
            logger.error("Error processing CCS PaymentStatus", ex);
        }
        logger.info("CCSAgentOutboundIns committed umi={}, groupId={}, fileName={}, messageId={}",
                ccsAgentOutboundIns.getUmi(), ccsAgentOutboundIns.getGroupId(), ccsAgentOutboundIns.getFilename(),
                messageId);
    }

    public void consumeBanstaReport(CCSAgentOutboundIns ccsAgentOutboundIns) {
        String messageId = idGenerator.messageId();
        logger.info("Consuming banstaReport fileName={}, groupId={}, umi={}, messageId={}",
                ccsAgentOutboundIns.getFilename(),
                ccsAgentOutboundIns.getGroupId(),
                ccsAgentOutboundIns.getUmi(),
                messageId);

        try {
            if (shouldProcess(CcsResponse.BANSTA, ccsAgentOutboundIns)) {
                paymentStatusService
                        .persistPaymentMessage(jsonMessageMarshaller.marshallToJsonString(ccsAgentOutboundIns),
                                CcsResponse.BANSTA.getType(), messageId);
                ccsStatusService.processBanstaReport(messageId, ccsAgentOutboundIns);
            } else {
                logger.info("This message should not be processed, the umi is {}, format is {}, groupId is {}",
                        ccsAgentOutboundIns.getUmi(),
                        ccsAgentOutboundIns.getFormat(),
                        ccsAgentOutboundIns.getGroupId());
            }
        } catch (Throwable ex) {
            logger.error("Error processing banstaReport", ex);
        }
        logger.info("BanstaReport committed umi={}, groupId={}, fileName={}, messageId={}",
                ccsAgentOutboundIns.getUmi(), ccsAgentOutboundIns.getGroupId(), ccsAgentOutboundIns.getFilename(),
                messageId);
    }

    public void consumeCcsPaymentResponse(CCSAgentOutboundIns ccsAgentOutboundIns) {
        String messageId = idGenerator.messageId();
        logger.info("Consuming ccs payment response fileName={}, groupId={}, umi={}, messageId={}",
                ccsAgentOutboundIns.getFilename(),
                ccsAgentOutboundIns.getGroupId(),
                ccsAgentOutboundIns.getUmi(),
                messageId);

        try {
            if (shouldProcess(CcsResponse.CCSRESP, ccsAgentOutboundIns)) {
                paymentStatusService
                        .persistPaymentMessage(jsonMessageMarshaller.marshallToJsonString(ccsAgentOutboundIns),
                                CcsResponse.CCSRESP.getType(), messageId);
                ccsStatusService.processCcsPaymentResponse(messageId, ccsAgentOutboundIns);
            } else {
                logger.info("This message should not be processed, the umi is {}, format is {}, groupId is {}",
                        ccsAgentOutboundIns.getUmi(),
                        ccsAgentOutboundIns.getFormat(),
                        ccsAgentOutboundIns.getGroupId());
            }
        } catch (Throwable ex) {
            logger.error("Error processing ccs payment response", ex);
        }
        logger.info("CcsPaymentResponse committed umi={}, groupId={}, fileName={}, messageId={}",
                ccsAgentOutboundIns.getUmi(), ccsAgentOutboundIns.getGroupId(), ccsAgentOutboundIns.getFilename(),
                messageId);
    }

    boolean shouldProcess(CcsResponse ccsResponse, CCSAgentOutboundIns ccsAgentOutboundIns) {
        String defaultSource = Optional.ofNullable(referenceDataService.getCcsRespProperties())
                .map(CcsRespProperties::getDefaultSource)
                .orElse(CcsResponse.CCSRESP.name());
        String groupSource = Optional.ofNullable(referenceDataService.getCcsRespProperties())
                .map(CcsRespProperties::getGroupSources)
                .map(gs -> gs.get(ccsAgentOutboundIns.getGroupId()))
                .orElse(defaultSource);
        return ccsResponse.getFormat().equals(ccsAgentOutboundIns.getFormat()) &&
                ccsResponse.name().equals(groupSource);
    }

    private void retryPaymentTransaction(PaymentTransaction paymentTransaction, int retry) {
        Map<String, Object> headers = ImmutableMap.of(
                PaymentConstant.KAFKA_SUSPEND_TO_HEADER, String.valueOf(System.currentTimeMillis() + retryInterval),
                PaymentConstant.KAFKA_RETRY_HEADER, String.valueOf(retry)
        );
        this.publishPaymentTransactionToEndpoint(paymentInitiateRetryEndpoint, paymentTransaction, headers);
    }

    void publishPaymentTransactionToEndpoint(String endpoint, PaymentTransaction paymentTransaction,
            Map<String, Object> headers) {
        KafkaUtil.sendToKafka(producer,
                endpoint,
                paymentTransaction,
                paymentTransaction::getGroupId,
                paymentTransaction::getMessageId,
                headers);
    }
}

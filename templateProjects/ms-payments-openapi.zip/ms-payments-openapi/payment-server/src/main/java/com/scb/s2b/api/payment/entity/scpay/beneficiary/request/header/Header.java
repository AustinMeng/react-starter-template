
package com.scb.s2b.api.payment.entity.scpay.beneficiary.request.header;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "txCtry",
    "instgChanl",
    "instgSubChanl",
    "msgId",
    "creDtTm",
    "nbOfTxs",
    "ctrlSum",
    "prePrcr",
    "payrollInd",
    "reqdPmtTp",
    "reqdSubPmtTp",
    "pmtTp",
    "subPmtTp",
    "instrPrty",
    "cdtDbtInd",
    "clrMsgTp",
    "clrMd",
    "txSts",
    "prcgDt",
    "prcgSts",
    "prcgSubSts",
    "btchBookg",
    "svcNm",
    "subSvcNm",
    "txEvtSts",
    "txEvtCd",
    "actnTp",
    "replayInd",
    "txRcvdDtTm",
    "vrsnNb",
    "applNm",
    "msgDefIdr",
    "tgtEnv",
    "svcStartDtTm",
    "svcEndDtTm",
    "rtgPrty"
})
public class Header {

    @JsonProperty("txCtry")
    private String txCtry;
    @JsonProperty("instgChanl")
    private String instgChanl;
    @JsonProperty("instgSubChanl")
    private String instgSubChanl;
    @JsonProperty("msgId")
    private String msgId;
    @JsonProperty("creDtTm")
    private String creDtTm;
    @JsonProperty("nbOfTxs")
    private String nbOfTxs;
    @JsonProperty("ctrlSum")
    private String ctrlSum;
    @JsonProperty("prePrcr")
    private String prePrcr;
    @JsonProperty("payrollInd")
    private String payrollInd;
    @JsonProperty("reqdPmtTp")
    private String reqdPmtTp;
    @JsonProperty("reqdSubPmtTp")
    private String reqdSubPmtTp;
    @JsonProperty("pmtTp")
    private String pmtTp;
    @JsonProperty("subPmtTp")
    private String subPmtTp;
    @JsonProperty("instrPrty")
    private String instrPrty;
    @JsonProperty("cdtDbtInd")
    private String cdtDbtInd;
    @JsonProperty("clrMsgTp")
    private String clrMsgTp;
    @JsonProperty("clrMd")
    private String clrMd;
    @JsonProperty("txSts")
    private String txSts;
    @JsonProperty("prcgDt")
    private String prcgDt;
    @JsonProperty("prcgSts")
    private String prcgSts;
    @JsonProperty("prcgSubSts")
    private String prcgSubSts;
    @JsonProperty("btchBookg")
    private String btchBookg;
    @JsonProperty("svcNm")
    private String svcNm;
    @JsonProperty("subSvcNm")
    private String subSvcNm;
    @JsonProperty("txEvtSts")
    private String txEvtSts;
    @JsonProperty("txEvtCd")
    private String txEvtCd;
    @JsonProperty("actnTp")
    private String actnTp;
    @JsonProperty("replayInd")
    private String replayInd;
    @JsonProperty("txRcvdDtTm")
    private String txRcvdDtTm;
    @JsonProperty("vrsnNb")
    private String vrsnNb;
    @JsonProperty("applNm")
    private String applNm;
    @JsonProperty("msgDefIdr")
    private String msgDefIdr;
    @JsonProperty("tgtEnv")
    private String tgtEnv;
    @JsonProperty("svcStartDtTm")
    private String svcStartDtTm;
    @JsonProperty("svcEndDtTm")
    private String svcEndDtTm;
    @JsonProperty("rtgPrty")
    private String rtgPrty;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("txCtry")
    public String getTxCtry() {
        return txCtry;
    }

    @JsonProperty("txCtry")
    public void setTxCtry(String txCtry) {
        this.txCtry = txCtry;
    }

    public Header withTxCtry(String txCtry) {
        this.txCtry = txCtry;
        return this;
    }

    @JsonProperty("instgChanl")
    public String getInstgChanl() {
        return instgChanl;
    }

    @JsonProperty("instgChanl")
    public void setInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
    }

    public Header withInstgChanl(String instgChanl) {
        this.instgChanl = instgChanl;
        return this;
    }

    @JsonProperty("instgSubChanl")
    public String getInstgSubChanl() {
        return instgSubChanl;
    }

    @JsonProperty("instgSubChanl")
    public void setInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
    }

    public Header withInstgSubChanl(String instgSubChanl) {
        this.instgSubChanl = instgSubChanl;
        return this;
    }

    @JsonProperty("msgId")
    public String getMsgId() {
        return msgId;
    }

    @JsonProperty("msgId")
    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public Header withMsgId(String msgId) {
        this.msgId = msgId;
        return this;
    }

    @JsonProperty("creDtTm")
    public String getCreDtTm() {
        return creDtTm;
    }

    @JsonProperty("creDtTm")
    public void setCreDtTm(String creDtTm) {
        this.creDtTm = creDtTm;
    }

    public Header withCreDtTm(String creDtTm) {
        this.creDtTm = creDtTm;
        return this;
    }

    @JsonProperty("nbOfTxs")
    public String getNbOfTxs() {
        return nbOfTxs;
    }

    @JsonProperty("nbOfTxs")
    public void setNbOfTxs(String nbOfTxs) {
        this.nbOfTxs = nbOfTxs;
    }

    public Header withNbOfTxs(String nbOfTxs) {
        this.nbOfTxs = nbOfTxs;
        return this;
    }

    @JsonProperty("ctrlSum")
    public String getCtrlSum() {
        return ctrlSum;
    }

    @JsonProperty("ctrlSum")
    public void setCtrlSum(String ctrlSum) {
        this.ctrlSum = ctrlSum;
    }

    public Header withCtrlSum(String ctrlSum) {
        this.ctrlSum = ctrlSum;
        return this;
    }

    @JsonProperty("prePrcr")
    public String getPrePrcr() {
        return prePrcr;
    }

    @JsonProperty("prePrcr")
    public void setPrePrcr(String prePrcr) {
        this.prePrcr = prePrcr;
    }

    public Header withPrePrcr(String prePrcr) {
        this.prePrcr = prePrcr;
        return this;
    }

    @JsonProperty("payrollInd")
    public String getPayrollInd() {
        return payrollInd;
    }

    @JsonProperty("payrollInd")
    public void setPayrollInd(String payrollInd) {
        this.payrollInd = payrollInd;
    }

    public Header withPayrollInd(String payrollInd) {
        this.payrollInd = payrollInd;
        return this;
    }

    @JsonProperty("reqdPmtTp")
    public String getReqdPmtTp() {
        return reqdPmtTp;
    }

    @JsonProperty("reqdPmtTp")
    public void setReqdPmtTp(String reqdPmtTp) {
        this.reqdPmtTp = reqdPmtTp;
    }

    public Header withReqdPmtTp(String reqdPmtTp) {
        this.reqdPmtTp = reqdPmtTp;
        return this;
    }

    @JsonProperty("reqdSubPmtTp")
    public String getReqdSubPmtTp() {
        return reqdSubPmtTp;
    }

    @JsonProperty("reqdSubPmtTp")
    public void setReqdSubPmtTp(String reqdSubPmtTp) {
        this.reqdSubPmtTp = reqdSubPmtTp;
    }

    public Header withReqdSubPmtTp(String reqdSubPmtTp) {
        this.reqdSubPmtTp = reqdSubPmtTp;
        return this;
    }

    @JsonProperty("pmtTp")
    public String getPmtTp() {
        return pmtTp;
    }

    @JsonProperty("pmtTp")
    public void setPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
    }

    public Header withPmtTp(String pmtTp) {
        this.pmtTp = pmtTp;
        return this;
    }

    @JsonProperty("subPmtTp")
    public String getSubPmtTp() {
        return subPmtTp;
    }

    @JsonProperty("subPmtTp")
    public void setSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
    }

    public Header withSubPmtTp(String subPmtTp) {
        this.subPmtTp = subPmtTp;
        return this;
    }

    @JsonProperty("instrPrty")
    public String getInstrPrty() {
        return instrPrty;
    }

    @JsonProperty("instrPrty")
    public void setInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
    }

    public Header withInstrPrty(String instrPrty) {
        this.instrPrty = instrPrty;
        return this;
    }

    @JsonProperty("cdtDbtInd")
    public String getCdtDbtInd() {
        return cdtDbtInd;
    }

    @JsonProperty("cdtDbtInd")
    public void setCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
    }

    public Header withCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
        return this;
    }

    @JsonProperty("clrMsgTp")
    public String getClrMsgTp() {
        return clrMsgTp;
    }

    @JsonProperty("clrMsgTp")
    public void setClrMsgTp(String clrMsgTp) {
        this.clrMsgTp = clrMsgTp;
    }

    public Header withClrMsgTp(String clrMsgTp) {
        this.clrMsgTp = clrMsgTp;
        return this;
    }

    @JsonProperty("clrMd")
    public String getClrMd() {
        return clrMd;
    }

    @JsonProperty("clrMd")
    public void setClrMd(String clrMd) {
        this.clrMd = clrMd;
    }

    public Header withClrMd(String clrMd) {
        this.clrMd = clrMd;
        return this;
    }

    @JsonProperty("txSts")
    public String getTxSts() {
        return txSts;
    }

    @JsonProperty("txSts")
    public void setTxSts(String txSts) {
        this.txSts = txSts;
    }

    public Header withTxSts(String txSts) {
        this.txSts = txSts;
        return this;
    }

    @JsonProperty("prcgDt")
    public String getPrcgDt() {
        return prcgDt;
    }

    @JsonProperty("prcgDt")
    public void setPrcgDt(String prcgDt) {
        this.prcgDt = prcgDt;
    }

    public Header withPrcgDt(String prcgDt) {
        this.prcgDt = prcgDt;
        return this;
    }

    @JsonProperty("prcgSts")
    public String getPrcgSts() {
        return prcgSts;
    }

    @JsonProperty("prcgSts")
    public void setPrcgSts(String prcgSts) {
        this.prcgSts = prcgSts;
    }

    public Header withPrcgSts(String prcgSts) {
        this.prcgSts = prcgSts;
        return this;
    }

    @JsonProperty("prcgSubSts")
    public String getPrcgSubSts() {
        return prcgSubSts;
    }

    @JsonProperty("prcgSubSts")
    public void setPrcgSubSts(String prcgSubSts) {
        this.prcgSubSts = prcgSubSts;
    }

    public Header withPrcgSubSts(String prcgSubSts) {
        this.prcgSubSts = prcgSubSts;
        return this;
    }

    @JsonProperty("btchBookg")
    public String getBtchBookg() {
        return btchBookg;
    }

    @JsonProperty("btchBookg")
    public void setBtchBookg(String btchBookg) {
        this.btchBookg = btchBookg;
    }

    public Header withBtchBookg(String btchBookg) {
        this.btchBookg = btchBookg;
        return this;
    }

    @JsonProperty("svcNm")
    public String getSvcNm() {
        return svcNm;
    }

    @JsonProperty("svcNm")
    public void setSvcNm(String svcNm) {
        this.svcNm = svcNm;
    }

    public Header withSvcNm(String svcNm) {
        this.svcNm = svcNm;
        return this;
    }

    @JsonProperty("subSvcNm")
    public String getSubSvcNm() {
        return subSvcNm;
    }

    @JsonProperty("subSvcNm")
    public void setSubSvcNm(String subSvcNm) {
        this.subSvcNm = subSvcNm;
    }

    public Header withSubSvcNm(String subSvcNm) {
        this.subSvcNm = subSvcNm;
        return this;
    }

    @JsonProperty("txEvtSts")
    public String getTxEvtSts() {
        return txEvtSts;
    }

    @JsonProperty("txEvtSts")
    public void setTxEvtSts(String txEvtSts) {
        this.txEvtSts = txEvtSts;
    }

    public Header withTxEvtSts(String txEvtSts) {
        this.txEvtSts = txEvtSts;
        return this;
    }

    @JsonProperty("txEvtCd")
    public String getTxEvtCd() {
        return txEvtCd;
    }

    @JsonProperty("txEvtCd")
    public void setTxEvtCd(String txEvtCd) {
        this.txEvtCd = txEvtCd;
    }

    public Header withTxEvtCd(String txEvtCd) {
        this.txEvtCd = txEvtCd;
        return this;
    }

    @JsonProperty("actnTp")
    public String getActnTp() {
        return actnTp;
    }

    @JsonProperty("actnTp")
    public void setActnTp(String actnTp) {
        this.actnTp = actnTp;
    }

    public Header withActnTp(String actnTp) {
        this.actnTp = actnTp;
        return this;
    }

    @JsonProperty("replayInd")
    public String getReplayInd() {
        return replayInd;
    }

    @JsonProperty("replayInd")
    public void setReplayInd(String replayInd) {
        this.replayInd = replayInd;
    }

    public Header withReplayInd(String replayInd) {
        this.replayInd = replayInd;
        return this;
    }

    @JsonProperty("txRcvdDtTm")
    public String getTxRcvdDtTm() {
        return txRcvdDtTm;
    }

    @JsonProperty("txRcvdDtTm")
    public void setTxRcvdDtTm(String txRcvdDtTm) {
        this.txRcvdDtTm = txRcvdDtTm;
    }

    public Header withTxRcvdDtTm(String txRcvdDtTm) {
        this.txRcvdDtTm = txRcvdDtTm;
        return this;
    }

    @JsonProperty("vrsnNb")
    public String getVrsnNb() {
        return vrsnNb;
    }

    @JsonProperty("vrsnNb")
    public void setVrsnNb(String vrsnNb) {
        this.vrsnNb = vrsnNb;
    }

    public Header withVrsnNb(String vrsnNb) {
        this.vrsnNb = vrsnNb;
        return this;
    }

    @JsonProperty("applNm")
    public String getApplNm() {
        return applNm;
    }

    @JsonProperty("applNm")
    public void setApplNm(String applNm) {
        this.applNm = applNm;
    }

    public Header withApplNm(String applNm) {
        this.applNm = applNm;
        return this;
    }

    @JsonProperty("msgDefIdr")
    public String getMsgDefIdr() {
        return msgDefIdr;
    }

    @JsonProperty("msgDefIdr")
    public void setMsgDefIdr(String msgDefIdr) {
        this.msgDefIdr = msgDefIdr;
    }

    public Header withMsgDefIdr(String msgDefIdr) {
        this.msgDefIdr = msgDefIdr;
        return this;
    }

    @JsonProperty("tgtEnv")
    public String getTgtEnv() {
        return tgtEnv;
    }

    @JsonProperty("tgtEnv")
    public void setTgtEnv(String tgtEnv) {
        this.tgtEnv = tgtEnv;
    }

    public Header withTgtEnv(String tgtEnv) {
        this.tgtEnv = tgtEnv;
        return this;
    }

    @JsonProperty("svcStartDtTm")
    public String getSvcStartDtTm() {
        return svcStartDtTm;
    }

    @JsonProperty("svcStartDtTm")
    public void setSvcStartDtTm(String svcStartDtTm) {
        this.svcStartDtTm = svcStartDtTm;
    }

    public Header withSvcStartDtTm(String svcStartDtTm) {
        this.svcStartDtTm = svcStartDtTm;
        return this;
    }

    @JsonProperty("svcEndDtTm")
    public String getSvcEndDtTm() {
        return svcEndDtTm;
    }

    @JsonProperty("svcEndDtTm")
    public void setSvcEndDtTm(String svcEndDtTm) {
        this.svcEndDtTm = svcEndDtTm;
    }

    public Header withSvcEndDtTm(String svcEndDtTm) {
        this.svcEndDtTm = svcEndDtTm;
        return this;
    }

    @JsonProperty("rtgPrty")
    public String getRtgPrty() {
        return rtgPrty;
    }

    @JsonProperty("rtgPrty")
    public void setRtgPrty(String rtgPrty) {
        this.rtgPrty = rtgPrty;
    }

    public Header withRtgPrty(String rtgPrty) {
        this.rtgPrty = rtgPrty;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Header withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(txCtry).append(instgChanl).append(instgSubChanl).append(msgId).append(creDtTm).append(nbOfTxs).append(ctrlSum).append(prePrcr).append(payrollInd).append(reqdPmtTp).append(reqdSubPmtTp).append(pmtTp).append(subPmtTp).append(instrPrty).append(cdtDbtInd).append(clrMsgTp).append(clrMd).append(txSts).append(prcgDt).append(prcgSts).append(prcgSubSts).append(btchBookg).append(svcNm).append(subSvcNm).append(txEvtSts).append(txEvtCd).append(actnTp).append(replayInd).append(txRcvdDtTm).append(vrsnNb).append(applNm).append(msgDefIdr).append(tgtEnv).append(svcStartDtTm).append(svcEndDtTm).append(rtgPrty).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Header) == false) {
            return false;
        }
        Header rhs = ((Header) other);
        return new EqualsBuilder().append(txCtry, rhs.txCtry).append(instgChanl, rhs.instgChanl).append(instgSubChanl, rhs.instgSubChanl).append(msgId, rhs.msgId).append(creDtTm, rhs.creDtTm).append(nbOfTxs, rhs.nbOfTxs).append(ctrlSum, rhs.ctrlSum).append(prePrcr, rhs.prePrcr).append(payrollInd, rhs.payrollInd).append(reqdPmtTp, rhs.reqdPmtTp).append(reqdSubPmtTp, rhs.reqdSubPmtTp).append(pmtTp, rhs.pmtTp).append(subPmtTp, rhs.subPmtTp).append(instrPrty, rhs.instrPrty).append(cdtDbtInd, rhs.cdtDbtInd).append(clrMsgTp, rhs.clrMsgTp).append(clrMd, rhs.clrMd).append(txSts, rhs.txSts).append(prcgDt, rhs.prcgDt).append(prcgSts, rhs.prcgSts).append(prcgSubSts, rhs.prcgSubSts).append(btchBookg, rhs.btchBookg).append(svcNm, rhs.svcNm).append(subSvcNm, rhs.subSvcNm).append(txEvtSts, rhs.txEvtSts).append(txEvtCd, rhs.txEvtCd).append(actnTp, rhs.actnTp).append(replayInd, rhs.replayInd).append(txRcvdDtTm, rhs.txRcvdDtTm).append(vrsnNb, rhs.vrsnNb).append(applNm, rhs.applNm).append(msgDefIdr, rhs.msgDefIdr).append(tgtEnv, rhs.tgtEnv).append(svcStartDtTm, rhs.svcStartDtTm).append(svcEndDtTm, rhs.svcEndDtTm).append(rtgPrty, rhs.rtgPrty).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

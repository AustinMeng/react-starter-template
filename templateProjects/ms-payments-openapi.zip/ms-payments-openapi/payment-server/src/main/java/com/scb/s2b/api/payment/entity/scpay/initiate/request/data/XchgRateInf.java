
package com.scb.s2b.api.payment.entity.scpay.initiate.request.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ntr",
    "rateTp",
    "advsdTxInd",
    "tnr",
    "cstmrRate",
    "valDt",
    "msgXchgRt",
    "sttlmAmt",
    "sttlmAmtCcy",
    "qtId",
    "grntedRateInd",
    "sttlmCtry",
    "dlvryTp",
    "clctnMtd",
    "ctrctInf"
})
public class XchgRateInf {

    @JsonProperty("ntr")
    private String ntr;
    @JsonProperty("rateTp")
    private String rateTp;
    @JsonProperty("advsdTxInd")
    private String advsdTxInd;
    @JsonProperty("tnr")
    private String tnr;
    @JsonProperty("cstmrRate")
    private String cstmrRate;
    @JsonProperty("valDt")
    private String valDt;
    @JsonProperty("msgXchgRt")
    private String msgXchgRt;
    @JsonProperty("sttlmAmt")
    private String sttlmAmt;
    @JsonProperty("sttlmAmtCcy")
    private String sttlmAmtCcy;
    @JsonProperty("qtId")
    private String qtId;
    @JsonProperty("grntedRateInd")
    private String grntedRateInd;
    @JsonProperty("sttlmCtry")
    private String sttlmCtry;
    @JsonProperty("dlvryTp")
    private String dlvryTp;
    @JsonProperty("clctnMtd")
    private String clctnMtd;
    @JsonProperty("ctrctInf")
    private List<CtrctInf> ctrctInf = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ntr")
    public String getNtr() {
        return ntr;
    }

    @JsonProperty("ntr")
    public void setNtr(String ntr) {
        this.ntr = ntr;
    }

    public XchgRateInf withNtr(String ntr) {
        this.ntr = ntr;
        return this;
    }

    @JsonProperty("rateTp")
    public String getRateTp() {
        return rateTp;
    }

    @JsonProperty("rateTp")
    public void setRateTp(String rateTp) {
        this.rateTp = rateTp;
    }

    public XchgRateInf withRateTp(String rateTp) {
        this.rateTp = rateTp;
        return this;
    }

    @JsonProperty("advsdTxInd")
    public String getAdvsdTxInd() {
        return advsdTxInd;
    }

    @JsonProperty("advsdTxInd")
    public void setAdvsdTxInd(String advsdTxInd) {
        this.advsdTxInd = advsdTxInd;
    }

    public XchgRateInf withAdvsdTxInd(String advsdTxInd) {
        this.advsdTxInd = advsdTxInd;
        return this;
    }

    @JsonProperty("tnr")
    public String getTnr() {
        return tnr;
    }

    @JsonProperty("tnr")
    public void setTnr(String tnr) {
        this.tnr = tnr;
    }

    public XchgRateInf withTnr(String tnr) {
        this.tnr = tnr;
        return this;
    }

    @JsonProperty("cstmrRate")
    public String getCstmrRate() {
        return cstmrRate;
    }

    @JsonProperty("cstmrRate")
    public void setCstmrRate(String cstmrRate) {
        this.cstmrRate = cstmrRate;
    }

    public XchgRateInf withCstmrRate(String cstmrRate) {
        this.cstmrRate = cstmrRate;
        return this;
    }

    @JsonProperty("valDt")
    public String getValDt() {
        return valDt;
    }

    @JsonProperty("valDt")
    public void setValDt(String valDt) {
        this.valDt = valDt;
    }

    public XchgRateInf withValDt(String valDt) {
        this.valDt = valDt;
        return this;
    }

    @JsonProperty("msgXchgRt")
    public String getMsgXchgRt() {
        return msgXchgRt;
    }

    @JsonProperty("msgXchgRt")
    public void setMsgXchgRt(String msgXchgRt) {
        this.msgXchgRt = msgXchgRt;
    }

    public XchgRateInf withMsgXchgRt(String msgXchgRt) {
        this.msgXchgRt = msgXchgRt;
        return this;
    }

    @JsonProperty("sttlmAmt")
    public String getSttlmAmt() {
        return sttlmAmt;
    }

    @JsonProperty("sttlmAmt")
    public void setSttlmAmt(String sttlmAmt) {
        this.sttlmAmt = sttlmAmt;
    }

    public XchgRateInf withSttlmAmt(String sttlmAmt) {
        this.sttlmAmt = sttlmAmt;
        return this;
    }

    @JsonProperty("sttlmAmtCcy")
    public String getSttlmAmtCcy() {
        return sttlmAmtCcy;
    }

    @JsonProperty("sttlmAmtCcy")
    public void setSttlmAmtCcy(String sttlmAmtCcy) {
        this.sttlmAmtCcy = sttlmAmtCcy;
    }

    public XchgRateInf withSttlmAmtCcy(String sttlmAmtCcy) {
        this.sttlmAmtCcy = sttlmAmtCcy;
        return this;
    }

    @JsonProperty("qtId")
    public String getQtId() {
        return qtId;
    }

    @JsonProperty("qtId")
    public void setQtId(String qtId) {
        this.qtId = qtId;
    }

    public XchgRateInf withQtId(String qtId) {
        this.qtId = qtId;
        return this;
    }

    @JsonProperty("grntedRateInd")
    public String getGrntedRateInd() {
        return grntedRateInd;
    }

    @JsonProperty("grntedRateInd")
    public void setGrntedRateInd(String grntedRateInd) {
        this.grntedRateInd = grntedRateInd;
    }

    public XchgRateInf withGrntedRateInd(String grntedRateInd) {
        this.grntedRateInd = grntedRateInd;
        return this;
    }

    @JsonProperty("sttlmCtry")
    public String getSttlmCtry() {
        return sttlmCtry;
    }

    @JsonProperty("sttlmCtry")
    public void setSttlmCtry(String sttlmCtry) {
        this.sttlmCtry = sttlmCtry;
    }

    public XchgRateInf withSttlmCtry(String sttlmCtry) {
        this.sttlmCtry = sttlmCtry;
        return this;
    }

    @JsonProperty("dlvryTp")
    public String getDlvryTp() {
        return dlvryTp;
    }

    @JsonProperty("dlvryTp")
    public void setDlvryTp(String dlvryTp) {
        this.dlvryTp = dlvryTp;
    }

    public XchgRateInf withDlvryTp(String dlvryTp) {
        this.dlvryTp = dlvryTp;
        return this;
    }

    @JsonProperty("clctnMtd")
    public String getClctnMtd() {
        return clctnMtd;
    }

    @JsonProperty("clctnMtd")
    public void setClctnMtd(String clctnMtd) {
        this.clctnMtd = clctnMtd;
    }

    public XchgRateInf withClctnMtd(String clctnMtd) {
        this.clctnMtd = clctnMtd;
        return this;
    }

    @JsonProperty("ctrctInf")
    public List<CtrctInf> getCtrctInf() {
        return ctrctInf;
    }

    @JsonProperty("ctrctInf")
    public void setCtrctInf(List<CtrctInf> ctrctInf) {
        this.ctrctInf = ctrctInf;
    }

    public XchgRateInf withCtrctInf(List<CtrctInf> ctrctInf) {
        this.ctrctInf = ctrctInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public XchgRateInf withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(ntr).append(rateTp).append(advsdTxInd).append(tnr).append(cstmrRate).append(valDt).append(msgXchgRt).append(sttlmAmt).append(sttlmAmtCcy).append(qtId).append(grntedRateInd).append(sttlmCtry).append(dlvryTp).append(clctnMtd).append(ctrctInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof XchgRateInf) == false) {
            return false;
        }
        XchgRateInf rhs = ((XchgRateInf) other);
        return new EqualsBuilder().append(ntr, rhs.ntr).append(rateTp, rhs.rateTp).append(advsdTxInd, rhs.advsdTxInd).append(tnr, rhs.tnr).append(cstmrRate, rhs.cstmrRate).append(valDt, rhs.valDt).append(msgXchgRt, rhs.msgXchgRt).append(sttlmAmt, rhs.sttlmAmt).append(sttlmAmtCcy, rhs.sttlmAmtCcy).append(qtId, rhs.qtId).append(grntedRateInd, rhs.grntedRateInd).append(sttlmCtry, rhs.sttlmCtry).append(dlvryTp, rhs.dlvryTp).append(clctnMtd, rhs.clctnMtd).append(ctrctInf, rhs.ctrctInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

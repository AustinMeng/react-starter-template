package com.scb.s2b.api.payment.camel.notification.processor;

import static com.scb.s2b.api.payment.config.PaymentConstant.ENTITY_TYPE_NOTIFICATION_ACK;

import com.scb.s2b.api.payment.camel.JmsProducerAdapter;
import com.scb.s2b.api.payment.camel.notification.handler.SNMNotificationHandler;
import com.scb.s2b.api.payment.config.property.NotificationProperties;
import com.scb.s2b.api.payment.entity.scpay.notification.Notification;
import com.scb.s2b.api.payment.entity.scpay.notification.header.NotificationHeader.EventCode;
import com.scb.s2b.api.payment.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.payment.model.PaymentMessage;
import com.scb.s2b.api.payment.repository.PaymentMessageRepository;
import com.scb.s2b.api.payment.util.IdGenerator;
import java.time.Instant;
import java.util.Map;
import javax.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
public class SNMNotificationProcessorImpl implements SNMNotificationProcessor {

    private final NotificationProperties notificationProperties;
    private final JmsProducerAdapter jmsProducer;
    private final Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap;
    private final PaymentMessageRepository paymentMessageRepository;
    private final JsonMessageMarshaller messageMarshaller;
    private final IdGenerator idGenerator;

    public SNMNotificationProcessorImpl(JmsProducerAdapter jmsProducer,
            Map<EventCode, SNMNotificationHandler> eventCodeHandlerMap,
            PaymentMessageRepository paymentMessageRepository,
            JsonMessageMarshaller messageMarshaller,
            NotificationProperties notificationProperties, IdGenerator idGenerator) {
        this.jmsProducer = jmsProducer;
        this.eventCodeHandlerMap = eventCodeHandlerMap;
        this.paymentMessageRepository = paymentMessageRepository;
        this.messageMarshaller = messageMarshaller;
        this.notificationProperties = notificationProperties;
        this.idGenerator = idGenerator;
    }

    @Override
    @Transactional(transactionManager = "transactionManager")
    public void processingNotification(Notification notification) {
        log.info("start to process notification with message id {}.", notification.getHeader().getMessageId());
        EventCode eventCode = notification.getHeader().getEventCode();
        SNMNotificationHandler handlerService = eventCodeHandlerMap.getOrDefault(eventCode, new SNMNotificationHandler(){});
        handlerService.handleNotification(notification);
        this.publishNotificationResponse(notification);
    }

    @Override
    @Transactional(transactionManager = "transactionManager", propagation = Propagation.REQUIRES_NEW)
    public void persistNotificationMessage(String message, String entityType, String messageId) {
        PaymentMessage event = PaymentMessage.builder()
                .messageId(messageId)
                .entityType(entityType)
                .contentType(MediaType.APPLICATION_JSON)
                .content(message)
                .timestamp(Instant.now())
                .build();
        log.info("Persisting NotificationMessage messageId={}, entityType={}",
                event.getMessageId(), event.getEntityType());
        paymentMessageRepository.save(event);
    }

    private void publishNotificationResponse(Notification notification) {
        String message = messageMarshaller.marshallToJsonString(notification);
        String messageId = idGenerator.messageId();
        this.persistNotificationMessage(message, ENTITY_TYPE_NOTIFICATION_ACK, messageId);
        jmsProducer.publishNMNotificationMessage(notificationResponseTopic(notification), messageId, message);
    }

    private String notificationResponseTopic(Notification notification) {
        String country = StringUtils.lowerCase(notification.getHeader().getCountryCode());
        String topicTemplate = notificationProperties.getNotificationRespTopicMap().getOrDefault(notification.getHeader().getCountryCode(),
                notificationProperties.getNotificationRespTopicMap().get("DEFAULT"));

        return String.format(topicTemplate, country, country);
    }
}


package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.error;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cd",
    "addtlInf"
})
public class Strd {

    @JsonProperty("cd")
    private String cd;
    @JsonProperty("addtlInf")
    private String addtlInf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cd")
    public String getCd() {
        return cd;
    }

    @JsonProperty("cd")
    public void setCd(String cd) {
        this.cd = cd;
    }

    public Strd withCd(String cd) {
        this.cd = cd;
        return this;
    }

    @JsonProperty("addtlInf")
    public String getAddtlInf() {
        return addtlInf;
    }

    @JsonProperty("addtlInf")
    public void setAddtlInf(String addtlInf) {
        this.addtlInf = addtlInf;
    }

    public Strd withAddtlInf(String addtlInf) {
        this.addtlInf = addtlInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Strd withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cd).append(addtlInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Strd) == false) {
            return false;
        }
        Strd rhs = ((Strd) other);
        return new EqualsBuilder().append(cd, rhs.cd).append(addtlInf, rhs.addtlInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}


package com.scb.s2b.api.payment.entity.scpay.initiate.response.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ref",
    "dt",
    "desc",
    "cdtDbtInd",
    "amt",
    "ccy",
    "cstmInvcDtls"
})
public class DtlsRcrd {

    @JsonProperty("ref")
    private String ref;
    @JsonProperty("dt")
    private String dt;
    @JsonProperty("desc")
    private String desc;
    @JsonProperty("cdtDbtInd")
    private String cdtDbtInd;
    @JsonProperty("amt")
    private String amt;
    @JsonProperty("ccy")
    private String ccy;
    @JsonProperty("cstmInvcDtls")
    private List<String> cstmInvcDtls = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ref")
    public String getRef() {
        return ref;
    }

    @JsonProperty("ref")
    public void setRef(String ref) {
        this.ref = ref;
    }

    public DtlsRcrd withRef(String ref) {
        this.ref = ref;
        return this;
    }

    @JsonProperty("dt")
    public String getDt() {
        return dt;
    }

    @JsonProperty("dt")
    public void setDt(String dt) {
        this.dt = dt;
    }

    public DtlsRcrd withDt(String dt) {
        this.dt = dt;
        return this;
    }

    @JsonProperty("desc")
    public String getDesc() {
        return desc;
    }

    @JsonProperty("desc")
    public void setDesc(String desc) {
        this.desc = desc;
    }

    public DtlsRcrd withDesc(String desc) {
        this.desc = desc;
        return this;
    }

    @JsonProperty("cdtDbtInd")
    public String getCdtDbtInd() {
        return cdtDbtInd;
    }

    @JsonProperty("cdtDbtInd")
    public void setCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
    }

    public DtlsRcrd withCdtDbtInd(String cdtDbtInd) {
        this.cdtDbtInd = cdtDbtInd;
        return this;
    }

    @JsonProperty("amt")
    public String getAmt() {
        return amt;
    }

    @JsonProperty("amt")
    public void setAmt(String amt) {
        this.amt = amt;
    }

    public DtlsRcrd withAmt(String amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("ccy")
    public String getCcy() {
        return ccy;
    }

    @JsonProperty("ccy")
    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public DtlsRcrd withCcy(String ccy) {
        this.ccy = ccy;
        return this;
    }

    @JsonProperty("cstmInvcDtls")
    public List<String> getCstmInvcDtls() {
        return cstmInvcDtls;
    }

    @JsonProperty("cstmInvcDtls")
    public void setCstmInvcDtls(List<String> cstmInvcDtls) {
        this.cstmInvcDtls = cstmInvcDtls;
    }

    public DtlsRcrd withCstmInvcDtls(List<String> cstmInvcDtls) {
        this.cstmInvcDtls = cstmInvcDtls;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DtlsRcrd withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(ref).append(dt).append(desc).append(cdtDbtInd).append(amt).append(ccy).append(cstmInvcDtls).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DtlsRcrd) == false) {
            return false;
        }
        DtlsRcrd rhs = ((DtlsRcrd) other);
        return new EqualsBuilder().append(ref, rhs.ref).append(dt, rhs.dt).append(desc, rhs.desc).append(cdtDbtInd, rhs.cdtDbtInd).append(amt, rhs.amt).append(ccy, rhs.ccy).append(cstmInvcDtls, rhs.cstmInvcDtls).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

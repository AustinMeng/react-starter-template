
package com.scb.s2b.api.payment.entity.scpay.beneficiary.response.error;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "xcptnInf"
})
public class Error {

    @JsonProperty("xcptnInf")
    private XcptnInf xcptnInf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("xcptnInf")
    public XcptnInf getXcptnInf() {
        return xcptnInf;
    }

    @JsonProperty("xcptnInf")
    public void setXcptnInf(XcptnInf xcptnInf) {
        this.xcptnInf = xcptnInf;
    }

    public Error withXcptnInf(XcptnInf xcptnInf) {
        this.xcptnInf = xcptnInf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Error withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(xcptnInf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Error) == false) {
            return false;
        }
        Error rhs = ((Error) other);
        return new EqualsBuilder().append(xcptnInf, rhs.xcptnInf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}

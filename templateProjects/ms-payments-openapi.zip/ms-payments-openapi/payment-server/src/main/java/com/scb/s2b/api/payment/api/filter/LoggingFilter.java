package com.scb.s2b.api.payment.api.filter;

import com.scb.s2b.api.payment.config.PaymentConstant;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.Provider;
import org.slf4j.MDC;

@Provider
public class LoggingFilter implements ContainerRequestFilter, ContainerResponseFilter {

    static final String GROUP_ID = "groupId";
    static final String CORRELATION_ID = "correlationId";

    @Context
    protected HttpServletRequest requst;

    @Override
    public void filter(ContainerRequestContext containerRequestContext) {
        String groupId = containerRequestContext.getHeaderString(PaymentConstant.GROUP_ID_HEADER);
        String correlationId = containerRequestContext.getHeaderString(PaymentConstant.CORRELATION_ID_HEADER);

        MDC.put(GROUP_ID, groupId);
        MDC.put(CORRELATION_ID, correlationId);
    }

    @Override
    public void filter(ContainerRequestContext containerRequestContext,
            ContainerResponseContext containerResponseContext) {
        MDC.clear();
    }
}

package com.scb.s2b.api.payment.api;

import com.scb.s2b.api.payment.processor.request.RequestProcessor;
import com.scb.s2b.api.payment.service.PaymentService;
import com.scb.s2b.api.payment.transformer.OpenApiPaymentInstructionTransformer;
import com.scb.s2b.api.payment.validation.PaynowRequestValidator;
import javax.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Singleton
public class PaynowApiImpl extends ProxyPaymentApiBase {

    @Autowired
    public PaynowApiImpl(PaymentService paymentService,
            @Qualifier("paynowRequestValidator") PaynowRequestValidator paymentRequestValidator,
            @Qualifier("paynowRequestProcessor") RequestProcessor requestProcessor,
            OpenApiPaymentInstructionTransformer openApiPaymentInstructionTransformer) {
        super(paymentService, paymentRequestValidator, requestProcessor, openApiPaymentInstructionTransformer);
    }
}

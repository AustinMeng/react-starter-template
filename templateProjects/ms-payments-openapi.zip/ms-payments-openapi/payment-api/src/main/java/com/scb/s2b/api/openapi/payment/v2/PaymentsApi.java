package com.scb.s2b.api.openapi.payment.v2;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiBulkPaymentIds;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiBulkPaymentInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPayeeInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentClientReferences;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentId;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentInstruction;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentStatusRequest;
import com.scb.s2b.api.openapi.payment.v2.model.OpenApiPaymentStatuses;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/payments")
@OpenAPIDefinition(tags = {
        @Tag(name = "Proxy", description = "Facilitates instant domestic transactions using proxies. A proxy allows you to instruct payments by identifying beneficiaries using secondary identifier such as mobile number, NRIC, Business Registration Number, etc.\n" +
            "Move Money APIs help to facilitate your finance operations such as instant domestic payments.", extensions = @Extension(properties = {@ExtensionProperty(name = "x-subcategory", value = "Move Money")})),
        @Tag(name = "Payment Initiation", description = "Facilitates domestic or cross border transactions. Move Money APIs help to facilitate your finance operations such as domestic or cross border payment initiation", extensions = @Extension(properties = {@ExtensionProperty(name = "x-subcategory", value = "Move Money")})),
        @Tag(name = "Inquiry", description = "Inquiry APIs enables you to retrieve payment details and statuses for both domestic and cross border transactions", extensions = @Extension(properties = {@ExtensionProperty(name = "x-subcategory", value = "Move Money")}))
})
public interface PaymentsApi {

    @POST
    @Path("/v2/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Payment Initiation",
            description = "<p>The Payment Initiation API exposes the ability to initiate a payment instruction, upon success it returns a payment reference identifier.</p><p>The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.</p>",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }\n")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            },
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK,CN,TW,SG,MY,TH,ID,PH,VN,IN,BD,LK,NP,AE,PK,BH,QA,JO,NG,ZA,KE,UG,TZ,CM,GH,ZM,CI,ZW,GB,US"),
            }),
            tags = {"Payment Initiation"})
    Response nonFastPaymentInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified
            , @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/crossborder/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Payment Initiation – Cross Border",
            description = "The Cross Border Payment Initiation API exposes the ability to initiate a cross border/cross currency payment instruction, and upon success it returns a payment reference identifier. The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "SG,HK,CN,AE,IN,MY,TH,ID,VN,BD,LK,NP,TW,PH,PK,QA,BH,JO,NG,ZA,TZ,CM,GH,ZM,ZW,CI,GB,US"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }\n")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response crossborderInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/payroll/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Payroll Initiation",
            description = "The Payroll Initiation API exposes the ability to initiate bulk payment instructions for processing payroll, upon success it returns a list of payment reference identifiers with respective statuses. The response is a representation or acknowledgment that the payroll instructions were received successfully. To check the status of a specific payroll payment, the client is required to use the Payment Status Inquiry API which provides the current state of that particular payroll payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK,SG,MY,IN,BD,LK,NP,AE,PK,JO,NG,ZA,KE,UG,TZ,CM,GH,ZM,CI,ZW,TH,PH,ID,VN"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"accepted\": [\n" +
                            "                      \"PAYROLL4594051\",\n" +
                            "                      \"PAYROLL4594052\",\n" +
                            "                      \"PAYROLL4594053\"\n" +
                            "                    ],\n" +
                            "                    \"rejected\": [\n" +
                            "                      {\n" +
                            "                        \"referenceId\": \"PAYROLL4594055\",\n" +
                            "                        \"errorCode\": \"AER-1105\",\n" +
                            "                        \"errorMessage\": \"Invalid value for debtorAccount.id\"\n" +
                            "                      },\n" +
                            "                      {\n" +
                            "                        \"referenceId\": \"PAYROLL4594057\",\n" +
                            "                        \"errorCode\": \"AER-1174\",\n" +
                            "                        \"errorMessage\": \"Creditor Account Id exceeds maximum length (34 characters)\"\n" +
                            "                      }\n" +
                            "                    ]\n" +
                            "                  }\n" +
                            "                \n")},  schema = @Schema(implementation = OpenApiBulkPaymentIds.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
            })
    Response payrollInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified
            , @Parameter(description = "") @Valid OpenApiBulkPaymentInstruction body);

    @POST
    @Path("/v2/bulk/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Bulk Transfer Initiation",
            description = "The Bulk Transfer initiation API exposes the ability to initiate single or multiple instructions in 1 message. This API supports both cross border and domestic transactions. Upon successful submission it returns a payment reference identifier for each instruction.\n"
                    + "The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK,CN,TW,SG,MY,TH,ID,PH,VN,IN,BD,LK,NP,AE,PK,BH,QA,JO,NG,ZA,KE,UG,TZ,CM,GH,ZM,ZW,CI")
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"accepted\": [\n" +
                            "                      \"PAYROLL4594051\",\n" +
                            "                      \"PAYROLL4594052\",\n" +
                            "                      \"PAYROLL4594053\"\n" +
                            "                    ],\n" +
                            "                    \"rejected\": [\n" +
                            "                      {\n" +
                            "                        \"referenceId\": \"PAYROLL4594055\",\n" +
                            "                        \"errorCode\": \"AER-1105\",\n" +
                            "                        \"errorMessage\": \"Invalid value for debtorAccount.id\"\n" +
                            "                      },\n" +
                            "                      {\n" +
                            "                        \"referenceId\": \"PAYROLL4594057\",\n" +
                            "                        \"errorCode\": \"AER-1174\",\n" +
                            "                        \"errorMessage\": \"Creditor Account Id exceeds maximum length (34 characters)\"\n" +
                            "                      }\n" +
                            "                    ]\n" +
                            "                  }\n" +
                            "                \n")},  schema = @Schema(implementation = OpenApiBulkPaymentIds.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
            })
    Response paymentsBulkInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiBulkPaymentInstruction body);

    @POST
    @Path("/v2/mwp/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Mobile Wallet Payment Initiation",
            description = "The Mobile Wallet Payment API exposes the ability to initiate domestic fund transfer from the Bank to a Mobile Wallet Account. Mobile Number is used to initiate the payment. " +
                    "\n" +
                    "Upon a successful transaction a payment reference identifier is generated. The response is a representation or acknowledgment that an instruction was received successfully. " +
                    "\n" +
                    "To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "KE,UG,TZ,BD,PK,NG,GH,ZM,VN,CN"),
            }),
            tags = {"Payment Initiation"},
            responses = {
            @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                    "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                    "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                    "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                    "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                    "                }\n")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
            @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
            @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response mobileWalletPaymentInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/fps/bank-transfer/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Hong Kong - FPS Account Transfer",
            description = "The FAST Initiation API exposes the ability to initiate an Instant account to account payment instruction across Hong Kong, upon successful submission it returns a payment reference identifier. The Payment currency will remain as HKD.<br/><br/>"
            + "The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }\n")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response fpsInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/imps/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "India – IMPS Account Transfer", description = "The Payment Initiation IMPS API exposes the ability to initiate an instant fund transfer in India. Upon success it returns a payment reference identifier. The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "IN"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "paymentIdentifier: P2P1112323123123\n" +
                            "internalTrackingId: 107d7818-8b97-4489-a718-1d81fe8ac244\n" +
                            "clientReferenceId: P2P1112323123123\n" +
                            "referenceId: P2P1112323123123\n" +
                            "statusString: Pending\n" +
                            "timestamp: '2020-09-03T13:49:34.673Z'\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response impsInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/imps/proxy/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "India - IMPS Initiation",
            description = "The IMPS Proxy Payment Initiation API exposes the ability to initiate a payment instruction, upon successful submission it returns a payment reference identifier. The Payment currency supported - INR. The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment. The proxy identifier is the MMID for a beneficiary.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "IN"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "paymentIdentifier: P2P1112323123123\n" +
                            "internalTrackingId: 107d7818-8b97-4489-a718-1d81fe8ac244\n" +
                            "clientReferenceId: P2P1112323123123\n" +
                            "referenceId: P2P1112323123123\n" +
                            "statusString: Pending\n" +
                            "timestamp: '2020-09-03T13:49:34.673Z'\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response impsProxyInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/fast/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Singapore - FAST Account Transfer", description = "The FAST Initiation API exposes the ability to initiate an Instant account to account payment instruction across Singapore, upon successful submission it returns a payment reference identifier. The Payment currency supported - SGD.<br/><br/>"
            + "The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "SG"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response fastInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/napas/bank-transfer/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Vietnam - NAPAS Account Transfer", description = "The NAPAS initiation API exposes the ability to initiate an Instant account to account payment instruction across Vietnam. Upon successful submission it returns a payment reference identifier. The Payment currency supported - VND.\n"
            + "The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "VN"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response napasBankTransferInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/fps/proxy/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Hong Kong - FPS Initiation", description = "The Faster Payment Systems (FPS) Proxy Payment Initiation API exposes the ability to initiate a payment instruction, upon successful submission it returns a payment reference identifier.<br/><br/>"
            + "The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.<br/><br/>"
            + "The FPS mandates the population of the proxy identifier. The proxy identifier is the Hong Kong handle for a beneficiary.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"internalTrackingId\": \"20200401OPENAPI421RNXN6814067\",\n" +
                            "                    \"clientReferenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"referenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"statusString\": \"Pending\",\n" +
                            "                    \"timestamp\": \"2020-05-15T07:53:50.347Z\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response fpsProxyPaymentInitiate(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/fps/proxy/initiate-with-validation")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Hong Kong - FPS Proxy with Name Validation", description = "Initiate a Payment Instruction across Instant payments to a Proxy ID or Address post a Successful validation of the Payee Name against the Actual Name of the Payee with the creditor bank. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.<br/><br/>"
            + "The FPS Proxy mandates the population of the proxy identifier. The proxy identifier is the Hong Kong handle for a beneficiary.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"internalTrackingId\": \"20200401OPENAPI421RNXN6814067\",\n" +
                            "                    \"clientReferenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"referenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"statusString\": \"Pending\",\n" +
                            "                    \"timestamp\": \"2020-05-15T07:53:50.347Z\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response fpsProxyPaymentInitiateProxyValidation(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/instapay/bank-transfer/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Philippines - InstaPay Account Transfer", description = "The InstaPay Bank Transfer API exposes the ability to initiate an Instant account to account payment instruction across Philippines, upon successful submission it returns a payment reference identifier. The Payment currency supported - PHP.<br/><br/>"
            + "The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "PH"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response instaPayBankTransferInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/instapay/proxy/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Philippines - InstaPay Initiation", description = "The InstaPay Proxy Payment Initiation API exposes the ability to initiate a payment instruction, upon successful submission it returns a payment reference identifier. The Payment currency supported - PHP.<br/><br/>"
            + "The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.<br/><br/>"
            + "The InstaPay mandates the population of the proxy identifier. The proxy identifier is the Philippines handle for a beneficiary.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "PH"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"internalTrackingId\": \"20200401OPENAPI421RNXN6814067\",\n" +
                            "                    \"clientReferenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"referenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"statusString\": \"Pending\",\n" +
                            "                    \"timestamp\": \"2020-05-15T07:53:50.347Z\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response instaPayProxyPaymentInitiate(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/instapay/proxy/initiate-with-validation")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Philippines - InstaPay Proxy with Name Validation", description = "Initiate a Payment Instruction across Instant payments to a Proxy ID or Address post a Successful validation of the Payee Name against the Actual Name of the Payee with the creditor bank. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.<br/><br/>"
            + "The InstaPay mandates the population of the proxy identifier. The proxy identifier is the Philippines handle for a beneficiary.<br/><br/>"
            + "The Payment currency supported - PHP.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "PH"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"internalTrackingId\": \"20200401OPENAPI421RNXN6814067\",\n" +
                            "                    \"clientReferenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"referenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"statusString\": \"Pending\",\n" +
                            "                    \"timestamp\": \"2020-05-15T07:53:50.347Z\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response instaPayProxyPaymentInitiateProxyValidation(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @GET
    @Path("/v2/{referenceId}")
    @Produces({"application/json"})
    @Operation(summary = "Payment Retrieval",
            description = "<p>The Payment Retrieval API exposes the ability to query a given payment instruction, based on your payment reference identifier .</p><p>The response is a complete reproduction of the initiation message with the addition of internal identifiers used for internal reporting and tracking.</p><p>A successful response indicates that the payment was found, a 404 response indicates that the payment reference identifier was not received by the Bank.</p>",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK,CN,TW,SG,MY,TH,ID,PH,VN,IN,BD,LK,NP,AE,PK,BH,QA,JO,NG,ZA,KE,UG,TZ,CM,GH,ZM,ZW,CI"),
            }),
            tags = {"Inquiry"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                  \"header\": {\n" +
                            "                    \"messageSender\": \"\",\n" +
                            "                    \"messageId\": \"OPENAPI4GMLLRJ7494249\",\n" +
                            "                    \"countryCode\": \"IN\",\n" +
                            "                    \"timestamp\": \"2018-10-18T14:59:23Z\"\n" +
                            "                    },\n" +
                            "                   \"instruction\": {\n" +
                            "                        \"paymentTimestamp\": \"2018-10-18T14:59:23Z\",\n" +
                            "                        \"paymentTypePreference\": \"Explicit\",\n" +
                            "                        \"requiredExecutionDate\": \"2020-06-22\",\n" +
                            "                        \"amount\": {\n" +
                            "                            \"currencyCode\": \"INR\",\n" +
                            "                            \"amount\": 4098\n" +
                            "                                  },\n" +
                            "                      \"referenceId\": \"2020051504561235311\",\n" +
                            "                      \"purpose\": \"OTHR\",\n" +
                            "                      \"paymentType\": \"IBFT\",\n" +
                            "                      \"chargerBearer\": \"DEBT\",\n" +
                            "                      \"debtor\": {\n" +
                            "                        \"legalEntityId\": \"SCB-1054xxxxx\",\n" +
                            "                        \"name\": \"1054xxxxx\"\n" +
                            "                                },\n" +
                            "                      \"debtorAccount\": {\n" +
                            "                        \"id\": \"22510603706\",\n" +
                            "                        \"identifierType\": \"BBAN\",\n" +
                            "                        \"accountType\": \"CACC\"\n" +
                            "                                    },\n" +
                            "                      \"debtorAgent\": {\n" +
                            "                         \"financialInstitution\": {\n" +
                            "                             \"postalAddress\": {\n" +
                            "                             \"line_1\": \"105455address2 xxxxx\",\n" +
                            "                             \"line_2\": \"105455address3 xxxxx\",\n" +
                            "                             \"city\": \"\",\n" +
                            "                             \"state\": \"\",\n" +
                            "                             \"postcode\": \"999\",\n" +
                            "                             \"country\": \"IN\"\n" +
                            "                                 },\n" +
                            "                          \"branchCode\": \"225\",\n" +
                            "                          \"name\": \"STANDARD CHARTERED BK\",\n" +
                            "                          \"BIC\": \"SCBLINBBXXX\"\n" +
                            "                                 },\n" +
                            "                          \"clearingSystemId\": \"MCP\",\n" +
                            "                          \"clearingSystemCode\": \"\",\n" +
                            "                          \"branchCode\": \"225\"\n" +
                            "                              },\n" +
                            "                       \"creditor\": {\n" +
                            "                           \"name\": \"test\",\n" +
                            "                           \"identity\": {\n" +
                            "                            \"id\": \"\",\n" +
                            "                            \"identityType\": \"\"\n" +
                            "                                  }\n" +
                            "                                   },\n" +
                            "                       \"creditorAgent\": {\n" +
                            "                             \"financialInstitution\": {\n" +
                            "                                 \"postalAddress\": {\n" +
                            "                                  \"line_1\": \"\",\n" +
                            "                                  \"line_2\": \"\",\n" +
                            "                                  \"line_3\": \"\",\n" +
                            "                                  \"city\": \"\",\n" +
                            "                                  \"state\": \"\",\n" +
                            "                                  \"postcode\": \"\",\n" +
                            "                                  \"country\": \"IN\"\n" +
                            "                                },\n" +
                            "                            \"branchCode\": \"\",\n" +
                            "                            \"name\": \"XXXX\",\n" +
                            "                            \"BIC\": \"SPSL0000001\"\n" +
                            "                                 },\n" +
                            "                           \"clearingSystemId\": \"\",\n" +
                            "                           \"clearingSystemCode\": \"\",\n" +
                            "                           \"branchCode\": \"\"\n" +
                            "                          },\n" +
                            "                        \"creditorAccount\": {\n" +
                            "                              \"id\": \"S119551457071\",\n" +
                            "                              \"identifierType\": \"BBAN\",\n" +
                            "                               \"accountType\": \"CASH\"\n" +
                            "                                     },\n" +
                            "                             \"batchId\": \"A0560302\",\n" +
                            "                                 \"channelId\": \"N0560302\"\n" +
                            "                                    }\n" +
                            "                          }\n" +
                            "                    }\n")},  schema = @Schema(implementation = OpenApiPaymentInstruction.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response paymentRetrieve(
            @Parameter(description = "Reference ID to retrieve payment details", required = true) @PathParam("referenceId") @NotBlank String referenceId);

    @POST
    @Path("/v2/status")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Payment Status Inquiry",
            description = "<p>The Payment Status Inquiry provides the ability to retrieve the payment status for a given set of payment IDs. The payment status returned will be the status at that point in time and the timestamp within the message will indicate the effective time of the status.</p><p>To determine if a payment has completed processing you may poll the API repeatedly with negligible performance impact. Alternatively you may use the Webhook capability to receive push notifications instead of polling.</p>",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "HK,CN,TW,SG,MY,TH,ID,PH,VN,IN,BD,LK,NP,AE,PK,NG,ZA,KE,UG,TZ,CM,GH,ZM,CI,ZW,US,QA,GB,JO,BH"),
            }),
            tags = {"Inquiry"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"statuses\": [\n" +
                            "                        {\n" +
                            "                            \"groupId\": \"APINTST1\",\n" +
                            "                            \"endToEndId\": \"INTERNAL1234567893\",\n" +
                            "                            \"clientIdentifier\": \"INTERNAL1234567893\",\n" +
                            "                            \"referenceId\": \"\",\n" +
                            "                            \"paymentContainerId\": \"9024f276-589f-4564-9cf4-475ecd695dd1\",\n" +
                            "                            \"statusString\": \"Completed\",\n" +
                            "                            \"statusCode\": \"91\",\n" +
                            "                            \"lastAssignee\": \"STS\",\n" +
                            "                            \"reasonCode\": \"64\",\n" +
                            "                            \"reasonIsoCode\": \"\",\n" +
                            "                            \"additionalInformation\": \"Ok, Request completed\",\n" +
                            "                            \"timestamp\": \"2018-12-21T06:57:10.170Z\",\n" +
                            "                            \"originalTransactionId\": \"\",\n" +
                            "                            \"clearingSystemReference\": \"20180827SCBLSGS0BRT4530131\",\n" +
                            "                            \"limitBreachIndicator\": \"\",\n" +
                            "                            \"reasonInformation\": \"Ok, Request completed\",\n" +
                            "                            \"creditorName\": \"\",\n" +
                            "                            \"cheque\": {\n" +
                            "                                \"number\": \"\",\n" +
                            "                                \"clearingDate\": \"2019-01-30\",\n" +
                            "                                \"transactionReference\": \"\",\n" +
                            "                                \"batchNumber\": \"\",\n" +
                            "                            }\n" +
                            "                        }\n" +
                            "                    ]\n" +
                            "                }\n")},  schema = @Schema(implementation = OpenApiPaymentStatuses.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response paymentsStatus(@Parameter(description = "") @Valid OpenApiPaymentClientReferences body);

    @POST
    @Path("/v2/paynow/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Singapore - PayNow Initiation", description = "<p>The PayNow Initiation API exposes the ability to initiate a payment instruction, upon success it returns a payment reference identifier.</p><p>The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Paynow Status Inquiry API which provides the current state of the payment.</p><p>Unlike Payment Initiation API, the PayNow API mandates the population of the proxy identifier. The proxy identifier is the Singapore handle for a beneficiary.</p>",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "SG"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"internalTrackingId\": \"20200401OPENAPI421RNXN6814067\",\n" +
                            "                    \"clientReferenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"referenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"statusString\": \"Pending\",\n" +
                            "                    \"timestamp\": \"2020-05-15T07:53:50.347Z\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response paynowInitiate(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/paynow/initiatewithproxyvalidation")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Singapore - PayNow Proxy with Name Validation", description = "The PayNow Proxy with Name Validation API allows to initiate a Payment Instruction across Instant payments to a Proxy ID or Address after a successful validation of the Payee Name against the Actual Name of the Payee with the creditor bank. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "SG"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"internalTrackingId\": \"20200401OPENAPI421RNXN6814067\",\n" +
                            "                    \"clientReferenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"referenceId\": \"ff3b490361864d8083d4ddcf32734d31\",\n" +
                            "                    \"statusString\": \"Pending\",\n" +
                            "                    \"timestamp\": \"2020-05-15T07:53:50.347Z\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response paynowInitiateProxyValidation(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/paynow/status")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Singapore - PayNow Status Inquiry",
            description = "The PayNow Status Inquiry provides the ability to retrieve the payment status for a given set of payment IDs. The payment status returned will be the status at that point in time and the timestamp within the message will indicate the effective time of the status. To determine if a payment has completed processing you may poll the API repeatedly with negligible performance impact. Alternatively, you may use the Webhook capability to receive push notifications instead of polling.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "SG"),
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"statuses\": [\n" +
                            "                        {\n" +
                            "                            \"groupId\": \"UAASTST1\",\n" +
                            "                            \"endToEndId\": \"SG_Paynow_proxy_VPA_PTV_08260004\",\n" +
                            "                            \"clientIdentifier\": \"SG_Paynow_proxy_VPA_PTV_08260004\",\n" +
                            "                            \"paymentContainerId\": \"37221\",\n" +
                            "                            \"statusString\": \"Completed\",\n" +
                            "                            \"statusCode\": \"69\",\n" +
                            "                            \"lastAssignee\": \"SCPay\",\n" +
                            "                            \"reasonCode\": \"69\",\n" +
                            "                            \"reasonIsoCode\": \"\",\n" +
                            "                            \"timestamp\": \"2020-08-26T05:50:30.041Z\",\n" +
                            "                            \"originalTransactionId\": \"SG_Paynow_proxy_VPA_PTV_08260004\",\n" +
                            "                            \"limitBreachIndicator\": \"\",\n" +
                            "                            \"reasonInformation\": \"Credited to Beneficiary\",\n" +
                            "                            \"instructionIdentifier\": \"40c3c03c-bc84-4895-b709-b3c5957a6b5b\",\n" +
                            "                            \"creditorName\": \"Andy Smith\",\n" +
                            "                            \"cheque\": {},\n" +
                            "                            \"referenceId\": \"SG_Paynow_proxy_VPA_PTV_08260004\",\n" +
                            "                            \"paymentType\": \"IBFT\"\n" +
                            "                        }\n" +
                            "                    ]\n" +
                            "                }\n")},  schema = @Schema(implementation = OpenApiPaymentStatuses.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response paynowStatus(@Parameter(description = "") @Valid OpenApiPaymentStatusRequest body);

    @POST
    @Path("/v2/promptpay/bank-transfer/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Thailand - PromptPay Account Transfer",
            description = "The PromptPay Bank Transfer API exposes the ability to initiate an Instant account to account payment instruction across Thailand, upon successful submission it returns a payment reference identifier. The Payment currency supported - THB. The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "TH")
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response promptPayBankTransferInitiate(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/promptpay/proxy/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Thailand - PromptPay Initiation",
            description = "The PromptPay Proxy Payment Initiation API exposes the ability to initiate a payment instruction, upon successful submission it returns a payment reference identifier. The Payment currency supported - THB. The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, you are required to use the Payment Status Inquiry API which provides the current state of the payment. The PromptPay mandates the population of the proxy identifier. The proxy identifier is the Thailand handle for a beneficiary.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "TH")
            }),
            tags = {"Proxy"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response promptPayProxyPaymentInitiate(@Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/psd2/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "PSD2 Faster Payment Initiation",
            description = "The Payment Initiation API exposes the ability to initiate a payment instruction, upon success it returns a payment reference identifier. The response is a representation or acknowledgment that an instruction was received successfully. To check the status of a specific payment, the client is required to use the Payment Status Inquiry API which provides the current state of the payment.",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "DE,GB,FR"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            })
    Response psd2PaymentInitiate(@Parameter(description = "") @HeaderParam("PreVerified") String preVerified,
            @Parameter(description = "") @Valid OpenApiPaymentInstruction body);

    @POST
    @Path("/v2/payee/initiate")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @Operation(summary = "Payment Initiation with Payee ID",
            description = "The Payment Initiation with Payee ID API provides you the ability to initiate a payment based on a given Payee ID. As a response upon success it returns a payment reference identifier. The response is a representation or acknowledgment that an instruction was received successfully.<br/><br/>",
            extensions = @Extension(properties = {
                    @ExtensionProperty(name = "x-markets", value = "SG,IN"),
            }),
            tags = {"Payment Initiation"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success with data", content = @Content(mediaType = "application/json", examples={@ExampleObject(value = "                {\n" +
                            "                    \"paymentIdentifier\": \"Q4594051\",\n" +
                            "                    \"internalTrackingId\": \"20181018OPENAPI1X3ODEU1111111\",\n" +
                            "                    \"clientReferenceId\": \"INTERNAL1234567893\",\n" +
                            "                    \"referenceId\": \"INTERNAL1234567893\"\n" +
                            "                }")},  schema = @Schema(implementation = OpenApiPaymentId.class))),
                    @ApiResponse(responseCode = "201", description = "Success. Data created", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "202", description = "Success. Data accepted", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "204", description = "Success. No data returned", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid request. Missing or invalid data", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "401", description = "Unauthorised request", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "403", description = "Authentication failed", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "429", description = "Default return code for health status, indicating a warning", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error. This indicates an error in the API server", content = @Content(schema = @Schema(implementation = Void.class))),
                    @ApiResponse(responseCode = "503", description = "System dependency is down or undergoing maintenance. Try again later", content = @Content(schema = @Schema(implementation = Void.class)))
            }
    )
    Response payeesInitiate(@ApiParam(value = "") @HeaderParam("PreVerified") String preVerified,
            @ApiParam(value = "") @Valid OpenApiPayeeInstruction body);
}

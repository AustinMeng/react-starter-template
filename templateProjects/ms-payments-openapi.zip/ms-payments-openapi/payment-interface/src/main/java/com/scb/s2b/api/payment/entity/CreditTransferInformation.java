package com.scb.s2b.api.payment.entity;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class CreditTransferInformation {

    @Builder.Default
    private AccountHeader creditorAccount = new AccountHeader();

    @Builder.Default
    private BranchAndInstituteHeader creditorAgent = new BranchAndInstituteHeader();

    @Builder.Default
    private DenominatedAmount amount = DenominatedAmount.ZERO;

    @Builder.Default
    private PartyIdentifier creditor = new PartyIdentifier();

}

package com.scb.s2b.api.payment.entity;


import java.io.Serializable;
import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class Contact implements Serializable {

    private String namePrefix;

    private String name;

    private String phoneNumber;

    private String mobileNumber;

    private String faxNumber;

    private String emailAddress;

    private String other;

}

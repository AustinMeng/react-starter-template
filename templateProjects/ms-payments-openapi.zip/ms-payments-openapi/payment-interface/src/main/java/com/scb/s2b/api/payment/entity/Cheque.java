package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class Cheque {

    private String number;

    private LocalDate clearingDate;

    private String transactionReference;

    private String batchNumber;

}

package com.scb.s2b.api.payment.entity;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Builder
@EqualsAndHashCode
public class DenominatedAmount implements Serializable {

    public static final DenominatedAmount ZERO = new DenominatedAmount("", BigDecimal.ZERO, "");

    private String currencyCode;

    private BigDecimal amount;

    private String priority;

}

package com.scb.s2b.api.payment.entity;


public class AccountIdentifier {

    public enum IdentifierType {BBAN, IBAN, Other}

    private String identifier;
    private IdentifierType identifierType;
    private String identifierScheme;

    public AccountIdentifier() {
    }

    public AccountIdentifier(String identifier, IdentifierType identifierType,
            String identifierScheme) {
        this.identifier = identifier;
        this.identifierType = identifierType;
        this.identifierScheme = identifierScheme;
    }

    public String getIdentifier() {
        return identifier;
    }

    public IdentifierType getIdentifierType() {
        return identifierType;
    }

    public String getIdentifierScheme() {
        return identifierScheme;
    }
}

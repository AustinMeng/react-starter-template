package com.scb.s2b.api.payment.entity;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
public class MetaTags {

    private String lookupResultReferenceId;

}


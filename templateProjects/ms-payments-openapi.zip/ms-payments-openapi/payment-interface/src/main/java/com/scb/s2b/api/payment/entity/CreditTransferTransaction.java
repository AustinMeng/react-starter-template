package com.scb.s2b.api.payment.entity;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class CreditTransferTransaction implements ExternalCodes {

    private String endToEndId;

    private String trackingId;

    private boolean isProxyPayment;

    private String proxyLookupRef;

    @Builder.Default
    private PaymentType paymentType = new PaymentType();

    @Builder.Default
    private PaymentAmount amount = PaymentAmount.ZERO;

    @Builder.Default
    private ExchangeRate exchangeRate = ExchangeRate.ZERO;

    private ChargeBearerType chargeBearer;

    @Builder.Default
    private ChequeInstruction chequeInstruction = new ChequeInstruction();

    @Builder.Default
    private PartyIdentifier ultimateDebtor = new PartyIdentifier();

    @Builder.Default
    private BranchAndInstituteHeader intermediateAgent1 = new BranchAndInstituteHeader();

    @Builder.Default
    private AccountHeader intermediateAgentAccount1 = new AccountHeader();

    @Builder.Default
    private BranchAndInstituteHeader intermediateAgent2 = new BranchAndInstituteHeader();

    @Builder.Default
    private AccountHeader intermediateAgentAccount2 = new AccountHeader();

    @Builder.Default
    private BranchAndInstituteHeader intermediateAgent3 = new BranchAndInstituteHeader();

    @Builder.Default
    private AccountHeader intermediateAgentAccount3 = new AccountHeader();

    @Builder.Default
    private BranchAndInstituteHeader creditorAgent = new BranchAndInstituteHeader();

    @Builder.Default
    private AccountHeader creditorAgentAccount = new AccountHeader();

    @Builder.Default
    private PartyIdentifier creditor = new PartyIdentifier();

    @Builder.Default
    private PartyInfoExtension creditorExtension = new PartyInfoExtension();

    @Builder.Default
    private AccountHeader creditorAccount = new AccountHeader();

    @Builder.Default
    private AccountHeader ultimateCreditor = new AccountHeader();

    @Builder.Default
    private List<InstructionForCreditAgent> instructionsForCreditorAgent = new ArrayList<>();

    private String instructionsForDebtorAgent;

    @Builder.Default
    private PurposeCode purposeCode = PurposeCode.OTHR;

    @Builder.Default
    private RegulatoryReporting regulatoryReporting = new RegulatoryReporting();

    @Builder.Default
    private Tax tax = new Tax();

    @Builder.Default
    private RemittanceDetail remittanceInformation = new RemittanceDetail();

    @Builder.Default
    private RemittanceDetailExtension remittanceInformationExtension = new RemittanceDetailExtension();

    @Builder.Default
    private RemittanceDetail relatedRemittanceInformation = new RemittanceDetail();

    @Builder.Default
    private RemittanceDetail relatedRemittanceInformationExtension = new RemittanceDetail();

    @Builder.Default
    private OnBehalfOf onBehalfOf = new OnBehalfOf();

    private String serviceType;

    private String subPaymentType;

    private String proxyType;

    private String customerType;

    public boolean hasTax() {
        return tax != null && tax.getTotalTaxAmount()!=null
                && tax.getTotalTaxAmount() != DenominatedAmount.ZERO;
    }

    public Boolean isProxyCreditor() {
        return creditor.getPartyIdentity().getId() != null &&
               !creditor.getPartyIdentity().getId().isEmpty();
    }

    public Boolean isOnBehalfOf() {
        return onBehalfOf != null && onBehalfOf.getName() != null &&
                !onBehalfOf.getName().isEmpty();
    }

    public Boolean hasRemittanceInformation(){
        return remittanceInformation.getUnstructured() != null;
    }
}

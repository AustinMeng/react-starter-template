package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class LineDetail implements ExternalCodes {

    private String proprietaryIdentificationType;

    private DocumentLineType identificationType;

    private String number;

    private LocalDate relatedDate;

    private String description;

    private ReferredDocumentAmount amount = new ReferredDocumentAmount();

}

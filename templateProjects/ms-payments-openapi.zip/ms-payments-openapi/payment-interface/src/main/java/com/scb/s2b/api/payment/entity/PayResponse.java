package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PayResponse {
    private String groupid;
    private String countrycode;
    private String customerref;
    private String status;
    private String statusdesc;
    private String batchref;
    private String paymentref;
    private String requiredexecutiondate;
    private String currencycode;
    private String fxrate;
    private String statusdescaddt;
    private String checknumber;
    private String paymenttype;
    private String uetr;
    private String creditorname;
    private String channelpayRef;
    private String substatuscode;
    private String sourceofstatus;
    private String botxnref;
    private String fxcontractno;
    private String customerfxrate;
    private String debitcurr;
    private String debitamount;
}

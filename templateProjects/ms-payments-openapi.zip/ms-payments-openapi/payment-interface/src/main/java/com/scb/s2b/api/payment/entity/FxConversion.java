package com.scb.s2b.api.payment.entity;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class FxConversion {

    private String fxType;

    private String quoteRefId;

    private BigDecimal quoteRefFXRate;

    private String contractId;

    private BigDecimal contractFXRate;

    private BigDecimal contractFXAmount;

    private String fxRateIndicator;

    private String deliveryOption;

    private String dealerName;

}

package com.scb.s2b.api.payment.entity;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@Builder
public class RemittanceDetailExtension {

    private String unstructured;

    @Builder.Default
    private StructuredRemittance structured = new StructuredRemittance();

    @Builder.Default
    private List<String> detailsLineLocalLanguage = new ArrayList<>();

}

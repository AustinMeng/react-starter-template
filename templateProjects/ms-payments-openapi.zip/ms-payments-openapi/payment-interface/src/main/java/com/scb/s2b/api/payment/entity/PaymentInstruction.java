package com.scb.s2b.api.payment.entity;


import com.scb.s2b.api.payment.entity.ExternalCodes.ChargeBearerType;
import com.scb.s2b.api.payment.entity.ExternalCodes.PaymentMethod;
import com.scb.s2b.api.payment.entity.ExternalCodes.PaymentTypePreference;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class PaymentInstruction {

    private PaymentSystem paymentSystem;
    private String requestId;
    private String countryCode;
    private String messageSender;

    private String groupId;
    private String customerId;
    private String purpose;
    private String purposeGroup;
    private String receivingCountryPurpose;

    private boolean beneEnquiryRequired;
    private boolean proxyEnquiryRequired;
    private boolean creditorNameValidRequired;
    private String selfOrdering;
    private String paymentSubProductType;
    private String chargeAccount;
    private Document document;
    private IntermediaryAgent intermediaryAgent;
    private FxConversion fxConversion;

    @Builder.Default
    private DenominatedAmount amount = new DenominatedAmount();

    @Builder.Default
    private AccountHeader debitAccount = new AccountHeader();

    @Builder.Default
    private BranchAndInstituteHeader debitAgent = new BranchAndInstituteHeader();

    @Builder.Default
    private PartyIdentifier debtor = new PartyIdentifier();

    @Builder.Default
    private Meta meta = new Meta();

    @Builder.Default
    private List<CreditTransferTransaction> creditTransferTransactionList = new ArrayList<>();

    private ChargeBearerType chargeBearer;

    private String clientReferenceId;
    private String paymentInfIdentifier;
    private String instructionsForDebtorAgent;

    @Builder.Default
    private PaymentOrigin paymentOrigin = new PaymentOrigin();

    @Builder.Default
    private PaymentTypePreference paymentTypePreference = PaymentTypePreference.Explicit;

    @Builder.Default
    private PaymentType paymentType = new PaymentType();

    private PaymentMethod paymentMethod;

    private boolean preVerified;

    @Builder.Default
    private OnBehalfOf onBehalfOf = new OnBehalfOf();

    private LocalDate requiredExecutionDate;

    private String datePriority;

    private String channelId;
    private String batchId;
    private String consentProvider;

    @Builder.Default
    private RemittanceDetail remittanceInfo = new RemittanceDetail();

    private String sourceOfFund;

    private Integer batchCount;

    private RegulatoryReporting regulatoryReporting;

    @Builder.Default
    private Instant timestamp = Instant.now();

    @Builder.Default
    private Instant paymentTimestamp = Instant.now();

    private String discountType;
    private String vatType;

    @Builder.Default
    private BigDecimal vatAmount = BigDecimal.ZERO;

    private String whtPrintingLocation;
    private String whtFormID;
    private String whtTaxID;
    private String whtRefNo;

    @Builder.Default
    private List<WHT> wht = new ArrayList<>();

    @Builder.Default
    private BigDecimal discountAmount = BigDecimal.ZERO;

    @Builder.Default
    private List<Invoice> invoice = new ArrayList<>();

}

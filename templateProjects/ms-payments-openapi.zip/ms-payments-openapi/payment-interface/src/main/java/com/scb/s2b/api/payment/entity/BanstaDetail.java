package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class BanstaDetail {

    private String customerRef;
    private String batchRef;
    private String paymentRef;
    private String status;
    private String statusDesc;
    private String statusDescAddt;
    private String creditorName;
    private String checkNumber;
    private String paymentType;
    private String requiredExecutionDate;
    private String currencyCode;
    private String debtorAccountCurrency;
    private String debtorAccountId;
    private PostalAddress postalAddress;
    private String creditorAccountId;
    private String fxRate;
}

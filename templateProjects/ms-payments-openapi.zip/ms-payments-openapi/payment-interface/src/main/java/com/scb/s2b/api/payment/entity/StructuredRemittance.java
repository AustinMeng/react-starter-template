package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class StructuredRemittance {

    @Builder.Default
    private ReferredDocumentInformation referredDocumentInformation = new ReferredDocumentInformation();

    @NonNull
    @Builder.Default
    private ReferredDocumentAmount referredDocumentAmount = new ReferredDocumentAmount();

    private String creditorReferenceInformation;

    private String creditorReferenceType;

    private String creditorReferenceId;

    private String creditorReferenceDetails;

    @Builder.Default
    private PartyIdentifier invoicer = new PartyIdentifier();

    @Builder.Default
    private PartyIdentifier invoicee = new PartyIdentifier();

    @Builder.Default
    private TaxRemittance taxRemittance = new TaxRemittance();

    @Builder.Default
    private Garnishment garnishmentRemittance = new Garnishment();

    private String additionalRemittanceInformation;

    public ReferredDocumentAmount getReferredDocumentAmount() {
        return referredDocumentAmount == null ? new ReferredDocumentAmount()
                : referredDocumentAmount;
    }

}

package com.scb.s2b.api.payment.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class PartyInfoExtension implements Serializable {

    @Builder.Default
    private List<String> addressLinesLL = new ArrayList<>();

    @Builder.Default
    private List<String> emailLinesLL = new ArrayList<>();

    @Builder.Default
    private List<String> nameLL = new ArrayList<>();

}

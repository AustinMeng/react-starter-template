package com.scb.s2b.api.payment.entity;

import lombok.*;

import java.time.LocalDate;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
public class ChequeInstruction implements ExternalCodes {

    @Builder.Default
    private ChequeType chequeType = ChequeType.BCHQ;

    private String chequeNumber;

    @Builder.Default
    private PartyIdentifier chequeFrom = new PartyIdentifier();

    @Builder.Default
    private ChequeDeliveryMethod deliveryMethod = ChequeDeliveryMethod.MLCD;

    @Builder.Default
    private PartyIdentifier deliverTo = new PartyIdentifier();

    @Builder.Default
    private InstructionPriority instructionPriority = InstructionPriority.NORM;

    private LocalDate chequeMaturityDate;

    private String formsCode;

    private String memoField;

    private String printLocation;

    private String signature;

    private String regionalClearingZone;

}

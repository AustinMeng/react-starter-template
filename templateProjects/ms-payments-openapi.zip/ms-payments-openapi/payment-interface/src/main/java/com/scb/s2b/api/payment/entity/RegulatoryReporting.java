package com.scb.s2b.api.payment.entity;

import com.scb.s2b.api.openapi.payment.v2.model.OpenApiInstructions;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@Builder
public class RegulatoryReporting {

    @Builder.Default
    private List<OpenApiInstructions> instructions = new ArrayList<>();

    private String bopCode1;

    private String bopCode2;

    private String natureOfPayment;

    private String residentCountry;

    private String transactionRemarks1;

    private String transactionRemarks2;

    private String currency1;

    private BigDecimal amount1;

    private String currency2;

    private BigDecimal amount2;

    private String referenceId;

}

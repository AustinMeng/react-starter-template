package com.scb.s2b.api.payment.entity;


import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
public class TppConsentDetails {

    private String tppId;

    private String consentId;

    private String groupId;

    private String tppGroupId;

    public Boolean isValid() {
        return isNotBlank(tppId) && isNotBlank(consentId) && isNotBlank(groupId) && isNotBlank(tppGroupId);
    }

    public static TppConsentDetails validDetails(String tppId, String tppGroupId, String consentId, String groupId) {
        return Optional.of(new TppConsentDetails(tppId, consentId, groupId, tppGroupId))
                .filter(TppConsentDetails::isValid).orElse(new TppConsentDetails());
    }
}

package com.scb.s2b.api.payment.entity;

import com.google.common.collect.ComparisonChain;
import java.math.BigInteger;
import java.time.Instant;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
public class PaymentTransactionStatus implements Comparable<PaymentTransactionStatus> {

    public enum Status {
        Pending(0),
        Rejected(2),
        Completed(4),
        Returned(8),
        Processed(16);

        private final int code;

        Status(int code) {
            this.code = code;
        }

        public String code() {
            return String.valueOf(code);
        }
    }

    private String messageId;

    @Setter
    private String groupId;

    @Setter
    private String clientReferenceId;

    private String endToEndId;

    @Setter
    private String trackingId;

    @Setter
    private BigInteger paymentTxnId;

    private String statusString;

    private String statusCode;

    private LocalDate valueDate;

    private String lastAssignee;

    private String reasonCode;

    private String reasonIsoCode;

    private String additionalInformation;

    @Builder.Default
    private Instant timestamp = Instant.now();

    private String clearingSystemReference;

    private String limitBreachIndicator;

    private String reasonInformation;

    @Builder.Default
    private Cheque cheque = new Cheque();

    private String creditorName;

    private String paymentType;

    private String countryCode;

    private LocalDate requiredExecutionDate;

    private String amountCurrencyCode;

    private String debtorAccountCurrency;

    private String debtorAccountId;

    private String creditorAccountId;

    private String contractFXRate;

    private PostalAddress creditorAddress;

    private String tppGroupId;

    private String fxContractNo;

    private String customerFxRate;

    private String debitAmount;

    public static String standardizeStatusCode(String statusCode) {
        String sc;
        switch (statusCode) {
            case "F1":
                sc = "64";
                break;
            case "F2":
                sc = "48";
                break;
            case "F4":
                sc = "69";
                break;
            case "F5":
            case "F6":
                sc = "44";
                break;
            default:
                sc = "62";
                break;
        }

        return sc;
    }

    public static String scpayReasonCodeToStatusString(String status) {
        switch (status) {
            case "64":
                return Status.Processed.name();
            case "69":
                return Status.Completed.name();
            case "44":
            case "72":
            case "102":
                return Status.Rejected.name();
            case "48":
                return Status.Returned.name();
            default:
                return Status.Pending.name();
        }
    }

    public String getGroupId() {
        return this.groupId;
    }

    @Override
    public int compareTo(PaymentTransactionStatus o) {
        return ComparisonChain.start()
                .compare(statusScore(this.getStatusString()), statusScore(o.getStatusString()))
                .compare(this.getTimestamp().toEpochMilli(), o.getTimestamp().toEpochMilli())
                .result();
    }

    static int statusScore(String statusString) {
        if (Status.Processed.name().equalsIgnoreCase(statusString)) {
            return 1;
        }
        if (Status.Completed.name().equalsIgnoreCase(statusString)) {
            return 2;
        }
        if (Status.Returned.name().equalsIgnoreCase(statusString)) {
            return 4;
        }
        if (Status.Rejected.name().equalsIgnoreCase(statusString)) {
            return 3;
        }

        return 0;
    }
}

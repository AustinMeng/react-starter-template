package com.scb.s2b.api.payment.entity;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum PaymentSystem {
    SCPAY("SCPAY"),
    CCS("CCS"),
    UNKNOWN("UNKNOWN"),
    H2H("H2H");

    private static final Map<String, PaymentSystem> sysMap;
    private final String system;

    static {
        sysMap = Stream.of(values()).collect(Collectors.toMap(PaymentSystem::getSystem, t -> t));
    }

    PaymentSystem(String system) {
        this.system = system;
    }

    public static PaymentSystem fromSystem(String system) {
        return sysMap.getOrDefault(system, UNKNOWN);
    }

    public String getSystem() {
        return system;
    }

}

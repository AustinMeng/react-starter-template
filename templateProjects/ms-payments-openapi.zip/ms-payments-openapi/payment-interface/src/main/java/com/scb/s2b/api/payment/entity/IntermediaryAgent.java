package com.scb.s2b.api.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class IntermediaryAgent {

    private String instructionCode;

    private String instructionDescription;

    private FinancialInstitution financialInstitution;
}

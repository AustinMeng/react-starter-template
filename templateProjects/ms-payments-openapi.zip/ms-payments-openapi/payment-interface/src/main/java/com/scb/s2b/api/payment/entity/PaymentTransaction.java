package com.scb.s2b.api.payment.entity;

import java.util.ArrayList;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
public class PaymentTransaction implements ExternalCodes {

    private PaymentSystem paymentSystem;

    private boolean beneEnquiryRequired;

    @Setter
    private boolean beneEnquiry;

    @Setter
    private boolean beneEnquiryDone;

    private boolean proxyEnquiryRequired;

    @Setter
    private boolean proxyEnquiry;

    @Setter
    private boolean proxyEnquiryDone;

    private boolean creditorNameValidRequired;

    @Setter
    private String proxyLookupId;

    private String countryCode;

    private String requestId;

    private String groupId;

    private String clientReferenceId;

    private String paymentInfIdentifier;

    @Setter
    private String messageId;

    private String messageSender;

    @Setter
    private String batchId;

    private boolean batchBooking;

    @Builder.Default
    private Meta meta = new Meta();

    private PaymentMethod paymentMethod;

    private long numberOfTransactions;

    private String customerId;

    @Builder.Default
    private BigDecimal controlSum = BigDecimal.ZERO;

    private String currency;

    private PaymentTypePreference paymentTypePreference;

    @Builder.Default
    private PaymentType paymentType = new PaymentType();

    private LocalDate requiredExecutionDate;

    private LocalDate poolAdjustmentDate;

    @Builder.Default
    private PartyIdentifier debtor = new PartyIdentifier();

    @Builder.Default
    private AccountHeader debtorAccount = new AccountHeader();

    @Builder.Default
    private BranchAndInstituteHeader debtorAgent = new BranchAndInstituteHeader();

    @Builder.Default
    private AccountHeader debtorAgentAccount = new AccountHeader();

    private String debtorAgentInstructions;

    @Builder.Default
    private PartyIdentifier ultimateDebtor = new PartyIdentifier();

    private ChargeBearerType chargeBearer;

    @Builder.Default
    private AccountHeader chargersAccount = new AccountHeader();

    @Builder.Default
    private BranchAndInstituteHeader chargersAccountAgent = new BranchAndInstituteHeader();

    @Builder.Default
    private List<CreditTransferTransaction> creditTransferTransactions = new ArrayList<>();

    private String consentProvider;

    @Builder.Default
    private Instant timestamp = Instant.now();

    @Builder.Default
    private Instant headerTimestamp = Instant.now();

    @Builder.Default
    private Instant paymentTimestamp = Instant.now();

    private String purposeCode;

    private String sourceOfFund;

    private String purposeGroup;

    private String receivingCountryPurpose;

    private String selfOrdering;

    private String paymentSubProductType;

    private String chargeAccount;

    private Document document;

    private IntermediaryAgent intermediaryAgent;

    private FxConversion fxConversion;

    private String datePriority;

    private Integer batchCount;

    private RegulatoryReporting regulatoryReporting;

    private String discountType;
    private String vatType;

    @Builder.Default
    private BigDecimal vatAmount = BigDecimal.ZERO;

    private String whtPrintingLocation;
    private String whtFormID;
    private String whtTaxID;
    private String whtRefNo;

    @Builder.Default
    private List<WHT> wht = new ArrayList<>();

    @Builder.Default
    private BigDecimal discountAmount = BigDecimal.ZERO;

    @Builder.Default
    private List<Invoice> invoice = new ArrayList<>();

}

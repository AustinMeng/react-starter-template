INSERT INTO PAYMENT.META_DESCRIPTOR
(ID, GROUP_ID, NAME, VERSION, CHANGE_REFERENCE, COMMENTS, FROZEN_VALUES, PREVIOUS_VERSION_ID, "TIMESTAMP")
VALUES('30d7ae79-63ea-4889-81a6-59f355a9bae4', 'SYSTEM', 'scb.internal.fast.cliq.paymentProperties', 1, 'CRQ000001499088', 'JORDAN Payment Properties', '{"paymentProperties":{"countries":{"JO":{"cities":["AMM"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"AMM","paymentMethod":"TRF","supportedPaymentTypes":["IBFT"]}}}}', NULL, CURRENT_TIMESTAMP);

INSERT INTO PAYMENT.META_DESCRIPTOR
(ID, GROUP_ID, NAME, VERSION, CHANGE_REFERENCE, COMMENTS, FROZEN_VALUES, PREVIOUS_VERSION_ID, "TIMESTAMP")
VALUES('5655c5a7-c660-4ffd-afe6-e7993bd06e1d', 'SYSTEM', 'scb.internal.fast.cips.paymentProperties', 1, 'CRQ000001482841', 'CIPS Fast Payment Properties', '{"paymentProperties":{"countries":{"NP":{"cities":["KTM"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KTM","paymentMethod":"TRF","supportedPaymentTypes": ["IBFT"]}}}}', NULL, CURRENT_TIMESTAMP);

INSERT INTO PAYMENT.META_DESCRIPTOR
(ID, GROUP_ID, NAME, VERSION, CHANGE_REFERENCE, COMMENTS, FROZEN_VALUES, PREVIOUS_VERSION_ID, "TIMESTAMP")
VALUES('6f2ed548-9708-45b3-bef9-7ceadc0fcce2', 'SYSTEM', 'scb.internal.paymentProperties', 8, 'CRQ000001499160', 'Supporting Payment Centers',
to_clob('{"paymentProperties":{"countries":{"BD":{"cities":["DHA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DHA","paymentMethod":"TRF"},')||
to_clob('"CN":{"cities":["SHA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SHA","paymentMethod":"TRF"},')||
to_clob('"HK":{"cities":["HKG"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HKG","paymentMethod":"TRF"},')||
to_clob('"ID":{"cities":["JKT"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"JKT","paymentMethod":"TRF"},')||
to_clob('"IN":{"cities":["BOM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BOM","paymentMethod":"TRF"},')||
to_clob('"KE":{"cities":["NBO"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NBO","paymentMethod":"TRF"},')||
to_clob('"UG":{"cities":["KLA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KLA","paymentMethod":"TRF"},')||
to_clob('"TZ":{"cities":["DAR"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DAR","paymentMethod":"TRF"},')||
to_clob('"GB":{"cities":["LDN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LDN","paymentMethod":"TRF"},')||
to_clob('"US":{"cities":["NYC"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NYC","paymentMethod":"TRF"},')||
to_clob('"JO":{"cities":["AMM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"AMM","paymentMethod":"TRF"},')||
to_clob('"BH":{"cities":["MAN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"MAN","paymentMethod":"TRF"},')||
to_clob('"AE":{"cities":["DXB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DXB","paymentMethod":"TRF"},')||
to_clob('"LK":{"cities":["CMB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"CMB","paymentMethod":"TRF"},')||
to_clob('"MY":{"cities":["KUL"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KUL","paymentMethod":"TRF"},')||
to_clob('"TH":{"cities":["BKK"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKK","paymentMethod":"TRF"},')||
to_clob('"ZW":{"cities":["GWE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GWE","paymentMethod":"TRF"},')||
to_clob('"ZM":{"cities":["LUN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LUN","paymentMethod":"TRF"},')||
to_clob('"TW":{"cities":["TPE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"TPE","paymentMethod":"TRF"},')||
to_clob('"VN":{"cities":["HAN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HAN","paymentMethod":"TRF"},')||
to_clob('"NP":{"cities":["KTM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KTM","paymentMethod":"TRF"},')||
to_clob('"PK":{"cities":["KHI"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KHI","paymentMethod":"TRF"},')||
to_clob('"ZA":{"cities":["JNB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"JNB","paymentMethod":"TRF"},')||
to_clob('"CM":{"cities":["DLA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DLA","paymentMethod":"TRF"},')||
to_clob('"GH":{"cities":["ACC"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"ACC","paymentMethod":"TRF"},')||
to_clob('"CI":{"cities":["ABJ"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"ABJ","paymentMethod":"TRF"},')||
to_clob('"NG":{"cities":["LOS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LOS","paymentMethod":"TRF"},')||
to_clob('"DE":{"cities":["FFT"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"FFT","paymentMethod":"TRF"},')||
to_clob('"SG":{"cities":["SIN"],"system":"CCS","chargerBearer":"SLEV","categoryPurpose":"OTHR","defaultCity":"SIN","paymentMethod":"TRF"},')||
to_clob('"PH":{"cities":["MNL"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"MNL","paymentMethod":"TRF"},')||
to_clob('"SA":{"cities":["RYD"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"RYD","paymentMethod":"TRF"},')||
to_clob('"QA":{"cities":["DOH"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DOH","paymentMethod":"TRF"},')||
to_clob('"SL":{"cities":["FRA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"FRA","paymentMethod":"TRF"},')||
to_clob('"GM":{"cities":["BJL"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BJL","paymentMethod":"TRF"},')||
to_clob('"MU":{"cities":["MRU"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"MRU","paymentMethod":"TRF"},')||
to_clob('"JP":{"cities":["SCB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SCB","paymentMethod":"TRF"},')||
to_clob('"KR":{"cities":["KFB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KFB","paymentMethod":"TRF"},')||
to_clob('"BW":{"cities":["GBE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GBE","paymentMethod":"TRF"},')||
to_clob('"BN":{"cities":["BKS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKS","paymentMethod":"TRF"}}}}'),
'64af44c5-2e37-4126-a361-0891f69328c1', CURRENT_TIMESTAMP);

INSERT INTO PAYMENT.META_DESCRIPTOR
(ID, GROUP_ID, NAME, VERSION, CHANGE_REFERENCE, COMMENTS, FROZEN_VALUES, PREVIOUS_VERSION_ID, "TIMESTAMP")
VALUES('011bc782-0201-4a53-b7f5-3bdb22023332', 'SYSTEM', 'scb.internal.crossborder.paymentProperties', 6, 'CRQ000001499160', 'SYSTEM Payment Properties',
to_clob('{"paymentProperties":{"countries":{"CN":{"cities":["SHA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SHA","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"HK":{"cities":["HKG"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HKG","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"IN":{"cities":["BOM"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BOM","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"GB":{"cities":["LDN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LDN","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"US":{"cities":["NYC"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NYC","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"AE":{"cities":["DXB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DXB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"TH":{"cities":["BKK"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKK","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"TW":{"cities":["TPE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"TPE","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"VN":{"cities":["HAN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HAN","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"NP":{"cities":["KTM"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KTM","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"DE":{"cities":["FFT"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"FFT","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"SG":{"cities":["SIN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SIN","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"BH":{"cities":["BHD"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BHD","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"KE":{"cities":["NBO"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NBO","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"NG":{"cities":["LOS"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LOS","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"ZA":{"cities":["JNB"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"JNB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"ZW":{"cities":["GWE"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GWE","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"SA":{"cities":["RYD"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"RYD","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"QA":{"cities":["DOH"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DOH","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"SL":{"cities":["FRA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"FRA","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"GM":{"cities":["BJL"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BJL","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"MU":{"cities":["MRU"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"MRU","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"JP":{"cities":["SCB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SCB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"KR":{"cities":["KFB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KFB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"BW":{"cities":["GBE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GBE","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"BN":{"cities":["BKS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKS","paymentMethod":"TRF","inferPaymentType":false}}}}'),
'56c497d4-399f-43d2-abf7-d5b2f1302a55', CURRENT_TIMESTAMP);

INSERT INTO PAYMENT.META_DESCRIPTOR
(ID, GROUP_ID, NAME, VERSION, CHANGE_REFERENCE, COMMENTS, FROZEN_VALUES, PREVIOUS_VERSION_ID, "TIMESTAMP")
VALUES('c3663b99-e8e7-4257-a84b-0e27de383091', 'SYSTEM', 'scb.internal.payroll.paymentProperties', 4, 'CRQ000001499160', 'SYSTEM Payment Properties for Payroll',
to_clob('{"paymentProperties":{"countries":{"HK":{"cities":["HKG"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HKG","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"SG":{"cities":["SIN"],"system":"CCS","chargerBearer":"SLEV","categoryPurpose":"OTHR","defaultCity":"SIN","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"MY":{"cities":["KUL"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KUL","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"IN":{"cities":["BOM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BOM","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"AE":{"cities":["DXB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DXB","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"KE":{"cities":["NBO"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NBO","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"BH":{"cities":["BHD"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BHD","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"NG":{"cities":["LOS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LOS","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"ZA":{"cities":["JNB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"JNB","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"ZW":{"cities":["GWE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GWE","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"JP":{"cities":["SCB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SCB","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"KR":{"cities":["KFB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KFB","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"BW":{"cities":["GBE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GBE","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]},')||
to_clob('"BN":{"cities":["BKS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKS","paymentMethod":"TRF","inferPaymentType":false,"supportedPaymentTypes":["PAY","XPAY"]}}}}'),
'd2cb3a81-b4c8-4d17-8ed0-bc26dbc59473', CURRENT_TIMESTAMP);

INSERT INTO PAYMENT.META_DESCRIPTOR
(ID, GROUP_ID, NAME, VERSION, CHANGE_REFERENCE, COMMENTS, FROZEN_VALUES, PREVIOUS_VERSION_ID, "TIMESTAMP")
VALUES('9795b062-33b4-4677-bb9d-3bfbd16558b6', 'SYSTEM', 'scb.internal.bulk.paymentProperties', 2, 'CRQ000001499160', 'Bulk Payment Properties',
to_clob('{"paymentProperties":{"countries":{"BD":{"cities":["DHA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DHA","paymentMethod":"TRF"},')||
to_clob('"CN":{"cities":["SHA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SHA","paymentMethod":"TRF"},')||
to_clob('"HK":{"cities":["HKG"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HKG","paymentMethod":"TRF"},')||
to_clob('"ID":{"cities":["JKT"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"JKT","paymentMethod":"TRF"},')||
to_clob('"IN":{"cities":["BOM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BOM","paymentMethod":"TRF"},')||
to_clob('"KE":{"cities":["NBO"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NBO","paymentMethod":"TRF"},')||
to_clob('"UG":{"cities":["KLA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KLA","paymentMethod":"TRF"},')||
to_clob('"TZ":{"cities":["DAR"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DAR","paymentMethod":"TRF"},')||
to_clob('"GB":{"cities":["LDN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LDN","paymentMethod":"TRF"},')||
to_clob('"US":{"cities":["NYC"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NYC","paymentMethod":"TRF"},')||
to_clob('"JO":{"cities":["AMM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"AMM","paymentMethod":"TRF"},')||
to_clob('"BH":{"cities":["MAN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"MAN","paymentMethod":"TRF"},')||
to_clob('"AE":{"cities":["DXB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DXB","paymentMethod":"TRF"},')||
to_clob('"LK":{"cities":["CMB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"CMB","paymentMethod":"TRF"},')||
to_clob('"MY":{"cities":["KUL"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KUL","paymentMethod":"TRF"},')||
to_clob('"TH":{"cities":["BKK"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKK","paymentMethod":"TRF"},')||
to_clob('"ZW":{"cities":["GWE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GWE","paymentMethod":"TRF"},')||
to_clob('"ZM":{"cities":["LUN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LUN","paymentMethod":"TRF"},')||
to_clob('"TW":{"cities":["TPE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"TPE","paymentMethod":"TRF"},')||
to_clob('"VN":{"cities":["HAN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HAN","paymentMethod":"TRF"},')||
to_clob('"NP":{"cities":["KTM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KTM","paymentMethod":"TRF"},')||
to_clob('"PK":{"cities":["KHI"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KHI","paymentMethod":"TRF"},')||
to_clob('"ZA":{"cities":["JNB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"JNB","paymentMethod":"TRF"},')||
to_clob('"CM":{"cities":["DLA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DLA","paymentMethod":"TRF"},')||
to_clob('"GH":{"cities":["ACC"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"ACC","paymentMethod":"TRF"},')||
to_clob('"CI":{"cities":["ABJ"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"ABJ","paymentMethod":"TRF"},')||
to_clob('"NG":{"cities":["LOS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LOS","paymentMethod":"TRF"},')||
to_clob('"DE":{"cities":["FFT"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"FFT","paymentMethod":"TRF"},')||
to_clob('"SG":{"cities":["SIN"],"system":"CCS","chargerBearer":"SLEV","categoryPurpose":"OTHR","defaultCity":"SIN","paymentMethod":"TRF"},')||
to_clob('"JP":{"cities":["SCB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SCB","paymentMethod":"TRF"},')||
to_clob('"KR":{"cities":["KFB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KFB","paymentMethod":"TRF"},')||
to_clob('"BW":{"cities":["GBE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GBE","paymentMethod":"TRF"},')||
to_clob('"BN":{"cities":["BKS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKS","paymentMethod":"TRF"}}}}'),
'4fb63549-bdfe-4907-b9ae-0b4159bf6585', CURRENT_TIMESTAMP);

COMMIT;
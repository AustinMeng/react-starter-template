INSERT INTO PAYMENT.META_DESCRIPTOR
(ID, GROUP_ID, NAME, VERSION, CHANGE_REFERENCE, COMMENTS, FROZEN_VALUES, PREVIOUS_VERSION_ID, "TIMESTAMP")
VALUES('06aaf207-2707-4819-b800-abae4adba635', 'SYSTEM', 'scb.internal.crossborder.paymentProperties', 7, 'CRQ000001513859', 'SYSTEM Payment Properties',
to_clob('{"paymentProperties":{"countries":{"CN":{"cities":["SHA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SHA","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"HK":{"cities":["HKG"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HKG","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"IN":{"cities":["BOM"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BOM","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"GB":{"cities":["LDN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LDN","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"US":{"cities":["NYC"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NYC","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"AE":{"cities":["DXB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DXB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"TH":{"cities":["BKK"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKK","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"TW":{"cities":["TPE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"TPE","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"VN":{"cities":["HAN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"HAN","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"NP":{"cities":["KTM"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KTM","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"DE":{"cities":["FFT"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"FFT","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"SG":{"cities":["SIN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SIN","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"BH":{"cities":["BHD"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BHD","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"KE":{"cities":["NBO"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"NBO","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"NG":{"cities":["LOS"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LOS","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"ZA":{"cities":["JNB"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"JNB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"ZW":{"cities":["GWE"],"system":"SCPAY","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GWE","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"SA":{"cities":["RYD"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"RYD","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"QA":{"cities":["DOH"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DOH","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"SL":{"cities":["FRA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"FRA","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"GM":{"cities":["BJL"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BJL","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"MU":{"cities":["MRU"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"MRU","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"JP":{"cities":["SCB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"SCB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"KR":{"cities":["KFB"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KFB","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"BW":{"cities":["GBE"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"GBE","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"BN":{"cities":["BKS"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"BKS","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"PK":{"cities":["KHI"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KHI","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"JO":{"cities":["AMM"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"AMM","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"ZM":{"cities":["LUN"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"LUN","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"UG":{"cities":["KLA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"KLA","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"TZ":{"cities":["DAR"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DAR","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"CM":{"cities":["DLA"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"DLA","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"GH":{"cities":["ACC"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"ACC","paymentMethod":"TRF","inferPaymentType":false},')||
to_clob('"CI":{"cities":["ABJ"],"system":"CCS","chargerBearer":"SHAR","categoryPurpose":"OTHR","defaultCity":"ABJ","paymentMethod":"TRF","inferPaymentType":false}}}}'),
'011bc782-0201-4a53-b7f5-3bdb22023332', CURRENT_TIMESTAMP);

COMMIT;
create table payment.ccs_txn (
    id                              bigserial   NOT NULL,
    group_id                        text        NOT NULL,
    message_id                      text        NOT NULL,
    filename                        text        NOT NULL,
    PRIMARY KEY(id)
);
CREATE INDEX ccs_index1 ON payment.ccs_txn(filename);
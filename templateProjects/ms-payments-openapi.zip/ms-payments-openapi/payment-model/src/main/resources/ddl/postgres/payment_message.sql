create table payment.payment_message (
    id                        bigserial   NOT NULL,
    message_id                text        NOT NULL,
    entity_type               text        NOT NULL,
    content_type              text        NOT NULL,
    content                   text        NOT NULL,
    timestamp                 timestamp   NOT NULL,
    PRIMARY KEY(id)
);

CREATE UNIQUE INDEX uniq_pm_index1 ON payment.payment_message (message_id);

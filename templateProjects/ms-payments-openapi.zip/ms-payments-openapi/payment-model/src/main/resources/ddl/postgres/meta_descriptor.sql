create table payment.meta_descriptor(
    id                        text        NOT NULL,
    group_id                  text        NOT NULL,
    name                      text        NOT NULL,
    version                   int         NOT NULL,
    change_reference          text,
    comments                  text,
    frozen_values             text        NOT NULL,
    previous_version_id       text,
    timestamp                 timestamp   NOT NULL,
    PRIMARY KEY(id),
    UNIQUE(group_id, name, version)
);

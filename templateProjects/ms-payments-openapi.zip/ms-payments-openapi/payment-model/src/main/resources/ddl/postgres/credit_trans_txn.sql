CREATE TABLE payment.credit_trans_txn (
    id                              bigserial    NOT NULL,
    end_to_end_id                   text         NOT NULL,
    tracking_id                     text         NOT NULL,
    payment_txn_id                  bigint       NOT NULL references payment.payment_txn(id),
    PRIMARY KEY(id)
);

CREATE INDEX ctt_index1 ON payment.credit_trans_txn (payment_txn_id);
CREATE INDEX ctt_index2 ON payment.credit_trans_txn (end_to_end_id);
CREATE UNIQUE INDEX uniq_ctt_index3 ON payment.credit_trans_txn (tracking_id);
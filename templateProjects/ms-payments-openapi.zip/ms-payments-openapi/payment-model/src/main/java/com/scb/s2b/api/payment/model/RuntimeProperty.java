package com.scb.s2b.api.payment.model;

import java.math.BigInteger;
import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "runtime_property", schema = "payment",
        indexes = {
                @Index(name = "uniq_rp_index1", columnList = "name", unique = true)
        }
)
public class RuntimeProperty {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    @Column(name = "name")
    private String name;

    @Column(name = "value")
    private String value;

    @Column(name = "message_id", nullable = false)
    private String messageId;

    @Column(name = "updated_time", nullable = false)
    @Default
    private Instant updatedTime = Instant.now();
}

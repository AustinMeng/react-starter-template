package com.scb.s2b.api.payment.model;

import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "ccs_txn", schema = "payment",
        indexes = {
                @Index(name = "ccs_index1", columnList = "filename"),
        }
)
public class CCSTxn {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    @Column(name = "group_id", nullable = false)
    private String groupId;

    @OneToMany(
            targetEntity = PaymentTxn.class,
            cascade = {CascadeType.ALL},
            fetch = FetchType.LAZY
    )
    @JoinTable(
            name = "ccs_txn_payment_txn_mapping",
            schema = "payment",
            joinColumns = { @JoinColumn(name = "ccs_txn_id") },
            inverseJoinColumns = { @JoinColumn(name = "payment_txn_id") }
    )
    @Builder.Default
    private List<PaymentTxn> paymentTxns = new LinkedList<>();

    @Column(name = "message_id", nullable = false)
    private String messageId;

    @Column(name = "filename", nullable = false)
    private String fileName;
}

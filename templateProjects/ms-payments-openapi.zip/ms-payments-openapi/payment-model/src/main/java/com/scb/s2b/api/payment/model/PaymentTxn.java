package com.scb.s2b.api.payment.model;

import java.time.LocalDate;
import lombok.*;

import javax.persistence.*;
import java.math.BigInteger;
import java.time.Instant;
import java.util.LinkedList;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"creditTransTxns", "paymentTxnStatuses"})
@Entity
@Table(name = "payment_txn", schema = "payment",
    indexes = {
            @Index(name = "uniq_pt_index1", columnList = "group_id, client_reference_id", unique = true),
            @Index(name = "pt_index2", columnList = "request_id"),
            @Index(name = "pt_index3", columnList = "group_id, batch_id"),
            @Index(name = "pt_index4", columnList = "group_id, timestamp"),
            @Index(name = "pt_index5", columnList = "group_id, required_execution_date"),
    }
)
public class PaymentTxn {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    @Column(name = "request_id")
    private String requestId;

    @Column(name = "group_id", nullable = false)
    private String groupId;

    @Column(name = "client_reference_id", nullable = false)
    private String clientReferenceId;

    @Column(name = "batch_id", nullable = true)
    private String batchId;

    @Column(name = "message_id", nullable = false)
    private String messageId;


    @Column(name = "timestamp", nullable = false)
    private Instant timestamp;

    @Column(name = "payload", nullable = false)
    private String payload;

    @Column(name = "required_execution_date", nullable = false)
    private LocalDate requiredExecutionDate;

    @OneToMany(
        targetEntity = CreditTransTxn.class,
        mappedBy = "paymentTxn",
        cascade = {CascadeType.ALL},
        fetch = FetchType.LAZY
    )
    @Builder.Default
    private List<CreditTransTxn> creditTransTxns = new LinkedList<>();

    public void addCreditTransTxn(CreditTransTxn creditTransTxn) {
        if (this.creditTransTxns == null) {
            this.creditTransTxns = new LinkedList<>();
        }

        creditTransTxn.setPaymentTxn(this);
        this.creditTransTxns.add(creditTransTxn);
    }

    @OneToMany(
        mappedBy = "paymentTxn",
        cascade = CascadeType.ALL,
        fetch = FetchType.LAZY
    )
    @Builder.Default
    private List<PaymentTxnStatus> paymentTxnStatuses = new LinkedList<>();

    public void addPaymentTxnStatus(PaymentTxnStatus paymentTxnStatus) {
        if (this.paymentTxnStatuses == null) {
            this.paymentTxnStatuses = new LinkedList<>();
        }

        paymentTxnStatus.setPaymentTxn(this);
        this.paymentTxnStatuses.add(paymentTxnStatus);
    }

    @OneToMany(
            targetEntity = AdditionalCreditTransInfo.class,
            mappedBy = "paymentTxn",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY
    )
    @Builder.Default
    private List<AdditionalCreditTransInfo> additionalCreditTransInfos = new LinkedList<>();

    public void addAdditionalCreditTransInfo(AdditionalCreditTransInfo additionalCreditTransInfo) {
        if (this.additionalCreditTransInfos == null) {
            this.additionalCreditTransInfos = new LinkedList<>();
        }

        additionalCreditTransInfo.setPaymentTxn(this);
        this.additionalCreditTransInfos.add(additionalCreditTransInfo);
    }

    public void afterPropertiesSet() {
        if (creditTransTxns != null && !creditTransTxns.isEmpty()) {
            creditTransTxns.forEach(ctt -> ctt.setPaymentTxn(this));
        }

        if (paymentTxnStatuses != null && !paymentTxnStatuses.isEmpty()) {
            paymentTxnStatuses.forEach(pts -> pts.setPaymentTxn(this));
        }

        if (additionalCreditTransInfos != null && !additionalCreditTransInfos.isEmpty()) {
            additionalCreditTransInfos.forEach(act -> act.setPaymentTxn(this));
        }
    }
}
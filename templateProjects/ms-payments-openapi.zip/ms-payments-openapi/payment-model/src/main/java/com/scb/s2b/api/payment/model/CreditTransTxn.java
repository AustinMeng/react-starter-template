package com.scb.s2b.api.payment.model;

import lombok.*;

import javax.persistence.*;
import java.math.BigInteger;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "credit_trans_txn", schema = "payment",
    indexes = {
        @Index(name = "ctt_index1", columnList = "payment_txn_id"),
        @Index(name = "ctt_index2", columnList = "end_to_end_id"),
        @Index(name = "uniq_ctt_index3", columnList = "tracking_id", unique = true)
    }
)
public class CreditTransTxn {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id ;

    @Column(name = "end_to_end_id", nullable = false)
    private String endToEndId;

    @Column(name = "tracking_id", nullable = false)
    private String trackingId;

    @ManyToOne(targetEntity = PaymentTxn.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "payment_txn_id", referencedColumnName = "id", nullable = false)
    private PaymentTxn paymentTxn;

}

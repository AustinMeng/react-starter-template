package com.scb.s2b.api.payment.model;

import lombok.*;

import javax.persistence.*;
import java.math.BigInteger;
import java.time.Instant;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "payment_message", schema = "payment",
    indexes = {
        @Index(name = "uniq_pm_index1", columnList = "message_id", unique = true)
    }
)
public class PaymentMessage {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    @Column(name = "message_id", nullable = false)
    private String messageId;

    @Column(name = "entity_type", nullable = false)
    private String entityType;

    @Column(name = "content_type", nullable = false)
    private String contentType;

    @Column(name = "content", nullable = false)
    private String content;

    @Column(name = "timestamp", nullable = false)
    private Instant timestamp;

}

# CCSAgent
## User cases
### CCS Agent process
![CCS Agent process](./doc/images/ccs_agent_process.png)

## CCS Outbound message route
### Route/topic for CCS outbound messages are decided in below order
1. If filename correlated to a row in ccs_agent_message_route table (specified in inbound request header), the callback endpoint in the row will be used
2. If noun/format/groupId match to [meta config](./ms-ccs-agent-server/src/test/resources/meta/routing_properties.json), the callback endpoint defined in meta will be used. Note there could be default endpoint defined for each noun/format
3. If noun is not empty, #NOUN#_CCS_ENDPOINT will be used 
4. OUTBOUND_CCS_ENDPOINT is used if none of previous rule matches

## Run CCSAgentApiApp in Intellij
### Add program arguments
```
--spring.config.location=classpath:/config/dev/application.yml
```
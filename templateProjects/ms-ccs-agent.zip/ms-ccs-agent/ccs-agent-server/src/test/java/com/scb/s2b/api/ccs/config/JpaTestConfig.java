package com.scb.s2b.api.ccs.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@EnableAutoConfiguration
@EntityScan({"com.scb.s2b.api.ccs.model"})
public class JpaTestConfig {
}

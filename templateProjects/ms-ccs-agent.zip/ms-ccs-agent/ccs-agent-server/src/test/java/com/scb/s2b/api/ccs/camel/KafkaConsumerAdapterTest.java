package com.scb.s2b.api.ccs.camel;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CALLBACK_ENDPOINT_HEADER;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CCS_IMPORT_SUSPEND_TO_HEADER;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.IMPORT_RETRY_HEADER;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.OUTBOUND_PAYLOAD_FORMAT_REJ3;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import com.scb.s2b.api.ccs.route.RouteHandler;
import com.scb.s2b.api.ccs.service.CCSAgentService;
import java.math.BigInteger;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;

public class KafkaConsumerAdapterTest {

    private final CCSAgentService ccsAgentService = mock(CCSAgentService.class);

    private final JsonMessageMarshaller jsonMessageMarshaller = mock(JsonMessageMarshaller.class);

    private final ProducerTemplate producer = mock(ProducerTemplate.class);

    private final String ccsImportReTryEndpoint = "ccsImportReTryEndpoint";

    private final RouteHandler routeHandler = mock(RouteHandler.class);

    private final KafkaConsumerAdapter kafkaConsumerAdapter = new KafkaConsumerAdapter(
            ccsAgentService, jsonMessageMarshaller, producer,
            ccsImportReTryEndpoint, 5, 15000L,
            "ocpkaf:callback", "awskaf:callback",
            "ocpkaf", "awskaf", routeHandler);

    private final CCSAgentInboundIns ccsAgentInboundIns = CCSAgentInboundIns.builder().groupId("SYSTEM")
            .noun("PAYMENTS")
            .format("JSON-PAYMENTS").payload("payment test").build();

    private final CCSMailBoxInbound ccsMailBoxInbound = CCSMailBoxInbound.builder().id(BigInteger.valueOf(1)).build();

    @Before
    public void setUp() {
        when(ccsAgentService.persistCCSInboundMessage(any())).thenReturn(ccsMailBoxInbound);
    }

    @Test
    public void consume_ccs_agentInstruction() {
        kafkaConsumerAdapter.consumeCCSAgentInstruction(ccsAgentInboundIns,
                ImmutableMap.of(CALLBACK_ENDPOINT_HEADER, "callback"),
                "ocpkaf", "ocpkaf:callback");

        verify(ccsAgentService).persistCCSAgentMessage(any());
        verify(ccsAgentService).persistCCSAgentMessageRoute(eq(ccsAgentInboundIns), eq("ocpkaf:callback"));
        verify(ccsAgentService).publishInboundMessage(any());
    }

    @Test
    public void consume_ccs_agentInstruction_retry() {
        when(ccsAgentService.isCCSAgentMsgRouteExisted(any(), any())).thenReturn(false);
        doNothing().when(ccsAgentService).publishInboundMessage(any());

        kafkaConsumerAdapter.consumeCCSAgentInstructionRetry(ccsAgentInboundIns,
                ImmutableMap.of(CALLBACK_ENDPOINT_HEADER, "ocpkaf:callback"));

        verify(ccsAgentService).persistCCSAgentMessageRoute(eq(ccsAgentInboundIns), eq("ocpkaf:callback"));
        verify(ccsAgentService).persistCCSInboundMessage(ccsAgentInboundIns);
    }

    @Test
    public void consume_ccs_agentInstruction_retry_with_exception() {
        when(ccsAgentService.isCCSAgentMsgRouteExisted(any(), any())).thenReturn(false);
        doNothing().when(ccsAgentService).publishInboundMessage(any());
        doThrow(new RuntimeException()).when(ccsAgentService).persistCCSInboundMessage(ccsAgentInboundIns);

        kafkaConsumerAdapter.consumeCCSAgentInstructionRetry(ccsAgentInboundIns,
                ImmutableMap.of(CALLBACK_ENDPOINT_HEADER, "ocpkaf:callback",
                        IMPORT_RETRY_HEADER, "6"));

        verify(ccsAgentService).persistCCSAgentMessageRoute(any(), eq("ocpkaf:callback"));
        verify(ccsAgentService).persistCCSInboundMessage(ccsAgentInboundIns);
        verify(ccsAgentService).publishExceptionTOCallback(any(), eq("ocpkaf:callback"), any());
    }

    @Test
    public void calculate_delay_base_on_header() {
        long now = System.currentTimeMillis();

        assertTrue(15000L - kafkaConsumerAdapter.calculateDelay(
                ImmutableMap.of(CCS_IMPORT_SUSPEND_TO_HEADER, String.valueOf(now + 15000L))) < 50L);
        assertEquals(0, kafkaConsumerAdapter.calculateDelay(
                ImmutableMap.of(CCS_IMPORT_SUSPEND_TO_HEADER, String.valueOf(now - 10L))).longValue());
    }

    @Test
    public void consume_ccs_import_without_callback_header() {
        when(routeHandler.getRoute(any(), any(), any(), any())).thenReturn("ocpkaf:noun_callback");
        doThrow(new RuntimeException("error")).when(ccsAgentService).publishInboundMessage(any());

        kafkaConsumerAdapter.consumeCCSAgentInstructionRetry(ccsAgentInboundIns,
                ImmutableMap.of(
                        IMPORT_RETRY_HEADER, "5",
                        CALLBACK_ENDPOINT_HEADER, EMPTY
                ));

        verify(ccsAgentService).publishExceptionTOCallback(eq(ccsAgentInboundIns), eq("ocpkaf:noun_callback"),
                eq(OUTBOUND_PAYLOAD_FORMAT_REJ3));
    }
}
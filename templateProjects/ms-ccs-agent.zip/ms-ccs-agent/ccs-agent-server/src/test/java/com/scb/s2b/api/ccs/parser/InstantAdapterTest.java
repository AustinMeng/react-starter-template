package com.scb.s2b.api.ccs.parser;

import com.scb.s2b.api.ccs.adapter.InstantAdapter;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.junit.Test;

public class InstantAdapterTest {
    InstantAdapter instantAdapter = new InstantAdapter();
    private static final String PATTERN = "yyyy-MM-dd HH:mm:ss";
    @Test
    public void marshalAndUnmarshal(){
        Instant instant = Instant.now();
        String time = marshalDeprecated(instant);
        Assert.assertEquals(time, instantAdapter.marshal(instant));
        Assert.assertEquals(unmarshalDeprecated(time), instantAdapter.unmarshal(time));
    }

    public Instant unmarshalDeprecated(String text) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(PATTERN);
        return LocalDateTime.parse(text, formatter).toInstant(ZoneOffset.of("+8"));
    }

    public String marshalDeprecated(Instant instant) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(PATTERN);
        return LocalDateTime.ofInstant(instant, ZoneOffset.of("+8")).format(formatter);
    }
}

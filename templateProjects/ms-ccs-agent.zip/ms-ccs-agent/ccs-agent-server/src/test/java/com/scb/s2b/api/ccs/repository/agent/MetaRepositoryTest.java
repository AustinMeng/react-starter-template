package com.scb.s2b.api.ccs.repository.agent;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.scb.s2b.api.ccs.config.JpaTestConfig;
import com.scb.s2b.api.ccs.model.agent.MetaDescriptor;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@DataJpaTest
@ContextConfiguration(classes = JpaTestConfig.class)
@RunWith(SpringRunner.class)
@EnableJpaRepositories("com.scb.s2b.api.ccs.repository")
@ActiveProfiles("test")
public class MetaRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private MetaRepository repository;

    @Test
    public void meta_saved_to_db() {
        MetaDescriptor meta = MetaDescriptor.builder()
            .groupId("groupId")
            .comments("test")
            .name("scb.meta")
            .version(1)
            .metaValues("{\"key\": {\"subKey1\": \"value1\", \"subKey2\": \"value2\"}}")
            .timestamp(Instant.now())
            .build();

        repository.save(meta);

        List<MetaDescriptor> metaList = repository.findAll();
        assertNotNull(metaList);
        assertEquals(1, metaList.size());
        assertNotNull(metaList.get(0).getId());
    }

    @Test
    public void get_meta_from_db() {
        MetaDescriptor meta1 = MetaDescriptor.builder()
            .groupId("groupId")
            .comments("test")
            .name("scb.meta")
            .version(1)
            .metaValues("{\"key\": {\"subKey1\": \"value1\", \"subKey2\": \"value2\"}}")
            .timestamp(Instant.now())
            .build();

        MetaDescriptor meta2 = MetaDescriptor.builder()
            .groupId("groupId")
            .comments("test")
            .name("scb.meta")
            .version(2)
            .metaValues("{\"key\": {\"subKey1\": \"value11\", \"subKey2\": \"value22\"}}")
            .timestamp(Instant.now())
            .build();

        entityManager.persist(meta1);
        entityManager.persist(meta2);

        MetaDescriptor md = repository.findTop1ByGroupIdAndNameOrderByVersionDesc("groupId", "scb.meta");
        assertNotNull(md);
        assertNotNull(md.getId());
        assertEquals(2, md.getVersion());

        Map<String, Map<String, Object>> metaValues = md.getValues();
        assertEquals("value11", metaValues.get("key").get("subKey1"));
    }
}
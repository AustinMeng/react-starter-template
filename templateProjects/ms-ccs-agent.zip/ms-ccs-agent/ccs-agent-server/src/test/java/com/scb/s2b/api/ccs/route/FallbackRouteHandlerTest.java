package com.scb.s2b.api.ccs.route;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FallbackRouteHandlerTest {

    private final FallbackRouteHandler handler
            = new FallbackRouteHandler("ocpkaf", "ocpkaf:OUTBOUND_CCS_ENDPOINT");

    @Test
    public void generate_endpoint_from_noun_or_fallback() {
        assertEquals("ocpkaf:PAYMENTS_CCS_ENDPOINT",
                handler.getEndpointInt("PAYMENTS", "FMT", "GRP", ""));
        assertEquals("ocpkaf:OUTBOUND_CCS_ENDPOINT",
                handler.getEndpointInt(null, "FMT", "GRP", ""));
        assertEquals("ocpkaf:OUTBOUND_CCS_ENDPOINT",
                handler.getEndpointInt("", "FMT", "GRP", ""));
        assertEquals("ocpkaf:OUTBOUND_CCS_ENDPOINT",
                handler.getEndpointInt("   ", "FMT", "GRP", ""));
    }
}
package com.scb.s2b.api.ccs.route;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.SYSTEM;
import static com.scb.s2b.api.ccs.service.ReferenceDataService.META_ROUTING_PROPERTIES;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.channels.foundation.commons.cadm.model.GroupDetail;
import com.scb.s2b.api.ccs.config.property.CacheProperties;
import com.scb.s2b.api.ccs.entity.refdata.CountryRoutingProperties;
import com.scb.s2b.api.ccs.entity.refdata.FormatRoutingProperties;
import com.scb.s2b.api.ccs.entity.refdata.NounRoutingProperties;
import com.scb.s2b.api.ccs.entity.refdata.RoutingProperties;
import com.scb.s2b.api.ccs.model.agent.MetaDescriptor;
import com.scb.s2b.api.ccs.repository.agent.MetaRepository;
import com.scb.s2b.api.ccs.service.ReferenceDataService;
import com.scb.s2b.api.ccs.service.impl.ReferenceDataServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

public class MetaRouteHandlerTest {

    private final MetaRepository metaRepository = mock(MetaRepository.class);
    private final CadmClient cadmClient = mock(CadmClient.class);
    private final CacheProperties cacheProperties = CacheProperties.builder().cadmCountryCodeInterval(1).build();
    private final GroupDetail groupDetail = mock(GroupDetail.class);
    private final ReferenceDataService referenceDataService = mock(ReferenceDataService.class);
    private final ReferenceDataService referenceDataService2 = new ReferenceDataServiceImpl(metaRepository, cadmClient, cacheProperties);

    private final MetaRouteHandler handler = new MetaRouteHandler(referenceDataService);
    private final MetaRouteHandler handler2 = new MetaRouteHandler(referenceDataService2);

    @Before
    public void setUp() {
        when(referenceDataService.getRoutingProperties()).thenReturn(new RoutingProperties(
                ImmutableMap.of("REPORTSCUST", new NounRoutingProperties(
                        ImmutableMap.of(
                                "CSV-BANSTA", new FormatRoutingProperties(
                                        ImmutableMap.of(
                                                "UAASTST1", "ocpkaf:REPORTSCUST_UAASTST1"
                                        ),
                                        ImmutableMap.of(
                                                "SG", new CountryRoutingProperties(
                                                        "awskaf:REPORTSCUST_SG",
                                                        ImmutableList.of("UAASTST2")
                                                )
                                        )
                                ),
                                "BANSTAMT199", new FormatRoutingProperties(
                                        ImmutableMap.of(
                                                "UAASTST1", "ocpkaf:REPORTSCUST_UAASTST1"
                                        ),
                                        ImmutableMap.of(
                                                "SG", new CountryRoutingProperties(
                                                        "awskaf:REPORTSCUST_SG",
                                                        ImmutableList.of("UAASTST1")
                                                )
                                        )
                                )
                        )
                ))
        ));
        MetaDescriptor metaDescriptor = MetaDescriptor.builder().metaValues(
                        "{"
                    + "    \"routingProperties\": {"
                    + "        \"nouns\": {"
                    + "            \"PAYMENTS\": {"
                    + "                \"formats\": {"
                    + "                    \"ACK3\": {"
                    + "                        \"groups\": {"
                    + "                            \"UAASTST2\": \"ocpkaf:uaastst1_ccsExport\""
                    + "                        },"
                    + "                        \"countries\": {"
                    + "                            \"SG\": {"
                    + "                                 \"endPoint\":\"awskaf:uaastst1_ccsExport\","
                    + "                                 \"exclusionGroups\":[\"UAASTST1\"]"
                    + "                             }"
                    + "                        }"
                    + "                    },"
                    + "                    \"REJ3\": {"
                    + "                        \"groups\": {"
                    + "                            \"UAASTST2\": \"ocpkaf:uaastst1_ccsExport\""
                    + "                        },"
                    + "                        \"countries\": {"
                    + "                            \"SG\": {"
                    + "                                 \"endPoint\":\"awskaf:uaastst1_ccsExport\","
                    + "                                 \"exclusionGroups\":[\"UAASTST1\"]"
                    + "                             }"
                    + "                        }"
                    + "                    }"
                    + "                }"
                    + "            },"
                    + "            \"REPORTSCUST\": {"
                    + "                \"formats\": {"
                    + "                    \"CSV-BANSTA\": {"
                    + "                        \"groups\": {"
                    + "                            \"UAASTST2\": \"ocpkaf:CSV-BANSTA_UAASTST2\""
                    + "                        },"
                    + "                        \"countries\": {"
                    + "                            \"SG\": {"
                    + "                                 \"endPoint\":\"awskaf:CSV-BANSTA_SG\","
                    + "                                 \"exclusionGroups\":[\"UAASTST1\"]"
                    + "                             }"
                    + "                        }"
                    + "                    },"
                    + "                    \"BANSTAMT199\": {"
                    + "                        \"groups\": {"
                    + "                            \"UAASTST2\": \"ocpkaf:BANSTAMT199_UAASTST1\""
                    + "                        },"
                    + "                        \"countries\": {"
                    + "                            \"SG\": {"
                    + "                                 \"endPoint\":\"awskaf:uaastst1_ccsExport\","
                    + "                                 \"exclusionGroups\":[\"UAASTST1\"]"
                    + "                             }"
                    + "                        }"
                    + "                    }"
                    + "                }"
                    + "            }"
                    + "        }"
                    + "    }"
                    + "}").build();
        when(metaRepository.findTop1ByGroupIdAndNameOrderByVersionDesc(SYSTEM, META_ROUTING_PROPERTIES))
                .thenReturn(metaDescriptor);
        when(referenceDataService.getCountryCodeByGroupId("UAASTST2")).thenReturn("SG");
        when(referenceDataService.getCountryCodeByGroupId("UAASTST3")).thenReturn("HK");
        when(referenceDataService.getCountryCodeByGroupId("UAASTST4")).thenReturn("SG");
        when(cadmClient.getGroupById("UAASTST2")).thenReturn(groupDetail);
        when(groupDetail.getCountryCode()).thenReturn("SG | SINGAPORE").thenReturn("");
    }

    @Test
    public void generate_endpoint_from_meta() {
        assertEquals("ocpkaf:REPORTSCUST_UAASTST1",
                handler.getEndpointInt("REPORTSCUST", "CSV-BANSTA", "UAASTST1", ""));
        assertNull(handler.getEndpointInt("REPORTSCUST", "CSV-BANSTA", "GROUP", ""));
        assertNull(handler.getEndpointInt("REPORTSCUST", "FORMAT", "UAASTST1", ""));
        assertNull(handler.getEndpointInt("NOUN", "CSV-BANSTA", "UAASTST1", ""));
    }

    @Test
    public void country_level_routing() {
        assertEquals("awskaf:REPORTSCUST_SG",
                handler.getEndpointInt("REPORTSCUST", "CSV-BANSTA", "UAASTST4", ""));
        assertNull(handler.getEndpointInt("REPORTSCUST", "CSV-BANSTA", "UAASTST3", ""));
    }

    @Test
    public void guava_cache_test() {
        assertEquals("ocpkaf:CSV-BANSTA_UAASTST2",
                handler2.getEndpointInt("REPORTSCUST", "CSV-BANSTA", "UAASTST2", ""));
        assertEquals("ocpkaf:CSV-BANSTA_UAASTST2",
                handler2.getEndpointInt("REPORTSCUST", "CSV-BANSTA", "UAASTST2", ""));
    }

    @Test
    public void fail_safe_when_generate_endpoint_from_meta() {
        when(referenceDataService.getCountryCodeByGroupId("UAASTST4")).thenThrow(new RuntimeException("error"));
        assertTrue(StringUtils.isBlank(
                handler.getEndpointInt("REPORTCUST", "CSV-BANSTA", "UAASTST4", "")));
    }
}
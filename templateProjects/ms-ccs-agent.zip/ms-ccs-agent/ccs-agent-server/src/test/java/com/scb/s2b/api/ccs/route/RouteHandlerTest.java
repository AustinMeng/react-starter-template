package com.scb.s2b.api.ccs.route;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.SYSTEM;
import static com.scb.s2b.api.ccs.service.ReferenceDataService.META_ROUTING_PROPERTIES;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.channels.foundation.commons.cadm.model.GroupDetail;
import com.scb.s2b.api.ccs.config.property.CacheProperties;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessageRoute;
import com.scb.s2b.api.ccs.model.agent.MetaDescriptor;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRouteRepository;
import com.scb.s2b.api.ccs.repository.agent.MetaRepository;
import com.scb.s2b.api.ccs.service.impl.ReferenceDataServiceImpl;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;

public class RouteHandlerTest {

    private final CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository = mock(
            CCSAgentMessageRouteRepository.class);

    private final MetaRepository metaRepository = mock(MetaRepository.class);
    private final CadmClient cadmClient = mock(CadmClient.class);
    private final CacheProperties cacheProperties = CacheProperties.builder().cadmCountryCodeInterval(1).build();
    private final GroupDetail groupDetail = mock(GroupDetail.class);
    private final GroupDetail hkGroupDetail = mock(GroupDetail.class);

    private final RouteHandler handler;

    public RouteHandlerTest() {
        RouteHandler headerHandler = new HeaderRouteHandler(ccsAgentMessageRouteRepository);
        RouteHandler metaHandler
                = new MetaRouteHandler(new ReferenceDataServiceImpl(metaRepository, cadmClient, cacheProperties));
        RouteHandler fallbackHandler
                = new FallbackRouteHandler("ocpkaf", "ocpkaf:OUTBOUND_CCS_ENDPOINT");

        headerHandler.setNext(metaHandler);
        metaHandler.setNext(fallbackHandler);

        this.handler = new RouteHandler() {
            @Override
            public void setNext(RouteHandler next) {
            }

            @Override
            protected RouteHandler getNext() {
                return headerHandler;
            }

            @Override
            protected String getEndpointInt(String noun, String format, String groupId, String filename) {
                return null;
            }
        };
    }

    @Before
    public void setUp() throws Exception {
        when(ccsAgentMessageRouteRepository.findByFileName(eq("filename1")))
                .thenReturn(CCSAgentMessageRoute.builder()
                        .fileName("filename1")
                        .callback("ocpkaf:outbound")
                        .build());

        MetaDescriptor routingMeta = null;

        try (InputStream is = this.getClass().getClassLoader()
                .getResourceAsStream("meta/routing_properties.json")) {
            assertNotNull(is);
            byte[] bytes = IOUtils.toByteArray(is);

            routingMeta = new MetaDescriptor("1234", SYSTEM, META_ROUTING_PROPERTIES, 1,
                    "", "Routing properties",
                    new String(bytes),
                    null,
                    Instant.now(),
                    null);
        } catch(IOException ex) {
            fail("Failed to read file meta/routing_properties.json");
        }
        when(groupDetail.getCountryCode()).thenReturn("SG");
        when(hkGroupDetail.getCountryCode()).thenReturn("HK");
        when(cadmClient.getGroupById("UAASTST3")).thenReturn(groupDetail);
        when(cadmClient.getGroupById("UAASTST2")).thenReturn(groupDetail);
        when(cadmClient.getGroupById("UAASTST1")).thenReturn(groupDetail);
        when(cadmClient.getGroupById("GROUP")).thenReturn(hkGroupDetail);
        when(metaRepository.findTop1ByGroupIdAndNameOrderByVersionDesc(SYSTEM, META_ROUTING_PROPERTIES))
                .thenReturn(routingMeta);
    }

    @Test
    public void get_route_by_filename() {
        assertEquals("ocpkaf:outbound",
                handler.getRoute("noun", "format", "group1", "filename1"));
    }

    @Test
    public void get_route_from_meta() {
        assertEquals("ocpkaf:REPORTSCUST_UAASTST1",
                handler.getRoute("REPORTSCUST", "CSV-BANSTA",
                        "UAASTST1", ""));
        assertEquals("ocpkaf:REPORTSCUST_CCS_ENDPOINT",
                handler.getRoute("REPORTSCUST", "CSV-BANSTA",
                        "UAASTST2", ""));
        assertEquals("awskaf:REPORTSCUST",
                handler.getRoute("REPORTSCUST", "CSV-BANSTA",
                        "UAASTST3", ""));
        assertEquals("ocpkaf:REPORTSCUST_CCS_ENDPOINT",
                handler.getRoute("REPORTSCUST", "CSV-BANSTA",
                        "GROUP", ""));
    }

    @Test
    public void get_fallback_route() {
        assertEquals("ocpkaf:NOUN_CCS_ENDPOINT",
                handler.getRoute("NOUN", "CSV-BANSTA", "UAASTST1", ""));
        assertEquals("ocpkaf:OUTBOUND_CCS_ENDPOINT",
                handler.getRoute("", "CSV-BANSTA", "UAASTST1", ""));
    }
}
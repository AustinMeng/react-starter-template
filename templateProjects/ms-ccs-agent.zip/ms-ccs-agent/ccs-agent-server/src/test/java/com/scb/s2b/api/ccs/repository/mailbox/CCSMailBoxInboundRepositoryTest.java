package com.scb.s2b.api.ccs.repository.mailbox;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.scb.s2b.api.ccs.config.JpaTestConfig;
import com.scb.s2b.api.ccs.entity.InboundMessageStatus;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import java.math.BigInteger;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@DataJpaTest
@ContextConfiguration(classes = JpaTestConfig.class)
@RunWith(SpringRunner.class)
@EnableJpaRepositories("com.scb.s2b.api.ccs.repository")
@ActiveProfiles("test")
public class CCSMailBoxInboundRepositoryTest {

    @SuppressWarnings("unused")
    @Autowired
    private CCSMailBoxInboundRepository repository;

    @Test
    public void ccsMailBoxInbound_saved_to_db() {
        CCSMailBoxInbound ccsMailBoxInbound = CCSMailBoxInbound.builder().fileName("fileName")
                .fileSize(BigInteger.valueOf(1000)).createdBy("API")
                .grpId("groupId").format("JSON-PAYMENTS")
                .noun("noun").payload(("payment "
                        + "test").getBytes())
                .source("API").status(InboundMessageStatus.INITIALIZED.getCode())
                .build();
        repository.save(ccsMailBoxInbound);
        List<CCSMailBoxInbound> ccsMailBoxInboundList = repository.findAll();

        assertNotNull(ccsMailBoxInboundList);
        assertEquals(1, ccsMailBoxInboundList.size());
        assertNotNull(ccsMailBoxInboundList.get(0).getId());

    }

}

package com.scb.s2b.api.ccs.transformer;


import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CHANNEL_API;
import static org.junit.Assert.assertEquals;

import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.entity.CCSAgentOutboundIns;
import com.scb.s2b.api.ccs.entity.InboundMessageStatus;
import com.scb.s2b.api.ccs.entity.PayloadEntity;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxOutbound;
import java.math.BigInteger;
import org.junit.Before;
import org.junit.Test;

public class CCSMailBoxTransformerTest {

    private final CCSMailBoxTransformer ccsMailBoxTransformer = new CCSMailBoxTransformer();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void ccsAgentIns_to_mailBoxInbound() {

        CCSAgentInboundIns ccsAgentInboundIns = CCSAgentInboundIns.builder().groupId("SYSTEM").noun("PAYMENTS")
                .format("JSON-PAYMENTS").fileName("fileName").fileSize(BigInteger.valueOf(1000))
                .payload("payment test").source("API").build();
        CCSMailBoxInbound ccsMailBoxInbound = ccsMailBoxTransformer.ccsAgentInsToMailBoxInbound(ccsAgentInboundIns);

        assertEquals(CHANNEL_API, ccsMailBoxInbound.getSource());
        assertEquals(InboundMessageStatus.INITIALIZED.getCode(), ccsMailBoxInbound.getStatus().intValue());
        assertEquals("fileName", ccsMailBoxInbound.getFileName());
    }

    @Test
    public void test_mailBoxOutbound_to_ccsAgentOutboundIns() {
        String umi = "umiout";
        String source = "API";
        String noum = "PAYMENTS";
        String format = "ACK3";
        String grpId = "groupId";
        String raw = "ACK3|21042008071836|GroupID.PAYMENTS.20080421031425.60843.Test.txt|08042115fp880000088170000|D0000345|H2H|75130|(INFO) File Sent|PAYSTS_XML";
        String filename = "GroupID.PAYMENTS.20080421031425.60843.Test.rej3";
        CCSMailBoxOutbound mailBoxOutbound = CCSMailBoxOutbound.builder()
                .umi(umi)
                .source(source)
                .noun(noum)
                .format(format)
                .grpId(grpId)
                .payload(raw.getBytes())
                .fileName(filename)
                .build();

        String payloadType = "ACK3";
        String payloadUmi = "08042115fp880000088170000";
        String remarks = "(INFO) File Sent";
        String product = "PAYSTS_XML";
        String batchNum = "D0000345";
        String channelIndicator = "H2H";
        String statusCode = "75130";
        PayloadEntity payload = PayloadEntity.builder()
                .type(payloadType)
                .umi(payloadUmi)
                .batchNumber(batchNum)
                .fileName(filename)
                .channelIndicator(channelIndicator)
                .product(product)
                .statusRemarks(remarks)
                .statusCode(statusCode)
                .build();
        CCSAgentOutboundIns outboundIns = ccsMailBoxTransformer
                .mailBoxOutboundToCCSAgentOutboundIns(mailBoxOutbound, payload);
        assertEquals(format, outboundIns.getFormat());
        assertEquals(source, outboundIns.getSource());
        assertEquals(noum, outboundIns.getNoun());
        assertEquals(umi, outboundIns.getUmi());
        assertEquals(raw, outboundIns.getRaw());
        assertEquals(grpId, outboundIns.getGroupId());
        assertEquals(filename, outboundIns.getFilename() + ".rej3");
        assertEquals(payloadType, outboundIns.getPayload().getType());
        assertEquals(filename, outboundIns.getPayload().getFileName());
        assertEquals(payloadUmi, outboundIns.getPayload().getUmi());
        assertEquals(remarks, outboundIns.getPayload().getStatusRemarks());
        assertEquals(statusCode, outboundIns.getPayload().getStatusCode());
        assertEquals(product, outboundIns.getPayload().getProduct());
        assertEquals(batchNum, outboundIns.getPayload().getBatchNumber());
        assertEquals(channelIndicator, outboundIns.getPayload().getChannelIndicator());
    }
}
package com.scb.s2b.api.ccs.repository.agent;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.scb.s2b.api.ccs.config.CCSAgentConstant;
import com.scb.s2b.api.ccs.config.JpaTestConfig;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessage;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@DataJpaTest
@ContextConfiguration(classes = JpaTestConfig.class)
@RunWith(SpringRunner.class)
@EnableJpaRepositories("com.scb.s2b.api.ccs.repository")
@ActiveProfiles("test")
public class CCSAgentMessageRepositoryTest {

    @Autowired
    CCSAgentMessageRepository ccsAgentMessageRepository;

    @Test
    public void test_ccs_agent_message_save() {
        CCSAgentMessage ccsAgentMessage = CCSAgentMessage.builder().messageId("fileName001")
                .entityType(CCSAgentConstant.ENTITY_TYPE_CCS_INBOUND_MSG).contentType(MediaType.APPLICATION_JSON_VALUE)
                .content("test")
                .build();
        ccsAgentMessageRepository.save(ccsAgentMessage);
        List<CCSAgentMessage> result = ccsAgentMessageRepository.findAll();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertNotNull(result.get(0).getId());
        assertEquals("fileName001", result.get(0).getMessageId());
    }
}
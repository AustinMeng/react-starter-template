package com.scb.s2b.api.ccs.route;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.scb.s2b.api.ccs.model.agent.CCSAgentMessageRoute;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRouteRepository;
import org.junit.Before;
import org.junit.Test;

public class HeaderRouteHandlerTest {

    private final CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository = mock(
            CCSAgentMessageRouteRepository.class);

    private final HeaderRouteHandler handler = new HeaderRouteHandler(ccsAgentMessageRouteRepository);

    @Before
    public void setUp() {
        when(ccsAgentMessageRouteRepository.findByFileName(eq("filename1")))
                .thenReturn(CCSAgentMessageRoute.builder()
                        .fileName("filename1")
                        .callback("outbound")
                        .build());

        when(ccsAgentMessageRouteRepository.findByFileName(eq("filename2")))
                .thenReturn(CCSAgentMessageRoute.builder()
                        .fileName("filename2")
                        .callback("")
                        .build());
    }

    @Test
    public void generate_endpoint_from_filename() {
        assertEquals("outbound",
                handler.getEndpointInt("NOUN", "FMT", "GROUP", "filename1"));
        assertNull(handler.getEndpointInt("NOUN", "FMT", "GROUP", "filename2"));
        assertNull(handler.getEndpointInt("NOUN", "FMT", "GROUP", "filename3"));
    }
}
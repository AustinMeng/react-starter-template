package com.scb.s2b.api.ccs.service.impl;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.SYSTEM;
import static com.scb.s2b.api.ccs.service.ReferenceDataService.META_ROUTING_PROPERTIES;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.s2b.api.ccs.config.property.CacheProperties;
import com.scb.s2b.api.ccs.entity.refdata.RoutingProperties;
import com.scb.s2b.api.ccs.model.agent.MetaDescriptor;
import com.scb.s2b.api.ccs.repository.agent.MetaRepository;
import com.scb.s2b.api.ccs.service.ReferenceDataService;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;

public class ReferenceDataServiceImplTest {

    private final MetaRepository metaRepository = mock(MetaRepository.class);
    private final CadmClient cadmClient = mock(CadmClient.class);
    private final CacheProperties cacheProperties = CacheProperties.builder().cadmCountryCodeInterval(1).build();
    private final ReferenceDataService referenceDataService = new ReferenceDataServiceImpl(metaRepository,cadmClient,cacheProperties);

    @Before
    public void setUp() {
        MetaDescriptor routingMeta = null;

        try (InputStream is = this.getClass().getClassLoader()
                .getResourceAsStream("meta/routing_properties.json")) {
            assertNotNull(is);
            byte[] bytes = IOUtils.toByteArray(is);

            routingMeta = new MetaDescriptor("1234", SYSTEM, META_ROUTING_PROPERTIES, 1,
                    "", "Routing properties",
                    new String(bytes),
                    null,
                    Instant.now(),
                    null);
        } catch(IOException ex) {
            fail("Failed to read file meta/routing_properties.json");
        }
        when(metaRepository.findTop1ByGroupIdAndNameOrderByVersionDesc(SYSTEM, META_ROUTING_PROPERTIES))
                .thenReturn(routingMeta);
    }

    @Test
    public void parse_meta_to_routing_properties() {
        RoutingProperties routingProperties = referenceDataService.getRoutingProperties();
        assertNotNull(routingProperties);
        assertNotNull(routingProperties.getNouns());
        assertNotNull(routingProperties.getNouns().get("REPORTSCUST"));
        assertNotNull(routingProperties.getNouns().get("REPORTSCUST").getFormats());
        assertNotNull(routingProperties.getNouns().get("REPORTSCUST").getFormats().get("CSV-BANSTA"));
        assertNotNull(routingProperties.getNouns().get("REPORTSCUST").getFormats().get("CSV-BANSTA").getGroups());
        assertEquals("ocpkaf:REPORTSCUST_UAASTST1",
                routingProperties.getNouns().get("REPORTSCUST").getFormats()
                        .get("CSV-BANSTA").getGroups().get("UAASTST1"));

        assertNull(routingProperties.getNouns().get("UNKNOWN_NOUN"));
        assertNull(routingProperties.getNouns().get("REPORTSCUST").getFormats().get("UNKNOWN_FMT"));
        assertNull(routingProperties.getNouns().get("REPORTSCUST").getFormats().get("CSV-BANSTA").getGroups()
                .get("UNKNOWN_GRP"));
    }
}
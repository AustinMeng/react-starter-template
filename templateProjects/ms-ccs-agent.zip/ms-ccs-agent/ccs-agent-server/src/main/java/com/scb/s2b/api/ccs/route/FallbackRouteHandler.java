package com.scb.s2b.api.ccs.route;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CCS_ENDPOINT_SUFFIX;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class FallbackRouteHandler extends RouteHandler {

    private RouteHandler next;

    private final String defaultPrefix;
    private final String defaultOutbound;

    public FallbackRouteHandler(String defaultPrefix, String defaultOutbound) {
        this.defaultPrefix = defaultPrefix;
        this.defaultOutbound = defaultOutbound;
    }

    @Override
    public void setNext(RouteHandler next) {
        this.next = next;
    }

    @Override
    protected RouteHandler getNext() {
        return next;
    }

    @Override
    protected String getEndpointInt(String noun, String format, String groupId, String filename) {
        String endpoint;
        if (StringUtils.isNotBlank(noun)) {
            log.info("Generating endpoint from noun for noun={}, format={}, group={}", noun, format, groupId);
            endpoint = defaultPrefix + ":" + noun + CCS_ENDPOINT_SUFFIX;
        } else {
            log.info("Fallback to default endpoint for noun={}, format={}, group={}", noun, format, groupId);
            endpoint = defaultOutbound;
        }

        return endpoint;
    }
}

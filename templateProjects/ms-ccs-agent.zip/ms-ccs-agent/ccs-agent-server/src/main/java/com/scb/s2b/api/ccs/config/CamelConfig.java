package com.scb.s2b.api.ccs.config;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.TAG_CCS_IMPORT;

import com.scb.s2b.api.ccs.camel.AsyncExceptionProcessor;
import com.scb.s2b.api.ccs.config.property.KafkaProperties;
import com.scb.s2b.api.ccs.config.property.KafkaSecurityProperties;
import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import java.nio.charset.StandardCharsets;
import javax.jms.JMSException;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import oracle.jms.AQjmsConnectionFactory;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.component.kafka.KafkaComponent;
import org.apache.camel.component.kafka.KafkaConfiguration;
import org.apache.camel.component.kafka.KafkaConstants;
import org.apache.camel.component.kafka.KafkaManualCommit;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

@SuppressWarnings("unused")
@Slf4j
public class CamelConfig {

    @Value("${ccs-agent.ora.endpoints.inboundAQ}")
    private String ccsInboundAQ;

    @Value("${ccs-agent.ora.endpoints.outboundAQ}")
    private String ccsOutboundAQ;

    @Value("${ccs-agent.kafka.importRetry}")
    private String importRetryEndpoint;

    @Value("${ccs-agent.retryInterval}")
    private int retryInterval;

    @Bean(name = "ocpKafkaProperties")
    @ConfigurationProperties("ccs-agent.kafka.ocp")
    public KafkaProperties ocpKafkaProperties() {
        return new KafkaProperties();
    }

    @Bean(name = "awsKafkaProperties")
    @ConfigurationProperties("ccs-agent.kafka.aws")
    public KafkaProperties awsKafkaProperties() {
        return new KafkaProperties();
    }

    @Profile("!test")
    @Bean(name = "ocpkaf-component")
    public KafkaComponent ocpKafkaComponent(@Qualifier("ocpKafkaProperties") KafkaProperties ocpKafkaProperties) {
        return this.buildKafkaComponent(ocpKafkaProperties);
    }

    @Profile("!test")
    @Bean(name = "awskaf-component")
    public KafkaComponent awsKafkaComponent(@Qualifier("awsKafkaProperties") KafkaProperties awsKafkaProperties) {
        return this.buildKafkaComponent(awsKafkaProperties);
    }

    @Bean(name = "ora-component")
    public JmsComponent aqJmsComponent(AQjmsConnectionFactory aqJmsConnectionFactory) {
        return JmsComponent.jmsComponent(aqJmsConnectionFactory);
    }

    @Bean
    public AQjmsConnectionFactory aqJmsConnectionFactory(@Qualifier("oracleDataSource") DataSource dataSource)
            throws JMSException {
        AQjmsConnectionFactory aqJmsConnectionFactory = new AQjmsConnectionFactory();
        aqJmsConnectionFactory.setDatasource(dataSource);
        return aqJmsConnectionFactory;
    }

    @Bean
    public AsyncExceptionProcessor asyncExceptionProcessor() {
        return new AsyncExceptionProcessor();
    }

    @Bean
    RouteBuilder routeBuilder(@Qualifier("ocpKafkaProperties") KafkaProperties ocpKafkaProps,
            @Qualifier("awsKafkaProperties") KafkaProperties awsKafkaProps,
            JsonMessageMarshaller jsonMessageMarshaller,
            AsyncExceptionProcessor exceptionProcessor) {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(Throwable.class).maximumRedeliveries(0);

                JacksonDataFormat ccsAgentInboundFormatter= new JacksonDataFormat(CCSAgentInboundIns.class);
                ccsAgentInboundFormatter.setObjectMapper(jsonMessageMarshaller.getObjectMapper());

                from(ocpKafkaProps.getEndpoints().get(TAG_CCS_IMPORT))
                        .routeId("ocpImportConsume")
                        .doTry()
                        .unmarshal(ccsAgentInboundFormatter).convertBodyTo(CCSAgentInboundIns.class)
                        .bean("kafkaConsumerAdapter", "consumeOcpImport(${body}, ${headers})")
                        .process(exchange -> {
                            KafkaManualCommit manual = exchange.getIn()
                                    .getHeader(KafkaConstants.MANUAL_COMMIT, KafkaManualCommit.class);
                            if(manual != null) {
                                manual.commitSync();
                            }
                        })
                        .log("Completed ocp kafka commit offset ${headers.kafka.OFFSET}")
                        .doCatch(Exception.class)
                        .log("Failed to process offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor)
                        .end();
                from(awsKafkaProps.getEndpoints().get(TAG_CCS_IMPORT))
                        .routeId("awsImportConsume")
                        .doTry()
                        .unmarshal(ccsAgentInboundFormatter).convertBodyTo(CCSAgentInboundIns.class)
                        .bean("kafkaConsumerAdapter", "consumeAwsImport(${body}, ${headers})")
                        .process(exchange -> {
                            KafkaManualCommit manual = exchange.getIn()
                                    .getHeader(KafkaConstants.MANUAL_COMMIT, KafkaManualCommit.class);
                            if(manual != null) {
                                manual.commitSync();
                            }
                        })
                        .log("Completed aws kafka commit offset ${headers.kafka.OFFSET}")
                        .doCatch(Exception.class)
                        .log("Failed to process offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor)
                        .end();

                from(importRetryEndpoint)
                        .routeId("importConsumeRetry")
                        .delay().method("kafkaConsumerAdapter", "calculateDelay(${headers})")
                        .doTry()
                        .unmarshal(ccsAgentInboundFormatter).convertBodyTo(CCSAgentInboundIns.class)
                        .bean("kafkaConsumerAdapter",
                                "consumeCCSAgentInstructionRetry(${body}, ${headers})")
                        .process(exchange -> {
                            KafkaManualCommit manual = exchange.getIn()
                                    .getHeader(KafkaConstants.MANUAL_COMMIT, KafkaManualCommit.class);
                            if(manual != null) {
                                manual.commitSync();
                            }
                        })
                        .log("Completed retry kafka commit offset ${headers.kafka.OFFSET}")
                        .doCatch(Exception.class)
                        .log("Failed to process retry offset ${headers.kafka.OFFSET}")
                        .process(exceptionProcessor)
                        .end();

                from(ccsOutboundAQ)
                        .routeId("aqOutbound")
                        .doTry()
                        .convertBodyTo(String.class, StandardCharsets.UTF_8.toString())
                        .bean("jmsConsumerAdapter", "consumeCCSOutbound")
                        .doCatch(Exception.class)
                        .process(exceptionProcessor)
                        .end();
            }
        };
    }

    private KafkaComponent buildKafkaComponent(KafkaProperties properties) {
        KafkaComponent kafka = new KafkaComponent();

        KafkaConfiguration configuration = new KafkaConfiguration();
        configuration.setKeySerializer("org.apache.kafka.common.serialization.IntegerSerializer");
        configuration.setValueSerializer("org.apache.kafka.common.serialization.ByteArraySerializer");
        configuration.setKeyDeserializer("org.apache.kafka.common.serialization.IntegerDeserializer");
        configuration.setValueDeserializer("org.apache.kafka.common.serialization.ByteArrayDeserializer");
        configuration.setAutoCommitEnable(false);
        configuration.setAllowManualCommit(true);
        configuration.setBrokers(properties.getBrokers());

        KafkaSecurityProperties kafkaSecurityProperties = properties.getSecurityInfo();
        if (kafkaSecurityProperties != null) {
            log.info("connection Kafka {} using SSL", properties.getBrokers());
            log.info("SSL parameters: {}", kafkaSecurityProperties);

            configuration.setSecurityProtocol(kafkaSecurityProperties.getSecurityProtocol());
            configuration.setSslKeystoreLocation(kafkaSecurityProperties.getKeystore());
            configuration.setSslKeystorePassword(kafkaSecurityProperties.getKeystorePassword());
            configuration.setSslTruststoreLocation(kafkaSecurityProperties.getTruststore());
            configuration.setSslTruststorePassword(kafkaSecurityProperties.getTruststorePassword());
            configuration.setSslKeyPassword(kafkaSecurityProperties.getKeyPassword());
            configuration.setSslEndpointAlgorithm(kafkaSecurityProperties.getEndpointAlgorithm());
        }

        kafka.setConfiguration(configuration);
        return kafka;
    }
}

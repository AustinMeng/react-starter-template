package com.scb.s2b.api.ccs.service.impl;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.SYSTEM;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.s2b.api.ccs.config.property.CacheProperties;
import com.scb.s2b.api.ccs.entity.refdata.RoutingProperties;
import com.scb.s2b.api.ccs.model.agent.MetaDescriptor;
import com.scb.s2b.api.ccs.repository.agent.MetaRepository;
import com.scb.s2b.api.ccs.service.ReferenceDataService;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;

@Slf4j
public class ReferenceDataServiceImpl implements ReferenceDataService {

    private final MetaRepository metaRepository;
    private final LoadingCache<String, String> countryGroupCache;
    private final ExecutorService executorService;

    public ReferenceDataServiceImpl(MetaRepository metaRepository,
            CadmClient cadmClient, CacheProperties cacheProperties) {
        this.metaRepository = metaRepository;
        Integer cadmCountryCodeInterval = 1440;

        if(cacheProperties.getCadmCountryCodeInterval() != null) {
            cadmCountryCodeInterval = cacheProperties.getCadmCountryCodeInterval();
        }
        executorService = new ThreadPoolExecutor(2, 6, 1, TimeUnit.MINUTES,
                new ArrayBlockingQueue<>(100));

        countryGroupCache = CacheBuilder.newBuilder().maximumSize(1000)
            .refreshAfterWrite(cadmCountryCodeInterval, TimeUnit.MINUTES)
            .build(new CacheLoader<String, String>() {
                @Override
                public String load(@Nonnull String groupId) {
                    log.info("Loading group detail for group id {} from CADM", groupId);
                    return cadmClient.getGroupById(groupId).getCountryCode().split("\\|")[0].trim();
                }
                @Override
                public ListenableFuture<String> reload(@Nonnull String key, @Nonnull String oldValue) {
                    log.info("Reloading group detail for group id {} from CADM", key);
                    try{
                        ListenableFutureTask<String> task = ListenableFutureTask.create(() -> load(key));
                        executorService.execute(task);
                        return task;
                    } catch (Exception e) {
                        log.error("Unable to load data from CADM for gourp: {}", key);
                    }
                    return Futures.immediateFuture(oldValue);
                }
            });
    }

    @Override
    @Cacheable(value = META_CACHE, cacheManager = "ehCacheManager", keyGenerator = "cacheKeyGenerator")
    public RoutingProperties getRoutingProperties() {
        log.info("getRoutingProperties");
        MetaDescriptor meta = metaRepository.findTop1ByGroupIdAndNameOrderByVersionDesc(SYSTEM,
                META_ROUTING_PROPERTIES);
        if (meta != null) {
            return meta.lookup("routingProperties", RoutingProperties.class);
        }

        return null;
    }

    @Override
    public String getCountryCodeByGroupId(String groupId) {
        if(this.countryGroupCache != null) {
            try {
                return this.countryGroupCache.get(groupId);
            } catch (ExecutionException e) {
                log.error("Unable to get group info from CADM for {}", groupId);
            }
        }
        return null;
    }
}

package com.scb.s2b.api.ccs.config;

import com.scb.s2b.api.ccs.config.property.UCPDataSourceProperties;
import java.sql.SQLException;
import java.util.Objects;
import javax.sql.DataSource;
import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SuppressWarnings("unused")
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = "com.scb.s2b.api.ccs.repository.mailbox",
        entityManagerFactoryRef = "oracleEntityManagerFactory",
        transactionManagerRef = "oracleTransactionManager"
)
public class OracleDbConfig {

    @Bean(name = "oracleDataSourceProps")
    @ConfigurationProperties("datasource.oracle")
    public UCPDataSourceProperties ucpDataSourceProperties() {
        return new UCPDataSourceProperties();
    }

    @Primary
    @Bean(name = "oracleDataSource")
    public DataSource dataSource(@Qualifier("oracleDataSourceProps") UCPDataSourceProperties ucpDataSourceProperties)
            throws SQLException {
        PoolDataSource dataSource = PoolDataSourceFactory.getPoolDataSource();
        dataSource.setUser(ucpDataSourceProperties.getUsername());
        dataSource.setPassword(ucpDataSourceProperties.getPassword());
        dataSource.setConnectionFactoryClassName(ucpDataSourceProperties.getDriverClassName());
        dataSource.setURL(ucpDataSourceProperties.getJdbcUrl());
        dataSource.setFastConnectionFailoverEnabled(ucpDataSourceProperties.getFastConnectionFailoverEnabled());
        dataSource.setInitialPoolSize(ucpDataSourceProperties.getInitialPoolSize());
        dataSource.setMinPoolSize(ucpDataSourceProperties.getMinPoolSize());
        dataSource.setMaxPoolSize(ucpDataSourceProperties.getMaxPoolSize());
        return dataSource;
    }

    @Primary
    @Bean(name = "oracleEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean oracleEntityManagerFactory(
            @Qualifier("oracleDataSource") DataSource dataSource, EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(dataSource)
                .packages("com.scb.s2b.api.ccs.model.mailbox")
                .persistenceUnit("oraclePersistenceUnit")
                .build();
    }

    @Primary
    @Bean(name = "oracleTransactionManager")
    public PlatformTransactionManager ccsAgentTxManager(
            @Qualifier("oracleEntityManagerFactory") LocalContainerEntityManagerFactoryBean entityManagerFactory) {
        return new JpaTransactionManager(Objects.requireNonNull(entityManagerFactory.getObject()));
    }

}

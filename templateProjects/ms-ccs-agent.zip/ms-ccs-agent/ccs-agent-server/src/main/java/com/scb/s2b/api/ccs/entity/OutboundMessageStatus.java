package com.scb.s2b.api.ccs.entity;

@SuppressWarnings("unused")
public enum OutboundMessageStatus {
    IN_PROGRESS(2200),
    PROCESSED(2300),
    REJECTED(2301),
    PICKUP_WITHOUT_AQ(2150);

    private final int status;

    OutboundMessageStatus(int code) {
        this.status = code;
    }

    public int code() {
        return status;
    }
}

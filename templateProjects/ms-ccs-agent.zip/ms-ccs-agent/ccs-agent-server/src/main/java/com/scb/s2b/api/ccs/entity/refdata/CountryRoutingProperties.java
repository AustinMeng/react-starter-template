package com.scb.s2b.api.ccs.entity.refdata;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class CountryRoutingProperties {
    String endPoint;
    List<String> exclusionGroups;
}

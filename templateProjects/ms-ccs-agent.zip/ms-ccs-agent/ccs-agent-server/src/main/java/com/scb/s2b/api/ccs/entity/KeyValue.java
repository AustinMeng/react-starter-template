package com.scb.s2b.api.ccs.entity;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlValue;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KeyValue {

    @XmlTransient
    private BigInteger id;

    @XmlValue
    public void setId(BigInteger id) {
        this.id = id;
    }

    @XmlValue
    public BigInteger getId() {
        return id;
    }

    @Default
    @XmlAttribute(name = "KeyName")
    private final String keyName = "ID";
}

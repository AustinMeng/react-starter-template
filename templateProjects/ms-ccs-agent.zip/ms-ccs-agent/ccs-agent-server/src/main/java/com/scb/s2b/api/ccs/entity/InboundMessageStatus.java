package com.scb.s2b.api.ccs.entity;

@SuppressWarnings("unused")
public enum InboundMessageStatus {
    INITIALIZED(1200), PROCESSED(1400), TO_BE_REHANDLED(1250), INVALID(1401);

    private final int code;

    InboundMessageStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
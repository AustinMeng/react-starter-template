package com.scb.s2b.api.ccs.repository.agent;

import com.scb.s2b.api.ccs.model.agent.CCSAgentMessage;
import java.math.BigInteger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CCSAgentMessageRepository extends JpaRepository<CCSAgentMessage, BigInteger> {

}

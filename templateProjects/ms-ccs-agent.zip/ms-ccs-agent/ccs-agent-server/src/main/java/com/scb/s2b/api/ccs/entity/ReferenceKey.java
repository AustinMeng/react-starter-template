package com.scb.s2b.api.ccs.entity;

import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReferenceKey {

    @XmlElement(name = "KeyValue")
    private KeyValue keyValue;
}

package com.scb.s2b.api.ccs.config;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.OUTBOUND_PAYLOAD_FORMAT_ACK3;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.OUTBOUND_PAYLOAD_FORMAT_REJ3;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.TAG_DEF_CALLBACK;

import com.google.common.collect.ImmutableMap;
import com.scb.channels.foundation.commons.cadm.CadmClient;
import com.scb.s2b.api.ccs.camel.JmsConsumerAdapter;
import com.scb.s2b.api.ccs.camel.KafkaConsumerAdapter;
import com.scb.s2b.api.ccs.camel.KafkaProducerAdapter;
import com.scb.s2b.api.ccs.config.property.CacheProperties;
import com.scb.s2b.api.ccs.config.property.KafkaProperties;
import com.scb.s2b.api.ccs.entity.PayloadEntity;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.ccs.marshaller.XmlMessageMarshaller;
import com.scb.s2b.api.ccs.parser.MessageParser;
import com.scb.s2b.api.ccs.parser.PipeDelimiterMessageParser;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRepository;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRouteRepository;
import com.scb.s2b.api.ccs.repository.agent.MetaRepository;
import com.scb.s2b.api.ccs.repository.mailbox.CCSMailBoxInboundRepository;
import com.scb.s2b.api.ccs.repository.mailbox.CCSMailBoxOutboundRepository;
import com.scb.s2b.api.ccs.route.FallbackRouteHandler;
import com.scb.s2b.api.ccs.route.HeaderRouteHandler;
import com.scb.s2b.api.ccs.route.MetaRouteHandler;
import com.scb.s2b.api.ccs.route.RouteHandler;
import com.scb.s2b.api.ccs.service.CCSAgentService;
import com.scb.s2b.api.ccs.service.CCSOutboundMessageService;
import com.scb.s2b.api.ccs.service.ReferenceDataService;
import com.scb.s2b.api.ccs.service.impl.CCSAgentServiceImpl;
import com.scb.s2b.api.ccs.service.impl.CCSOutboundMessageServiceImpl;
import com.scb.s2b.api.ccs.service.impl.ReferenceDataServiceImpl;
import com.scb.s2b.api.ccs.transformer.CCSMailBoxTransformer;
import com.scb.s2b.api.ccs.transformer.KafkaMessageTransformer;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

@SuppressWarnings("unused")
public class CCSAgentConfig {

    @Value("${ccs-agent.ora.endpoints.inboundAQ}")
    private String ccsInboundAQ;

    @Value("${ccs-agent.kafka.defaultOutboundPrefix}")
    private String defaultOutboundPrefix;

    @Value("${ccs-agent.kafka.defaultOutboundTopic}")
    private String defaultOutboundTopic;

    @Value("${ccs-agent.kafka.importRetry}")
    private String importRetryEndpoint;

    @Value("${ccs-agent.maxRetry}")
    private int maxRetry;

    @Value("${ccs-agent.retryInterval}")
    private int retryInterval;

    @Bean
    public JmsConsumerAdapter jmsConsumerAdapter(CCSAgentService ccsAgentService,
            XmlMessageMarshaller xmlMessageMarshaller) {
        return new JmsConsumerAdapter(ccsAgentService, xmlMessageMarshaller);
    }

    @Bean
    public KafkaConsumerAdapter kafkaConsumerAdapter(CCSAgentService ccsAgentService,
            JsonMessageMarshaller jsonMessageMarshaller, ProducerTemplate producer,
            @Qualifier("ocpKafkaProperties") KafkaProperties ocpKafkaProps,
            @Qualifier("awsKafkaProperties") KafkaProperties awsKafkaProps,
            RouteHandler routeHandler) {
        return new KafkaConsumerAdapter(ccsAgentService, jsonMessageMarshaller, producer,
                importRetryEndpoint, maxRetry, retryInterval,
                ocpKafkaProps.getEndpoints().get(TAG_DEF_CALLBACK),
                awsKafkaProps.getEndpoints().get(TAG_DEF_CALLBACK),
                ocpKafkaProps.getPrefix(), awsKafkaProps.getPrefix(), routeHandler);
    }

    @Bean
    public JsonMessageMarshaller jsonMessageMarshaller() {
        return new JsonMessageMarshaller();
    }

    @Bean
    public XmlMessageMarshaller xmlMessageMarshaller() {
        return new XmlMessageMarshaller();
    }

    @Bean
    public KafkaProducerAdapter kafkaProducerAdapter(
            ProducerTemplate producer, JsonMessageMarshaller jsonMessageMarshaller) {
        return new KafkaProducerAdapter(
                producer, jsonMessageMarshaller);
    }

    @Bean
    public CCSMailBoxTransformer ccsMailBoxTransformer() {
        return new CCSMailBoxTransformer();
    }

    @Bean
    public KafkaMessageTransformer kafkaMessageTransformer(JsonMessageMarshaller jsonMessageMarshaller) {
        return new KafkaMessageTransformer(jsonMessageMarshaller);
    }

    @Bean
    public Map<String, Function<byte[], PayloadEntity>> payloadProcessors(
            @Qualifier("pipeDelimiterMessageParser") @Autowired MessageParser pipeDelimiterParser) {
        Function<byte[], PayloadEntity> pipeDelimiterMessageProcessor = bytes -> Optional
                .ofNullable(pipeDelimiterParser.parse(new String(bytes, StandardCharsets.UTF_8))).orElse(null);
        return ImmutableMap.of(OUTBOUND_PAYLOAD_FORMAT_ACK3, pipeDelimiterMessageProcessor,
                OUTBOUND_PAYLOAD_FORMAT_REJ3, pipeDelimiterMessageProcessor);
    }

    @Bean
    public CCSOutboundMessageService ccsOutboundMessageService(
            CCSMailBoxOutboundRepository ccsMailBoxOutboundRepository) {
        return new CCSOutboundMessageServiceImpl(ccsMailBoxOutboundRepository);
    }

    @Bean
    public CCSAgentService ccsAgentService(CCSMailBoxInboundRepository ccsMailBoxInboundRepository,
            CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository,
            CCSAgentMessageRepository ccsAgentMessageRepository,
            CCSMailBoxTransformer ccsMailBoxTransformer, ProducerTemplate producer,
            XmlMessageMarshaller xmlMessageMarshaller,
            JsonMessageMarshaller jsonMessageMarshaller,
            KafkaProducerAdapter kafkaProducer, Map<String, Function<byte[], PayloadEntity>> payloadProcessors,
            CCSOutboundMessageService ccsOutboundMessageService, RouteHandler routeHandler) {
        return new CCSAgentServiceImpl(ccsMailBoxInboundRepository,
                ccsAgentMessageRouteRepository, ccsAgentMessageRepository, ccsMailBoxTransformer,
                producer, ccsInboundAQ, xmlMessageMarshaller,
                jsonMessageMarshaller, kafkaProducer,
                payloadProcessors, ccsOutboundMessageService, routeHandler);
    }

    @Bean
    public RouteHandler routeHandler(CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository,
            ReferenceDataService referenceDataService) {
        RouteHandler headerHandler = new HeaderRouteHandler(ccsAgentMessageRouteRepository);
        RouteHandler metaHandler = new MetaRouteHandler(referenceDataService);
        RouteHandler fallbackHandler = new FallbackRouteHandler(defaultOutboundPrefix, defaultOutboundTopic);

        headerHandler.setNext(metaHandler);
        metaHandler.setNext(fallbackHandler);

        return new RouteHandler() {
            @Override
            public void setNext(RouteHandler next) {
            }

            @Override
            protected RouteHandler getNext() {
                return headerHandler;
            }

            @Override
            protected String getEndpointInt(String noun, String format, String groupId, String filename) {
                return null;
            }
        };
    }

    @Qualifier("pipeDelimiterMessageParser")
    @Bean
    public MessageParser pipeDelimiterMessageParser() {
        return new PipeDelimiterMessageParser();
    }

    @Bean
    public ReferenceDataService referenceDataService(MetaRepository metaRepository, CadmClient cadmClient,
            CacheProperties cacheProperties) {
        return new ReferenceDataServiceImpl(metaRepository, cadmClient, cacheProperties);
    }

}

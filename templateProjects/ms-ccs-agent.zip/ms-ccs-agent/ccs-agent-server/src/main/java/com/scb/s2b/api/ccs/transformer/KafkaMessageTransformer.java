package com.scb.s2b.api.ccs.transformer;

import com.scb.channels.foundation.notificationengine.KafkaStruct;
import com.scb.channels.foundation.notificationengine.MessageWrapper;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import java.lang.management.ManagementFactory;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import org.apache.commons.lang3.StringUtils;

@SuppressWarnings("unused")
public class KafkaMessageTransformer {

    private final JsonMessageMarshaller messageMarshaller;

    private final AtomicLong seq = new AtomicLong(0);

    public KafkaMessageTransformer(JsonMessageMarshaller messageMarshaller) {
        this.messageMarshaller = messageMarshaller;
    }

    public <T> byte[] wrap(String groupId, T obj, String trackingId) {
        return this.wrap(groupId, obj, trackingId, 0, 0);
    }

    public <T> byte[] wrap(String groupId, T obj, String trackingId, int retry, long suspendTo) {
        String contentType = "application/json;" + obj.getClass().getName();

        MessageWrapper wrapper = MessageWrapper.wrap(messageMarshaller.marshallToJsonByteArray(obj),
                contentType, groupId)
                .withTrackingId(StringUtils.isNotBlank(trackingId) ? trackingId : UUID.randomUUID().toString());
        KafkaStruct struct = new KafkaStruct(wrapper, pid(), partition(), seqNo().toString(), retry, suspendTo);

        return struct.serialize();
    }

    public <T> T unwrap(byte[] data, Class<T> type) {
        if (KafkaStruct.isKafkaStruct(data)) {
            KafkaStruct kafkaStruct = KafkaStruct.deserialise(data);

            return messageMarshaller.unmarshal(kafkaStruct.getMessageWrapper().getContent(), type);
        }

        return null;
    }

    private String partition() {
        return Thread.currentThread().getName();
    }

    private String pid() {
        return ManagementFactory.getRuntimeMXBean().getName().split("@")[0];
    }

    private Long seqNo() {
        return seq.getAndIncrement();
    }
}

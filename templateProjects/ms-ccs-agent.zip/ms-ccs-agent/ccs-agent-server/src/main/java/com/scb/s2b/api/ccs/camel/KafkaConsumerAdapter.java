package com.scb.s2b.api.ccs.camel;

import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CALLBACK_ENDPOINT_HEADER;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.CCS_IMPORT_SUSPEND_TO_HEADER;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.ENTITY_TYPE_CCS_INBOUND_MSG;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.IMPORT_RETRY_HEADER;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.OUTBOUND_PAYLOAD_FORMAT_DUPL;
import static com.scb.s2b.api.ccs.config.CCSAgentConstant.OUTBOUND_PAYLOAD_FORMAT_REJ3;
import static org.apache.commons.lang3.StringUtils.EMPTY;

import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableMap;
import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessage;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import com.scb.s2b.api.ccs.route.RouteHandler;
import com.scb.s2b.api.ccs.service.CCSAgentService;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;

public class KafkaConsumerAdapter {

    private final CCSAgentService ccsAgentService;

    private final JsonMessageMarshaller jsonMessageMarshaller;

    private final ProducerTemplate producer;

    private final String importRetryEndpoint;

    private final int maxRetry;

    private final long retryInterval;

    private final String ocpDefaultCallback;
    private final String awsDefaultCallback;

    private final String ocpPrefix;
    private final String awsPrefix;

    private final RouteHandler routeHandler;

    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerAdapter.class);

    public KafkaConsumerAdapter(CCSAgentService ccsAgentService,
            JsonMessageMarshaller jsonMessageMarshaller, ProducerTemplate producer,
            String importRetryEndpoint, int maxRetry, long retryInterval,
            String ocpDefaultCallback, String awsDefaultCallback,
            String ocpPrefix, String awsPrefix,
            RouteHandler routeHandler) {
        this.ccsAgentService = ccsAgentService;
        this.jsonMessageMarshaller = jsonMessageMarshaller;
        this.producer = producer;
        this.importRetryEndpoint = importRetryEndpoint;
        this.maxRetry = maxRetry;
        this.retryInterval = retryInterval;
        this.ocpDefaultCallback = ocpDefaultCallback;
        this.awsDefaultCallback = awsDefaultCallback;
        this.ocpPrefix = ocpPrefix;
        this.awsPrefix = awsPrefix;
        this.routeHandler = routeHandler;
    }

    @SuppressWarnings("unused")
    public void consumeOcpImport(CCSAgentInboundIns ccsAgentInboundIns, Map<String, Object> headers) {
        this.consumeCCSAgentInstruction(ccsAgentInboundIns, headers, ocpPrefix, ocpDefaultCallback);
    }

    @SuppressWarnings("unused")
    public void consumeAwsImport(CCSAgentInboundIns ccsAgentInboundIns, Map<String, Object> headers) {
        this.consumeCCSAgentInstruction(ccsAgentInboundIns, headers, awsPrefix, awsDefaultCallback);
    }

    void consumeCCSAgentInstruction(CCSAgentInboundIns ccsAgentInboundIns, Map<String, Object> headers,
            String prefix, String defaultCallback) {
        String callback = this.getHeader(headers, CALLBACK_ENDPOINT_HEADER, String::valueOf, EMPTY);
        callback = StringUtils.isBlank(callback) ? defaultCallback : prefix + ":" + callback;

        logger.info("CCSAgentInstruction with filename={} payload={} received from {}",
                ccsAgentInboundIns.getFileName(),
                ccsAgentInboundIns.getPayload(),
                prefix);

        //Audit inbound message
        CCSAgentMessage ccsAgentMessage = CCSAgentMessage.builder()
                .messageId(Optional.ofNullable(ccsAgentInboundIns.getFileName()).orElse(
                        UUID.randomUUID().toString()))
                .entityType(ENTITY_TYPE_CCS_INBOUND_MSG)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(jsonMessageMarshaller.marshallToJsonString(ccsAgentInboundIns))
                .build();
        ccsAgentService.persistCCSAgentMessage(ccsAgentMessage);

        try {
            if (!ccsAgentService.isCCSAgentMsgRouteExisted(ccsAgentInboundIns.getFileName(),
                    ccsAgentInboundIns.getNoun())) {
                processCCSAgentImportedMessage(ccsAgentInboundIns, callback);
            } else {
                logger.warn("ccsAgentInboundIns with fileName={} is duplicated",
                        ccsAgentInboundIns.getFileName());
                ccsAgentService.publishExceptionTOCallback(ccsAgentInboundIns, callback, OUTBOUND_PAYLOAD_FORMAT_DUPL);
            }
        } catch (Throwable ex) {
            logger.error("Failed to send CCSAgentInboundIns with fileName={}, ex={}",
                    ccsAgentInboundIns.getFileName(), Throwables.getStackTraceAsString(ex));

            this.retryCCSAgentInstruction(ccsAgentInboundIns, callback, 1);
        }
    }

    public void consumeCCSAgentInstructionRetry(CCSAgentInboundIns ccsAgentInboundIns, Map<String, Object> headers) {
        int retry = this.getHeader(headers, IMPORT_RETRY_HEADER, Integer::parseInt, 0);
        String callback = this.getHeader(headers, CALLBACK_ENDPOINT_HEADER, String::valueOf, EMPTY);

        logger.info("Retry CCSAgentInboundIns with fileName={} the {} time", ccsAgentInboundIns.getFileName(), retry);
        try {
            processCCSAgentImportedMessage(ccsAgentInboundIns, callback);
        } catch (Throwable ex) {
            logger.error("Fail to retry CCSAgentInbound message with fileName={} the {} time, ex={}",
                    ccsAgentInboundIns.getFileName(), retry, Throwables.getStackTraceAsString(ex));
            if (retry >= maxRetry) {
                logger.warn("Retry failed after {} times, publishing rejection", maxRetry);

                if (StringUtils.isBlank(callback)) {
                    callback = routeHandler.getRoute(ccsAgentInboundIns.getNoun(), OUTBOUND_PAYLOAD_FORMAT_REJ3,
                            ccsAgentInboundIns.getGroupId(), ccsAgentInboundIns.getFileName());
                }
                ccsAgentService.publishExceptionTOCallback(ccsAgentInboundIns, callback, OUTBOUND_PAYLOAD_FORMAT_REJ3);
            } else {
                this.retryCCSAgentInstruction(ccsAgentInboundIns, callback, ++retry);
            }
        }
    }

    private void processCCSAgentImportedMessage(CCSAgentInboundIns ccsAgentInboundIns, String callBack) {
        CCSMailBoxInbound ccsMailBoxInbound;
        if (!ccsAgentService.isCCSAgentMsgRouteExisted(ccsAgentInboundIns.getFileName(),
                ccsAgentInboundIns.getNoun())) {
            ccsAgentService.persistCCSAgentMessageRoute(ccsAgentInboundIns, callBack);
        }
        if ((ccsMailBoxInbound = ccsAgentService.getCCSInboundMessage(ccsAgentInboundIns.getFileName())) == null) {
            ccsMailBoxInbound = ccsAgentService.persistCCSInboundMessage(ccsAgentInboundIns);
        }
        ccsAgentService.publishInboundMessage(ccsMailBoxInbound.getId());
    }

    public Long calculateDelay(Map<String, Object> headers) {
        try {
            long now = System.currentTimeMillis();
            long suspendTo = this.getHeader(headers, CCS_IMPORT_SUSPEND_TO_HEADER, Long::parseLong, now);

            return suspendTo > now ? suspendTo - now : 0;
        } catch (NumberFormatException ex) {
            return retryInterval;
        }
    }

    private void retryCCSAgentInstruction(CCSAgentInboundIns ccsAgentInboundIns, String callback, int retry) {
        Map<String, Object> headers = ImmutableMap
                .of(CALLBACK_ENDPOINT_HEADER, callback,
                        IMPORT_RETRY_HEADER, String.valueOf(retry),
                        CCS_IMPORT_SUSPEND_TO_HEADER, String.valueOf(System.currentTimeMillis() + retryInterval));
        byte[] bytes = jsonMessageMarshaller.marshallToJsonByteArray(ccsAgentInboundIns);
        producer.sendBodyAndHeaders(importRetryEndpoint, bytes, headers);
    }

    <T> T getHeader(Map<String, Object> headers, String header, Function<String, T> parser, T defaultVal) {
        T value = defaultVal;
        String headerVal;
        Object content = headers.get(header);
        if (content instanceof byte[]) {
            headerVal= new String((byte[]) headers.get(header), StandardCharsets.UTF_8);
        } else if (content != null) {
            headerVal = content.toString();
        } else {
            headerVal = String.valueOf(defaultVal);
        }

        try {
            value = parser.apply(headerVal);
        } catch (Exception exception) {
            // Ignore exception
        }

        return value;
    }
}

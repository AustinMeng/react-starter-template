package com.scb.s2b.api.ccs.parser;

import com.scb.s2b.api.ccs.entity.PayloadEntity;

public interface MessageParser {
    PayloadEntity parse(String payload);
}

package com.scb.s2b.api.ccs.marshaller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

@SuppressWarnings("unused")
public class XmlMessageMarshaller {
    private final XmlMapper xmlMapper;

    public XmlMessageMarshaller() {
        this.xmlMapper = new XmlMapper();
        this.xmlMapper.registerModule(new JaxbAnnotationModule());
        this.xmlMapper.configure(ToXmlGenerator.Feature.WRITE_XML_DECLARATION, true);
    }

    public <T> String marshallToString(T instance) {
        try {
            return xmlMapper.writeValueAsString(instance);
        } catch (JsonProcessingException ex) {
            throw new RuntimeException(ex);
        }
    }

    public <T> byte[] marshallToByteArray(T instance) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            xmlMapper.writeValue(outputStream, instance);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }

        return outputStream.toByteArray();
    }

    public <T> T unmarshal(String json, Class<T> type) {
        try {
            return xmlMapper.readValue(json, type);
        } catch (JsonProcessingException ex) {
            throw new RuntimeException(ex);
        }
    }

    public <T> T unmarshal(byte[] data, Class<T> type) {
        try {
            return xmlMapper.readValue(data, type);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}

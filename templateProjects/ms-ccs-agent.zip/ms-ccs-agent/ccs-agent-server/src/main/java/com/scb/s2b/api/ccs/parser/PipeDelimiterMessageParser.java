package com.scb.s2b.api.ccs.parser;


import com.scb.s2b.api.ccs.entity.PayloadEntity;
import java.util.StringTokenizer;
import org.apache.commons.lang3.StringUtils;

public class PipeDelimiterMessageParser implements MessageParser {

    private final static String OUTBOUND_MESSAGE_DELIMITER = "|";

    @Override
    public PayloadEntity parse(String payload) {
        if (StringUtils.isEmpty(payload)) {
            throw new IllegalArgumentException("Payload message is empty.");
        }
        StringTokenizer tokenizer = new StringTokenizer(payload, OUTBOUND_MESSAGE_DELIMITER, true);

        // noun, dateTime and fileName is mandatory.
        if (StringUtils.endsWith(payload, OUTBOUND_MESSAGE_DELIMITER) || tokenizer.countTokens() < 3) {
            throw new IllegalArgumentException("Invalid payload message.");
        }

        String type = nextValue(tokenizer);
        String dateTime = nextValue(tokenizer);
        String fileName = nextValue(tokenizer);

        String umi = nextValue(tokenizer);
        String batchNumber = nextValue(tokenizer);
        String channelIndicator = nextValue(tokenizer);
        String statusCode = nextValue(tokenizer);
        String statusRemark = nextValue(tokenizer);
        String product = nextValue(tokenizer);

        return PayloadEntity.builder()
                .type(type)
                .dateTime(dateTime)
                .fileName(fileName)
                .umi(umi)
                .batchNumber(batchNumber)
                .channelIndicator(channelIndicator)
                .statusCode(statusCode)
                .statusRemarks(statusRemark)
                .product(product)
                .build();
    }

    private String nextValue(StringTokenizer tokenizer) {
        String ret = null;
        if (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken();
            if (!OUTBOUND_MESSAGE_DELIMITER.equals(token)) {
                ret = token;
                if (tokenizer.hasMoreTokens()) {
                    tokenizer.nextToken();
                }
            }

        }

        return ret;
    }
}

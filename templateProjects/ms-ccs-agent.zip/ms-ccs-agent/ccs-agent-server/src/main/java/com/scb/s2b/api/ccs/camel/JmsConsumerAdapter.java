package com.scb.s2b.api.ccs.camel;

import com.scb.s2b.api.ccs.entity.RequestMessage;
import com.scb.s2b.api.ccs.marshaller.XmlMessageMarshaller;
import com.scb.s2b.api.ccs.service.CCSAgentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JmsConsumerAdapter {


    private static final Logger logger = LoggerFactory.getLogger(JmsConsumerAdapter.class);

    private final CCSAgentService ccsAgentService;

    private final XmlMessageMarshaller xmlMessageMarshaller;

    public JmsConsumerAdapter(CCSAgentService ccsAgentService,
            XmlMessageMarshaller xmlMessageMarshaller) {
        this.ccsAgentService = ccsAgentService;
        this.xmlMessageMarshaller = xmlMessageMarshaller;
    }

    public void consumeCCSOutbound(String message) {
        logger.info("Received ccs outbound message:\n{}", message);
        // extract id from request message
        RequestMessage requestMessage = xmlMessageMarshaller.unmarshal(message, RequestMessage.class);
        ccsAgentService.processCCSOutboundMessage(requestMessage.getReferenceKey().getKeyValue().getId());
    }
}

package com.scb.s2b.api.ccs.config.property;

import java.util.Map;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class KafkaProperties {
    private String brokers;
    private Map<String, String> endpoints;
    private KafkaSecurityProperties securityInfo;
    private String prefix;
}

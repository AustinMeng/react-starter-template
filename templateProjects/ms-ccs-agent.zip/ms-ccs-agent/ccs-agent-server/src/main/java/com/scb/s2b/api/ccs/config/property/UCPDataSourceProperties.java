package com.scb.s2b.api.ccs.config.property;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class UCPDataSourceProperties {

    private String username;
    private String password;
    private String jdbcUrl;
    private String driverClassName;
    private Boolean fastConnectionFailoverEnabled;
    private Integer initialPoolSize;
    private Integer minPoolSize;
    private Integer maxPoolSize;
}

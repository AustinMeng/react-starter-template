package com.scb.s2b.api.ccs.repository.mailbox;

import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import java.math.BigInteger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CCSMailBoxInboundRepository extends JpaRepository<CCSMailBoxInbound, BigInteger> {

    CCSMailBoxInbound findCCSMailBoxInboundByFileName(String fileName);
}

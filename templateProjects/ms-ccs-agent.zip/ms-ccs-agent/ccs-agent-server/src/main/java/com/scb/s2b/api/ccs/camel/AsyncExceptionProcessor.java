package com.scb.s2b.api.ccs.camel;

import java.io.IOException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.NoTypeConversionAvailableException;
import org.apache.camel.Processor;

@Slf4j
public class AsyncExceptionProcessor implements Processor {

    public static final String KAFKA_OFFSET = "kafka.OFFSET";
    public static final String KAFKA_PARTITION = "kafka.PARTITION";

    @Override
    public void process(Exchange exchange) {
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);

        Optional.ofNullable(exchange.getIn().getHeader(KAFKA_OFFSET))
                .ifPresent(offset -> log.error("offset Is failed to process offset: {}", offset));
        Optional.ofNullable(exchange.getIn().getHeader(KAFKA_PARTITION))
                .ifPresent(partition -> log.error("On partition: {}", partition));
        log.error("## Asynchronous Kakfka is failed to process ##");

        if (exception instanceof IOException) {
            log.error("IO exception occurred while processing {}", exception.getMessage());
        } else if (exception instanceof NoTypeConversionAvailableException) {
            log.error("Unable to decrypt the body Type -> {} :: message -> {}",
                    exchange.getIn().getBody(), exception.getMessage());
        }
        log.error("Exception stack trace", exception);
    }
}

package com.scb.s2b.api.ccs.service;

import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessage;
import com.scb.s2b.api.ccs.model.mailbox.CCSMailBoxInbound;
import java.math.BigInteger;

public interface CCSAgentService {

    CCSMailBoxInbound persistCCSInboundMessage(CCSAgentInboundIns ccsAgentInboundIns);

    CCSMailBoxInbound getCCSInboundMessage(String fileName);

    void publishInboundMessage(BigInteger id);

    /**
     * process outbound message
     *
     * @param id message id
     */
    void processCCSOutboundMessage(BigInteger id);

    void persistCCSAgentMessageRoute(CCSAgentInboundIns ccsAgentInboundIns, String callback);

    boolean isCCSAgentMsgRouteExisted(String fileName, String noun);

    void publishExceptionTOCallback(CCSAgentInboundIns ccsAgentInboundIns, String callback, String format);

    void persistCCSAgentMessage(CCSAgentMessage ccsAgentMessage);
}

package com.scb.s2b.api.ccs.route;

import com.google.common.base.Strings;
import com.scb.s2b.api.ccs.model.agent.CCSAgentMessageRoute;
import com.scb.s2b.api.ccs.repository.agent.CCSAgentMessageRouteRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class HeaderRouteHandler extends RouteHandler {

    private final CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository;

    private RouteHandler next;

    public HeaderRouteHandler(CCSAgentMessageRouteRepository ccsAgentMessageRouteRepository) {
        this.ccsAgentMessageRouteRepository = ccsAgentMessageRouteRepository;
    }

    @Override
    public void setNext(RouteHandler next) {
        this.next = next;
    }

    @Override
    protected RouteHandler getNext() {
        return next;
    }

    @Override
    protected String getEndpointInt(String noun, String format, String groupId, String filename) {
        String endpoint = null;

        if(StringUtils.isNotBlank(filename)) {
            CCSAgentMessageRoute ccsAgentMessageRoute = ccsAgentMessageRouteRepository.findByFileName(filename);
            if (ccsAgentMessageRoute != null && StringUtils.isNotBlank(ccsAgentMessageRoute.getCallback())) {
                endpoint = ccsAgentMessageRoute.getCallback();
            }
        }

        if (StringUtils.isNotBlank(endpoint)) {
            log.info("Generating endpoint from header for filename={}", filename);
        }

        return Strings.emptyToNull(endpoint);
    }
}

create SCHEMA IF NOT EXISTS CC_API_CCS_AGENT;

create TABLE IF NOT EXISTS CC_API_CCS_AGENT.ccs_agent_message_route (
    id                 bigint          NOT NULL    auto_increment,
    callback           VARCHAR(255)    NOT NULL,
    filename           VARCHAR(255)    NOT NULL,
    noun               VARCHAR(255)    NOT NULL,
    createddate        TIMESTAMP (6)   DEFAULT sysdate       NOT NULL,
    PRIMARY KEY(id)
);
create UNIQUE INDEX IF NOT EXISTS uniq_ccs_amr_index1 ON CC_API_CCS_AGENT.ccs_agent_message_route(filename);

create table if not exists CC_API_CCS_AGENT.ccs_agent_message (
    id                        bigint          NOT NULL    auto_increment,
    message_id                varchar(60)     NOT NULL,
    entity_type               varchar(20)     NOT NULL,
    content_type              varchar(20)     NOT NULL,
    content                   clob            NOT NULL,
    timestamp                 timestamp       NOT NULL,
    PRIMARY KEY(id)
);
CREATE INDEX cam_index1 ON CC_API_CCS_AGENT.ccs_agent_message (message_id);

create table if not exists CC_API_CCS_AGENT.meta_descriptor(
    id                        varchar(60)        NOT NULL,
    group_id                  varchar(10)        NOT NULL,
    name                      varchar(80)        NOT NULL,
    version                   int                NOT NULL,
    change_reference          varchar(20),
    comments                  varchar(255),
    frozen_values             clob               NOT NULL,
    previous_version_id       varchar(60),
    timestamp                 timestamp          NOT NULL,
    PRIMARY KEY(id),
    UNIQUE(group_id, name, version)
);
INSERT INTO CC_API_CCS_AGENT.meta_descriptor(group_id, name, version, change_reference, comments, frozen_values, id, previous_version_id, timestamp)
 select 'SYSTEM','scb.internal.routing.ccsAgentProperties',1,null,'CCS Agent routing properties','{"routingProperties":{"nouns":{"REPORTSCUST":{"formats":{"CSV-BANSTA":{"groups":{"UAASTST1":"anole:ocpkaf:CSV-BANSTA_UAASTST1"},"countries":{"SG":{"endPoint":"anole:awskaf:CSV-BANSTA","exclusionGroups":["TEST003"]},"PH":{"endPoint":"anole:ocpkaf:CSV-BANSTA"}}},"BANSTAMT199":{"groups":{"UAASTST1":"anole:ocpkaf:BANSTAMT199_UAASTST1"},"countries":{"SG":{"endPoint":"anole:awskaf:BANSTAMT199","exclusionGroups":["UAASTST1"]},"PH":{"endPoint":"anole:ocpkaf:BANSTAMT199"}}}}}}}}','38fa38bd-b699-4fe7-9113-960f614ef44e',null,current_timestamp
 from dual where not exists (select * from CC_API_CCS_AGENT.meta_descriptor where group_id = 'SYSTEM' and name = 'scb.internal.routing.ccsAgentProperties' and version = 1);


CREATE SCHEMA IF NOT EXISTS CC_CCS_S2BCCSQ;

CREATE TABLE if not exists CC_CCS_S2BCCSQ.CCS_API_MAILBOX_INBOUND (
	ID            NUMBER(12,0)                        NOT NULL,
    GRPID         VARCHAR(70)                         NOT NULL,
    SOURCE        VARCHAR(16)                         NOT NULL,
    NOUN          VARCHAR(16)                         NOT NULL,
    FORMAT        VARCHAR(20)                         NOT NULL,
    FILENAME      VARCHAR(255)                        NOT NULL,
    FILE_SIZE     NUMBER(10,0)                        NOT NULL,
    PAYLOAD       BLOB                                NOT NULL,
    STATUS        NUMBER(4,0)                         NOT NULL,
    UMI           VARCHAR(25)                                 ,
    CREATEDBY     VARCHAR(25) DEFAULT 'API'           NOT NULL,
    CREATEDDATE   TIMESTAMP (6) DEFAULT sysdate       NOT NULL,
    MODIFIEDBY    VARCHAR(25)                                 ,
    MODIFIEDDATE  TIMESTAMP (6) DEFAULT sysdate       NOT NULL
);

CREATE TABLE if not exists  CC_CCS_S2BCCSQ.CCS_API_MAILBOX_OUTBOUND (
   	ID            NUMBER(12,0)                        NOT NULL,
	UMI           VARCHAR(25)                         NOT NULL,
	GRPID         VARCHAR(70)                         NOT NULL,
	SOURCE        VARCHAR(16)                         NOT NULL,
	NOUN          VARCHAR(16)                         NOT NULL,
	FORMAT        VARCHAR(20)                         NOT NULL,
	FILENAME      VARCHAR(255)                        NOT NULL,
	FILE_SIZE     NUMBER(10,0)                        NOT NULL,
	PAYLOAD       BLOB                                NOT NULL,
	STATUS        NUMBER(4,0)                         NOT NULL,
	CREATEDBY     VARCHAR(25) DEFAULT 'CCS'           NOT NULL,
	CREATEDDATE   TIMESTAMP (6) DEFAULT sysdate       NOT NULL,
	MODIFIEDBY    VARCHAR(25)                                 ,
	MODIFIEDDATE  TIMESTAMP (6) DEFAULT sysdate       NOT NULL
);


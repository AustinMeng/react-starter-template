package com.scb.api.ccs.test.stub;

import com.google.common.collect.Maps;
import com.scb.api.ccs.test.wiremock.FileBasedWireMock;
import java.net.UnknownHostException;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(staticName = "of")
@Slf4j
public class CadmStub {

    private static final String DEFAULT_STUB_DATA_FILE = "cadm.stub";

    private String stubDataFile;

    public int start() throws UnknownHostException {
        if (StringUtils.isBlank(stubDataFile)) {
            stubDataFile = DEFAULT_STUB_DATA_FILE;
        }
        return start(null);
    }

    public int start(Integer forcePort) throws UnknownHostException {
        return FileBasedWireMock.init(this.getClass().getClassLoader().getResourceAsStream(stubDataFile),
                forcePort,
                defaultProperties()
        ).getHttpsPort();
    }

    private Map<String, String> defaultProperties() {
        Map<String, String> properties = Maps.newHashMap();
        properties.put("host", "localhost");
        return properties;
    }
}

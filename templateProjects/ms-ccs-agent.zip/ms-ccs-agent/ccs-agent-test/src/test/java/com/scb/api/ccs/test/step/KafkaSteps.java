package com.scb.api.ccs.test.step;

import static org.awaitility.Awaitility.await;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.foundation.commons.camel.anole.AnoleEndpoint;
import com.scb.s2b.api.ccs.entity.CCSAgentInboundIns;
import com.scb.s2b.api.ccs.marshaller.JsonMessageMarshaller;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;

@SuppressWarnings("unused")
public class KafkaSteps {

    @Autowired
    private CamelContext camelContext;

    @Autowired
    private StepUtils stepUtils;

    @Autowired
    private JsonMessageMarshaller jsonMessageMarshaller;

    @Autowired
    private ProducerTemplate producer;

    private final Map<String, AnoleEndpoint> endpoints = new HashMap<>();

//    private static final String PREFIX = "anole:kafka:";

    @Given("kafka topic {word} is emptied")
    public void clearTopic(String topic) {
        AnoleEndpoint anoleEndpoint = this.getEndpoint(topic);
        anoleEndpoint.purgeQueue();
    }

    @Then("kafka topic {word} receives {int} message(s) in {int} second(s)")
    public void verifyTopic(String topic, int num, int seconds) {
        AnoleEndpoint anoleEndpoint = this.getEndpoint(topic);

        await().atMost(seconds, TimeUnit.SECONDS)
                .until(() -> anoleEndpoint.getIncrementalMessages().size() == num);
        anoleEndpoint.takeSnapshot();
    }

    @When("a message {word} is received from kafka topic {word}")
    public void receiveKafkaMessage(String file, String topic) throws JsonProcessingException {
        String json = stepUtils.loadContent(file);
        CCSAgentInboundIns ccsAgentInboundIns = new ObjectMapper().readValue(json, CCSAgentInboundIns.class);
        byte[] message = jsonMessageMarshaller.marshallToJsonByteArray(ccsAgentInboundIns);
        producer.sendBody(topic, message);
    }

    @When("a message {word} is received from kafka topic {word} with header")
    public void receiveKafkaMessageWithHeader(String file, String topic, DataTable dataTable)
            throws JsonProcessingException {
        List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);
        Map<String, Object> headers = new HashMap<>();
        details.get(0).forEach(headers::put);
        String json = stepUtils.loadContent(file);
        CCSAgentInboundIns ccsAgentInboundIns = new ObjectMapper().readValue(json, CCSAgentInboundIns.class);
        byte[] message = jsonMessageMarshaller.marshallToJsonByteArray(ccsAgentInboundIns);
        producer.sendBodyAndHeaders(topic, message, headers);
    }

    private AnoleEndpoint getEndpoint(String topic) {
        return endpoints
                .computeIfAbsent(topic, t -> camelContext.getEndpoint(t, AnoleEndpoint.class));
    }

}

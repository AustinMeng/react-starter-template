package com.scb.api.ccs.test.step;

import static org.junit.Assert.assertEquals;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;

@SuppressWarnings("unused")
public class StepUtils {

    private String refId = "";

    private static final String JSON_PATH = "jsonPath";
    private static final String XML_PATH = "xmlPath";
    private static final String VALUE = "value";

    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yy");
    private final DocumentBuilder builder;

    public StepUtils() {
        try {
            DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
            builder = domFactory.newDocumentBuilder();
            domFactory.setNamespaceAware(true);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public String loadContent(String resourcePath) {
        try (InputStream input = StepUtils.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if(input != null) {
                return IOUtils.toString(input, StandardCharsets.UTF_8);
            } else {
                throw new RuntimeException("Failed to load content from " + resourcePath);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void verifyJsonDetails(String json, List<Map<String, String>> details) {
        DocumentContext docContext = JsonPath
                .parse(json, Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS));
        details.forEach(d -> assertEquals(d.get(VALUE), docContext.read(d.get(JSON_PATH))));
    }

    public void verifyXmlDetails(String xml, List<Map<String, String>> details) {
        try {
            Document document = builder.parse(new ByteArrayInputStream(xml.getBytes()));
            details.forEach(d -> {
                        String xmlPath = d.get(XML_PATH);
                        String dataValue = d.get(VALUE);
                        dataValue = "KeyValue".equals(xmlPath) ? dataValue
                                .replace("${YY}", LocalDate.now().format(dateTimeFormatter)) : dataValue;
                        assertEquals(dataValue, evaluate(document, xmlPath));
                    }
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public String replaceWithDefault(String payload, Map<String, String> vals, Map<String, String> defVals) {
        Map<String, String> dataModel = new HashMap<>(vals);
        defVals.forEach((key, value) -> dataModel.merge(key, value, (v1, v2) -> v1));
        String emptyStr = "";
        for (String k : dataModel.keySet()) {
            String v = dataModel.get(k);
            if (StringUtils.equalsIgnoreCase(v, "generated()")) {
                refId = String.valueOf(System.currentTimeMillis());
                payload = StringUtils.replaceIgnoreCase(payload, "${" + k + "}", refId);
            } else if (StringUtils.equalsIgnoreCase(v, "empty()")) {
                payload = StringUtils.replaceIgnoreCase(payload, "${" + k + "}", emptyStr);
            } else {
                payload = StringUtils.replaceIgnoreCase(payload, "${" + k + "}", v);
            }
        }

        return payload;
    }

    public String getRefId() {
        return refId;
    }

    public String evaluate(Document document, String xPathStr) {
        return document.getElementsByTagName(xPathStr).item(0).getTextContent().trim();
    }

}

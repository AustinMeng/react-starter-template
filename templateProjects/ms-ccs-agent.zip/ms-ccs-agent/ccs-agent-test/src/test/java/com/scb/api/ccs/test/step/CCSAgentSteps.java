package com.scb.api.ccs.test.step;

import com.scb.api.ccs.test.config.TestConfig;
import com.scb.s2b.api.ccs.CCSAgentApiApp;
import io.cucumber.java.en.When;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@SuppressWarnings("unused")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(
        webEnvironment = RANDOM_PORT,
        properties = {
                "server.port=RANDOM_PORT"
        }
)
@ContextConfiguration(classes = {
        TestConfig.class,
        CCSAgentApiApp.class
})
@ActiveProfiles("test")
public class CCSAgentSteps {
        @LocalServerPort
        private Integer port;

        @Autowired
        private StepUtils stepUtils;

        @When("after {int} millisecond(s)")
        public void wait(int millis) {
                try {
                        Thread.sleep(millis);
                } catch (InterruptedException ex) {
                        throw new RuntimeException(ex);
                }
        }
}

create table ccs_agent.ccs_agent_message (
    id                        bigserial   NOT NULL,
    message_id                text        NOT NULL,
    entity_type               text        NOT NULL,
    content_type              text        NOT NULL,
    content                   text        NOT NULL,
    timestamp                 timestamp   NOT NULL,
    PRIMARY KEY(id)
);

CREATE INDEX cam_index1 ON ccs_agent.ccs_agent_message (message_id);
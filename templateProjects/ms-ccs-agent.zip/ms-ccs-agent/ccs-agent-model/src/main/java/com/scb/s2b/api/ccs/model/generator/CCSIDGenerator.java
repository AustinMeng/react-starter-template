package com.scb.s2b.api.ccs.model.generator;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.enhanced.SequenceStyleGenerator;

@SuppressWarnings("unused")
public class CCSIDGenerator extends SequenceStyleGenerator {

    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yy");

    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object obj)
            throws HibernateException {
        String id = String.valueOf(super.generate(session, obj));
        StringUtils.leftPad(id, 10, '0');
        return BigInteger
                .valueOf(Long.parseLong(LocalDate.now().format(dateTimeFormatter)
                        + StringUtils.leftPad(id, 10, '0')));
    }
}

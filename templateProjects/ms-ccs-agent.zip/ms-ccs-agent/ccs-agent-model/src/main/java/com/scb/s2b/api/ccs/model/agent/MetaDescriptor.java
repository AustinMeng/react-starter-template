package com.scb.s2b.api.ccs.model.agent;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(
        name = "meta_descriptor", schema = "CC_API_CCS_AGENT",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"group_id", "name", "version"})
        })
@GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
public class MetaDescriptor {
    @Id
    @GeneratedValue(generator = "uuid2")
    @Getter
    private String id;

    @Column(name = "group_id", nullable = false)
    @Getter
    private String groupId;

    @Column(name = "name", nullable = false)
    @Getter
    private String name;

    @Column(name = "version", nullable = false)
    @Getter
    private int version;

    @Column(name = "change_reference")
    @Getter
    private String changeReference;

    @Column(name = "comments")
    @Getter
    private String comments;

    @Column(name = "frozen_values", nullable = false)
    private String metaValues;

    @Column(name = "previous_version_id")
    @Getter
    private String preVersionId;

    @Column(name = "timestamp", nullable = false)
    @Getter
    private Instant timestamp;

    @Transient
    private Map<String, Map<String, Object>> values;

    @SuppressWarnings("unchecked")
    public Map<String, Map<String, Object>> getValues() {
        if (values == null && metaValues.length() > 0) {
            try {
                values = objectMapper().readValue(metaValues, Map.class);
            } catch (IOException e) {
                throw new RuntimeException(e.getMessage(), e);
            }
        }
        return values;
    }

    public Map<String, Object> lookup(String key) {
        return values.get(key);
    }

    public <T> T lookup(String key, Class<T> type) {
        return objectMapper().convertValue(getValues().get(key), type);
    }

    private ObjectMapper objectMapper() {
        return new ObjectMapper();
    }
}

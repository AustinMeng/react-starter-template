package com.scb.s2b.api.ccs.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CCSAgentOutboundIns {
    private String umi;
    private String source;
    private String noun;
    private String format;
    private String groupId;
    private String raw;
    private String filename;
    private PayloadEntity payload;
}
